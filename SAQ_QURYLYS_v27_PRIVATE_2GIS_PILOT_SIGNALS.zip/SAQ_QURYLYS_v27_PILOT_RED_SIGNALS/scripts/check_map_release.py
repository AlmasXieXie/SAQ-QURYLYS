"""Map acceptance test against the **actual** local application database.

Usage from project root:
    python scripts/check_map_release.py
    python scripts/check_map_release.py --require-all-geolocated

A test may pass UI checks with synthetic fixtures while failing real geographic
coverage. This script explicitly distinguishes those two facts.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from fastapi.testclient import TestClient
from app.main import app


def main():
    parser = argparse.ArgumentParser(description='SAQ QURYLYS map release acceptance')
    parser.add_argument('--require-all-geolocated', action='store_true')
    args = parser.parse_args()
    with TestClient(app) as client:
        page = client.get('/').text
        assert client.get('/').status_code == 200
        assert 'city-map' in page and 'unlocated-panel' in page and 'data-view="developers"' in page
        s = client.get('/api/signal-map/snapshot')
        assert s.status_code == 200, s.text
        data = s.json()
        assert data['total'] == 40, f'Expected 40 named objects, got {data["total"]}'
        assert data['mapped'] + data['without_coordinates'] == data['total']
        assert sum(data['counts'].values()) == 40
        assert all(p['map_color'] in ('red', 'yellow', 'green', 'gray') for p in data['items'])
        assert all(p['color_reason'] for p in data['items'])
        dev = client.get('/api/v8/developers').json()
        bins = [d for d in dev if d.get('bin') and d.get('bin_source')]
        print(f'Catalog: {data["total"]}/40 real ЖК')
        print(f'Geographically located: {data["mapped"]}/40')
        print(f'Unlocated (CLICKABLE but NOT plotted geographically): {data["without_coordinates"]}')
        print(f'Developer labels with sourced BIN: {len(bins)}/{len(dev)}')
        print(f'Signal colors: {data["counts"]}')
        print(f'UI core elements and all 40 data cards: PASS')
        if data['without_coordinates']:
            missing=', '.join(x['name'] for x in data['items'] if not x['has_coordinates'])
            print('MISSING GEO:', missing)
        if args.require_all_geolocated and data['mapped'] != 40:
            print('FAIL: cannot certify 40 correctly located real ЖК. No fake coordinates inserted.')
            raise SystemExit(2)
        print('PASS: map UI/data smoke test. Real geo completeness:', 'FULL' if data['mapped']==40 else 'INCOMPLETE')

if __name__=='__main__':
    main()
