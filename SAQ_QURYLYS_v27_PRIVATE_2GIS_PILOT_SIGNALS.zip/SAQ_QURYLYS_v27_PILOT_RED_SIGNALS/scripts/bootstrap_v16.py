"""Local-only upgrade: copy a stopped previous SQLite DB (with evidence, coordinates).

Does not mutate the original. Docker uses the existing named volume instead.
No secret is ever embedded in the packaged archive.
"""
from __future__ import annotations
from pathlib import Path
import os
import sqlite3
import re

PROJECT = Path(__file__).resolve().parent.parent
NEEDED = {'unified_buildings','registry_ad_monitoring'}


def sibling_dirs(root:Path):
    for version in (25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8):
        yield from sorted(root.parent.glob(f'SAQ_QURYLYS_v{version}*'),reverse=True)


def copy_previous_database(root:Path=PROJECT):
    if os.getenv('SAQ_DATABASE_URL'):
        return {'status':'custom_database_skip'}
    dest=root/'saq.sqlite3'
    if dest.exists():return {'status':'already_exists'}
    for folder in sibling_dirs(root):
        for src in (folder/'saq.sqlite3', folder/'project'/'saq.sqlite3'):
            if not src.is_file() or src.resolve()==dest.resolve():continue
            if src.stat().st_size>150_000_000:continue
            try:
                with sqlite3.connect(f'file:{src.as_posix()}?mode=ro',uri=True,timeout=4) as old:
                    tables={x[0] for x in old.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                    if not NEEDED.issubset(tables):continue
                    with sqlite3.connect(dest) as new:
                        old.backup(new)
                        if new.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                            raise RuntimeError('Corrupt source database')
                return {'status':'copied','source_version':folder.name,'path':str(src)}
            except (sqlite3.Error,OSError,RuntimeError):
                try:dest.unlink(missing_ok=True)
                except OSError:pass
                continue
    return {'status':'no_previous_db'}


def migrate_local_key(root:Path=PROJECT):
    """Optional local 2GIS public MapGL key handoff. The .env file stays ignored by Git/Docker image."""
    dest=root/'.env'
    if dest.exists():return 'already_configured'
    for folder in sibling_dirs(root):
        source=next((x for x in (folder/'.env',folder/'project'/'.env') if x.is_file()),folder/'.env')
        if not source.is_file():continue
        try:
            content=source.read_text(encoding='utf-8')
            match=re.search(r'^SAQ_2GIS_KEY\s*=\s*([^\r\n#]+)',content,re.M)
            if match and match.group(1).strip():
                dest.write_text('SAQ_2GIS_KEY='+match.group(1).strip()+'\n',encoding='utf-8')
                return 'local_configuration_copied'
        except (UnicodeError,OSError):continue
    return 'no_previous_key'


if __name__=='__main__':
    r=copy_previous_database()
    k=migrate_local_key()
    print('Local database:',r['status'],r.get('source_version',''))
    print('Local map configuration:',k)
