# Local-only optional MapGL config transfer; no key is printed or stored in source control.
$project = Split-Path -Parent $PSScriptRoot
$dest = Join-Path $project '.env'
if (Test-Path -LiteralPath $dest) { exit 0 }
$parent = Split-Path -Parent $project
$dirs = Get-ChildItem -LiteralPath $parent -Directory -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -match '^SAQ_QURYLYS_v(21|20|19|18|17|16|15|14|13|12|11|10|9)_' } |
    Sort-Object Name -Descending
foreach ($folder in $dirs) {
    $old = Join-Path $folder.FullName '.env'
    if (-not (Test-Path -LiteralPath $old)) { continue }
    try {
        $matched = Get-Content -LiteralPath $old -ErrorAction Stop |
            Where-Object { $_ -match '^SAQ_2GIS_KEY\s*=\s*[^#\s]+' } |
            Select-Object -First 1
        if ($matched) {
            [System.IO.File]::WriteAllText($dest, $matched.Trim() + "`n", [System.Text.Encoding]::ASCII)
            break
        }
    } catch { continue }
}
