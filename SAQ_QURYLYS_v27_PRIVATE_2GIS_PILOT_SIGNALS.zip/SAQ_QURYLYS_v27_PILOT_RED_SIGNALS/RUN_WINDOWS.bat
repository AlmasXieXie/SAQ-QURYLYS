@echo off
chcp 65001 >nul
cd /d "%~dp0"
title SAQ QURYLYS launcher
echo.
echo SAQ QURYLYS v27 - 2026+ ad matching and scoped UGA/VKO registry, 2GIS
echo ------------------------------------------
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "scripts\bootstrap_env.ps1" >nul 2>nul
REM Old v16 container may still own port 8000; NEVER open a stale application.
powershell.exe -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing 'http://localhost:8000/api/health' -TimeoutSec 2; Write-Host 'Port 8000 is occupied by an existing server. Close the previous SAQ QURYLYS (docker compose down) before launching v27.';exit 17 } catch { if ($_.Exception.Response) { Write-Host 'Port 8000 is responding unexpectedly. Close the old service.'; exit 17 }; exit 0 }"
if errorlevel 1 goto already_running
where docker >nul 2>nul
if NOT %ERRORLEVEL% EQU 0 goto python_fallback
echo Docker found. Building application (first launch can take several minutes)...
docker compose up -d --build
if errorlevel 1 goto python_fallback
goto open_site
:python_fallback
echo Trying local Python launcher...
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (set "PYTHON=py") else (set "PYTHON=python")
%PYTHON% --version >nul 2>nul
if NOT %ERRORLEVEL% EQU 0 (
 echo Please install Docker Desktop or Python 3.12+ first.
 pause
 exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
 echo Creating isolated Python environment...
 %PYTHON% -m venv .venv
 if errorlevel 1 goto fail
)
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto fail
.venv\Scripts\python.exe scripts\bootstrap_v16.py
start "" powershell.exe -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 4; Start-Process 'http://localhost:8000/'"
echo The browser will open automatically. Close this window to stop the Python server.
.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000
goto end
:open_site
powershell.exe -NoProfile -Command "$ready=$false;for ($i=0; $i -lt 30; $i++){try{$v=(Invoke-RestMethod -Uri 'http://localhost:8000/api/health' -TimeoutSec 2).version;if($v -eq '27.0.0'){$ready=$true;break};Write-Host ('WRONG VERSION: '+$v);exit 17}catch{Start-Sleep -Seconds 1}};if(-not $ready){exit 18}"
if errorlevel 1 goto fail
start "" "http://localhost:8000/"
echo Application ready at http://localhost:8000/
echo For Docker use docker compose down to stop the server.
goto end
:already_running
echo Stop the previous application first. An older app on port 8000 causes a blank/stale map.
echo In the previous version's folder run: docker compose down
pause
exit /b 1
:fail
echo Error starting SAQ QURYLYS. Check network or Python/Docker installation.
pause
:end
