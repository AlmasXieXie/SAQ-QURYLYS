# v8 — происхождение данных и ограничения

Срез данных: 2026-10-17, Усть-Каменогорск. Каждую запись следует перепроверять перед выводом о действующем разрешении или ходе строительства.

## ЖК

- Поиск по разделу строящихся ЖК Krisha.kz: https://krisha.kz/complex/search/ust-kamenogorsk/?state%5B%5D=1
- Карта ЖК от источника (отдельно от нашей): https://krisha.kz/complex/search/map/ust-kamenogorsk/
- Машиночитаемый срез: `data/verified_38_construction_catalog_2026-10-17.csv` (38 именованных карточек, адреса и прямые ссылки).
- Примеры источников со сведениями о девелопере: https://krisha.kz/complex/show/ust-kamenogorsk/vivalife/ ; https://krisha.kz/complex/show/ust-kamenogorsk/easton/ ; https://krisha.kz/complex/show/ust-kamenogorsk/orda/ ; https://krisha.kz/complex/show/ust-kamenogorsk/greenleaf/ ; https://krisha.kz/complex/show/ust-kamenogorsk/muztau/ ; https://krisha.kz/complex/show/ust-kamenogorsk/birinshiui/

## Страницы девелоперов

- AN Groups: https://angroups.kz/ ; https://www.instagram.com/an.groups/
- Tumar Group: https://tumar-group.kz/ ; https://www.instagram.com/tumar.oskemen/
- Biryuza: https://biryuza.kz/
- BS Holding (Easton): https://bs-holding.kz/?page_id=35
- ЖБК, объекты Коктем/Крылова: https://www.zhbk.kz/ ; https://koktem-uk.kz/

Иные названия из каталога не автоматически считаются проверенными юридическими лицами. В БД различаются сайт/бренд, юридическое наименование, БИН и уполномоченное ТОО. При отсутствии прямого официального подтверждения поле остаётся пустым.

## 2ГИС

- MapGL JS API: https://docs.2gis.com/mapgl/start/first-steps
- Geocoder/Search API: https://docs.2gis.com/api/search/geocoder/overview
- Подложка MapGL и поиск адресов могут требовать **разные права** на API-ключе.
- У каталога **нет вручную выдуманных координат**. Адресную точку можно сохранить только при точном ответе Geocoder. Она **не доказывает** границы стройплощадки. Права на копирование и распространение геоданных 2ГИС определяются условиями API.
- Известные конфликты: Gran Via — разногласие по Жибек жолы 6/2 и Есенберлина 43; ORDA — номера 17/19а в источниках. Эти ЖК не ставятся случайным маркером.

## Реестр разрешений

Справочники КЖК, eLicense, Qazreestr, eQurylys, eGov, КГД, RSP, кадастр, открытые данные РК, госзакупки и Ashyq существуют как ссылки/форматы импортов в `/registry`, однако **массовая подтверждённая выгрузка из каждого из них ещё не выполнена**. Наличие указанного на коммерческом портале номера разрешения не подтверждает его текущую юридическую силу.

**Нет данных ≠ отрицательное заключение.** Результат анализа рекламных текстов — сигнал для проверки человеком, не штраф, не обвинение и не автоматическое решение.
