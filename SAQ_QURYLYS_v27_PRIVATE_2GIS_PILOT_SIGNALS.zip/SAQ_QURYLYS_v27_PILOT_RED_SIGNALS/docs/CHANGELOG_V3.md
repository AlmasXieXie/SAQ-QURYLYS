# V3 / 17 October 2026

- True OSM polygons for landuse/building construction from Overpass; 24-hour cache; failures shown explicitly.
- Strict GeoJSON polygon editing via UI map clicks, source URL, reviewer and timestamp.
- Leaflet scroll wheel zoom enabled; separate zone layers and map controls.
- New neutral restrained visual language with smaller, calmer UI controls.
- Direct original-publication links when `https://` source is present; no invented Instagram links for fictitious adverts.
- Verified-integration code using Ashyq CSV, Instagram Graph API hashtag search, OLX Partner API authorized user adverts, operator-approved RSS/Atom.
- CSV permit search, dedup, save provenance; no automatic R1 from register misses.
- 29 passing tests. External APIs are mock-tested; real network access in build container is unavailable.

## Explicit boundaries

Not full-platform Instagram/OLX scraping; no data gathered without tokens/authorization. No official property cadastral contours claimed for OSM. No real company accused by demo risk scores.
