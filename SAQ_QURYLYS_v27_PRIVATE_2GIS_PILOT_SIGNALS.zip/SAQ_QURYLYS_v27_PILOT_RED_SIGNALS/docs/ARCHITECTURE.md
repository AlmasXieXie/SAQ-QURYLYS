# Архитектура и объяснимость SAQ QURYLYS

## Слои

1. Web UI: один статический HTML, CSS и JS — без этапа сборки. Работает со всеми REST API через same-origin fetch.
2. API FastAPI: CRUD для ЖК и публикаций, человеческая модерация, сигналы, PDF, OCR, импорт CSV.
3. Postgres/SQLite через SQLAlchemy: `projects`, `advertisements`, `signals`.
4. NLP/ML: символьные TF-IDF n-граммы на названиях объектов, нечёткое сопоставление, извлечение предложений оплаты, цен и рекламных фраз.
5. Deterministic Scoring: шесть факторов строго по методике ТЗ; источник и подтверждённость обязательны; гипотезы никогда не увеличивают балл автоматически.

## Юридическая осторожность

| Условие | Последствие |
|---|---|
| Правовое основание неизвестно | R1 = 0, метка «Нужна проверка» |
| Проверено отсутствие применимого законного основания + документ | R1 +35 |
| Скриншот/объявление содержит предложенный депозит, аналитик подтверждает фиксацию | R2 +25 |
| Объявление содержит признак продажи строящегося ЖК, аналитик подтверждает | R3 +10 |
| Гарантия оператора подтверждена | R1 НЕ начисляется |
| 60+ без пары R1+R2 | Жёлтая зона |
| 60+ и одновременно R1+R2 | Красная зона |

Объявления от AI всегда сначала `pending`. Доказательный вес содержимого объявления появляется только после `accepted`. Если объявление отклонено, фактор пересчитывается без его участия. Р1 не появляется от нулевых результатов поиска.

## Ограничения и следующие шаги

- Реальный ETL Homeportal КЖК потребует разрешённой выгрузки/контрактного API; в MVP доступен безопасный импорт CSV.
- Instagram Graph API и OLX не гарантируют широкого публичного поиска. Их источники и соблюдение условий требуется согласовать до промышленного внедрения.
- Для production: SSO акимата, роли, журнал каждого изменения документов, бэкапы, неизменяемый evidence store, TLS, безопасное хранилище OCR и retention policy.
- Реальная улицовая подложка Усть-Каменогорска загружается из OSM через Leaflet; при недоступности Leaflet используется официальный iframe OSM. В полной изоляции от интернета реальная подложка не загрузится — офлайн-тайлов в дистрибутиве нет.
- CSV КЖК допускает объекты без координат (NULL), а карту пополняет только географически подтверждённая позиция; сохранённое поле `coordinate_source` показывает происхождение координат.
- Импорт рекламы через CSV не выполняет скрапинг; сервер отмечает каждую запись как `pending`, дедуплицирует источники, а скоринг меняется только после подтверждения аналитиком.
- Сохранённый пример KЖК «Золотой квадрат» (`data/kzhk_uka_verified_example.csv`) содержит только проверяемые публичные поля, со ссылкой на источник и фиксированную дату. Он не имитирует живой API.

## Качество

Сквозные тесты покрывают все три сценария A/B/C из §5, новые входные тексты, контекст отрицаний, распознавание упоминания цены без ошибочного R2, перенос предложения из `pending` в `accepted`, переоценку правового основания, сигналы и PDF.

## v3 additions (17 October 2026)

- `app/geo_zones.py` reads OSM `landuse=construction` and `building=construction` ways from Overpass and caches the genuine closed geometries (24 hours), with no cadastral or legal claim. Offline fetch is explicitly marked as unavailable/stale.
- `projects.boundary_geojson` stores evidence-backed analyst-drawn WGS84 footprints; API rejects invalid/unclosed or out-of-region polygons. Geometry is a separate evidentiary layer and never increases the legal risk score automatically.
- `app/connectors.py` provides the real official interfaces for public Ashyq CSV permits, permitted Meta Graph hashtag media, OLX Partner API adverts belonging to the OAuth account, and administrator-allowlisted RSS/Atom. All imported adverts stay `pending`.
- The live `registry_permits` table retains permission source metadata; the frontend offers synchronization, CSV fallback and search. Missing entries do not trigger `R1`.
- Leaflet wheel zoom, zone layer toggles and map-click editor are in `app/static/app.js`. Meta/OLX permissions are intentionally **not bypassed**; API credentials exist only in server environment variables.
