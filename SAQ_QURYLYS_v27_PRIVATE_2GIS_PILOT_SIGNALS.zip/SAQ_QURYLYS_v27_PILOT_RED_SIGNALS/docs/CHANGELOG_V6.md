# v6 — Real geodata and developer profiles (17 October 2026)

- Added real-estate georeference `/geo`: real unified registry ONLY, no 8 demo complexes.
- Up to 15 real project cards: 14 public registry entries + real 2GIS Diamond location.
- Clickable search links to 2GIS, Yandex Maps and Google Maps for every complex.
- Verified developer site/Instagram/BIN references for AN Groups, Tumar Group; developer source page Biryuza; sources from KЖК for Zolotoy Square. BIN of group not assumed to be legal company of a project.
- Address conflicts explicitly flagged for ORDA (17 vs 19а), ASYLYM (18 vs 18б), Prestizh/Diamond (both use Uvalieva 7 area).
- Safe on-demand address geocoding by OSM Nominatim: bounded to Ust-Kamenogorsk, house number + street + city required, no street centroids or fictitious points, ≥1.2 sec delay, manual source review for uncertain cases.
- Optional Overpass `landuse/building=construction` polygon overlay, independent of building pins and not a legal site boundary.
- Independent `/registry` map links and developer profiles. Legacy risk scoring remains in `/` using demo data.
- Clean API route smoke test (15 real, one confirmed map point, manually reviewed point persisted). 38 Python tests and 3 map JS regressions passed.

## Unresolved
External OSM online geocoding not executable in build environment. Most positions currently missing; geocoding button must be run on a network-enabled server and resulting candidates validated. Do not claim 15 accurate construction footprint coordinates. Website auto-synchronization with all public registries remains incomplete, and authenticated API is not implemented (local-only prototype).
