"""Conservative OSM address geocoding; manual validation for non-exact matches.

Runs once on user opening the map (or via manual retry). Policy: 1 request/second max, persistent cache,
OSM attribution, no scraping of 2GIS/Yandex/Google. Never maps road centroids as a site.
"""
from __future__ import annotations
import asyncio
from datetime import datetime, timezone
from threading import Lock
from urllib.parse import urlencode
import httpx
from sqlalchemy import select
from app.database import SessionLocal
from app.unified_registry import RegistryBuilding
from app.catalog_uka import catalog_keys

GEOCODER='https://nominatim.openstreetmap.org/search'
VALID_CITY=('усть-каменогорск','өскемен','oskemen','ust-kamenogorsk','ust kamenogorsk','ust-kamenogorsk city','öskemen','oskemen city')
STATUS={'scheduled':False,'running':False,'total':0,'processed':0,'resolved':0,'unresolved':0,'error':'','last_finished':None, 'rejected':0,'skipped_ambiguous':0}
CANDIDATES={}
lock=Lock()

def is_local_point(lat,lon):
    return 49.72<=lat<=50.22 and 82.24<=lon<=82.98

def number_from_address(address):
    import re
    # Addresses in the registry are comma-separated with house number at the end.
    last=address.split(',')[-1].strip()
    m=re.search(r'\d+[а-яa-z]?\s*(?:[/\\-]\s*\d+[а-яa-z]?)?',last,re.I)
    return (m.group().replace(' ','').casefold() if m else '')

def norm_number(s):
    return (s or '').lower().replace(' ','').replace('б','b').replace('в','v').replace('а','a')

def street_from_address(address):
    import re
    parts=[x.strip() for x in address.split(',')]
    if len(parts)<2:return ''
    street=parts[-2] if len(parts)>2 else parts[0]
    street=re.sub(r'(?i)\b(улица|ул|ул\.|проспект|пр|пр\.|микрорайон|мкр|имени|көшесі|даңғылы|строение|строит)\b',' ',street)
    street=re.sub(r'[^0-9a-zа-яёәғқңөұүһі\s-]',' ',street.casefold())
    return ' '.join(street.split())

def similar_street(expected,found):
    import difflib
    # Weak street matches are presented as candidates, never placed automatically.
    if not expected or not found:return False
    x=expected.replace('ё','е').replace('и. ','').replace('ильяса ','').replace('ул. ','')
    y=found.casefold().replace('ё','е').replace('ильяса ','')
    return difflib.SequenceMatcher(a=x,b=y).ratio()>=0.70

def check_exact_response(item,expected,street=''):
    try:
        lat=float(item['lat']);lon=float(item['lon'])
    except (KeyError,ValueError,TypeError):return False
    if not is_local_point(lat,lon):return False
    addr=item.get('address') or {}
    display=(item.get('display_name') or '').casefold()
    city=' '.join(str(addr.get(k,'')).casefold() for k in ('city','town','municipality','county','state_district','state'))
    if not any(x in (display+' '+city) for x in VALID_CITY):return False
    house=norm_number(str(addr.get('house_number') or ''))
    # Missing or conflicting exact house number may be a street centroid; reject.
    if not house or not expected or house!=norm_number(expected):return False
    road=' '.join(str(addr.get(k,'')) for k in ('road','pedestrian','residential','street')).strip()
    if street and not similar_street(street,road):return False
    return True

async def geocode_all_missing():
    with lock:
        if STATUS['running']:return
        STATUS.update(scheduled=False,running=True,total=0,processed=0,resolved=0,unresolved=0,error='',rejected=0)
    try:
        with SessionLocal() as db:
            ids=[r.id for r in db.scalars(select(RegistryBuilding).where(RegistryBuilding.latitude.is_(None))).all() if r.building_key in catalog_keys()]
        with lock:STATUS['total']=len(ids)
        headers={'User-Agent':'SAQ-Qurylys-Municipal-Registry/7.0 (address validation; contact: administrator of locally running instance)',
                 'Accept-Language':'ru,kk,en'}
        async with httpx.AsyncClient(timeout=9,headers=headers,follow_redirects=False) as client:
            consecutive_failures=0
            for bid in ids:
                with SessionLocal() as db:
                    b=db.get(RegistryBuilding,bid)
                    if not b or b.latitude is not None:
                        STATUS['processed']+=1;continue
                    name,address=b.name,b.address
                expected=number_from_address(address)
                # Roads with several blocks, intersections and provisional positions
                # must never be matched to the last house number by accident.
                tail=address.split(',',1)[-1]
                address_is_ambiguous=(tail.count(',')>1 or 'позиция ' in address.casefold()
                    or '–' in address or ' / ' in address or ' (без номера)' in address)
                if address_is_ambiguous:
                    STATUS['skipped_ambiguous']+=1
                    STATUS['unresolved']+=1;STATUS['processed']+=1;continue
                if not expected:
                    STATUS['unresolved']+=1;STATUS['processed']+=1;continue
                # Single request per building with a city bounded viewbox.
                params={'q':address+', Казахстан','format':'jsonv2','addressdetails':1,
                        'limit':4,'viewbox':'82.24,50.22,82.98,49.72','bounded':1}
                try:
                    r=await client.get(GEOCODER,params=params)
                    r.raise_for_status();items=r.json()
                    consecutive_failures=0
                except (httpx.HTTPError,ValueError) as e:
                    consecutive_failures+=1
                    STATUS['error']='Картографический сервис временно недоступен: '+str(e)[:140]
                    STATUS['unresolved']+=1;STATUS['processed']+=1
                    if consecutive_failures>=2:break
                    await asyncio.sleep(1.2);continue
                street=street_from_address(address)
                match=next((p for p in items if check_exact_response(p,expected,street)),None)
                if match:
                    with SessionLocal() as db:
                        b=db.get(RegistryBuilding,bid)
                        if b and b.latitude is None:
                            b.latitude=float(match['lat']);b.longitude=float(match['lon'])
                            b.coordinate_source=f'GEOCODE:OSM Nominatim: address {expected}; https://www.openstreetmap.org/{match.get("osm_type","node")}/{match.get("osm_id",0)}'
                            db.commit();STATUS['resolved']+=1
                else:
                    STATUS['unresolved']+=1
                    if items:
                        # Candidate never becomes a public map pin without explicit review.
                        CANDIDATES[bid]=[{'lat':float(p['lat']),'lon':float(p['lon']),
                            'display_name':p.get('display_name',''),
                            'source_url':f'https://www.openstreetmap.org/{p.get("osm_type","node")}/{p.get("osm_id",0)}'}
                            for p in items[:3] if is_local_point(float(p['lat']),float(p['lon']))]
                STATUS['processed']+=1
                await asyncio.sleep(1.2)
    finally:
        STATUS['last_finished']=datetime.now(timezone.utc).isoformat()
        STATUS['running']=False

