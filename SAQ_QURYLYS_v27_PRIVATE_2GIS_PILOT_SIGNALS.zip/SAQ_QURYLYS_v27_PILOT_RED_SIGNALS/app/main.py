"""SAQ QURYLYS API: an evidence-first, human-in-the-loop demonstrator."""
from __future__ import annotations
import csv
from datetime import datetime, timezone
from io import StringIO
import os
from pathlib import Path
import uuid

from fastapi import Depends, FastAPI, File, HTTPException, Query, UploadFile
from contextlib import asynccontextmanager
import asyncio
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import func, select, inspect
from sqlalchemy.orm import Session

from app.analyzer import analyze_text
from app.database import Base, engine, get_db, SessionLocal
from app.models import Project, Advertisement, Signal, RegistryPermit
from app.unified_registry import load_starter
from app.developer_bins import add_verified_company_bins
from app.catalog_uka import load_catalog
from app.extra_problem_sites import load_extra
from app.unified_api import router as unified_router
from app.geo_zones import construction_zones
from app import connectors
from app.pdf_report import report_pdf
from app.scoring import score_project
from app.v8_api import router as v8_router, RegistryAd
from app.v9_api import router as v9_router
from app.v10_api import router as v10_router
from app.v11_geocode import router as v11_router
from app.v11_migration import import_from_prior
from app.ad_verification_api import router as verification_router
from app.autonomous_monitor import router as monitor_router, background_schedule
from app.ad_archive_v24 import router as archive_v24_router
from app.ad_monitor_v25 import router as monitor_v25_router
from app.registry_deep_v24 import router as registry_v24_router, reconcile_mio_exact
from app.official_mio_v26 import seed_official_list
from app.seed_public_ads_v24 import seed_real_publications
from app.seed_public_ads_v26 import seed_2026_ads
from app.v13_geolocate import router as geolocate_router
from app.v14_geofill import router as v14_router, background_loop
from app.workbench import router as workbench_router
from app.signal_map import router as signal_map_router
from app.registry_bridge import router as linkage_router, reconcile
from app.browser_geolocate import router as browser_geolocate_router

ROOT = Path(__file__).resolve().parent
@asynccontextmanager
async def lifespan(app):
    # Dedicated background workers run only while the application is running.
    # Avoid external network in automated tests; endpoints remain testable.
    tasks=[]
    if not os.getenv('PYTEST_CURRENT_TEST'):
        tasks=[asyncio.create_task(background_schedule()),asyncio.create_task(background_loop())]
    try:
        yield
    finally:
        for task in tasks:task.cancel()
        if tasks:await asyncio.gather(*tasks,return_exceptions=True)

app = FastAPI(title="SAQ QURYLYS", version="27.0.0", docs_url="/api/docs", redoc_url=None, lifespan=lifespan)
origins = [x.strip() for x in os.getenv("SAQ_CORS_ORIGINS", "").split(",") if x.strip()]
if origins:
    app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["GET", "POST", "PATCH"], allow_headers=["Content-Type"])


# Public deployment guard. Configure BOTH SAQ_ADMIN_USER and SAQ_ADMIN_PASSWORD
# behind TLS reverse proxy; disabled for loopback-only local development.
import secrets
from fastapi import Request
from fastapi.responses import JSONResponse
@app.middleware("http")
async def saq_access_guard(request:Request,call_next):
    username=os.getenv('SAQ_ADMIN_USER','')
    password=os.getenv('SAQ_ADMIN_PASSWORD','')
    if os.getenv('SAQ_PUBLIC_MODE','0')=='1' and not (username and password):
        return Response('Set SAQ_ADMIN_USER and SAQ_ADMIN_PASSWORD for public deployment',status_code=503)
    if username and password:
        import base64
        token=request.headers.get('authorization','')
        ok=False
        if token.startswith('Basic '):
            try:
                userpass=base64.b64decode(token[6:],validate=True).decode('utf-8')
                if ':' in userpass:
                    u,p=userpass.split(':',1)
                    ok=secrets.compare_digest(u,username) and secrets.compare_digest(p,password)
            except (ValueError,UnicodeDecodeError):pass
        if not ok:
            return Response('Authentication required',status_code=401,headers={'WWW-Authenticate':'Basic realm="SAQ QURYLYS"'})
    return await call_next(request)

# Startup initializes the evidence-first registry and real construction catalog.
Base.metadata.create_all(bind=engine)
app.include_router(unified_router)
app.include_router(v8_router)
app.include_router(v9_router)
app.include_router(v10_router)
app.include_router(v11_router)
app.include_router(verification_router)
app.include_router(monitor_router)
app.include_router(archive_v24_router)
app.include_router(monitor_v25_router)
app.include_router(registry_v24_router)
app.include_router(geolocate_router)
app.include_router(v14_router)
app.include_router(workbench_router)
app.include_router(signal_map_router)
app.include_router(linkage_router)
app.include_router(browser_geolocate_router)
with SessionLocal() as session:
    load_starter(session)
    load_catalog(session)
    load_extra(session)
    add_verified_company_bins(session)
    reconcile(session)
    seed_official_list(session)
    reconcile_mio_exact(session)
    import_from_prior(session, ROOT.parent)
    seed_real_publications(session)
    seed_2026_ads(session)
# Lightweight forward-compatible migration of a previous local SQLite demo database.
if engine.dialect.name == "sqlite":
    with engine.begin() as conn:
        column_names = {col["name"] for col in inspect(conn).get_columns("projects")}
        if "registry_url" not in column_names:
            conn.exec_driver_sql("ALTER TABLE projects ADD COLUMN registry_url VARCHAR(500) NOT NULL DEFAULT ''")
        if "coordinate_source" not in column_names:
            conn.exec_driver_sql("ALTER TABLE projects ADD COLUMN coordinate_source VARCHAR(500) NOT NULL DEFAULT ''")
        for name, definition in (
            ('boundary_geojson','JSON'),('boundary_source',"VARCHAR(500) NOT NULL DEFAULT ''"),
            ('boundary_checked_by',"VARCHAR(120) NOT NULL DEFAULT ''"),('boundary_checked_at',"VARCHAR(40) NOT NULL DEFAULT ''")):
            if name not in column_names:
                conn.exec_driver_sql(f"ALTER TABLE projects ADD COLUMN {name} {definition}")
# v8 live-facing instance: do not seed demo, and delete legacy example rows.
# Analyst-authored real projects remain in legacy tables for audit and migration,
# but they are never mixed into the v8 registry or map.
with SessionLocal() as session:
    old_demo=session.scalars(select(Project).where(Project.demo==True)).all()
    for legacy in old_demo:
        # Keep the isolated, explicitly fictional training cases across restarts.
        if not legacy.name.startswith("ЖК DEMO «"):session.delete(legacy)
    # Orphan sample ads from the original demo are also removed.
    for legacy_ad in session.scalars(select(Advertisement).where(Advertisement.demo==True)).all():
        # Only retain ads belonging to the clearly labeled separate training sandbox.
        if legacy_ad.project is None or not legacy_ad.project.name.startswith("ЖК DEMO «"):
            session.delete(legacy_ad)
    session.commit()

app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")

class AnalysisInput(BaseModel):
    text: str = Field(min_length=5, max_length=30000)

class AdCreate(AnalysisInput):
    platform: str = Field(default="manual", max_length=30)
    account: str = Field(default="", max_length=100)
    source_url: str = Field(default="", max_length=500)
    posted_at: str = Field(default="", max_length=30)
    project_id: int | None = None
    image_path: str = Field(default="", max_length=350)
    @field_validator("image_path")
    @classmethod
    def valid_image_path(cls, v):
        import re
        if v and not re.fullmatch(r"/static/uploads/[0-9a-f]{32}\.png", v):
            raise ValueError("Можно прикреплять только скриншот, загруженный через OCR")
        return v
    @field_validator("source_url")
    @classmethod
    def valid_source_url(cls, v):
        if v and not (v.startswith("https://") or v.startswith("http://") or v.startswith("demo://")):
            raise ValueError("Допустимы только ссылки http/https")
        return v

class ReviewInput(BaseModel):
    status: str
    reviewer: str = Field(min_length=2, max_length=120)
    project_id: int | None = None
    @field_validator("status")
    @classmethod
    def status_values(cls, v):
        if v not in ["accepted", "rejected", "pending"]:
            raise ValueError("Недопустимый статус")
        return v

class LegalInput(BaseModel):
    status: str
    basis: str = Field(default="", max_length=250)
    source: str = Field(default="", max_length=500)
    reviewer: str = Field(min_length=2, max_length=120)
    @field_validator("status")
    @classmethod
    def status_values(cls, v):
        if v not in ["unknown", "verified_absent", "verified_guarantee", "verified_permit"]:
            raise ValueError("Недопустимый статус")
        return v

class LocationInput(BaseModel):
    latitude: float = Field(ge=49.65, le=50.25)
    longitude: float = Field(ge=82.2, le=83.05)
    source: str = Field(min_length=10, max_length=500)
    reviewer: str = Field(min_length=2, max_length=120)
    @field_validator("source")
    @classmethod
    def location_source(cls, v):
        if not v.strip().startswith(("https://", "http://", "DEMO:")):
            raise ValueError("Нужна ссылка на картографический источник или DEMO-документ")
        return v.strip()

class SignalInput(BaseModel):
    author: str = Field(min_length=2, max_length=120)
    note: str = Field(default="", max_length=2000)

class DecisionInput(SignalInput):
    status: str
    @field_validator("status")
    @classmethod
    def decision_values(cls, v):
        if v not in ["confirmed", "returned"]:
            raise ValueError("Только confirmed или returned")
        return v


def serialize_ad(ad):
    return {"id": ad.id, "project_id": ad.project_id, "project_name": ad.project.name if ad.project else None,
            "platform": ad.platform, "account": ad.account, "source_url": ad.source_url,
            "posted_at": ad.posted_at, "captured_at": ad.captured_at.isoformat() if ad.captured_at else "",
            "text": ad.text, "image_path": ad.image_path, "analysis": ad.analysis,
            "review_status": ad.review_status, "reviewed_by": ad.reviewed_by,
            "reviewed_at": ad.reviewed_at.isoformat() if ad.reviewed_at else None, "demo": ad.demo}


def serialize_project(project, detail=False):
    scoring = score_project(project, project.ads)
    row = {"id": project.id, "name": project.name, "address": project.address, "district": project.district,
           "latitude": project.latitude, "longitude": project.longitude, "developer": project.developer,
           "bin": project.bin, "stage": project.stage, "completion": project.completion,
           "claimed_completion": project.claimed_completion, "legal_status": project.legal_status,
           "legal_basis": project.legal_basis, "registry_url": project.registry_url,
           "coordinate_source": project.coordinate_source, "legal_source": project.legal_source,
           "legal_checked_at": project.legal_checked_at, "completion_source": project.completion_source,
           "claimed_source": project.claimed_source, "demo": project.demo,
           "ad_count": len(project.ads), "score": scoring["score"], "zone": scoring["zone"],
           "pending_ads": scoring["pending_ads"], "factor_codes": [f["code"] for f in scoring["factors"]]}
    if detail:
        row.update({"factors": scoring["factors"], "missing": scoring["missing"],
                    "ads": [serialize_ad(ad) for ad in sorted(project.ads, key=lambda a: a.id, reverse=True)],
                    "signals": [serialize_signal(s) for s in sorted(project.signals, key=lambda s: s.id, reverse=True)]})
    return row


def serialize_signal(s):
    return {"id": s.id, "project_id": s.project_id, "project_name": s.project.name if s.project else "",
            "score": s.score_snapshot, "zone": s.zone_snapshot, "factors": s.factors_snapshot,
            "status": s.status, "author": s.author, "note": s.note,
            "created_at": s.created_at.isoformat() if s.created_at else "",
            "reviewed_at": s.reviewed_at.isoformat() if s.reviewed_at else None}


def project_or_404(db, id):
    project = db.get(Project, id)
    if not project:
        raise HTTPException(404, "Объект не найден")
    return project

@app.get("/api/health")
def health(db: Session = Depends(get_db)):
    return {"status": "ok", "version": "27.0.0", "project_count": db.scalar(select(func.count()).select_from(Project)), "demo": False}

@app.get("/api/projects")
def projects_list(q: str = "", zone: str = "", db: Session = Depends(get_db)):
    records = db.scalars(select(Project).order_by(Project.id)).all()
    records = [serialize_project(p) for p in records]
    if q:
        needle = q.lower().strip()
        records = [p for p in records if needle in (p["name"] + p["developer"] + p["address"]).lower()]
    if zone in ("red", "yellow", "green"):
        records = [p for p in records if p["zone"] == zone]
    return records

@app.get("/api/projects/{project_id}")
def project_detail(project_id: int, db: Session = Depends(get_db)):
    return serialize_project(project_or_404(db, project_id), detail=True)

@app.get("/api/dashboard")
def dashboard(db: Session = Depends(get_db)):
    rows = [serialize_project(p) for p in db.scalars(select(Project)).all()]
    count = {zone: sum(1 for p in rows if p["zone"] == zone) for zone in ("red", "yellow", "green")}
    return {"project_count": len(rows), "ad_count": db.scalar(select(func.count()).select_from(Advertisement)),
            "pending_ads": db.scalar(select(func.count()).select_from(Advertisement).where(Advertisement.review_status == "pending")),
            "signal_count": db.scalar(select(func.count()).select_from(Signal)),
            "zones": count, "highest_risk": sorted(rows, key=lambda x: x["score"], reverse=True)[:5],
            "projects": rows, "mode": "demonstration"}

@app.get("/api/ads")
def ads_list(review_status: str = "", db: Session = Depends(get_db)):
    stmt = select(Advertisement).order_by(Advertisement.id.desc())
    if review_status:
        stmt = stmt.where(Advertisement.review_status == review_status)
    return [serialize_ad(ad) for ad in db.scalars(stmt).all()]

@app.post("/api/analyze")
def analyze_preview(payload: AnalysisInput, db: Session = Depends(get_db)):
    return analyze_text(payload.text, db.scalars(select(Project)).all())

@app.post("/api/ads", status_code=201)
def add_ad(payload: AdCreate, db: Session = Depends(get_db)):
    if payload.project_id:
        project_or_404(db, payload.project_id)
    analysis = analyze_text(payload.text, db.scalars(select(Project)).all())
    ad = Advertisement(**payload.model_dump(exclude={"project_id"}),
                       project_id=payload.project_id or analysis["matching"]["project_id"],
                       analysis=analysis, review_status="pending", demo=True)
    db.add(ad)
    db.commit()
    db.refresh(ad)
    return serialize_ad(ad)

@app.post("/api/ads/{ad_id}/review")
def review_ad(ad_id: int, payload: ReviewInput, db: Session = Depends(get_db)):
    ad = db.get(Advertisement, ad_id)
    if not ad:
        raise HTTPException(404, "Публикация не найдена")
    if payload.project_id is not None:
        project_or_404(db, payload.project_id)
        ad.project_id = payload.project_id
    if payload.status == "accepted" and not ad.project_id:
        raise HTTPException(422, "Сначала выберите ЖК")
    ad.review_status = payload.status
    ad.reviewed_by = payload.reviewer
    ad.reviewed_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(ad)
    return serialize_ad(ad)

@app.post("/api/projects/{project_id}/legal")
def update_legal(project_id: int, payload: LegalInput, db: Session = Depends(get_db)):
    project = project_or_404(db, project_id)
    if payload.status != "unknown" and not payload.source.strip():
        raise HTTPException(422, "Для проверенного статуса нужен источник документа")
    project.legal_status = payload.status
    project.legal_basis = payload.basis
    project.legal_source = payload.source
    project.legal_checked_at = datetime.now(timezone.utc).date().isoformat()
    db.commit()
    return serialize_project(project, detail=True)

@app.post("/api/projects/{project_id}/location")
def update_location(project_id: int, payload: LocationInput, db: Session = Depends(get_db)):
    """Operator-verified coordinates; address-only imported records must not be guessed."""
    project = project_or_404(db, project_id)
    project.latitude = payload.latitude
    project.longitude = payload.longitude
    project.coordinate_source = payload.source
    db.commit()
    return serialize_project(project, detail=True)

@app.get("/api/signals")
def signals_list(db: Session = Depends(get_db)):
    return [serialize_signal(s) for s in db.scalars(select(Signal).order_by(Signal.id.desc())).all()]

@app.post("/api/projects/{project_id}/signals", status_code=201)
def create_signal(project_id: int, payload: SignalInput, db: Session = Depends(get_db)):
    project = project_or_404(db, project_id)
    risk = score_project(project, project.ads)
    signal = Signal(project_id=project.id, score_snapshot=risk["score"],
                    zone_snapshot=risk["zone"], factors_snapshot=risk["factors"],
                    author=payload.author, note=payload.note, status="pending")
    db.add(signal)
    db.commit()
    db.refresh(signal)
    return serialize_signal(signal)

@app.post("/api/signals/{signal_id}/decision")
def decide_signal(signal_id: int, payload: DecisionInput, db: Session = Depends(get_db)):
    signal = db.get(Signal, signal_id)
    if not signal:
        raise HTTPException(404, "Сигнал не найден")
    signal.status = payload.status
    signal.author = payload.author
    signal.note = payload.note
    signal.reviewed_at = datetime.now(timezone.utc)
    db.commit()
    return serialize_signal(signal)

@app.get("/api/projects/{project_id}/report.pdf")
def project_report(project_id: int, signal_id: int | None = None, db: Session = Depends(get_db)):
    project = project_or_404(db, project_id)
    signal = db.get(Signal, signal_id) if signal_id else None
    if signal_id and (not signal or signal.project_id != project_id):
        raise HTTPException(404, "Сигнал не найден у этого ЖК")
    score = score_project(project, project.ads)
    if signal:
        score["score"], score["zone"], score["factors"] = signal.score_snapshot, signal.zone_snapshot, signal.factors_snapshot
    result = report_pdf(project, score, signal, project.ads)
    return Response(content=result, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="saq-project-{project_id}.pdf"'})

@app.post("/api/ocr")
async def read_screenshot(file: UploadFile = File(...)):
    if file.content_type not in ("image/jpeg", "image/png", "image/webp"):
        raise HTTPException(415, "Разрешены PNG, JPG, WEBP")
    contents = await file.read(5 * 1024 * 1024 + 1)
    if len(contents) > 5 * 1024 * 1024:
        raise HTTPException(413, "Размер изображения должен быть меньше 5 МБ")
    try:
        from PIL import Image, ImageOps
        import pytesseract
        from io import BytesIO
        with Image.open(BytesIO(contents)) as im:
            if im.width * im.height > 20_000_000:
                raise HTTPException(413, "Слишком высокое разрешение")
            clean = ImageOps.grayscale(im.convert("RGB"))
            text = pytesseract.image_to_string(clean, lang="rus+eng").strip()
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(503, f"OCR недоступен: {type(exc).__name__}. Текст можно ввести вручную.")
    folder = ROOT / "static" / "uploads"
    folder.mkdir(exist_ok=True)
    filename = uuid.uuid4().hex + ".png"
    # Store canonical png (not untrusted original), no uploaded filename in path.
    clean.save(folder / filename)
    return {"text": text, "image_path": f"/static/uploads/{filename}", "length": len(text)}

@app.post("/api/import/projects.csv")
async def import_projects_csv(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """Import public registry export; imported records are NEVER presumed permitted or illegal.

    Expected UTF-8 CSV columns:
    name,address,developer,bin,latitude,longitude,stage,completion,source_url
    Coordinates can be blank (not fabricated); the object remains in the registry but off the map.
    """
    if not (file.filename or "").lower().endswith(".csv"):
        raise HTTPException(415, "Ожидается CSV-файл")
    raw = await file.read(2 * 1024 * 1024 + 1)
    if len(raw) > 2 * 1024 * 1024:
        raise HTTPException(413, "Максимальный размер CSV — 2 МБ")
    try:
        text = raw.decode("utf-8-sig")
        delimiter = ";" if text.splitlines() and text.splitlines()[0].count(";") > text.splitlines()[0].count(",") else ","
        reader = csv.DictReader(StringIO(text), delimiter=delimiter)
        required = {"name", "address", "developer"}
        if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
            raise HTTPException(422, "Нет обязательных столбцов: " + ", ".join(sorted(required)))
        existing_names = set(db.scalars(select(Project.name)).all())
        added, skipped, errors = 0, 0, []
        for line, row in enumerate(reader, start=2):
            if line > 5002:
                raise HTTPException(413, "Максимум 5000 объектов за один импорт")
            try:
                name = (row.get("name") or "").strip()[:180]
                if not name: raise ValueError("Пустое название")
                if name in existing_names:
                    skipped += 1
                    continue
                raw_lat, raw_lon = (row.get("latitude") or "").strip(), (row.get("longitude") or "").strip()
                if bool(raw_lat) != bool(raw_lon):
                    raise ValueError("Координаты должны быть указаны обе либо отсутствовать")
                lat, lon = (float(raw_lat), float(raw_lon)) if raw_lat else (None, None)
                if lat is not None and not (40 <= lat <= 56 and 46 <= lon <= 88):
                    raise ValueError("Координаты вне Казахстана")
                completion = int(row.get("completion") or 0)
                if not (0 <= completion <= 100):
                    raise ValueError("Готовность должна быть от 0 до 100%")
                source = (row.get("source_url") or "").strip()
                if source and not source.startswith(("https://", "http://")):
                    raise ValueError("Некорректная ссылка на первоисточник")
                obj = Project(name=name, aliases=[], address=(row.get("address") or "").strip()[:300],
                              district=(row.get("district") or "").strip()[:120],
                              developer=(row.get("developer") or "").strip()[:180],
                              bin=(row.get("bin") or "").strip()[:12],
                              latitude=lat, longitude=lon, stage=(row.get("stage") or "Не уточнено")[:120],
                              completion=completion, registry_url=source,
                              coordinate_source=source if lat is not None else "",
                              legal_status="unknown", legal_basis="Требуется проверка",
                              demo=False)
                db.add(obj)
                existing_names.add(name)
                added += 1
            except (ValueError, TypeError) as exc:
                errors.append({"line": line, "reason": str(exc)})
        db.commit()
        return {"added": added, "skipped": skipped, "errors": errors[:25],
                "notice": "Импортированные объекты помечены статусом 'не проверено'; данные не устанавливают факт нарушения."}
    except UnicodeDecodeError:
        raise HTTPException(422, "CSV должен быть в UTF-8")


@app.post("/api/import/kzhk-uka-example")
def import_kzhk_uka_example(db: Session = Depends(get_db)):
    """One-click OFFLINE snapshot of an actual KZhK page, not a live API integration.

    Snapshot: KZhK project 1141, status as of 2026-08-31. Legal basis is intentionally
    unverified in our case database until a human checks the document and the phase.
    """
    with (ROOT.parent / "data" / "kzhk_uka_verified_example.csv").open(encoding="utf-8-sig", newline="") as f:
        example = next(csv.DictReader(f))
    name = example["name"]
    existing = db.scalar(select(Project).where(Project.name == name))
    if existing:
        return {"added": 0, "project": serialize_project(existing), "notice": "Этот пример уже импортирован"}
    project = Project(name=name, aliases=["Золотой квадрат", "Золотой Квадрат", "Zolotoi Kvadrat"],
                      address=example["address"], district="Усть-Каменогорск",
                      developer=example["developer"], bin=example["bin"],
                      latitude=None, longitude=None, stage=example["stage"],
                      completion=int(example["completion"]),
                      completion_source="https://www.homeportal.kz/ru/projects/1141 (данные на 31.08.2026)",
                      registry_url=example["source_url"], legal_status="unknown", demo=False)
    db.add(project)
    db.commit()
    return {"added": 1, "project": serialize_project(project),
            "notice": "Импортирована сохранённая публичная карточка КЖК, а НЕ результат онлайн-проверки. Координаты и правовые основания требуют подтверждения аналитиком."}

@app.post("/api/import/ads.csv")
async def import_ads_csv(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """Batch import of legitimately obtained public ad text; never scrapes a platform.

    Required columns: text. Optional: platform,account,source_url,posted_at,project_name.
    Text and matching are AI hypotheses until a human reviews each ad.
    """
    if not (file.filename or "").lower().endswith(".csv"):
        raise HTTPException(415, "Ожидается CSV-файл")
    raw = await file.read(2 * 1024 * 1024 + 1)
    if len(raw) > 2 * 1024 * 1024:
        raise HTTPException(413, "Максимальный размер CSV — 2 МБ")
    try:
        content = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise HTTPException(422, "CSV должен быть в UTF-8")
    first = content.splitlines()[0] if content.splitlines() else ""
    reader = csv.DictReader(StringIO(content), delimiter=";" if first.count(";") > first.count(",") else ",")
    if not reader.fieldnames or "text" not in reader.fieldnames:
        raise HTTPException(422, "Нет обязательного столбца text")
    projects = db.scalars(select(Project)).all()
    by_name = {p.name.casefold().strip(): p for p in projects}
    existing_urls = set(db.scalars(select(Advertisement.source_url).where(Advertisement.source_url != "")).all())
    added, skipped, errors, unmatched = 0, 0, [], 0
    for line, row in enumerate(reader, start=2):
        if line > 1001:
            raise HTTPException(413, "Максимум 1000 объявлений")
        try:
            ad_text = (row.get("text") or "").strip()
            if len(ad_text) < 5 or len(ad_text) > 30000:
                raise ValueError("Текст должен содержать от 5 до 30000 символов")
            url = (row.get("source_url") or "").strip()
            if url and (len(url) > 500 or not url.startswith(("https://", "http://", "demo://"))):
                raise ValueError("Некорректная ссылка на источник")
            if url and url in existing_urls:
                skipped += 1
                continue
            project_name = (row.get("project_name") or "").strip().casefold()
            if project_name and project_name not in by_name:
                raise ValueError("Указанный ЖК отсутствует в реестре")
            model_result = analyze_text(ad_text, projects)
            project_id = by_name[project_name].id if project_name else model_result["matching"]["project_id"]
            ad = Advertisement(text=ad_text, platform=((row.get("platform") or "manual").strip()[:30]),
                               account=(row.get("account") or "").strip()[:100],
                               source_url=url, posted_at=(row.get("posted_at") or "").strip()[:30],
                               project_id=project_id, analysis=model_result, review_status="pending", demo=False)
            db.add(ad)
            if not project_id:
                unmatched += 1
            if url:
                existing_urls.add(url)
            added += 1
        except (ValueError, TypeError) as exc:
            errors.append({"line": line, "reason": str(exc)})
    db.commit()
    return {"added": added, "skipped": skipped, "unmatched": unmatched, "errors": errors[:25],
            "notice": "Все импортированные публикации ожидают проверки аналитиком. Импорт не подтверждает достоверность источника."}

@app.get('/api/map/construction-zones')
def zones(refresh: bool = False):
    """Construction polygons are sourced from OpenStreetMap, NOT cadastral survey."""
    return construction_zones(refresh=refresh)


class BoundaryInput(BaseModel):
    geometry: dict
    source: str = Field(min_length=10,max_length=500)
    reviewer: str = Field(min_length=2,max_length=120)


def check_boundary(geo: dict) -> dict:
    """Bounded, closed, WGS84 GeoJSON Polygon; do not accept arbitrary geometry types."""
    if geo.get('type')!='Polygon' or not isinstance(geo.get('coordinates'),list) or len(geo['coordinates'])!=1:
        raise HTTPException(422,'Нужен один GeoJSON Polygon без отверстий')
    ring=geo['coordinates'][0]
    if not isinstance(ring,list) or len(ring)<4 or len(ring)>250 or ring[0]!=ring[-1]:
        raise HTTPException(422,'Полигон должен быть замкнутым (4–250 вершин)')
    for vertex in ring:
        if (not isinstance(vertex,list) or len(vertex)!=2 or
                any(isinstance(v,bool) or not isinstance(v,(int,float)) for v in vertex)):
            raise HTTPException(422,'Каждая вершина: [долгота, широта]')
        lon,lat=vertex
        if not 82.2<=lon<=83.05 or not 49.65<=lat<=50.25:
            raise HTTPException(422,'Полигон должен быть в регионе Усть-Каменогорска')
    if len({tuple(v) for v in ring[:-1]})<3:
        raise HTTPException(422,'Полигон вырожден')
    area=abs(sum(ring[i][0]*ring[i+1][1]-ring[i+1][0]*ring[i][1] for i in range(len(ring)-1)))/2
    if not 1e-10 < area < 0.0003:
        raise HTTPException(422,'Недостоверная площадь полигона')
    return {'type':'Polygon','coordinates':[ring]}


@app.post('/api/projects/{project_id}/boundary')
def set_boundary(project_id:int, payload:BoundaryInput, db:Session=Depends(get_db)):
    project=project_or_404(db,project_id)
    if not (payload.source.startswith(('https://','http://')) or (project.demo and payload.source.startswith('DEMO:'))):
        raise HTTPException(422,'Укажите достоверный источник контура / DEMO-источник для учебного ЖК')
    project.boundary_geojson=check_boundary(payload.geometry)
    project.boundary_source=payload.source
    project.boundary_checked_by=payload.reviewer
    project.boundary_checked_at=datetime.now(timezone.utc).isoformat()
    db.commit()
    return serialize_project(project)


@app.get('/api/map/project-boundaries')
def project_boundaries(db:Session=Depends(get_db)):
    """Project footprints drawn only if specifically evidenced/entered by an analyst."""
    return {'type':'FeatureCollection', 'features': [
        {'type':'Feature','geometry':p.boundary_geojson,'properties':{
            'project_id':p.id,'name':p.name,'demo':p.demo,'source_url':p.boundary_source,
            'reviewed_by':p.boundary_checked_by,'checked_at':p.boundary_checked_at}}
        for p in db.scalars(select(Project)).all() if p.boundary_geojson]}


@app.get('/api/registries/status')
def registries_status(db:Session=Depends(get_db)):
    return {'connectors':connectors.source_status(),
            'permits_stored':db.scalar(select(func.count()).select_from(RegistryPermit))}


@app.get('/api/registries/permits')
def registries_permits(q:str='',limit:int=Query(default=40,ge=1,le=200),db:Session=Depends(get_db)):
    stmt=select(RegistryPermit).order_by(RegistryPermit.imported_at.desc()).limit(1000)
    permits=db.scalars(stmt).all()
    if q:
        permits=[x for x in permits if q.lower() in (x.permission_number+' '+x.project_name+' '+x.developer).lower()]
    return [{'permission_number':p.permission_number,'project_name':p.project_name,'developer':p.developer,
             'issue_date':p.issue_date,'source_url':p.source_url,'imported_at':p.imported_at.isoformat()} for p in permits[:limit]]


def _pick(row,*names):
    lower={str(k).lower().strip():str(v or '').strip() for k,v in row.items() if k}
    for name in names:
        if lower.get(name):return lower[name]
    return ''


def load_permits(rows,db):
    count=0;duplicates=0
    for row in rows:
        number=_pick(row,'permission_number','номер разрешения')[:130]
        key=_pick(row,'permission_id','id') or number
        if not key:
            continue
        key='ashyq:'+key[:280]
        if db.scalar(select(RegistryPermit.id).where(RegistryPermit.permission_key==key)):
            duplicates+=1;continue
        db.add(RegistryPermit(permission_key=key,permission_number=number,
            project_name=_pick(row,'object_location','object','наименование объекта')[:400],
            developer=_pick(row,'builder_name','застройщик')[:300],
            issue_date=_pick(row,'issue_date','дата выдачи')[:60],
            source_url=connectors.ASHYQ_PAGE,metadata_original={str(k):str(v or '')[:1000] for k,v in row.items()}))
        count+=1
    db.commit()
    return {'added':count,'duplicates':duplicates, 'total_seen':len(rows),
            'notice':'Записи из реестра не изменяют юридический статус ЖК автоматически; совпадение проверяет аналитик.'}


@app.post('/api/registries/ashyq/sync')
def sync_ashyq(db:Session=Depends(get_db)):
    try:
        rows=connectors.permits_csv()
    except (connectors.ConnectorError, __import__('httpx').HTTPError, ValueError) as exc:
        raise HTTPException(502, f'Реестр Ashyq недоступен: {type(exc).__name__}. Можно импортировать CSV вручную.')
    return load_permits(rows,db)


@app.post('/api/registries/ashyq/import.csv')
async def import_ashyq_csv(file:UploadFile=File(...),db:Session=Depends(get_db)):
    data=await file.read(5_000_001)
    if len(data)>5_000_000:raise HTTPException(413,'CSV слишком велик')
    try:
        txt=data.decode('utf-8-sig')
        delim=csv.Sniffer().sniff(txt[:1500],delimiters=',;\t')
        rows=list(csv.DictReader(StringIO(txt),dialect=delim))
        if len(rows)>12000: raise HTTPException(413,'Превышено 12000 строк')
        if not rows or not any('permission' in x.lower() or 'разрешен' in x.lower() for x in rows[0]):
            raise HTTPException(422,'Неверная таблица: отсутствуют поля разрешений')
        return load_permits(rows,db)
    except (UnicodeDecodeError,csv.Error) as exc:
        raise HTTPException(422, 'Неверный CSV') from exc


def ingest_records(records,db):
    existing={a for a in db.scalars(select(Advertisement.source_url)).all() if a}
    added=skipped=unmatched=ignored=0
    projects=db.scalars(select(Project)).all()
    for row in records[:70]:
        text=(row.get('text') or '').strip()[:20000]
        url=(row.get('source_url') or '')[:500]
        if len(text)<5 or (url and url in existing):
            skipped+=1;continue
        analysis=analyze_text(text,projects)
        housing=any(x in text.lower() for x in ('квартир','новостро','жилой комплекс','жк ','жк\n','тұрғын үй','пәтер','үй кешені'))
        development=any(x in text.lower() for x in ('строящ','строительств','котлован','возводит','новостро','сдача','дольщ','құрылыс','үлестік','кешен'))
        # Relevant listing OR specific matched project; no blanket import of unrelated social feed.
        if not (housing and (development or analysis['matching']['project_id'])):
            ignored+=1;continue
        db.add(Advertisement(platform=str(row.get('platform') or 'other')[:30],
            account=str(row.get('account') or '')[:100],source_url=url,
            posted_at=str(row.get('posted_at') or '')[:30],text=text,analysis=analysis,
            project_id=analysis['matching']['project_id'],review_status='pending',demo=False))
        if not analysis['matching']['project_id']:unmatched+=1
        added+=1
        if url:existing.add(url)
    db.commit()
    return {'added':added,'skipped':skipped,'unmatched':unmatched,'irrelevant':ignored,
            'notice':'Все записи из официальных API/каналов поступают на проверку; балл риска не изменён.'}


@app.post('/api/collect/{provider}')
def collect(provider:str,db:Session=Depends(get_db)):
    adapters={'instagram':connectors.instagram_hashtags,'olx':connectors.olx_account_ads,'rss':connectors.rss_items}
    if provider not in adapters:raise HTTPException(404,'Нет такого адаптера')
    try:
        rows=adapters[provider]()
    except connectors.ConnectorError as exc:
        raise HTTPException(409,str(exc))
    return {'provider':provider,'fetched':len(rows),**ingest_records(rows,db)}


@app.get('/api/sources')
def sources():
    return [
        {'name':'Жилищный портал КЖК','url':'https://homeportal.kz','integration':'public-card/import','live':False},
        {'name':'Qazreestr','url':'https://qazreestr.kz','integration':'manual verification','live':False},
        {'name':'Ashyq Data — разрешения МИО','url':connectors.ASHYQ_PAGE,'integration':'public CSV sync','live':True},
        {'name':'E-License','url':'https://elicense.kz','integration':'manual verification','live':False},
        {'name':'eQurylys','url':'https://reestr.equrylys.kz/organizations','integration':'manual verification','live':False},
        {'name':'eGov','url':'https://egov.kz','integration':'manual verification','live':False},
        {'name':'КГД','url':'https://kgd.gov.kz','integration':'manual verification','live':False},
        {'name':'Реестр субъектов предпринимательства','url':'https://rsp.gov.kz','integration':'manual verification','live':False},
        {'name':'Кадастровая карта','url':'https://map.gov4c.kz/egkn/','integration':'manual verification','live':False},
        {'name':'Открытые данные РК','url':'https://data.egov.kz','integration':'manual verification','live':False},
        {'name':'Реестр недобросовестных поставщиков','url':'https://procurement.gov.kz/ru/registry/rnu','integration':'manual verification','live':False},
    ]

@app.get("/", include_in_schema=False)
def index():
    return FileResponse(ROOT / "static" / "signal_map.html")


@app.post("/api/import/uka-real-snapshot")
def import_uka_real_snapshot(db: Session = Depends(get_db)):
    """Import dated public-source snapshots, not a live scrape or verified legal conclusion."""
    import csv as _csv
    source_dir = ROOT.parent / "data"
    projects_added = ads_added = 0
    names = set(db.scalars(select(Project.name)).all())
    with (source_dir / "uka_real_projects_2026-10-17.csv").open(encoding="utf-8-sig", newline="") as f:
        for row in _csv.DictReader(f):
            if row["name"] in names: continue
            db.add(Project(name=row["name"],aliases=[],address=row["address"],district="Усть-Каменогорск",developer=row["developer"],bin="",latitude=None,longitude=None,stage=row["stage"],completion=0,registry_url=row["source_url"],legal_status="unknown",legal_basis="Требуется проверка",demo=False))
            names.add(row["name"]); projects_added+=1
    db.flush()
    all_projects = db.scalars(select(Project)).all()
    lookup = {p.name:p for p in all_projects}
    existing = set(db.execute(select(Advertisement.source_url,Advertisement.text)).all())
    with (source_dir / "uka_real_publications_2026-10-17.csv").open(encoding="utf-8-sig", newline="") as f:
        for row in _csv.DictReader(f):
            key=(row["source_url"],row["text"])
            if key in existing: continue
            analysis=analyze_text(row["text"],all_projects)
            target=lookup.get(row["project_name"])
            db.add(Advertisement(platform=row["platform"],account=row["account"],source_url=row["source_url"],posted_at=row["posted_at"],text=row["text"],project_id=target.id if target else None,analysis=analysis,review_status="pending",demo=False))
            existing.add(key); ads_added+=1
    db.commit()
    return {"projects_added":projects_added,"publications_added":ads_added,"snapshot_date":"2026-10-17","notice":"Публичные сведения, не подтверждение юридического статуса. Не является живой синхронизацией. Координаты отсутствуют до проверки."}


@app.get("/registry",include_in_schema=False)
def unified_registry_page():
    return FileResponse(ROOT / "static" / "signal_map.html")

@app.get("/geo", include_in_schema=False)
def real_geo_map():
    return FileResponse(ROOT / "static" / "signal_map.html")

@app.get("/workbench", include_in_schema=False)
def analyst_workbench():
    return FileResponse(ROOT / "static" / "signal_map.html")

@app.get("/verify", include_in_schema=False)
def verification_page():
    return FileResponse(ROOT / "static" / "signal_map.html")
