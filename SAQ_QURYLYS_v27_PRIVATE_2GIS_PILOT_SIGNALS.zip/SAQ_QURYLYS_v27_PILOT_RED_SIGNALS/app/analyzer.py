"""Real, input-dependent NLP: phrase extraction and ML-assisted entity matching.

Suggestions have no legal force and do not enter scoring before analyst acceptance.
"""
import re
from rapidfuzz import fuzz
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

PAYMENT_TERMS = re.compile(r"(?:платн(?:ая|ую|ой)\s+брон[ьи]|забронируйт[ее]?\s+за|брон(?:ь|и|ировани[ея])|депозит\w*|предоплат\w*|первоначальн\w*\s+взнос\w*|внес(?:ите|ти|ение)\s+(?:ден[еь]г|средств|\d)|оплат(?:ите|а|ить)\s+(?:брон\w*|депозит\w*|сейчас)|задаток|аван[сc]\w*|алдын\s*ала\s*т[өо]лем|бастапқы\s*жарна|кепілақы|депозит\s*т[өо]ле|брондау\s*үшін\s*т[өо]лем)", re.I)
NEGATIVE_PAYMENT = re.compile(r"(?:без\s+(?:депозит\w*|предоплат\w*|взнос\w*|аванса)|(?:бесплатн\w*|без\s+оплаты)\s+брон\w*|(?:депозит|предоплата|взнос|бронь)\s+(?:не\s+нужен|не\s+требуется|не\s+нужна)|алдын\s*ала\s*т[өо]лемсіз|депозитсіз|тегін\s*брондау)", re.I)
SALE = re.compile(r"(?:прода[её]тся|продаж[аиуе]|квартир\w*|жк\s|новостройк\w*|жил(?:ой|ого)\s+комплекс\w*|долев\w*|п[әa]тер|т[ұy]рғын\s+үй)", re.I)
AD_SIGNAL = re.compile(r"(?:прода[её]тся|продаж[аиуе]|купить|старт\s+продаж|от\s*\d[\d\s,.]*\s*(?:₸|тг|тенге|млн)|бронь|бронируйте|выберите\s+квартиру|рассрочк\w*|ипотек\w*|сатылады|сатылым|п[әa]тер\s+сату|брондау|б[өo]ліп\s*т[өo]леу)", re.I)
PRICE = re.compile(r"(?:\d[\d\s,.]{1,16})\s*(?:₸|тенге|тг|млн(?:\s*₸|\s*тг)?)", re.I)
UNDER_CONSTRUCTION = re.compile(r"(?:стро[иья]\w*|котлован\w*|на\s+этапе|сдача\s+(?:в|\d)|возвод\w*|готовност\w*|құрылыс|салынып\s+жатыр)", re.I)

def normalize(s):
    return re.sub(r"\s+", " ", re.sub(r"[^\w\s]", " ", (s or "").lower().replace("ё", "е"))).strip()

def context(text, match, radius=58):
    return text[max(0, match.start()-radius):min(len(text), match.end()+radius)].strip()

def match_project(text, projects):
    if not projects:
        return {"project_id": None, "project_name": None, "confidence": 0, "alternatives": [], "method": "tfidf+fuzzy"}
    nt = normalize(text)
    corpus = []
    per_project = []
    for p in projects:
        terms = [p.name] + (p.aliases or []) + [p.address]
        for term in terms:
            if normalize(term):
                corpus.append(normalize(term))
                per_project.append(p)
    if not corpus or not nt:
        return {"project_id": None, "project_name": None, "confidence": 0, "alternatives": [], "method": "tfidf+fuzzy"}
    # Character n-grams robustly recognize typos and variant name spellings.
    vectorizer = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), lowercase=True)
    matrix = vectorizer.fit_transform(corpus + [nt])
    similarities = cosine_similarity(matrix[-1], matrix[:-1]).ravel()
    ranked = {}
    for idx, term in enumerate(corpus):
        score = float(similarities[idx])
        if len(term) >= 4 and re.search(r"(?<!\w)" + re.escape(term) + r"(?!\w)", nt):
            score = max(score, 0.99)
        elif len(term) >= 4:
            score = max(score, 0.60 * fuzz.partial_ratio(term, nt) / 100)
        pid = per_project[idx].id
        if score > ranked.get(pid, 0): ranked[pid] = score
    top = sorted(ranked.items(), key=lambda pair: pair[1], reverse=True)
    byid = {p.id: p for p in projects}
    alternatives = [{"project_id": pid, "name": byid[pid].name, "similarity": round(value, 2)} for pid, value in top[:3]]
    best_id, best_value = top[0]
    second_value = top[1][1] if len(top) > 1 else 0
    reliable = best_value >= .60 and (best_value - second_value >= .08 or best_value >= .95)
    return {"project_id": best_id if reliable else None,
            "project_name": byid[best_id].name if reliable else None,
            "confidence": round(best_value, 2), "alternatives": alternatives, "method": "tfidf+fuzzy"}

def analyze_text(text, projects):
    text = (text or "").strip()
    if not text:
        raise ValueError("Публикация не может быть пустой")
    payment = None
    for m in PAYMENT_TERMS.finditer(text):
        neighborhood = context(text, m, 42)
        if NEGATIVE_PAYMENT.search(neighborhood):
            continue
        payment = m
        break
    sale = SALE.search(text)
    advert = AD_SIGNAL.search(text)
    promote = bool(sale and advert)
    price = PRICE.search(text)
    stage = UNDER_CONSTRUCTION.search(text)
    return {
        "model": "SAQ Explainable NLP v1 · TF-IDF+fuzzy+context rules",
        "payment": {"found": payment is not None, "snippet": context(text, payment) if payment else "",
                    "reason": "Возможно предложение внесения средств" if payment else "Прямое предложение оплаты не выявлено"},
        "advertising": {"found": promote, "snippet": context(text, advert) if promote else "",
                        "reason": "Продвижение продажи недвижимости" if promote else "Признаков продажи недостаточно"},
        "price": {"found": price is not None, "snippet": price.group() if price else ""},
        "construction_mention": {"found": stage is not None, "snippet": context(text, stage) if stage else ""},
        "matching": match_project(text, projects),
        "requires_review": True,
        "disclaimer": "Вывод ИИ является гипотезой; фактор подтверждает аналитик",
    }
