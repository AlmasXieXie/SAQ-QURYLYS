"""Production-facing v8 registry, developer analytics, and real-only ad review.

These endpoints never expose legacy demonstration records. A catalog listing
is NOT a governmental certificate or proof of active construction.
"""
from __future__ import annotations
import os
from datetime import datetime, timezone
from urllib.parse import urlparse
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import Integer, String, Text, DateTime, ForeignKey, select
from sqlalchemy.orm import Mapped, mapped_column, Session
from app.database import Base, get_db
from app.unified_registry import (RegistryBuilding, RegistryAuthorization, keyify, building_payload)
from app.extra_problem_sites import all_real_keys as catalog_keys
from app.real_enrichment import enrich
from app.catalog_details_v8 import decorate
from app import geocode_2gis as geo
from app.analyzer import PAYMENT_TERMS, NEGATIVE_PAYMENT, AD_SIGNAL, UNDER_CONSTRUCTION
from app.auto_decisions import evaluate_building, decide_ad

router=APIRouter(prefix='/api/v8',tags=['Реальная аналитика v8'])

class RegistryAd(Base):
    __tablename__='registry_ad_monitoring'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    building_id:Mapped[int|None]=mapped_column(ForeignKey('unified_buildings.id'),nullable=True,index=True)
    platform:Mapped[str]=mapped_column(String(40))
    url:Mapped[str]=mapped_column(String(700),unique=True,index=True)
    text:Mapped[str]=mapped_column(Text)
    account:Mapped[str]=mapped_column(String(200),default='')
    status:Mapped[str]=mapped_column(String(32),default='pending')
    reviewed_by:Mapped[str]=mapped_column(String(100),default='')
    added_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))

class AdInput(BaseModel):
    building_id:int|None=None
    url:str=Field(min_length=13,max_length=700)
    text:str=Field(min_length=5,max_length=20000)
    platform:str=Field(default='manual',max_length=40)
    account:str=Field(default='',max_length=200)

class AdReview(BaseModel):
    status:str
    reviewer:str=Field(min_length=2,max_length=100)
    building_id:int|None=None

def check_url(s):
    parsed=urlparse(s)
    return parsed.scheme in ('https','http') and bool(parsed.hostname) and parsed.hostname not in ('localhost','127.0.0.1')

def record(db,b):
    p=building_payload(db,b)
    dev,facts,extra_permits=decorate(p)
    return {**p,'profile':enrich(p),'developer':dev,'facts':facts,'additional_permits':extra_permits}

def catalog(db):
    keys=catalog_keys()
    return [record(db,b) for b in db.scalars(select(RegistryBuilding).order_by(RegistryBuilding.name)).all() if b.building_key in keys]

def ad_analysis(text):
    pay=bool(PAYMENT_TERMS.search(text) and not NEGATIVE_PAYMENT.search(text))
    return {'advertising_terms':bool(AD_SIGNAL.search(text)),'payment_terms':pay,
            'construction_terms':bool(UNDER_CONSTRUCTION.search(text)),
            'assessment':'Требуется проверка аналитиком' if pay else 'Нет подтверждённого нарушения',
            'disclaimer':'Ключевые слова — не доказательство незаконного привлечения денег.'}

def ad_out(a,building_by_id=None,decision=None):
    analysis=ad_analysis(a.text)
    if decision and decision.get('color')=='green':
        analysis['assessment']='Применимое основание по ЖК подтверждено (сверить корпус, продавца и ДДУ)'
    return {'id':a.id,'building_id':a.building_id,'building_name':(building_by_id or {}).get(a.building_id),
      'url':a.url,'platform':a.platform,'account':a.account,'text':a.text,
      'status':a.status,'reviewed_by':a.reviewed_by,'added_at':a.added_at.isoformat() if a.added_at else '',
      'analysis':analysis,
      'legal_assessment':decision or {'color':'yellow','label':'ЖК не сопоставлен','reason':'Без точной привязки к проекту право привлечения дольщиков не подтверждено.'}}

@router.get('/settings')
def settings():
    # MapGL requires client-visible key. Keep private data/service credentials elsewhere.
    return {'map_provider':'2gis','mapgl_key':os.getenv('SAQ_2GIS_KEY','').strip(),
      'has_key':geo.key_available(),'geocoder_service':'not_verified','legacy_demo_visible':False}

@router.get('/catalog')
def get_catalog(db:Session=Depends(get_db)):
    return catalog(db)

@router.get('/catalog/{building_id}')
def get_project(building_id:int,db:Session=Depends(get_db)):
    b=db.get(RegistryBuilding,building_id)
    if not b or b.building_key not in catalog_keys():raise HTTPException(404,'ЖК не найден в совокупном каталоге')
    return record(db,b)

@router.get('/developers')
def developers(db:Session=Depends(get_db)):
    groups={}
    for b in catalog(db):
        d=b['developer']; name=d['name']
        if name=='Не установлен':
            # The government list has four projects with unknown legal entities.
            # Show them explicitly rather than hiding the original public match.
            name='Юрлицо уточняется — '+b['name']
        if name not in groups:
            groups[name]={'name':name,'site':d.get('site'),'instagram':d.get('instagram'),'project_page':d.get('project_page'),
               'bin':d.get('bin') or d.get('registered_bin'), 'bin_source':d.get('bin_source'),
               'bin_note':d.get('bin_role') or 'БИН и юридическая роль требуют подтверждения',
               'identity_level':d['identity_level'],'projects':[]}
        original=db.get(RegistryBuilding,b['id'])
        decision,linked=evaluate_building(db,original)
        groups[name]['projects'].append({'id':b['id'],'name':b['name'],
             'map_color':decision['map_color'],'decision_label':decision['map_status_label'],
             'authorization_verified':decision['authorization_verified'],
             'kzhk':next((x for x in linked['docs'] if x['type']=='kzhk_guarantee' and x['status'].startswith('official')),None),
             'mio':next((x for x in linked['docs'] if x['type']=='mio_equity_permit' and x['status'].startswith('official')),None),
             'mio_reported':next((x for x in linked['docs'] if x['type']=='mio_equity_permit' and not x['status'].startswith('official') and 'НЕ ОПУБЛИКОВАН' not in x['number']),None),
             'bank_participation':any(x['type']=='mio_equity_permit' and 'БВУ' in x['notes'] for x in linked['docs']),
             'document_scope':linked['scope']})
    for group in groups.values():
        counts={color:sum(p['map_color']==color for p in group['projects']) for color in ('green','yellow','red')}
        group['status_counts']=counts
        group['display_status']=('Все связанные ЖК имеют подтверждённое основание' if counts['green']==len(group['projects']) else
          f"Есть подтверждение для {counts['green']} из {len(group['projects'])} ЖК" if counts['green'] else
          'Применимые основания по проектам ещё не подтверждены')
    return sorted(groups.values(),key=lambda x:(-len(x['projects']),x['name'].casefold()))

@router.get('/analytics')
def analytics(db:Session=Depends(get_db)):
    c=catalog(db);devs={x['developer']['name'] for x in c if x['developer']['name']!='Не установлен'}
    ads=db.scalars(select(RegistryAd)).all()
    docs=sum(bool(x['authorizations'] or x['additional_permits']) for x in c)
    return {'buildings':len(c),'developer_labels':len(developers(db)),
      'developer_unknown':sum(x['developer']['name']=='Не установлен' for x in c),
      'mapped':sum(x['latitude'] is not None and x['longitude'] is not None for x in c),
      'unmapped':sum(x['latitude'] is None or x['longitude'] is None for x in c),
      'with_document_claims':docs,'without_linked_documents':len(c)-docs,
      'ads':len(ads),'unreviewed_ads':sum(x.status=='pending' for x in ads),
      'payment_language':sum(ad_analysis(x.text)['payment_terms'] for x in ads),
      'risk_verdicts':0,
      'mode':'real_catalog_no_demo','data_status':'40_existing_plus_4_uga_vko_official_project_mentions',
      'warning':'44 объекта: 40 прежнего каталога и 4 из официального перечня ВКО без геокоординат. Статусы основаны на источниках и не заменяют юридическую проверку сделки.'}

@router.get('/ads')
def ads(db:Session=Depends(get_db)):
    buildings={b.id:b for b in db.scalars(select(RegistryBuilding)).all() if b.building_key in catalog_keys()}
    names={b.id:b.name for b in buildings.values()}
    decisions={bid:evaluate_building(db,b) for bid,b in buildings.items()}
    return [ad_out(a,names,decide_ad({'building_id':a.building_id,'text':a.text},*decisions[a.building_id])
                   if a.building_id in decisions else None)
            for a in db.scalars(select(RegistryAd).order_by(RegistryAd.id.desc())).all()
            if a.building_id is None or a.building_id in names]

@router.post('/ads',status_code=201)
def add_ad(body:AdInput,db:Session=Depends(get_db)):
    if not check_url(body.url):raise HTTPException(422,'Нужна прямая публичная HTTP(S)-ссылка на публикацию')
    if body.building_id is not None:
        b=db.get(RegistryBuilding,body.building_id)
        if not b or b.building_key not in catalog_keys():raise HTTPException(422,'Выбранный ЖК не входит в текущий каталог')
    prev=db.scalar(select(RegistryAd).where(RegistryAd.url==body.url))
    if prev:raise HTTPException(409,'Публикация с такой ссылкой уже есть')
    rec=RegistryAd(building_id=body.building_id,url=body.url,text=body.text,platform=body.platform,account=body.account)
    db.add(rec);db.commit();db.refresh(rec)
    dec,link=evaluate_building(db,b) if body.building_id is not None else ({}, {})
    return ad_out(rec, {b.id:b.name} if body.building_id is not None else None,
                  decide_ad({'building_id':rec.building_id,'text':rec.text},dec,link) if rec.building_id else None)

@router.post('/ads/{ad_id}/review')
def review_ad(ad_id:int,body:AdReview,db:Session=Depends(get_db)):
    if body.status not in ('pending','accepted','rejected'):raise HTTPException(422,'Недопустимый статус')
    a=db.get(RegistryAd,ad_id)
    if not a:raise HTTPException(404,'Публикация не найдена')
    if body.building_id is not None:
        b=db.get(RegistryBuilding,body.building_id)
        if not b or b.building_key not in catalog_keys():raise HTTPException(422,'ЖК не входит в каталог')
        a.building_id=body.building_id
    if body.status=='accepted' and a.building_id is None:raise HTTPException(422,'Перед подтверждением укажите ЖК')
    a.status=body.status;a.reviewed_by=body.reviewer;db.commit();db.refresh(a)
    b=db.get(RegistryBuilding,a.building_id) if a.building_id else None
    dec,link=evaluate_building(db,b) if b else ({},{})
    return ad_out(a,{b.id:b.name} if b else None, decide_ad({'building_id':a.building_id,'text':a.text},dec,link) if b else None)

@router.get('/geocode/status')
def geostatus():
    return {**geo.STATUS,'key_ready':geo.key_available(), 'candidates':len(geo.CANDIDATES)}

@router.get('/geocode/candidates/{building_id}')
def candidates(building_id:int):return geo.CANDIDATES.get(building_id,[])

@router.post('/geocode/start')
def start_geocode(background:BackgroundTasks):
    if not geo.key_available():raise HTTPException(422,'Отсутствует ключ 2ГИС в .env')
    with geo.lock:
        if geo.STATUS['scheduled'] or geo.STATUS['running']:
            return dict(geo.STATUS)
        geo.STATUS['scheduled']=True
    background.add_task(geo.run_geocoding)
    return {**geo.STATUS,'note':'Ищем ТОЛЬКО точные одиночные адреса через Geocoder 2ГИС. Проверка права доступа к Geocoder API происходит при запросе.'}
