"""Normalized records for sources, projects, advertising and human decisions."""
from datetime import datetime, timezone
from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, JSON, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database import Base

def utcnow():
    return datetime.now(timezone.utc)

class Project(Base):
    __tablename__ = "projects"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(180), unique=True, index=True)
    aliases: Mapped[list] = mapped_column(JSON, default=list)
    address: Mapped[str] = mapped_column(String(300))
    district: Mapped[str] = mapped_column(String(120), default="")
    latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    longitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    developer: Mapped[str] = mapped_column(String(180))
    bin: Mapped[str] = mapped_column(String(12), default="")
    stage: Mapped[str] = mapped_column(String(120))
    completion: Mapped[int] = mapped_column(Integer, default=0)
    claimed_completion: Mapped[int | None] = mapped_column(Integer, nullable=True)
    registry_url: Mapped[str] = mapped_column(String(500), default="")
    coordinate_source: Mapped[str] = mapped_column(String(500), default="")
    boundary_geojson: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    boundary_source: Mapped[str] = mapped_column(String(500), default="")
    boundary_checked_by: Mapped[str] = mapped_column(String(120), default="")
    boundary_checked_at: Mapped[str] = mapped_column(String(40), default="")
    legal_status: Mapped[str] = mapped_column(String(30), default="unknown")
    legal_basis: Mapped[str] = mapped_column(String(250), default="")
    legal_source: Mapped[str] = mapped_column(String(500), default="")
    legal_checked_at: Mapped[str] = mapped_column(String(40), default="")
    completion_source: Mapped[str] = mapped_column(String(300), default="")
    claimed_source: Mapped[str] = mapped_column(String(300), default="")
    verified_complaint: Mapped[bool] = mapped_column(Boolean, default=False)
    complaint_evidence: Mapped[str] = mapped_column(String(250), default="")
    verified_delay: Mapped[bool] = mapped_column(Boolean, default=False)
    delay_evidence: Mapped[str] = mapped_column(String(250), default="")
    demo: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    ads: Mapped[list["Advertisement"]] = relationship(back_populates="project", cascade="all, delete-orphan")
    signals: Mapped[list["Signal"]] = relationship(back_populates="project", cascade="all, delete-orphan")

class Advertisement(Base):
    __tablename__ = "advertisements"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    project_id: Mapped[int | None] = mapped_column(ForeignKey("projects.id"), index=True, nullable=True)
    platform: Mapped[str] = mapped_column(String(30), default="manual")
    account: Mapped[str] = mapped_column(String(100), default="")
    source_url: Mapped[str] = mapped_column(String(500), default="")
    posted_at: Mapped[str] = mapped_column(String(30), default="")
    captured_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    text: Mapped[str] = mapped_column(Text)
    image_path: Mapped[str] = mapped_column(String(350), default="")
    analysis: Mapped[dict] = mapped_column(JSON, default=dict)
    review_status: Mapped[str] = mapped_column(String(24), default="pending")
    reviewed_by: Mapped[str] = mapped_column(String(120), default="")
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    demo: Mapped[bool] = mapped_column(Boolean, default=True)
    project: Mapped[Project | None] = relationship(back_populates="ads")

class Signal(Base):
    __tablename__ = "signals"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    score_snapshot: Mapped[int] = mapped_column(Integer)
    zone_snapshot: Mapped[str] = mapped_column(String(20))
    factors_snapshot: Mapped[list] = mapped_column(JSON, default=list)
    status: Mapped[str] = mapped_column(String(30), default="pending")
    author: Mapped[str] = mapped_column(String(120), default="")
    note: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    project: Mapped[Project] = relationship(back_populates="signals")


class RegistryPermit(Base):
    __tablename__ = 'registry_permits'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    permission_key: Mapped[str] = mapped_column(String(300), unique=True, index=True)
    permission_number: Mapped[str] = mapped_column(String(130), default='')
    project_name: Mapped[str] = mapped_column(String(400), default='')
    developer: Mapped[str] = mapped_column(String(300), default='')
    issue_date: Mapped[str] = mapped_column(String(60), default='')
    source_url: Mapped[str] = mapped_column(String(500), default='')
    imported_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    metadata_original: Mapped[dict] = mapped_column(JSON, default=dict)
