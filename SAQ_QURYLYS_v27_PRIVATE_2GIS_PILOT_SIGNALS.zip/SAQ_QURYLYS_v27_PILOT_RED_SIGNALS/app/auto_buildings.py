"""Exact-address association of registry ЖК with 2GIS building features.

The matching is conditional: 2GIS Places API access is needed for the live job.
Only unique exact-address building matches become associations. Records carry an
explicit automated/unverified provenance; the job does not invent geometries.
"""
from __future__ import annotations

import asyncio
import json
import os
import re
from datetime import datetime, timezone
from threading import Lock
from urllib.parse import quote

import httpx
from sqlalchemy import select
from app.database import SessionLocal
from app.extra_problem_sites import all_real_keys
from app.geocode_2gis import compare, parts
from app.unified_registry import RegistryBuilding
from app.v9_api import GeometryLink, local_polygon

API='https://catalog.api.2gis.com/3.0/items/geocode'
BYID='https://catalog.api.2gis.com/3.0/items/byid'
FIELDS='items.point,items.address,items.geometry.selection,items.full_address_name'
STATE={'running':False,'scheduled':False,'processed':0,'total':0,'linked':0,'already_linked':0,'ambiguous':0,'without_geometry':0,'skipped':0,'errors':0,'last_error':'','last_run':None,'osm_running':False,'osm_linked':0,'osm_error':''}
GUARD=Lock()

def is_conflicted(name,address):
    s=(name+' '+address).casefold()
    # These locations have competing addresses / overlapping project claims in
    # the original registry: do not auto-bind them until an analyst resolves them.
    return any(x in s for x in ('gran via','astoria','asylym','diamond'))

def eligible(name,address):
    return bool(parts(address)) and not is_conflicted(name,address)

def geometry_to_polygon(value):
    """Accept only actual polygon geometry in WKT/GeoJSON form from provider."""
    if isinstance(value,dict):
        if value.get('type')=='Feature':value=value.get('geometry')
        elif value.get('type')=='GeometryCollection':return None
        if value.get('type')=='Polygon':
            coords=value.get('coordinates')
            polygon={'type':'Polygon','coordinates':coords}
            return polygon if local_polygon(polygon) else None
        if 'wkt' in value:return geometry_to_polygon(value['wkt'])
        if 'selection' in value:return geometry_to_polygon(value['selection'])
        return None
    if isinstance(value,list):
        for item in value:
            result=geometry_to_polygon(item)
            if result:return result
        return None
    if not isinstance(value,str):return None
    value=value.strip()
    if value.startswith('{'):
        try:return geometry_to_polygon(json.loads(value))
        except ValueError:return None
    # Some 2GIS variants encode selection as WKT. Only outer ring in a basic
    # POLYGON is accepted; never approximate a footprint from a centroid.
    match=re.fullmatch(r'POLYGON\s*\(\(\s*(.*?)\s*\)\)',value,re.I|re.S)
    if not match:return None
    ring=[]
    try:
        for piece in match.group(1).split(','):
            pair=piece.strip().split()
            if len(pair)!=2:return None
            ring.append([float(pair[0]),float(pair[1])])
    except ValueError:return None
    result={'type':'Polygon','coordinates':[ring]}
    return result if local_polygon(result) else None

def exact_match_candidates(items,address):
    matching=[item for item in items if item.get('type')=='building' and compare(item,address)]
    # Some server results omit `type` for buildings on geocoder. A candidate
    # must have type='building' or subtype indicating a building to be accepted.
    if not matching:
        matching=[item for item in items if item.get('subtype') in ('building','building.home') and compare(item,address)]
    return matching

def to_link_fields(item,name,address):
    point=item.get('point') or {}
    try:lat,lon=float(point['lat']),float(point['lon'])
    except (KeyError,ValueError,TypeError):return None
    if not (49.65<=lat<=50.25 and 82.2<=lon<=83.05):return None
    fid=str(item.get('id') or '')
    if not re.fullmatch(r'\d{1,32}',fid):return None
    poly=geometry_to_polygon((item.get('geometry') or {}).get('selection'))
    return {'feature_id':fid,'polygon':poly,'position':[lon,lat],
            'source_url':f'https://2gis.kz/ust-kamenogorsk/geo/{fid}',
            'note':f'Автосопоставление: точное совпадение адреса {address}; корпус и стадия стройки документально не подтверждены'[:400]}

def save_match(project_id,item,address):
    """Store unique consistent matches; preserve previous manual assignments."""
    from app.geocode_2gis import compare
    if not compare(item,address):return 'ambiguous'
    fields=to_link_fields(item,'',address)
    if not fields:return 'ambiguous'
    with SessionLocal() as db:
        b=db.get(RegistryBuilding,project_id)
        if not b or b.building_key not in all_real_keys() or not eligible(b.name,b.address):return 'skipped'
        current=db.scalar(select(GeometryLink).where(GeometryLink.provider=='2gis',GeometryLink.feature_id==fields['feature_id']))
        if current:return 'already_linked' if current.building_id==project_id else 'ambiguous'
        # Do not assign a second 2GIS building to a single-address ЖК.
        already=db.scalar(select(GeometryLink).where(GeometryLink.building_id==project_id,GeometryLink.provider=='2gis'))
        if already:return 'already_linked'
        db.add(GeometryLink(building_id=project_id,provider='2gis',**fields,linked_by='Автоматически: точный адрес 2ГИС',association_method='auto_exact_address'))
        if b.latitude is None and b.longitude is None:
            b.latitude,b.longitude=fields['position'][1],fields['position'][0]
            b.coordinate_source='2GIS_EXACT_ADDRESS_AUTO:'+fields['feature_id']
        db.commit()
    return 'linked' if fields['polygon'] else 'without_geometry'

async def query_address(client,address,key):
    r=await client.get(API,params={'q':address+', Казахстан','type':'building','fields':FIELDS,'page_size':10,'key':key})
    if r.status_code in (401,402,403,429):raise PermissionError(f'2ГИС вернул HTTP {r.status_code}: ключ не предоставляет доступ к Places/Geocoder API')
    r.raise_for_status()
    data=r.json()
    code=data.get('meta',{}).get('code')
    if code not in (200,None):raise ValueError('Ответ 2ГИС: код '+str(code))
    return (data.get('result') or {}).get('items') or []

async def run():
    with GUARD:
        if STATE['running']:return
        STATE.update(running=True,scheduled=False,processed=0,total=0,linked=0,already_linked=0,ambiguous=0,without_geometry=0,skipped=0,errors=0,last_error='',osm_linked=0,osm_error='')
    try:
        key=os.getenv('SAQ_2GIS_KEY','').strip()
        if not key:raise PermissionError('Нет ключа 2ГИС')
        with SessionLocal() as db:
            records=[(b.id,b.name,b.address) for b in db.scalars(select(RegistryBuilding)).all() if b.building_key in all_real_keys()]
        STATE['total']=len(records)
        async with httpx.AsyncClient(timeout=15,follow_redirects=False) as client:
            for project_id,name,address in records:
                try:
                    if not eligible(name,address):STATE['skipped']+=1;continue
                    with SessionLocal() as db:
                        existing=db.scalar(select(GeometryLink).where(GeometryLink.building_id==project_id,GeometryLink.provider=='2gis'))
                    if existing:STATE['already_linked']+=1;continue
                    items=await query_address(client,address,key)
                    matched=exact_match_candidates(items,address)
                    if len(matched)!=1:STATE['ambiguous']+=1;continue
                    state=save_match(project_id,matched[0],address)
                    STATE[state]+=1
                except PermissionError:
                    raise
                except Exception as error:
                    STATE['errors']+=1
                    STATE['last_error']=f'Один адрес: {type(error).__name__}: {str(error)[:90]}'
                finally:
                    STATE['processed']+=1
                await asyncio.sleep(0.3)
    except (PermissionError,httpx.HTTPError) as error:
        STATE['last_error']=str(error)[:220]
    finally:
        with GUARD:
            STATE['running']=False;STATE['scheduled']=False
            STATE['last_run']=datetime.now(timezone.utc).isoformat()

def status():
    info=dict(STATE)
    info['running']=bool(info['running'] or info['scheduled'] or info['osm_running'])
    return info

def schedule():
    with GUARD:
        if STATE['running'] or STATE['scheduled'] or STATE['osm_running']:return False
        STATE['scheduled']=True
    return True

async def match_clicked(feature_id):
    """Resolve a clicked 2GIS vector building ID to an exact-address ЖК."""
    if not re.fullmatch(r'\d{1,32}',str(feature_id)):
        return {'linked':False,'reason':'Не ID здания 2ГИС'}
    with SessionLocal() as db:
        existing=db.scalar(select(GeometryLink).where(GeometryLink.provider=='2gis',GeometryLink.feature_id==str(feature_id)))
        if existing:return {'linked':True,'building_id':existing.building_id,'source':'saved'}
    key=os.getenv('SAQ_2GIS_KEY','').strip()
    if not key:return {'linked':False,'reason':'Не задан ключ 2ГИС'}
    try:
        async with httpx.AsyncClient(timeout=12,follow_redirects=False) as client:
            r=await client.get(BYID,params={'id':str(feature_id),'fields':FIELDS,'key':key})
            if r.status_code in (401,402,403):return {'linked':False,'reason':'Нет доступа Places API в ключе 2ГИС'}
            r.raise_for_status()
            items=(r.json().get('result') or {}).get('items') or []
    except (httpx.HTTPError,ValueError):return {'linked':False,'reason':'Не удалось получить адрес здания из 2ГИС'}
    if len(items)!=1:return {'linked':False,'reason':'Нет однозначной карточки здания'}
    item=items[0]
    if str(item.get('id'))!=str(feature_id):return {'linked':False,'reason':'ID карточки не совпадает'}
    with SessionLocal() as db:
        matches=[b for b in db.scalars(select(RegistryBuilding)).all() if b.building_key in all_real_keys() and eligible(b.name,b.address) and compare(item,b.address)]
    if len(matches)!=1:return {'linked':False,'reason':'Адрес здания не имеет однозначного совпадения с ЖК в реестре'}
    state=save_match(matches[0].id,item,matches[0].address)
    if state in ('linked','without_geometry','already_linked'):
        return {'linked':True,'building_id':matches[0].id,'source':state}
    return {'linked':False,'reason':'Привязка неоднозначна'}

# Independent fallback: exactly addressed and genuinely surveyed OSM building
# footprints. This does NOT synthesize a rectangle from an address point.
OSM_API='https://overpass-api.de/api/interpreter'
OSM_STATE={'processed':0,'linked':0,'ambiguous':0,'last_error':''}

def osm_query(projects):
    numbers=[]
    for _,name,address in projects:
        if eligible(name,address):
            value=parts(address)[1].replace(' ', '')
            if value not in numbers:numbers.append(value)
    if not numbers:return None
    expr='|'.join(re.escape(n) for n in numbers)
    # Search actual OSM building outlines with the same house numbers. A
    # street name still has to match *exactly* before saving a link.
    return f'[out:json][timeout:40];way["building"]["addr:housenumber"~"^({expr})$",i](49.80,82.30,50.10,82.90);out geom 6000;'

def canonical_street(text):
    from app.geocode_2gis import normalize
    text=re.sub(r'(?i)^(ул(?:ица)?\\.?|пр(?:оспект)?\\.?|улица|проспект)\\s+', '',text.strip())
    text=re.sub(r'(?i)^(ильяса|каныша|ю\\.)\\s+', '',text)
    return normalize(text)

def osm_address_exact(item, address):
    parsed=parts(address)
    if not parsed:return False
    expected_street, expected_no=parsed
    tags=item.get('tags') or {}
    street=tags.get('addr:street','')
    number=tags.get('addr:housenumber','')
    from app.geocode_2gis import normalize
    return bool(street and number and canonical_street(street)==canonical_street(expected_street)
                and normalize(number)==normalize(expected_no))

def osm_polygon(item):
    geo=item.get('geometry') or []
    try:ring=[[float(pt['lon']),float(pt['lat'])] for pt in geo]
    except (ValueError,TypeError,KeyError):return None
    polygon={'type':'Polygon','coordinates':[ring]}
    return polygon if local_polygon(polygon) else None

async def run_osm():
    OSM_STATE.update(processed=0,linked=0,ambiguous=0,last_error='')
    with SessionLocal() as db:
        projects=[(b.id,b.name,b.address) for b in db.scalars(select(RegistryBuilding)).all() if b.building_key in all_real_keys()]
    query=osm_query(projects)
    if not query:return
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(49,connect=10),follow_redirects=False) as client:
            response=await client.post(OSM_API,data={'data':query},headers={'User-Agent':'SAQ-Qurylys/10 (research, exact-address match)'})
            response.raise_for_status()
            if len(response.content)>12_000_000:raise ValueError('Слишком большой ответ Overpass')
            raw=response.json().get('elements') or []
        for project_id,name,address in projects:
            if not eligible(name,address):continue
            OSM_STATE['processed']+=1
            candidates=[x for x in raw if x.get('type')=='way' and osm_address_exact(x,address) and osm_polygon(x)]
            if len(candidates)!=1:
                OSM_STATE['ambiguous']+=1
                continue
            item=candidates[0]
            ident=str(item['id'])
            with SessionLocal() as db:
                original=db.get(RegistryBuilding,project_id)
                if not original or original.building_key not in all_real_keys():continue
                linked=db.scalar(select(GeometryLink).where(GeometryLink.provider=='osm',GeometryLink.feature_id==ident))
                if linked:continue
                if db.scalar(select(GeometryLink).where(GeometryLink.building_id==project_id,GeometryLink.provider=='osm')):continue
                polygon=osm_polygon(item)
                db.add(GeometryLink(building_id=project_id,provider='osm',feature_id=ident,polygon=polygon,
                    position=None,source_url=f'https://www.openstreetmap.org/way/{ident}',
                    linked_by='Автоматически: точный адрес OSM',association_method='auto_exact_address_osm',
                    note='Реальная геометрия OSM и единственный точный адрес; фактическая стройка и корпус требуют проверки'))
                if original.latitude is None and original.longitude is None:
                    coords=polygon['coordinates'][0]
                    original.longitude=sum(p[0] for p in coords[:-1])/(len(coords)-1)
                    original.latitude=sum(p[1] for p in coords[:-1])/(len(coords)-1)
                    original.coordinate_source='OSM_EXACT_ADDRESS_AUTO:'+ident
                db.commit();OSM_STATE['linked']+=1
    except (httpx.HTTPError,ValueError) as error:
        OSM_STATE['last_error']=str(error)[:180]

async def run_all():
    # 2GIS and OSM are separate data entitlements and may succeed separately.
    # OSM processing still proceeds if 2GIS Places access is not authorized.
    STATE['osm_running']=True
    await run()
    try:await run_osm()
    finally:
        STATE['osm_running']=False
        STATE['osm_linked']=OSM_STATE['linked']
        STATE['osm_error']=OSM_STATE['last_error']
