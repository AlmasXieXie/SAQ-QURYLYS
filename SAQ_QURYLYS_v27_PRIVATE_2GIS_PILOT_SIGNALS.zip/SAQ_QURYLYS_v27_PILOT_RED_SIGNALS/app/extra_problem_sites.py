"""Specifically sourced problem construction projects absent from 38-item Krisha catalog.

Separate from a current-stage assertion. No inherited, fabricated geocoordinates.
A building address in a mapping directory is not a verified parcel or footprint.
"""
from app.unified_registry import RegistryBuilding,insert_evidence,upsert_company,keyify
from sqlalchemy.orm import Session
from sqlalchemy import select

EXTRA=[
 {
  'name':'ЖК Diamond',
  'address':'Усть-Каменогорск, пересечение ул. Ю. Увалиева и ул. Кокжал Барака, 19-й жилой район',
  'developer':'ATQ Corporate (указано в 2ГИС; юридическая роль не подтверждена)',
  'stage':'reported_unfinished',
  'sources':[
   ('khc','https://khc.kz/ru/press-center/announcements/3837/',
    'КЖК, 22.01.2026: гарантийный случай, незавершённое строительство ЖК Diamond; приглашение инвесторов завершить объект.','official'),
   ('2gis','https://2gis.kz/ustkam/firm/70000001059877798',
    'В 2ГИС представлена карточка Diamond на Увалиева 7стр. Адрес отличается от описания участка в КЖК; координаты из старой версии отозваны.','third_party_claim')]
 },
 {
  'name':'ЖК Astoria',
  'address':'Усть-Каменогорск, ул. Кокжал Барака, 18а, 18б, 18в',
  'developer':'ТОО «Дейнека» (по данным Korter; требуется проверка роли)',
  'stage':'reported_problem_site',
  'sources':[
   ('media','https://sozmedia.kz/111398/',
    '28.01.2026: проблемное строительство ЖК Astoria; сообщено о работе по завершению.','media_report'),
   ('media','https://yk-news.kz/news/v-ust-kamenogorske-vyyavili-narusheniya-v-sfere-stroitelstva-72330',
    'Сообщалось о возобновлении строительно-монтажных работ и планируемом завершении во II квартале 2026. Состояние на 17.10.2026 не проверено.','media_report'),
   ('korter','https://korter.kz/жк-astoria-усть-каменогорск',
    'Каталог Korter указывает 3 корпуса на Кокжал Барака 18а-в и застройщика Дейнека; актуальность требует проверки.','third_party_claim')]
 },
]


def extra_keys():return {'uka:problem:'+keyify(item['name']) for item in EXTRA}


def all_real_keys():
    from app.catalog_uka import catalog_keys
    from app.official_mio_v26 import gov_keys
    return catalog_keys()|extra_keys()|gov_keys()


def load_extra(db:Session):
    added=0
    for item in EXTRA:
        key='uka:problem:'+keyify(item['name'])
        b=db.scalar(select(RegistryBuilding).where(RegistryBuilding.building_key==key))
        if b is None:
            # Label is not a verified legal identity.
            company=upsert_company(db,item['developer'])
            b=RegistryBuilding(building_key=key,name=item['name'],address=item['address'],
                developer_label=item['developer'],stage_reported=item['stage'],stage_verified='unknown',
                latitude=None,longitude=None,coordinate_source='',company_id=company.id if company else None)
            db.add(b);db.flush();added+=1
        for source,url,text,level in item['sources']:
            insert_evidence(db,source,url,text,level,b.id,b.company_id,
                raw_fields={'checked_on':'2026-10-17','source_as_of':'2026-01' if source=='khc' else '2026'})
    db.commit();return added
