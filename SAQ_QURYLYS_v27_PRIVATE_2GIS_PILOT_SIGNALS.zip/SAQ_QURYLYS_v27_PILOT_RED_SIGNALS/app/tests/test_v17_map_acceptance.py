"""Release blockers introduced by the blank-map incident (v16).

These tests deliberately do NOT pretend unknown coordinates are geocoded.
A separate strict acceptance command fails unless 40 real coords are present.
"""
from pathlib import Path
import sqlite3
import importlib.util
from fastapi.testclient import TestClient
from app.main import app
from app.developer_bins import CORPORATE_BINS

ROOT=Path(__file__).resolve().parents[2]


def test_map_first_boot_never_silent_empty():
    with TestClient(app) as c:
        r=c.get('/api/signal-map/snapshot').json()
        assert r['total']==44
        assert sum(r['counts'].values())==44
        assert r['mapped']+r['without_coordinates']==44
        assert all(p['map_color'] in ('red','yellow','green') for p in r['items'])
        assert r['visibility_issue'] == ('no_coordinates' if r['mapped']==0 else 'partial_coordinates' if r['mapped']<40 else None)
        page=c.get('/').text
        assert 'id="unlocated-pins"' in page  # on-map clickable cards for unlocated ЖК
        assert 'id="city-map"' in page
        assert page.count('data-view="') >= 9
        assert c.get('/api/health').json()['version']=='27.0.0'


def test_sourced_bin_records_not_licenses():
    assert len(CORPORATE_BINS)>=15
    for label,(bin_id,source,entity) in CORPORATE_BINS.items():
        assert len(bin_id)==12 and bin_id.isdigit(), label
        assert source.startswith('https://'),label
    # Cited BINs are company identity only and do not imply a building permit.
    assert 'НЕ подтверждает' in (ROOT/'app/developer_bins.py').read_text()


def test_v16_bootstrap_recovers_existing_db(tmp_path, monkeypatch):
    monkeypatch.delenv('SAQ_DATABASE_URL', raising=False)
    modpath=ROOT/'scripts/bootstrap_v16.py'
    spec=importlib.util.spec_from_file_location('saq_v17_boot',modpath)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    old=tmp_path/'SAQ_QURYLYS_v16_SIGNAL_MAP'
    new=tmp_path/'SAQ_QURYLYS_v17_SIGNAL_MAP'
    old.mkdir();new.mkdir()
    db=old/'saq.sqlite3'
    with sqlite3.connect(db) as c:
        c.execute('CREATE TABLE unified_buildings (id INTEGER PRIMARY KEY, lat REAL, lon REAL)')
        c.execute('CREATE TABLE registry_ad_monitoring (id INTEGER PRIMARY KEY)')
        c.executemany('INSERT INTO unified_buildings (lat,lon) VALUES (?,?)',[(49.9,82.5)]*25)
        c.commit()
    result=mod.copy_previous_database(new)
    assert result['status']=='copied',result
    assert result['source_version']==old.name
    with sqlite3.connect(new/'saq.sqlite3') as c:
        assert c.execute('SELECT count(*) FROM unified_buildings WHERE lat IS NOT NULL').fetchone()[0]==25
    assert db.is_file() # never modify previous DB


def test_frontend_has_both_pin_and_unlocated_click_routes():
    js=(ROOT/'app/static/signal_map.js').read_text()
    assert 'function markerHTML' in js
    assert 'function renderUnlocated' in js
    assert 'data-pin=' in js
    assert 'data-case=' in js
    assert 'startGeoCheck' in js
