"""OCR, URL, record linking and RSS importer must never imply illegal conduct."""
from io import BytesIO
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from app.database import Base,get_db
from app.main import app
from app.unified_registry import load_starter
from app.catalog_uka import load_catalog
from app.extra_problem_sites import load_extra
from app.ad_verification_api import ocr_image, public_url

@pytest.fixture
def client():
    e=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(e)
    Session=sessionmaker(bind=e)
    with Session() as s:load_starter(s);load_catalog(s);load_extra(s)
    def db_override():
        with Session() as s:yield s
    app.dependency_overrides[get_db]=db_override
    with TestClient(app) as c:yield c
    app.dependency_overrides.clear();e.dispose()


def test_ocr_text_to_real_project_and_thirdparty_evidence(client):
    r=client.post('/api/v12/verify/text',json={'text':'ЖК AINALAIYN. Бронь. Первоначальный взнос 200 000 ₸.'})
    assert r.status_code==200
    x=r.json()
    assert x['project']['name']=='ЖК AINALAIYN'
    assert x['status']=='documents_require_check'
    assert x['document_evidence'][0]['number']=='KZ40VWE00002526'
    assert x['document_evidence'][0]['status_in_registry']=='reported_third_party'
    assert 'НЕ' in x['disclaimer']


def test_nonmatching_does_not_accuse(client):
    r=client.post('/api/v12/verify/text',json={'text':'Долевое участие аванс недостроенный ЖК Новый супердом'}).json()
    assert r['status']=='project_not_identified'
    assert r['project'] is None
    assert not r['document_evidence']


def test_exact_word_boundary_blocks_misleading_project_match(client):
    r=client.post('/api/v12/verify/text',json={'text':'Курс ORDAK учим маркетингу и строительству'}).json()
    assert r['project'] is None


def test_manual_selection_is_explicit(client):
    x=client.post('/api/v12/verify/text',json={'text':'Продажа с бронью, строительный объект','selected_project_id':999999})
    assert x.status_code==422
    names=client.get('/api/v8/catalog').json()
    pid=next(x['id'] for x in names if x['name']=='ЖК ORDA')
    x=client.post('/api/v12/verify/text',json={'text':'Продажа с бронью, строительный объект','selected_project_id':pid}).json()
    assert x['selection_mode']=='manual' and x['project']['name']=='ЖК ORDA'


def test_ssrf_and_nonpublic_hosts_rejected():
    for url in ['http://127.0.0.1:8000/a','http://localhost/admin','http://10.1.1.1/',
                'http://192.168.1.2/img.png','http://[::1]/','file:///etc/passwd',
                'http://169.254.169.254/latest/meta-data','http://u:p@example.com/',
                'https://example.com:8065/a']:
        assert not public_url(url),url


def test_upload_type_and_size_guard(client):
    r=client.post('/api/v12/verify/screenshot',files={'file':('ad.svg',b'<svg/>','image/svg+xml')})
    assert r.status_code==415
    r=client.post('/api/v12/verify/screenshot',files={'file':('large.png',b'0'*(6*1024*1024+1),'image/png')})
    assert r.status_code==413


def test_url_html_extracts_text_without_javascript(client,monkeypatch):
    from app import ad_verification_api as api
    monkeypatch.setattr(api,'fetch_public',lambda url:('<html><head><meta property="og:title" content="ЖК ORDA продажа квартир"></head><body>Бронь и аванс<script>JK Fake</script></body></html>'.encode('utf-8'),'text/html',url))
    data=client.post('/api/v12/verify/url',json={'url':'https://olx.kz/item/123'}).json()
    assert data['project']['name']=='ЖК ORDA'
    assert 'Fake' not in data['text']
    assert data['source_url']=='https://olx.kz/item/123'


def test_url_image_ocr(client,monkeypatch):
    from app import ad_verification_api as api
    monkeypatch.setattr(api,'fetch_public',lambda url:(b'image-data','image/png',url))
    monkeypatch.setattr(api,'ocr_image',lambda data:'ЖК AINALAIYN первоначальный взнос')
    data=client.post('/api/v12/verify/url',json={'url':'https://pictures.example.com/ad.png'}).json()
    assert data['ocr_used'] and data['project']['name']=='ЖК AINALAIYN'


def test_rss_import_optin_and_dedup(client):
    content='''<rss version="2.0"><channel><item><title>ЖК ORDA, бронь</title><link>https://www.olx.kz/d/ad123</link><description>Предоплата 50000 тенге</description></item></channel></rss>'''.encode()
    r=client.post('/api/v12/rss/import',files={'file':('export.xml',content,'application/xml')},data={'save':'false'})
    assert r.status_code==200 and r.json()['count']==1 and r.json()['saved']==0
    assert client.get('/api/v8/ads').json()==[]
    r=client.post('/api/v12/rss/import',files={'file':('export.xml',content,'application/xml')},data={'save':'true'})
    assert r.json()['saved']==1
    assert len(client.get('/api/v8/ads').json())==1
    r=client.post('/api/v12/rss/import',files={'file':('export.xml',content,'application/xml')},data={'save':'true'})
    assert r.json()['saved']==0


def test_rss_rejects_xml_entities(client):
    raw=b'<!DOCTYPE rss [<!ENTITY x SYSTEM "file:///etc/passwd">]><rss>&x;</rss>'
    r=client.post('/api/v12/rss/import',files={'file':('bad.xml',raw,'application/xml')})
    assert r.status_code==422


def test_real_tesseract_recognizes_sample():
    from PIL import Image,ImageDraw,ImageFont
    import shutil
    if not shutil.which('tesseract'):pytest.skip('Tesseract not available on test host')
    # image is a test fixture, not a purported real advertisement
    f='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    try:font=ImageFont.truetype(f,36)
    except OSError:pytest.skip('System font not available')
    im=Image.new('RGB',(1400,260),'white');d=ImageDraw.Draw(im)
    d.text((25,25),'ЖК AINALAIYN',font=font,fill='black')
    d.text((25,115),'Продажа квартир, бронь, взнос',font=font,fill='black')
    blob=BytesIO();im.save(blob,format='PNG')
    text=ocr_image(blob.getvalue())
    assert 'AINALAIYN' in text and 'бронь' in text.lower()

def test_sale_text_alone_not_equity_payment_signal(client):
    x=client.post('/api/v12/verify/text',json={'text':'ЖК ORDA. Продажа готовой квартиры, документы, собственник'}).json()
    assert x['project']['name']=='ЖК ORDA'
    assert x['risk_signal']=='no_direct_payment_terms'
    assert not (x['keywords'] or []) or x['keywords']==['продажа недвижимости']


def test_negated_advance_payment_not_positive_signal(client):
    x=client.post('/api/v12/verify/text',json={'text':'ЖК ORDA без предоплаты. Продажа квартир'}).json()
    assert x['project']['name']=='ЖК ORDA'
    assert x['risk_signal']=='no_direct_payment_terms'
