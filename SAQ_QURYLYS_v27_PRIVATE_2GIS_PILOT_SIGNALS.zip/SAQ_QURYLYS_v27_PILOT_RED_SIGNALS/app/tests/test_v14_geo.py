"""Offline regressions only: NOT proof of live 2GIS/Photon access."""
from types import SimpleNamespace
from app.v14_geofill import (canonical_title, point_of, choose, photon_match, photon_named,
                             match_address_2gis, query_plan)


def p(name='ЖК ЖАНЫМ',address='Усть-Каменогорск, пр. Ильяса Есенберлина, 92'):
    return SimpleNamespace(name=name,address=address,profile={'map_links':{'2gis':'https://2gis.kz/ust-kamenogorsk/firm/70000001096100658'}})


def test_card_name_matches_without_project_prefix():
    assert canonical_title('ЖК ЖАНЫМ')==canonical_title('ЖАНЫМ')
    assert canonical_title('Жилой комплекс ЖАНЫМ')==canonical_title('ЖАНЫМ')
    assert canonical_title('ЖК ЖАНЫМ')!=canonical_title('ЖК ASYLYM')


def test_address_in_2gis_full_name_city_last():
    item={'id':'8000','name':'ЖАНЫМ','full_name':'Проспект Ильяса Есенберлина, 92, Усть-Каменогорск',
          'point':{'lat':49.90,'lon':82.60}}
    assert match_address_2gis(item,p().address)
    assert choose(p(),[item])[1]=='2gis_exact'


def test_named_city_point_accepted_as_approx_not_construction_footprint():
    item={'id':'8888','name':'ЖАНЫМ','type':'building',
          'address_name':'Ильяса Есенберлина, 94','point':{'lat':49.906,'lon':82.601}}
    assert choose(p(),[item])[1]=='2gis_named'
    assert choose(p(),[item,dict(item,id='9999',point={'lat':49.91,'lon':82.61})])[1]=='ambiguous'


def test_foreign_city_and_wrong_name_rejected():
    a={'id':'100','name':'ЖАНЫМ','point':{'lat':43.25,'lon':76.95}}
    b={'id':'101','name':'ЖК ASYLYM','point':{'lat':49.9,'lon':82.6}}
    assert choose(p(),[a,b])[0] is None


def test_disputed_orda_no_name_only_assignment():
    item={'name':'ORDA','type':'building','address_name':'Кокжал Барака, 19а',
          'point':{'lat':49.91,'lon':82.60}}
    assert choose(p('ЖК ORDA','Усть-Каменогорск, Кокжал Барака, 17'),[item])[0] is None


def test_geometry_centroid_also_supported():
    item={'name':'ЖАНЫМ','type':'building','geometry':{'centroid':{'lat':49.9,'lon':82.6}}}
    assert point_of(item)['lat']==49.9
    assert choose(p(),[item])[1]=='2gis_named'


def test_photon_requires_house_number_and_street():
    f={'geometry':{'coordinates':[82.61,49.92]},'properties':{
       'city':'Усть-Каменогорск','street':'Ильяса Есенберлина','housenumber':'92'}}
    assert photon_match(f,p().address)
    assert not photon_match(f,p('ЖК ЖАНЫМ','Усть-Каменогорск, пр. Ильяса Есенберлина, 93').address)
    assert not photon_match(dict(f,geometry={'coordinates':[76.9,43.2]}),p().address)


def test_photon_name_is_optional_approx_and_not_other_city():
    f={'geometry':{'coordinates':[82.61,49.92]},'properties':{
       'name':'ЖК ЖАНЫМ','city':'Усть-Каменогорск'}}
    assert photon_named(f,p())
    assert not photon_named(dict(f,properties={'name':'ЖК ЖАНЫМ','city':'Алматы'}),p())


def test_direct_card_used_for_lookup():
    plan=query_plan(p())
    assert any('byid' in url for url,_ in plan)
    assert any('items/geocode' in url for url,_ in plan)
    assert all('key' not in params for _,params in plan)


def test_no_uncontrolled_geopoint_for_empty_geodata():
    assert choose(p(),[])[0] is None
