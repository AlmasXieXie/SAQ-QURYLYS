"""Only exactly matching real map features may become persistent ЖК links.

All sample coordinates here are mock fixtures, NOT real ЖК location claims.
"""
import asyncio
from app import auto_buildings as a

RING=[[82.61,49.95],[82.611,49.95],[82.611,49.951],[82.61,49.95]]
WKT='POLYGON (('+', '.join(f'{lon} {lat}' for lon,lat in RING)+'))'

def test_provider_wkt_yields_only_real_polygon():
    assert a.geometry_to_polygon(WKT)=={'type':'Polygon','coordinates':[RING]}
    assert a.geometry_to_polygon('POINT (82.61 49.95)') is None
    assert a.geometry_to_polygon('POLYGON ((82.61 49.95, 82.7 49.95, 82.61 49.95))') is None
    assert a.geometry_to_polygon('POLYGON ((37 55, 38 55, 38 56, 37 55))') is None

def test_conflicts_and_multi_address_not_autolinked():
    assert not a.eligible('ЖК Diamond','Усть-Каменогорск, ул. Ю. Увалиева, 7')
    assert not a.eligible('ЖК Astoria','Усть-Каменогорск, ул. Кокжал Барака, 18а')
    assert not a.eligible('ЖК ASYLYM','Усть-Каменогорск, ул. Кокжал Барака, 18а')
    assert not a.eligible('ЖК Gran Via','Усть-Каменогорск, ул. Жибек жолы, 6/2')
    assert not a.eligible('ЖК Коктем','Усть-Каменогорск, ул. Есенберлина, 14, 16')
    assert a.eligible('ЖК Золотой квадрат','Усть-Каменогорск, ул. Кайсенова, 55/1')

def test_strict_2gis_address_matches_unique_building():
    address='Усть-Каменогорск, ул. Кайсенова, 55/1'
    good={'id':'987654321','type':'building','full_name':'Усть-Каменогорск, улица Кайсенова, 55/1',
          'address_name':'улица Кайсенова, 55/1','point':{'lat':49.95,'lon':82.61},
          'geometry':{'selection':WKT}}
    bad={**good,'id':'987654322','address_name':'улица Кайсенова, 55/11'}
    assert a.exact_match_candidates([good,bad],address)==[good]
    assert a.to_link_fields(good,'',address)['polygon']['coordinates']==[RING]
    assert not a.exact_match_candidates([bad],address)

def test_osm_footprint_requires_full_address_and_closed_way():
    tags={'addr:street':'Кайсенова','addr:housenumber':'55/1','building':'construction'}
    pointlist=[{'lon':x,'lat':y} for x,y in RING]
    feature={'type':'way','id':99999,'tags':tags,'geometry':pointlist}
    address='Усть-Каменогорск, ул. Кайсенова, 55/1'
    assert a.osm_address_exact(feature,address)
    assert a.osm_polygon(feature)['type']=='Polygon'
    assert not a.osm_address_exact({**feature,'tags':{**tags,'addr:housenumber':'55/11'}},address)
    assert a.osm_polygon({**feature,'geometry':pointlist[:-1]}) is None

def test_json_polygon_supported_without_synthetic_conversion():
    polygon={'type':'Polygon','coordinates':[RING]}
    assert a.geometry_to_polygon(polygon)==polygon
    assert a.geometry_to_polygon({'type':'Point','coordinates':[82.61,49.95]}) is None


def test_real_app_auto_associates_only_exact_address(monkeypatch):
    from sqlalchemy import create_engine, select
    from sqlalchemy.orm import Session, sessionmaker
    from sqlalchemy.pool import StaticPool
    from app.database import Base
    from app.unified_registry import RegistryBuilding, load_starter
    from app.catalog_uka import load_catalog
    from app.extra_problem_sites import load_extra
    from app.v9_api import GeometryLink
    engine=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(engine)
    factory=sessionmaker(bind=engine)
    with factory() as db:
        load_starter(db);load_catalog(db);load_extra(db)
    monkeypatch.setattr(a,'SessionLocal',factory)
    monkeypatch.setenv('SAQ_2GIS_KEY','test-only-key')
    async def fake_query(_client,address,_key):
        if 'Кайсенова, 55/1' in address:
            return [{'id':'999111333','type':'building',
                'full_name':'Усть-Каменогорск, ул. Кайсенова, 55/1',
                'address_name':'Кайсенова, 55/1','point':{'lat':49.95,'lon':82.61},
                'geometry':{'selection':WKT}}]
        # an unverified coincidental number cannot create a link
        return [{'id':'999111334','type':'building',
                'full_name':'Усть-Каменогорск, ул. Другая, 55/1',
                'address_name':'Другая, 55/1','point':{'lat':49.95,'lon':82.61}}]
    async def fast_sleep(_seconds):pass
    monkeypatch.setattr(a,'query_address',fake_query)
    monkeypatch.setattr(a.asyncio,'sleep',fast_sleep)
    asyncio.run(a.run())
    with factory() as db:
        links=db.scalars(select(GeometryLink)).all()
        assert len(links)==1
        link=links[0]
        assert link.association_method=='auto_exact_address'
        assert link.polygon['coordinates']==[RING]
        building=db.get(RegistryBuilding,link.building_id)
        assert building.name=='ЖК Золотой квадрат'
        assert len(db.scalars(select(RegistryBuilding)).all())>=40
    # second import does not duplicate a linked building
    asyncio.run(a.run())
    with factory() as db:
        assert len(db.scalars(select(GeometryLink)).all())==1


def test_real_osm_match_is_deterministic_and_cached(monkeypatch):
    from sqlalchemy import create_engine,select
    from sqlalchemy.orm import sessionmaker
    from sqlalchemy.pool import StaticPool
    from app.database import Base
    from app.unified_registry import RegistryBuilding,load_starter
    from app.catalog_uka import load_catalog
    from app.extra_problem_sites import load_extra
    from app.v9_api import GeometryLink
    engine=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(engine)
    factory=sessionmaker(bind=engine)
    with factory() as db:
        load_starter(db);load_catalog(db);load_extra(db)
    monkeypatch.setattr(a,'SessionLocal',factory)
    feature={'type':'way','id':8473662,
             'tags':{'building':'construction','addr:street':'Кайсенова','addr:housenumber':'55/1'},
             'geometry':[{'lon':x,'lat':y} for x,y in RING]}
    class FakeResponse:
        content=b'{}'
        def raise_for_status(self):pass
        def json(self):return {'elements':[feature]}
    class FakeClient:
        def __init__(self,*args,**kwargs):pass
        async def __aenter__(self):return self
        async def __aexit__(self,*args):pass
        async def post(self,*args,**kwargs):return FakeResponse()
    monkeypatch.setattr(a.httpx,'AsyncClient',FakeClient)
    asyncio.run(a.run_osm())
    with factory() as db:
        links=db.scalars(select(GeometryLink)).all()
        assert len(links)==1
        assert links[0].provider=='osm'
        assert links[0].association_method=='auto_exact_address_osm'
        assert db.get(RegistryBuilding,links[0].building_id).name=='ЖК Золотой квадрат'
    asyncio.run(a.run_osm())
    with factory() as db:assert len(db.scalars(select(GeometryLink)).all())==1
