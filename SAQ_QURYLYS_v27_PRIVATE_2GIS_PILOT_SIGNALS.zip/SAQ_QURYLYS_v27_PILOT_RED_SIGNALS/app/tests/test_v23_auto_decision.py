"""v23 regression: green inherits to exact project ads, never the whole developer."""
from sqlalchemy import create_engine,select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from fastapi.testclient import TestClient
from app.database import Base,get_db
from app.main import app
from app.unified_registry import RegistryBuilding,load_starter
from app.catalog_uka import load_catalog
from app.extra_problem_sites import load_extra
from app.registry_bridge import reconcile
from app.v8_api import RegistryAd
from app.workbench import LegalCheck,VerifiedFactor


def test_every_surface_reuses_one_project_specific_decision():
    eng=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(eng)
    Local=sessionmaker(bind=eng,expire_on_commit=False)
    with Local() as db:
        load_starter(db);load_catalog(db);load_extra(db);reconcile(db)
        gold=db.scalar(select(RegistryBuilding).where(RegistryBuilding.name=='ЖК Золотой квадрат'))
        other=db.scalar(select(RegistryBuilding).where(RegistryBuilding.name=='ЖК ЖАНЫМ'))
        g_id,o_id=gold.id,other.id
        # Legitimate advertisement has payment wording. Another (spot 2) does
        # NOT inherit the 2025 guarantee for spot 1.
        db.add_all([
          RegistryAd(building_id=g_id,platform='krisha',url='https://example.org/v23/ad1',text='ЖК Золотой квадрат. Продажа квартир, аванс 500000 тенге'),
          RegistryAd(building_id=g_id,platform='krisha',url='https://example.org/v23/ad2',text='ЖК Золотой квадрат пятно 2, продажа, аванс 500000 тенге'),
          RegistryAd(building_id=o_id,platform='krisha',url='https://example.org/v23/ad3',text='ЖК ЖАНЫМ, аванс 100000 тенге'),
          RegistryAd(building_id=None,platform='krisha',url='https://example.org/v23/ad4',text='Золотой квадрат, аванс 100000 тенге')])
        db.commit()
    def override():
        with Local() as db: yield db
    app.dependency_overrides[get_db]=override
    try:
        with TestClient(app) as c:
            snap=c.get('/api/signal-map/snapshot').json()
            byname={x['name']:x for x in snap['items']}
            assert byname['ЖК Золотой квадрат']['map_color']=='green'
            assert byname['ЖК Золотой квадрат']['triage_score']>=25 # ads signal retained, not a verdict
            assert byname['ЖК ЖАНЫМ']['map_color']=='yellow'
            assert byname['ЖК Золотой квадрат']['authorization_verified'] is True
            ads={x['url'].split('/')[-1]:x for x in c.get('/api/v8/ads').json()}
            assert [ads['ad1']['legal_assessment']['color'],ads['ad2']['legal_assessment']['color'],ads['ad3']['legal_assessment']['color'],ads['ad4']['legal_assessment']['color']]==['green','yellow','yellow','yellow']
            assert c.get(f'/api/workbench/cases/{g_id}').json()['auto_decision']['map_color']=='green'
            assert c.get(f'/api/unified/buildings/{g_id}').json()['auto_decision']['map_color']=='green'
            unified=c.get('/api/unified/buildings').json()
            assert next(x for x in unified if x['id']==g_id)['auto_decision']['map_color']=='green'
            dev=c.get('/api/v8/developers').json()
            target=next(x for x in dev if any(xp['id']==g_id for xp in x['projects']))
            assert next(x for x in target['projects'] if x['id']==g_id)['map_color']=='green'
            companies=c.get('/api/unified/companies').json()
            legal=next(x for x in companies if x['bin']=='970640000190')
            assert any(p['id']==g_id and p['map_color']=='green' for p in legal['related_buildings'])
            assert c.get('/api/signal-map/snapshot').json()['counts']==snap['counts']
    finally:
        app.dependency_overrides.clear();eng.dispose()


def test_conflict_and_independent_verified_issues_win_over_green():
    eng=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(eng); Local=sessionmaker(bind=eng,expire_on_commit=False)
    with Local() as db:
        load_starter(db);load_catalog(db);load_extra(db);reconcile(db)
        gold=db.scalar(select(RegistryBuilding).where(RegistryBuilding.name=='ЖК Золотой квадрат'))
        bid=gold.id
        db.add(LegalCheck(building_id=bid,status='verified_absent',evidence_url='https://example.org/inconsistent-review',reviewer='QA',note='Противоречие официальному источнику'))
        db.commit()
    def override():
        with Local() as db: yield db
    app.dependency_overrides[get_db]=override
    try:
        with TestClient(app) as c:
            row=next(x for x in c.get('/api/signal-map/snapshot').json()['items'] if x['id']==bid)
            assert row['map_color']=='yellow'
        with Local() as db:
            l=db.scalar(select(LegalCheck).where(LegalCheck.building_id==bid))
            l.status='unknown'
            db.add(VerifiedFactor(building_id=bid,code='R4',note='Подтверждённая жалоба',evidence_url='https://example.org/complaint',reviewer='QA'))
            db.commit()
        with TestClient(app) as c:
            row=next(x for x in c.get('/api/signal-map/snapshot').json()['items'] if x['id']==bid)
            assert row['map_color']=='yellow'
    finally:
        app.dependency_overrides.clear();eng.dispose()
