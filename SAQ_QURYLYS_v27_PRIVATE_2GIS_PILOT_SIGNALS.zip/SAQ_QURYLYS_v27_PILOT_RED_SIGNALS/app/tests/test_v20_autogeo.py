"""V20 critical path regression checks with simulated upstream HTTP responses.

They do NOT claim real external 2GIS connectivity or 40 real mapped pins.
"""
from pathlib import Path
import asyncio
import httpx
from fastapi.testclient import TestClient
from app.main import app
from app.v14_geofill import point_of, request_items, choose
from types import SimpleNamespace


def test_geocode_parses_real_2gis_wkt_geometry():
    assert point_of({'geometry': {'centroid': 'POINT(82.612 49.956)'}}) == {'lat': 49.956, 'lon': 82.612}
    assert point_of({'point': {'lat': 49.956, 'lon': 82.612}}) == {'lat': 49.956, 'lon': 82.612}
    assert point_of({'geometry': {'centroid': 'POINT(bad 49.956)'}}) == {}


def test_2gis_404_is_no_results_and_403_hides_private_key():
    async def f(status):
        def handler(request):
            assert request.url.params['key'] == 'private_test_key'
            return httpx.Response(status, json={'meta': {'code': status}, 'result': {'items': []}})
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            return await request_items(client, 'https://catalog.api.2gis.com/3.0/items', {'q': 'Усть-Каменогорск'}, 'private_test_key')
    assert asyncio.run(f(404)) == []
    try:asyncio.run(f(403))
    except PermissionError as exc:
        assert '403' in str(exc) and 'private_test_key' not in str(exc)
    else:assert False, '403 must not be accepted'


def test_named_exact_candidate_from_actual_dto_schema():
    p=SimpleNamespace(name='ЖК ЖАНЫМ',address='Усть-Каменогорск, ул. Ильяса Есенберлина, 92')
    item={'id':'7000000000001','name':'ЖК ЖАНЫМ','type':'building',
          'point':{'lat':49.95,'lon':82.61},'address_name':'улица Есенберлина, 92'}
    found, precision=choose(p,[item])
    assert found==item and precision in ('2gis_exact','2gis_named')


def test_release_has_version_20_and_all_forty_cards():
    with TestClient(app) as client:
        assert client.get('/api/health').json()['version']=='27.0.0'
        s=client.get('/api/signal-map/snapshot').json()
        assert s['total']==44 and s['mapped']+s['without_coordinates']==44
        html=client.get('/').text
        assert 'id="city-map"' in html
        assert 'id="geolocate-all"' in html
        assert 'id="connect-2gis"' in html
        assert 'data-view="developers"' in html


def test_windows_launcher_checks_correct_version():
    text=Path('RUN_WINDOWS.bat').read_text(encoding='utf-8')
    assert "'27.0.0'" in text
    assert "if($v -eq '17.0.0')" not in text


def test_frontend_starts_geolocate_automatically():
    js=Path('app/static/signal_map.js').read_text(encoding='utf-8')
    assert 'startGeoCheck(true)' in js
    assert "api('/api/v14/geofill/start'" in js
    assert 'Найти все ЖК' in Path('app/static/signal_map.html').read_text(encoding='utf-8')
