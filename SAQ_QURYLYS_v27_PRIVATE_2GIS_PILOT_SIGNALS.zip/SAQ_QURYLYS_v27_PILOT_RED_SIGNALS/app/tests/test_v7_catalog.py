"""Catalog sources, direct hyperlinks and conservative map export."""
import csv
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool
from app.database import Base
from app.catalog_uka import CSV_FILE,load_catalog,catalog_keys
from app.unified_registry import RegistryBuilding,load_starter,keyify
from app.real_geocode import number_from_address
from app.unified_api import construction_catalog,catalog_geojson


def db_session():
    engine=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(engine)
    return Session(engine)


def test_csv_checked_catalog_has_38_unique_projects_and_source_urls():
    with CSV_FILE.open(encoding='utf-8-sig',newline='') as f:
        items=list(csv.DictReader(f))
    assert len(items)==len(catalog_keys())==38
    for row in items:
        assert row['address'].startswith('Усть-Каменогорск, ')
        assert row['source_url'].startswith('https://')
        assert row['listing_url'].startswith('https://krisha.kz/')
        assert row['source_page'] in ('1','2','3','4')
        assert row['address_precision'] in ('single_catalog_address','multi_address','position_only')


def test_api_only_thirty_eight_and_missing_geojson_initially():
    with db_session() as db:
        load_starter(db)
        load_catalog(db)
        catalog=construction_catalog(db=db)
        assert len(catalog)==38
        assert not any(x['name']=='ЖК Diamond' for x in catalog)
        assert all(x['latitude'] is None for x in catalog)
        geo=catalog_geojson(db=db)
        assert geo['mapped']==0 and geo['total_catalog']==38
        east=next(x for x in catalog if x['name']=='ЖК Easton')
        assert '/firm/' in east['profile']['map_links']['2gis']
        assert east['profile']['direct_2gis_card']


def test_ambiguous_addresses_are_not_safe_for_single_house_match():
    assert number_from_address('Усть-Каменогорск, пр. Ильяса Есенберлина, позиция 98')=='98'
    # The caller rejects 'позиция', since that is NOT house 98.
    assert number_from_address('Усть-Каменогорск, ул. Кокжал Барака, 18а, 18б, 18в')=='18в'
    # The caller rejects multi-address, since last building alone is not the site.
