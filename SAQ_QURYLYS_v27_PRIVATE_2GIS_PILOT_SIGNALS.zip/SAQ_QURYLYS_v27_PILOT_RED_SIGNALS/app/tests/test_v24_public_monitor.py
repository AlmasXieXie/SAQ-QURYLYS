"""v24: repeatable attribution and legal-source tests without network access."""
from sqlalchemy import create_engine, select, func
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from app.database import Base
from app.unified_registry import load_starter, import_ashyq_rows, RegistryBuilding, RegistryAuthorization
from app.catalog_uka import load_catalog
from app.extra_problem_sites import load_extra
from app.registry_bridge import reconcile
from app.seed_public_ads_v24 import seed_real_publications
from app.ad_archive_v24 import PublicAd, AdRevision, save_ad, ad_json
from app.ad_attribution_v24 import canonical_url, candidates_for, address_parts
from app.registry_deep_v24 import reconcile_mio_exact, same_specific_site
from app.auto_decisions import evaluate_building
from app import connectors
from app.main import app  # ensure all model tables registered before create_all


def db_fixture():
    engine=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Local=sessionmaker(engine,expire_on_commit=False)
    return engine,Local


def test_real_archival_seed_preserves_sightings_and_legal_separation():
    engine,Local=db_fixture()
    try:
        with Local() as db:
            load_starter(db);load_catalog(db);load_extra(db);reconcile(db)
            assert seed_real_publications(db)==12
            assert seed_real_publications(db)==0
            ads=db.scalars(select(PublicAd)).all()
            assert len(ads)==12 and all(a.seen_count==1 for a in ads)
            assert sorted(set(a.platform for a in ads))==['krisha','olx']
            asylym=next(a for a in ads if a.url.endswith('1007414984'))
            detail=ad_json(db,asylym)
            assert detail['project_name']=='ЖК ASYLYM'
            assert detail['organization_bin']=='201040022748'
            assert detail['publisher_identity_confirmed'] is False
            assert detail['legal_assessment']['color']=='green'
            # Owner listing concerns a project but never proves an AN Groups ad.
            owner=next(a for a in ads if 'IDqTcLD' in a.url)
            who=ad_json(db,owner)
            assert who['project_name']=='ЖК AINALAIYN' and not who['publisher_identity_confirmed']
            assert who['legal_assessment']['color']=='yellow'
            new_text=asylym.latest_text+' Изменены условия рассрочки.'
            updated,created=save_ad(db,url=asylym.url,text=new_text,feed='QA repeated scan')
            db.commit()
            assert not created and updated.seen_count==2
            assert db.scalar(select(func.count()).select_from(AdRevision).where(AdRevision.ad_id==asylym.id))==2
            save_ad(db,url=asylym.url,text=new_text,feed='QA repeated scan')
            db.commit()
            assert db.scalar(select(func.count()).select_from(AdRevision).where(AdRevision.ad_id==asylym.id))==2
    finally:engine.dispose()


def test_ambiguous_ad_is_not_linked_and_url_canonicalized():
    engine,Local=db_fixture()
    try:
        with Local() as db:
            load_starter(db);load_catalog(db);load_extra(db);reconcile(db)
            out=candidates_for(db,'Продажа квартир в ЖК ASYLYM и ЖК ORDA')
            assert out['confidence']=='ambiguous' and out['building_id'] is None
            wrong=candidates_for(db,'Квартиры AN Groups, рассрочка')
            assert wrong['building_id'] is None
            assert canonical_url('https://www.instagram.com/reel/COOL123/?utm_source=qq')=='https://instagram.com/reel/COOL123'
            assert canonical_url('http://localhost:9000/x')==''
            assert address_parts('Усть-Каменогорск, ул. Есенберлина, 5/1')[1]=='5/1'
    finally:engine.dispose()


def test_government_permit_requires_same_exact_document_and_address():
    assert same_specific_site('г. Усть-Каменогорск ул. Есенберлина 5/1',
                              'Усть-Каменогорск, ул. Есенберлина, 5/1')
    assert not same_specific_site('г. Усть-Каменогорск ул. Есенберлина 5/2',
                                  'Усть-Каменогорск, ул. Есенберлина, 5/1')
    engine,Local=db_fixture()
    try:
        with Local() as db:
            load_starter(db);load_catalog(db);load_extra(db);reconcile(db)
            bad=import_ashyq_rows(db,[{'permission_number':'KZ40VWE00002526',
              'object_location':'Усть-Каменогорск ул. Есенберлина 5/2','builder_name':'AN Groups'}],connectors.ASHYQ_PAGE)
            first=reconcile_mio_exact(db)
            assert first['matched']==[] and first['number_only']==['KZ40VWE00002526']
            # A second government record with exactly matching address is enough;
            # the mismatching row above must never be elevated to green.
            import_ashyq_rows(db,[{'permission_number':'KZ40VWE00002526',
              'object_location':'Усть-Каменогорск ул. Есенберлина 5/1','builder_name':'AN Groups'}],connectors.ASHYQ_PAGE)
            second=reconcile_mio_exact(db)
            assert any(x['name']=='ЖК AINALAIYN' for x in second['matched'])
            rows=db.scalars(select(RegistryAuthorization).where(RegistryAuthorization.source_code=='ashyq')).all()
            assert len([x for x in rows if x.status=='official_project_match'])==1
            assert len([x for x in rows if x.status=='official_number_candidate'])==1
            # Green is scoped only to exact claimed project; not all AN Groups developments.
            a=db.scalar(select(RegistryBuilding).where(RegistryBuilding.name=='ЖК AINALAIYN'))
            other=db.scalar(select(RegistryBuilding).where(RegistryBuilding.name=='ЖК ASYLTAS'))
            assert evaluate_building(db,a)[0]['map_color']=='green'
            assert evaluate_building(db,other)[0]['map_color']=='yellow'
    finally:engine.dispose()
