"""Regression tests: 38 sourced construction entries; never seed fake coordinates."""
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool
from app.database import Base
from app.models import Project
from app.unified_registry import RegistryBuilding,load_starter,building_payload,keyify
from app.catalog_uka import load_catalog,catalog_keys
from app.real_geocode import is_local_point,check_exact_response,street_from_address
from app.real_enrichment import enrich


def new_db():
    engine=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(engine)
    return Session(engine)


def test_real_catalog_38_no_demo_faked_pins():
    with new_db() as db:
        load_starter(db)
        result=load_catalog(db)
        assert result['catalog_items']==38
        keys=catalog_keys()
        records=db.scalars(select(RegistryBuilding)).all()
        catalog=[b for b in records if b.building_key in keys]
        assert len(catalog)==38
        assert db.scalars(select(Project)).all()==[]
        assert not [b for b in records if b.latitude is not None]
        assert 'uka:'+keyify('ЖК Diamond') not in keys
        assert any(b.name=='ЖК Easton' for b in catalog)
        assert any(b.name=='ЖК Золотой квадрат' for b in catalog)
        assert load_catalog(db)['new']==0
        assert len(db.scalars(select(RegistryBuilding)).all())==len(records)


def test_wrong_diamond_seed_removed_on_migration():
    with new_db() as db:
        load_starter(db)
        d=RegistryBuilding(building_key='uka:'+keyify('ЖК Diamond'),name='ЖК Diamond',
            address='Усть-Каменогорск, ул. Увалиева, 7',
            stage_reported='construction',latitude=49.889947,longitude=82.614964,
            coordinate_source='2GIS:old_invalid_pin')
        db.add(d);db.commit()
        result=load_catalog(db)
        assert result['diamond_invalidated'] is True
        assert d.latitude is None and d.longitude is None
        assert d.building_key not in catalog_keys()


def test_important_sources_and_direct_2gis_links():
    with new_db() as db:
        load_starter(db);load_catalog(db)
        records={b.name:b for b in db.scalars(select(RegistryBuilding))}
        for name in ['ЖК AINALAIYN','ЖК ASYLYM','ЖК Asyl Tau','ЖК ЖАНЫМ','ЖК ORDA','ЖК Easton']:
            p=enrich(building_payload(db,records[name]))
            assert p['map_links']['2gis'].startswith('https://2gis.kz/')
            assert p['map_links']['google'].startswith('https://www.google.com/maps/')
            assert p['map_links']['yandex'].startswith('https://yandex.kz/maps/')
            assert p['location_precision']=='missing'
        east=enrich(building_payload(db,records['ЖК Easton']))
        assert east['direct_2gis_card'] and '/firm/' in east['map_links']['2gis']
        an=enrich(building_payload(db,records['ЖК AINALAIYN']))
        assert an['developer_instagram']=='https://www.instagram.com/an.groups'
        assert an['brand_bin']=='970340000010'
        orda=enrich(building_payload(db,records['ЖК ORDA']))
        assert len(orda['alternative_addresses'])==2


def test_geocoder_rejects_wrong_house_city_street_and_centroid():
    expected='Усть-Каменогорск, ул. Кокжал Барака, 17'
    assert street_from_address(expected)=='кокжал барака'
    good={'lat':'49.95','lon':'82.60','display_name':'Өскемен, Кокжал Барака, 17',
          'address':{'city':'Усть-Каменогорск','road':'Кокжал Барака','house_number':'17'}}
    assert check_exact_response(good,'17','кокжал барака')
    assert not check_exact_response(good,'19а','кокжал барака')
    assert not check_exact_response(good,'17','есенберлина')
    assert not check_exact_response({**good,'address':{'road':'Кокжал Барака','city':'Усть-Каменогорск'}},'17','кокжал барака')
    assert not check_exact_response({**good,'lat':'51.0'},'17','кокжал барака')
    assert not check_exact_response({**good,'address':{**good['address'],'city':'Семей'},'display_name':'Семей'},'17','кокжал барака')
    assert is_local_point(49.95,82.6)
