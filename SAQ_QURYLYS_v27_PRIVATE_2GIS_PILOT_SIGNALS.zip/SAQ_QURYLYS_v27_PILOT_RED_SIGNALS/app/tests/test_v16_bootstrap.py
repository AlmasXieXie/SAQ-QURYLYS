import os, sqlite3
from pathlib import Path
from scripts.bootstrap_v16 import copy_previous_database, migrate_local_key


def test_upgrade_preserves_database_without_modifying_previous(tmp_path,monkeypatch):
    monkeypatch.delenv('SAQ_DATABASE_URL',raising=False)
    old=tmp_path/'SAQ_QURYLYS_v15_ANALYST_READY';new=tmp_path/'SAQ_QURYLYS_v16_SIGNAL_MAP'
    old.mkdir();new.mkdir()
    with sqlite3.connect(old/'saq.sqlite3') as db:
        db.execute('CREATE TABLE unified_buildings (id INTEGER PRIMARY KEY, name TEXT, latitude REAL)')
        db.execute('CREATE TABLE registry_ad_monitoring (id INTEGER PRIMARY KEY, text TEXT)')
        db.execute('CREATE TABLE analyst_legal_checks (id INTEGER PRIMARY KEY, reviewer TEXT)')
        db.execute("INSERT INTO unified_buildings VALUES(1,'Test Building',49.955)")
        db.execute("INSERT INTO registry_ad_monitoring VALUES(1,'Evidence')")
        db.execute("INSERT INTO analyst_legal_checks VALUES(1,'Reviewer')")
    assert copy_previous_database(new)['status']=='copied'
    with sqlite3.connect(new/'saq.sqlite3') as db:
        assert db.execute('SELECT latitude FROM unified_buildings').fetchone()[0]==49.955
        assert db.execute('SELECT text FROM registry_ad_monitoring').fetchone()[0]=='Evidence'
        assert db.execute('SELECT reviewer FROM analyst_legal_checks').fetchone()[0]=='Reviewer'
    assert copy_previous_database(new)['status']=='already_exists'
    with sqlite3.connect(old/'saq.sqlite3') as db:
        assert db.execute('SELECT count(*) FROM registry_ad_monitoring').fetchone()[0]==1


def test_bootstrap_key_is_local_and_never_logged(tmp_path,monkeypatch):
    monkeypatch.delenv('SAQ_DATABASE_URL',raising=False)
    old=tmp_path/'SAQ_QURYLYS_v15_ANALYST_READY';new=tmp_path/'SAQ_QURYLYS_v16_SIGNAL_MAP'
    old.mkdir();new.mkdir()
    (old/'.env').write_text('SAQ_2GIS_KEY=local-private-test-key\nSAQ_ADMIN_PASSWORD=other-secret\n',encoding='utf8')
    assert migrate_local_key(new)=='local_configuration_copied'
    assert (new/'.env').read_text().strip()=='SAQ_2GIS_KEY=local-private-test-key'
    assert 'other-secret' not in (new/'.env').read_text()
    assert migrate_local_key(new)=='already_configured'
