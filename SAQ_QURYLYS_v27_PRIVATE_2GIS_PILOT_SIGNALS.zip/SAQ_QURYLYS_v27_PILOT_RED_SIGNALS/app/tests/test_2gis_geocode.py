from app.geocode_2gis import compare,parts,request_params


def test_exact_2gis_address_matching():
    candidate={'full_name':'Усть-Каменогорск, улица Кайсенова, 55/1',
               'address_name':'улица Кайсенова, 55/1','point':{'lat':49.965,'lon':82.61}}
    assert compare(candidate,'Усть-Каменогорск, ул. Кайсенова, 55/1')
    assert not compare(candidate,'Усть-Каменогорск, ул. Кайсенова, 55/2')
    assert not compare(candidate,'Усть-Каменогорск, ул. Увалиева, 55/1')
    assert not compare({**candidate,'point':{'lat':51,'lon':82.61}},'Усть-Каменогорск, ул. Кайсенова, 55/1')


def test_reject_multiple_or_provisional_addresses():
    assert parts('Усть-Каменогорск, пр. Ильяса Есенберлина, позиция 98') is None
    assert parts('Усть-Каменогорск, пр. Ильяса Есенберлина, 14, 16 / ул. Утепова, 34/7') is None
    assert parts('Усть-Каменогорск, Казыбек би (без номера)') is None


def test_key_not_printed_or_placed_in_query_without_runtime_value():
    params=request_params('Усть-Каменогорск, ул. Кайсенова, 55/1','a-key')
    assert params['key']=='a-key'
    assert params['fields']=='items.point,items.geometry.centroid'
    assert params['q'].startswith('Усть-Каменогорск')
