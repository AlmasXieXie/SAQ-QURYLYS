/* Regression tests for the v3 map (run with: node app/tests/map_frontend.test.cjs).
   Mocked Leaflet API verifies front-end rendering and async requests without network. */
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.resolve(__dirname, '../static/app.js'), 'utf8');
const safeSource = source.substring(0, source.indexOf("document.addEventListener('click'"));

const projects=[
 {id:1,name:'DEMO-1',address:'Условный 1',developer:'DEMO',latitude:49.95,longitude:82.61,score:35,zone:'yellow',demo:true},
 {id:2,name:'DEMO-2',address:'Условный 2',developer:'DEMO',latitude:49.97,longitude:82.63,score:70,zone:'red',demo:true},
 {id:3,name:'Без координат',address:'Условный 3',developer:'DEMO',latitude:null,longitude:null,score:10,zone:'green',demo:false},
];
function harness(){
 const root={innerHTML:'',warning:null,querySelector(query){return query==='.map-failure-warning'?this.warning:null},appendChild(node){this.warning=node}};
 const status={textContent:''};
 const trace={mapRemoves:0,markers:[],layers:[],tileErrors:[],tileLoads:[],requests:[]};
 const map={setView(){return this},remove(){trace.mapRemoves++},on(){return this},fitBounds(){return this},invalidateSize(){return this},removeLayer(layer){trace.layers=trace.layers.filter(x=>x!==layer)}};
 const L={
   map(){return map},
   tileLayer(){return {on(name,fn){if(name==='tileerror')trace.tileErrors.push(fn);if(name==='tileload')trace.tileLoads.push(fn);return this},addTo(){return this}}},
   divIcon(options){return options},marker(point){return {addTo(){trace.markers.push(point);return this},bindPopup(){return this}}},
   geoJSON(data,options){return {data,options,addTo(){trace.layers.push(this);return this}}},
   latLngBounds(pts){return pts},
   control:{zoom(){return {addTo(){}}},scale(){return {addTo(){}}}},
 };
 const doc={querySelector(query){if(query==='#map-container')return root;if(query==='#zone-layer-status')return status;return null},createElement(){return {className:'',textContent:''}}};
 const ctx=vm.createContext({L,window:{L},document:doc,console,setTimeout(){return 42},clearTimeout(){},URL,FormData,fetch(){throw Error('Unexpected real fetch')},Date,Math,Number});
 vm.runInContext(safeSource,ctx);
 vm.runInContext('state.page="map";state.projects=globalThis.demoProjects;state.showOSMZones=true;state.showProjectZones=true;',Object.assign(ctx,{demoProjects:projects}));
 return {ctx,root,status,trace,map};
}
const tick=()=>new Promise(resolve=>setImmediate(resolve));
(async()=>{
 // Tiles can fail repeatedly; markers must remain and Leaflet must not be removed.
 let h=harness();
 h.ctx.getResponse=async path=>path.includes('construction')?{type:'FeatureCollection',features:[],status:'unavailable'}:{type:'FeatureCollection',features:[]};
 vm.runInContext('req=globalThis.getResponse; initMap()',h.ctx);
 assert.equal(h.trace.markers.length,2,'Both located projects appear as markers');
 for(let i=0;i<12;i++)h.trace.tileErrors[0]();
 assert.equal(h.trace.mapRemoves,0,'Tile errors must NEVER tear down the active map');
 assert.equal(h.trace.markers.length,2,'Markers survive tile errors');
 assert.match(h.root.warning.textContent,/Тайлы OpenStreetMap/);

 // OSM slow: project boundaries must render immediately, without awaiting Overpass.
 h=harness();let finishOSM;
 h.ctx.getResponse=path=>{
   h.trace.requests.push(path);
   if(path.includes('construction-zones'))return new Promise(resolve=>{finishOSM=resolve});
   if(path.includes('project-boundaries'))return Promise.resolve({type:'FeatureCollection',features:[{type:'Feature',geometry:{type:'Polygon',coordinates:[[[82.61,49.95],[82.62,49.95],[82.62,49.96],[82.61,49.95]]]},properties:{project_id:1,demo:true,name:'DEMO',source_url:'DEMO:'}}]});
   throw Error('unexpected '+path);
 };
 vm.runInContext('req=globalThis.getResponse;initMap()',h.ctx);
 await tick();await tick();
 assert.ok(h.trace.requests.some(p=>p.includes('construction-zones')));
 assert.ok(h.trace.requests.some(p=>p.includes('project-boundaries')),'Project request must start without waiting for OSM');
 assert.equal(h.trace.layers.length,1,'Project polygon renders while OSM is pending');
 assert.match(h.status.textContent,/ЖК: 1 контуров/);
 finishOSM({type:'FeatureCollection',features:[],status:'unavailable'});await tick();
 assert.equal(h.trace.layers.length,2,'OSM response does not remove project polygon');

 // Switching off OSM should not hide project boundaries.
 vm.runInContext('state.showOSMZones=false;refreshMapZones()',h.ctx);await tick();await tick();
 assert.equal(h.trace.layers.length,1);
 assert.equal(h.trace.layers[0].data.features.length,1);
 console.log('Map frontend: 3 regression tests passed');
})().catch(err=>{console.error(err);process.exit(1)});
