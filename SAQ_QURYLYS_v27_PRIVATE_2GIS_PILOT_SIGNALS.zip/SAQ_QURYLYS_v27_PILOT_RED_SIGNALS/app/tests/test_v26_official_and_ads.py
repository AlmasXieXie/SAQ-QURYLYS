"""v26 regional-authority lists, new-build year filter and project-specific ad colors."""
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from app.main import app
from app.database import Base
from app.unified_registry import RegistryBuilding,load_starter
from app.catalog_uka import load_catalog
from app.extra_problem_sites import load_extra
from app.registry_bridge import reconcile
from app.official_mio_v26 import seed_official_list
from app.seed_public_ads_v24 import seed_real_publications
from app.seed_public_ads_v26 import seed_2026_ads
from app.ad_archive_v24 import PublicAd,AdRevision
from app.ad_monitor_v25 import AdYearEvidence,ad_public
from app.auto_decisions import evaluate_building
from app.ad_intelligence_v25 import year_from_listing
from app.v8_api import developers


def session_fixture():
    eng=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(eng)
    return eng,sessionmaker(eng,expire_on_commit=False)


def seed(db):
    load_starter(db);load_catalog(db);load_extra(db);reconcile(db)
    seed_official_list(db)
    seed_real_publications(db)
    seed_2026_ads(db)
    db.commit()


def test_legal_status_project_scope_and_two_permit_columns():
    eng,Local=session_fixture()
    try:
        with Local() as db:
            seed(db)
            results={b.name: evaluate_building(db,b)[0]['map_color'] for b in db.scalars(select(RegistryBuilding)).all()}
            assert results['ЖК ORDA']=='green'
            assert results['ЖК ASYLYM']=='green'
            assert results['ЖК AINALAIYN']=='green'
            assert results['ЖК ЖАНЫМ']=='yellow'
            assert results['ЖК Престиж']=='yellow' # guarantee incident
            assert results['ЖК Satti City 2']=='yellow' # phase not matched
            devs=developers(db)
            assert any(x['name']=='Юрлицо уточняется — ЖК BELGRAVIA' for x in devs)
            orda=next(p for d in devs for p in d['projects'] if p['name']=='ЖК ORDA')
            assert orda['mio']['status']=='official_public_project_list'
            assert orda['mio']['source'].startswith('https://www.gov.kz/')
            assert orda['kzhk'] is None
            asylym=next(p for d in devs for p in d['projects'] if p['name']=='ЖК ASYLYM')
            assert asylym['kzhk']['status'].startswith('official')
            assert asylym['mio'] is None
    finally:eng.dispose()


def test_krisha_2026_year_seed_is_idempotent_and_preserves_archive():
    eng,Local=session_fixture()
    try:
        with Local() as db:
            seed(db)
            sample=db.scalar(select(PublicAd).where(PublicAd.url=='https://krisha.kz/a/show/1009904335'))
            assert sample is not None
            revision_count=len(db.scalars(select(AdRevision).where(AdRevision.ad_id==sample.id)).all())
            seen=sample.seen_count
            assert db.get(AdYearEvidence,sample.id).completion_year==2026
            assert ad_public(db,sample)['year']['status']=='active'
            seed_2026_ads(db)
            assert db.get(PublicAd,sample.id).seen_count==seen
            assert len(db.scalars(select(AdRevision).where(AdRevision.ad_id==sample.id)).all())==revision_count
            assert ad_public(db,sample)['legal_assessment']['color']=='green'
    finally:eng.dispose()


def test_commissioning_year_not_inferred_from_posting_date():
    assert year_from_listing('ЖК ORDA. Объявление опубликовано 18.10.2026')['status']=='review'
    assert year_from_listing('ЖК ORDA. Год постройки: 2024')['status']=='excluded'
    assert year_from_listing('ЖК ORDA. Год постройки: 2026')['status']=='active'
    assert year_from_listing('ЖК ORDA. Год постройки: 2027; дом сдан')['status']=='excluded'
    assert year_from_listing('ЖК ORDA. Год постройки: 2026, срок сдачи 2027')['status']=='review'
