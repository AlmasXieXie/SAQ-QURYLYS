"""Independent tests for explainability, unknown legal state and three TЗ scenarios."""
from types import SimpleNamespace
import pytest
from app.scoring import score_project
from app.analyzer import analyze_text


def P(**overrides):
    defaults=dict(name='ЖК DEMO «Альфа»',aliases=['Демо Альфа'],address='Учебный квартал',id=1,
        legal_status='unknown',legal_source='',stage='Котлован',claimed_completion=None,completion=15,
        completion_source='',claimed_source='',verified_complaint=False,complaint_evidence='',
        verified_delay=False,delay_evidence='')
    return SimpleNamespace(**(defaults|overrides))

def A(text, accepted=True):
    from app.analyzer import analyze_text
    return SimpleNamespace(id=12,review_status='accepted' if accepted else 'pending',
                           source_url='demo://test',analysis=analyze_text(text,[P()]))

@pytest.mark.parametrize('stage,legal,source,adtext,expected,zone',[
    ('Котлован','unknown','','ЖК DEMO Альфа: квартиры в продаже, внесите депозит 200 000 ₸',35,'yellow'),
    ('Котлован','verified_absent','DEMO: документ','ЖК DEMO Альфа: квартиры в продаже, внесите депозит 200 000 ₸',70,'red'),
    ('Котлован','verified_guarantee','DEMO: гарантия','ЖК DEMO Альфа: квартиры в продаже от 20 млн ₸',10,'green'),
])
def test_required_scenarios(stage,legal,source,adtext,expected,zone):
    p=P(stage=stage,legal_status=legal,legal_source=source)
    result=score_project(p,[A(adtext)])
    assert (result['score'],result['zone'])==(expected,zone)

def test_unreviewed_ai_hypothesis_does_not_score():
    p=P(legal_status='unknown')
    r=score_project(p,[A('ЖК DEMO Альфа продажа квартир, депозит 500 000 ₸',False)])
    assert r['score']==0 and r['pending_ads']==1 and r['zone']=='green'

def test_absence_is_not_inferred_from_empty_source():
    assert score_project(P(legal_status='verified_absent',legal_source=''),[])['score']==0

def test_high_score_without_r1_r2_is_yellow():
    p=P(legal_status='verified_guarantee',legal_source='verified',
        verified_complaint=True,complaint_evidence='DEMO: complaint',verified_delay=True,delay_evidence='DEMO: delay',
        claimed_completion=70,completion=20,claimed_source='DEMO: announcement',completion_source='DEMO: act')
    result=score_project(p,[A('ЖК DEMO Альфа продается квартира от 20 млн ₸')])
    assert result['zone']=='yellow' and result['score']==40

def test_free_booking_is_not_payment():
    r=analyze_text('ЖК DEMO Альфа. Продажа квартир 22 млн ₸. Бронирование бесплатно, депозит не требуется.',[P()])
    assert not r['payment']['found']
    assert r['price']['found'] and r['advertising']['found']

def test_genuine_deposit_detected_and_cited():
    r=analyze_text('Продаётся квартира, ЖК DEMO Альфа. Для заявки внесите депозит 200 000 ₸.',[P()])
    assert r['payment']['found'] and 'депозит' in r['payment']['snippet']
    assert r['matching']['project_id']==1

def test_new_text_works_not_canned():
    projects=[P(),P(id=2,name='ЖК DEMO «Бета»',aliases=['Демо Бета'])]
    result=analyze_text('Квартира в Демо Бета от 15 млн ₸, возможна бронь за 100 000 ₸',projects)
    assert result['matching']['project_id']==2 and result['payment']['found']

def test_price_alone_does_not_mean_deposit():
    r=analyze_text('Продажа квартиры в ЖК DEMO Альфа: стоимость 21 млн ₸', [P()])
    assert r['price']['found'] and r['advertising']['found']
    assert not r['payment']['found']
