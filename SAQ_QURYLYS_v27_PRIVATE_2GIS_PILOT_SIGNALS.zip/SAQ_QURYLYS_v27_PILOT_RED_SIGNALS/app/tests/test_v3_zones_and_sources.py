"""V3 coverage: real OSM geometry, human-drawn contours, authorized APIs and permits."""
import io
import json
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from app.database import Base,get_db
from app.main import app
from app.seed import seed_demo
from app import geo_zones,connectors


def test_osm_polygons_are_real_closed_ways_only():
    raw={'elements':[
        {'type':'way','id':102,'tags':{'landuse':'construction','name':'Существующий участок OSM'},'geometry':[
             {'lat':49.955,'lon':82.612},{'lat':49.956,'lon':82.612},
             {'lat':49.956,'lon':82.613},{'lat':49.955,'lon':82.612}]},
        {'type':'way','id':103,'tags':{'building':'construction'},'geometry':[
             {'lat':49.955,'lon':82.612},{'lat':49.956,'lon':82.612},
             {'lat':49.956,'lon':82.614}]},
        {'type':'way','id':104,'tags':{'building':'construction'},'geometry':[
             {'lat':50.955,'lon':82.612},{'lat':50.956,'lon':82.612},
             {'lat':50.956,'lon':82.614},{'lat':50.955,'lon':82.612}]}
    ]}
    result=geo_zones.to_geojson(raw)
    assert len(result['features'])==1
    assert result['features'][0]['properties']['source_url']=='https://www.openstreetmap.org/way/102'
    assert result['features'][0]['properties']['verified'] is False


def test_offline_osm_does_not_fabricate_polygons(monkeypatch,tmp_path):
    monkeypatch.setattr(geo_zones,'CACHE_PATH',tmp_path/'missing.json')
    def fail(*args,**kwargs):raise __import__('httpx').ConnectError('blocked')
    monkeypatch.setattr(__import__('httpx').Client,'post',fail)
    result=geo_zones.construction_zones()
    assert result['status']=='unavailable' and result['features']==[]


def test_meta_and_olx_require_credentials(monkeypatch):
    for name in ('SAQ_IG_ACCESS_TOKEN','SAQ_IG_USER_ID','SAQ_OLX_ACCESS_TOKEN'):
        monkeypatch.delenv(name,raising=False)
    for f in (connectors.instagram_hashtags,connectors.olx_account_ads):
        try:f();assert False,'must require configured credentials'
        except connectors.ConnectorError:pass


def test_real_partner_adapters_transform_api_responses(monkeypatch):
    monkeypatch.setenv('SAQ_OLX_ACCESS_TOKEN','test-token-not-real')
    monkeypatch.setenv('SAQ_IG_ACCESS_TOKEN','test-token-not-real')
    monkeypatch.setenv('SAQ_IG_USER_ID','123456')
    monkeypatch.setenv('SAQ_IG_HASHTAGS','newbuild')
    def fake_get(url,*,headers=None,params=None,limit=5000000):
        assert headers['Authorization'].startswith('Bearer ')
        if 'olx.kz' in url:return json.dumps({'data':[{'url':'https://www.olx.kz/ad/example','title':'Квартира','description':'Взнос 300 000 ₸','created_at':'2026-10-17'}]}).encode()
        if url.endswith('ig_hashtag_search'):return json.dumps({'data':[{'id':'33'}]}).encode()
        return json.dumps({'data':[{'caption':'ЖК строится, бронирование 50 000 ₸','permalink':'https://www.instagram.com/p/xyz/','timestamp':'2026-10-17'}]}).encode()
    monkeypatch.setattr(connectors,'_get',fake_get)
    assert connectors.olx_account_ads()[0]['platform']=='olx'
    assert connectors.instagram_hashtags()[0]['source_url'].startswith('https://www.instagram.com/')


def test_project_boundary_does_not_change_score_and_registry_sync_does_not_verify(monkeypatch):
    engine=create_engine('sqlite://', connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Session=sessionmaker(bind=engine)
    with Session() as db:seed_demo(db)
    def override():
        with Session() as db:yield db
    app.dependency_overrides[get_db]=override
    try:
        with TestClient(app) as c:
            old=c.get('/api/projects/1').json()
            assert old['score']==35
            polygon={'type':'Polygon','coordinates':[[[82.610,49.950],[82.612,49.950],[82.612,49.952],[82.610,49.950]]]}
            invalid=c.post('/api/projects/1/boundary',json={'geometry':{'type':'Point','coordinates':[82.61,49.95]},'source':'https://www.openstreetmap.org/','reviewer':'Аналитик'})
            assert invalid.status_code==422
            r=c.post('/api/projects/1/boundary',json={'geometry':polygon,'source':'https://www.openstreetmap.org/way/111','reviewer':'Аналитик'})
            assert r.status_code==200 and r.json()['score']==35
            feature=c.get('/api/map/project-boundaries').json()['features']
            assert any(x['properties']['project_id']==1 for x in feature)
            rows=[{'permission_id':'official-id-555','permission_number':'MIО-0001','object_location':'ЖК в Усть-Каменогорске','builder_name':'Застройщик','issue_date':'2026-10-01'}]
            monkeypatch.setattr(connectors,'permits_csv',lambda:rows)
            assert c.post('/api/registries/ashyq/sync').json()['added']==1
            assert c.post('/api/registries/ashyq/sync').json()['duplicates']==1
            assert c.get('/api/registries/permits?q=MIO-0001').status_code==200
            assert c.get('/api/projects/1').json()['legal_status']=='unknown'
            assert c.post('/api/collect/instagram').status_code in (409,502)
    finally:
        app.dependency_overrides.clear();engine.dispose()


def test_source_list_includes_all_named_registries():
    with TestClient(app) as c:
        r=c.get('/api/sources')
        assert r.status_code==200
        urls=[x['url'] for x in r.json()]
        assert len(urls)>=11
        assert any('elicense.kz' in url for url in urls)
        assert any('map.gov4c.kz' in url for url in urls)
        assert 'scrollWheelZoom:true' in c.get('/static/app.js').text
        assert 'project-boundaries' in c.get('/static/app.js').text
        assert 'data-collect' in c.get('/static/app.js').text
