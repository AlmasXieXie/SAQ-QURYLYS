"""v8 behaviour: real-only catalog, map, analytics, and human ad workflow.
All tests use a disposable database supplied to the test process.
"""
from fastapi.testclient import TestClient
from app.main import app


def test_main_and_real_catalog():
    with TestClient(app) as c:
        assert c.get('/').status_code == 200
        assert 'signal_map.js' in c.get('/').text
        assert c.get('/geo').status_code == 200
        h=c.get('/api/health').json()
        assert h['demo'] is False
        projects=c.get('/api/v8/catalog').json()
        assert len(projects)==44
        assert len({x['name'] for x in projects})==44
        assert all('DEMO' not in x['name'].upper() for x in projects)
        assert any(x['name']=='ЖК Diamond' and x['latitude'] is None for x in projects)
        assert any(x['name']=='ЖК Astoria' for x in projects)
        assert all(x['address'].startswith('Усть-Каменогорск') for x in projects)


def test_real_analytics_and_developer_linking():
    with TestClient(app) as c:
        a=c.get('/api/v8/analytics').json()
        assert a['buildings']==44
        assert a['ads']>=12  # v24 seeds 12 genuine publicly indexed listing URLs
        assert a['developer_labels']>=20
        assert a['mapped']+a['unmapped']==44
        assert a['mode']=='real_catalog_no_demo'
        d=c.get('/api/v8/developers').json()
        assert len(d)==a['developer_labels']
        assert any(x['name']=='AN Groups' and len(x['projects'])>=2 for x in d)
        assert any(x['name']=='Железобетонный комбинат' and x['site'] for x in d)
        projects=c.get('/api/v8/catalog').json()
        selected=next(x for x in projects if x['name']=='ЖК AINALAIYN')
        detail=c.get('/api/v8/catalog/'+str(selected['id'])).json()
        assert detail['developer']['site']=='https://angroups.kz/'
        assert detail['developer']['instagram']
        assert detail['authorizations']
        assert not detail['stage_verified']=='construction'
        assert '2gis' in detail['profile']['map_links']


def test_ad_review_never_creates_demo():
    with TestClient(app) as c:
        project=next(x for x in c.get('/api/v8/catalog').json() if x['name']=='ЖК ORDA')
        url='https://example.com/ustkam/test-real-ad-integration'
        body={'url':url,'building_id':project['id'],'text':'Продажа квартир в ЖК ORDA, бронь 200000 тенге', 'platform':'website'}
        r=c.post('/api/v8/ads',json=body)
        assert r.status_code==201
        ad=r.json()
        assert ad['building_id']==project['id']
        assert ad['analysis']['payment_terms']
        assert c.post('/api/v8/ads',json=body).status_code==409
        rv=c.post(f'/api/v8/ads/{ad["id"]}/review',json={'status':'accepted','reviewer':'Тестовый аналитик'})
        assert rv.status_code==200
        assert rv.json()['status']=='accepted'
        assert c.get('/api/v8/analytics').json()['ads']>=1
        assert c.post('/api/v8/ads',json={'url':'javascript:alert(1)','text':'Продажа квартиры'}).status_code==422


def test_old_demo_records_removed():
    with TestClient(app) as c:
        old=c.get('/api/projects').json()
        assert not any(p.get('demo') for p in old)
        assert not any(p.get('demo') for p in c.get('/api/ads').json())


def test_existing_validators_and_ocr():
    with TestClient(app) as c:
        assert c.post('/api/ocr',files={'file':('evil.txt',b'x','text/plain')}).status_code==415
        assert c.get('/api/v8/settings').json()['map_provider']=='2gis'
        assert c.get('/static/v8.js').status_code==200
        assert c.get('/static/v8.css').status_code==200
