"""v16: colors are derived from evidence, never inferred from an absent local permit."""
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from app.database import Base,get_db
from app.main import app
from app.unified_registry import load_starter
from app.catalog_uka import load_catalog
from app.extra_problem_sites import load_extra
from app.signal_map import visual_state,visual_reason


def test_coloring_logic_never_green_by_missing_data():
    basic={'zone':'green','score':0,'triage_score':0,'pending_ads':0}
    assert visual_state(basic,'unknown')=='yellow'
    assert visual_state(basic,'verified_guarantee')=='green'
    assert visual_state(basic,'verified_mio')=='green'
    assert visual_state({**basic,'triage_score':25,'pending_ads':1},'unknown')=='yellow'
    assert visual_state({**basic,'zone':'red','score':70},'verified_absent')=='red'
    assert visual_state({**basic,'zone':'yellow','score':35},'verified_absent')=='yellow'
    assert 'НЕ' in visual_reason(basic,'yellow')


def test_live_signal_cycle_and_explainability():
    engine=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Local=sessionmaker(bind=engine,expire_on_commit=False)
    with Local() as db:
        load_starter(db);load_catalog(db);load_extra(db)
    def override():
        with Local() as db:yield db
    app.dependency_overrides[get_db]=override
    try:
        with TestClient(app) as c:
            assert 'signal_map.js' in c.get('/').text
            for route in ('/geo','/workbench','/registry','/verify'):
                assert 'signal_map.js' in c.get(route).text
            start=c.get('/api/signal-map/snapshot').json()
            assert start['total']==40
            assert start['counts']=={'red':0,'yellow':40,'green':0}
            assert start['unverified']==40
            assert start['mapped']+start['without_coordinates']==40
            project=next(x for x in start['items'] if x['name']=='ЖК AINALAIYN')
            id=project['id']
            payload={'building_id':id,'platform':'olx','url':'https://example.org/v16/unique-check',
                     'text':'ЖК AINALAIYN, строящийся комплекс. Продажа квартир, платная бронь 200000 тенге.'}
            assert c.post('/api/v8/ads',json=payload).status_code==201
            live=next(x for x in c.get('/api/signal-map/snapshot').json()['items'] if x['id']==id)
            assert live['map_color']=='yellow'
            assert live['score']==0 and live['triage_score']>=25
            assert live['evidence_kind']=='automatic_hypothesis'
            ad=c.get(f'/api/workbench/cases/{id}').json()['risk']['ads'][0]
            assert ad['payment_excerpt']
            assert c.post(f'/api/workbench/ads/{ad["id"]}/review',json={'status':'accepted','analyst':'Ревизор МИО'}).status_code==200
            reviewed=next(x for x in c.get('/api/signal-map/snapshot').json()['items'] if x['id']==id)
            assert reviewed['map_color']=='yellow' and reviewed['score']==25
            check=c.post(f'/api/workbench/cases/{id}/legal',json={'analyst':'Ревизор МИО',
                      'status':'verified_absent','stage_status':'under_construction',
                      'evidence_url':'https://example.org/fictional-verified-document',
                      'note':'Синтетический пример независимой сверки правового основания конкретной очереди ЖК.'})
            assert check.status_code==200
            red=next(x for x in c.get('/api/signal-map/snapshot').json()['items'] if x['id']==id)
            assert red['map_color']=='red' and red['score']==70
            assert 'не заключение' in red['color_reason'].lower()
            another=next(x for x in start['items'] if x['name']=='ЖК ORDA')['id']
            res=c.post(f'/api/workbench/cases/{another}/legal',json={
                'analyst':'Ревизор МИО','status':'verified_guarantee','stage_status':'under_construction',
                'evidence_url':'https://example.org/fictional-guarantee',
                'note':'Тест: отдельно подтверждено применимое основание для указанной строительной очереди.'})
            assert res.status_code==200
            new=next(x for x in c.get('/api/signal-map/snapshot').json()['items'] if x['id']==another)
            assert new['map_color']=='green'
    finally:
        app.dependency_overrides.clear();engine.dispose()
