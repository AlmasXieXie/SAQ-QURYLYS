"""No synthetic building shapes: real OSM polygons and explicit 2GIS feature links only."""
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool
from sqlalchemy.orm import Session
from fastapi.testclient import TestClient
from app.database import Base,get_db
from app.main import app
from app.unified_registry import load_starter
from app.catalog_uka import load_catalog
from app.extra_problem_sites import load_extra
from app.v9_api import local_polygon
from app.geo_zones import to_geojson
import app.v9_api as v9

REAL_RING=[[82.612,49.956],[82.61222,49.956],[82.61222,49.95624],[82.612,49.956]]
FAKE_OSM={'type':'FeatureCollection','features':[
 {'type':'Feature','geometry':{'type':'Polygon','coordinates':[REAL_RING]},
  'properties':{'osm_id':998877,'name':'', 'classification':'building_construction',
  'source_url':'https://www.openstreetmap.org/way/998877','osm_address':'', 'verified':False}}
 ],'status':'cached','fetched_at':'2026-10-17T07:00:00+00:00'}


def client():
    eng=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(eng)
    db=Session(eng);load_starter(db);load_catalog(db);load_extra(db);db.close()
    def dependency():
        with Session(eng) as db:yield db
    app.dependency_overrides[get_db]=dependency
    return TestClient(app)


def test_geometry_never_generated_from_point():
    assert local_polygon({'type':'Polygon','coordinates':[REAL_RING]})
    assert not local_polygon({'type':'Point','coordinates':[82.61,49.95]})
    assert not local_polygon({'type':'Polygon','coordinates':[[[82.61,49.95],[82.62,49.96],[82.62,49.95]]]})
    assert not local_polygon({'type':'Polygon','coordinates':[[[40,40],[40.1,40],[40.1,40.1],[40,40]]]})


def test_osm_only_explicit_tags_and_real_closed_ways():
    features=to_geojson({'elements':[
        {'type':'way','id':11,'tags':{'building':'construction','addr:street':'Кайсенова','addr:housenumber':'55/1'},'geometry':[{'lon':x,'lat':y} for x,y in REAL_RING]},
        {'type':'way','id':12,'tags':{'building':'construction'},'geometry':[{'lon':82.61,'lat':49.95},{'lon':82.62,'lat':49.95},{'lon':82.62,'lat':49.96}]},
    ]})['features']
    assert len(features)==1
    assert features[0]['properties']['classification']=='building_construction'
    assert features[0]['properties']['osm_address']=='Кайсенова, 55/1'
    assert features[0]['geometry']['coordinates'][0]==REAL_RING


def test_polygon_link_conflict_deletion_and_real_catalog(monkeypatch):
    monkeypatch.setattr(v9,'construction_zones',lambda **kw:FAKE_OSM)
    with client() as c:
        try:
            assert 'signal_map.js' in c.get('/geo').text
            projects=c.get('/api/v8/catalog').json()
            assert len(projects)==40
            assert any(p['name']=='ЖК Diamond' and p['latitude'] is None for p in projects)
            assert c.get('/api/v9/construction').json()['features'][0]['properties']['osm_id']==998877
            a,b=projects[0]['id'],projects[1]['id']
            payload={'building_id':a,'provider':'osm','feature_id':'998877','linked_by':'Инспектор'}
            r=c.post('/api/v9/links',json=payload)
            assert r.status_code==201,r.text
            link=r.json()
            assert link['polygon']['type']=='Polygon'
            assert link['accuracy']=='analyst_association_not_independently_verified'
            assert len(c.get('/api/v9/links').json())==1
            assert c.post('/api/v9/links',json=payload).status_code==201
            assert len(c.get('/api/v9/links').json())==1
            assert c.post('/api/v9/links',json={**payload,'building_id':b}).status_code==409
            assert c.post('/api/v9/links',json={**payload,'feature_id':'123456789'}).status_code==422
            assert c.post('/api/v9/links',json={**payload,'building_id':999999}).status_code==422
            assert c.request('DELETE',f'/api/v9/links/{link["id"]}',json={'linked_by':'Инспектор'}).status_code==200
            assert c.get('/api/v9/links').json()==[]
        finally:app.dependency_overrides.clear()


def test_2gis_requires_manual_click_coordinates_and_2gis_source():
    with client() as c:
        try:
            a=c.get('/api/v8/catalog').json()[0]['id']
            payload={'building_id':a,'provider':'2gis','feature_id':'700300987','linked_by':'Картограф',
              'source_url':'https://2gis.kz/ust-kamenogorsk/search/test'}
            assert c.post('/api/v9/links',json=payload).status_code==422
            assert c.post('/api/v9/links',json={**payload,'click_coordinates':[90.5,51.2]}).status_code==422
            assert c.post('/api/v9/links',json={**payload,'click_coordinates':[82.61,49.95],'source_url':'https://example.com'}).status_code==422
            r=c.post('/api/v9/links',json={**payload,'click_coordinates':[82.61,49.95]})
            assert r.status_code==201,r.text
            assert r.json()['polygon'] is None
            assert r.json()['position']==[82.61,49.95]
            assert len(c.get('/api/v9/links').json())==1
        finally:app.dependency_overrides.clear()
