'use strict';
const fs=require('node:fs');const assert=require('node:assert/strict');
const html=fs.readFileSync('app/static/signal_map.html','utf8');
const js=fs.readFileSync('app/static/signal_map.js','utf8');
for(const part of ['map','review','ads','signals','registry','developers','ocr','sources','training'])
  assert.match(html,new RegExp('data-view="'+part+'"'));
assert.match(js,/\bmarkerHTML\(/);
assert.match(js,/class=\\?"signal-pin/);
assert.match(js,/api\/signal-map\/snapshot/);
assert.match(js,/setInterval\(backgroundRefresh,15000\)/);
assert.match(js,/api\/workbench\/cases\//);
assert.match(js,/data-create-signal/);
assert.match(js,/data-ocr-save/);
console.log('v16 UI contract: menu, pin colors, refresh, evidence, signals, OCR — OK');
