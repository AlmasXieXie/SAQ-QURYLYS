"""Run an end-to-end review in isolated database. TestClient and production API agree."""
from io import BytesIO
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base, get_db
from app.main import app
from app.seed import seed_demo

@pytest.fixture
def isolated():
    eng=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(eng)
    Local=sessionmaker(bind=eng,expire_on_commit=False)
    with Local() as session:seed_demo(session)
    def override():
        with Local() as session:yield session
    app.dependency_overrides[get_db]=override
    with TestClient(app) as c:yield c
    app.dependency_overrides.clear()
    eng.dispose()

def test_submission_review_score_and_pdf(isolated):
    c=isolated
    assert c.get('/api/projects/5').json()['score']==10
    text='Продаётся квартира в ЖК DEMO Эпсилон. Внесите депозит 999 000 ₸.'
    new=c.post('/api/ads',json={'text':text,'platform':'manual'}).json()
    assert new['review_status']=='pending' and new['project_id']==5
    assert c.get('/api/projects/5').json()['score']==10
    checked=c.post(f"/api/ads/{new['id']}/review",json={'status':'accepted','reviewer':'Тестовый аналитик'}).json()
    assert checked['review_status']=='accepted'
    assert c.get('/api/projects/5').json()['score']==35
    # Source-proven absence can move a verified deposit case into the red zone.
    legal=c.post('/api/projects/5/legal',json={'status':'verified_absent',
        'basis':'ДЕМО акт проверки','source':'DEMO: акт №1','reviewer':'Тестовый аналитик'})
    assert legal.status_code==200 and legal.json()['score']==70
    sig=c.post('/api/projects/5/signals',json={'author':'Тестовый аналитик','note':'Проверка'}).json()
    assert sig['score']==70 and sig['zone']=='red' and sig['status']=='pending'
    confirmed=c.post(f"/api/signals/{sig['id']}/decision",json={'status':'confirmed','author':'Тестовый аналитик','note':'Подтверждено по учебному документу'})
    assert confirmed.json()['status']=='confirmed'
    pdf=c.get(f"/api/projects/5/report.pdf?signal_id={sig['id']}")
    assert pdf.content[:5]==b'%PDF-' and len(pdf.content)>7000

def test_import_registry_defaults_to_unknown(isolated):
    c=isolated
    csv_data='name,address,developer,bin,latitude,longitude,stage,completion,source_url\n"ЖК Тестовый Импорт","Демо адрес","ТОО Демо",000000000000,49.95,82.61,"Фундамент",14,https://homeportal.kz\n'
    r=c.post('/api/import/projects.csv',files={'file':('objects.csv',csv_data.encode('utf-8'),'text/csv')})
    assert r.status_code==200,r.text
    assert r.json()['added']==1
    projects=c.get('/api/projects').json()
    inserted=next(p for p in projects if p['name']=='ЖК Тестовый Импорт')
    assert inserted['legal_status']=='unknown' and inserted['score']==0
    repeated=c.post('/api/import/projects.csv',files={'file':('objects.csv',csv_data.encode('utf-8'),'text/csv')})
    assert repeated.json()['skipped']==1
