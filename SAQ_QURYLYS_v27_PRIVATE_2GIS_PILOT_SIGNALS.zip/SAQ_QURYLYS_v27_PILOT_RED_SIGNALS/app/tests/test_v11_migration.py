import sqlite3
from pathlib import Path
from app.v11_migration import TRUSTED_PREFIXES,CONFLICT_NAMES

def test_no_unverified_sources_or_diamond_migrated():
    assert not any('DEMO' in s for s in TRUSTED_PREFIXES)
    assert 'ЖК Diamond' in CONFLICT_NAMES and 'ЖК Gran Via' in CONFLICT_NAMES

def test_previous_db_original_is_not_written(tmp_path):
    old=tmp_path/'SAQ_QURYLYS_v10_AUTO_BUILDINGS'
    old.mkdir()
    f=old/'saq.sqlite3'
    conn=sqlite3.connect(f)
    conn.execute('create table unified_buildings (building_key text, address text, latitude float, longitude float, coordinate_source text)')
    conn.execute("insert into unified_buildings values ('unknown','mock',49.95,82.61,'DEMO')")
    conn.commit();conn.close()
    before=f.read_bytes()
    from app.v11_migration import import_from_prior
    class FakeDb:
        def scalars(self,*a):return type('Scalars',(),{'all':lambda self:[]})()
    assert import_from_prior(FakeDb(),tmp_path/'SAQ_QURYLYS_v11_CITYWIDE_CLICKABLE')['imported']==0
    assert f.read_bytes()==before
