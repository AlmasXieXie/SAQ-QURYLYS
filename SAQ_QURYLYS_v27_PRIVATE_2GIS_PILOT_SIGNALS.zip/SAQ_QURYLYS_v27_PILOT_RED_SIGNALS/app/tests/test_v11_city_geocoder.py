"""v11 never converts uncertain addresses or street-centres into real ЖК pins."""
from app.v11_geocode import canonical_street, exact_address, choose_one, nominatim_params


def sample(lat='49.956', lon='82.612', house='55/1', street='улица Кайсенова'):
    return {'lat': lat, 'lon': lon, 'osm_id': 1234, 'osm_type': 'way',
            'address': {'road': street, 'house_number': house, 'city': 'Усть-Каменогорск'}}


def test_exact_osm_house_match():
    addr='Усть-Каменогорск, ул. Кайсенова, 55/1'
    assert exact_address(sample(),addr)
    assert not exact_address(sample(house='55'),addr)
    assert not exact_address(sample(house='55/2'),addr)
    assert not exact_address(sample(street='улица Кокжал Барака'),addr)
    assert not exact_address(sample(lat='43.24'),addr)
    assert not exact_address({'lat':'49.96','lon':'82.6','address':{'road':'улица Кайсенова'}},addr)


def test_ambiguity_and_problem_site_addresses_rejected():
    addr='Усть-Каменогорск, ул. Кайсенова, 55/1'
    assert choose_one([sample(),sample()],addr)[1]=='ambiguous'
    assert choose_one([sample(house='55/2')],addr)[1]=='missing'
    assert choose_one([sample()],addr)[1]=='resolved'
    assert not exact_address(sample(), 'Усть-Каменогорск, пересечение ул. Увалиева и Кокжал Барака, 19-й жилой район')
    assert not exact_address(sample(), 'Усть-Каменогорск, пр. Казыбек би (без номера)')


def test_street_suffixes_and_bbox_limit():
    assert canonical_street('пр. Ильяса Есенберлина')==canonical_street('улица Есенберлина')
    p=nominatim_params('Усть-Каменогорск, ул. Кайсенова, 55/1')
    assert p['bounded']==1 and p['addressdetails']==1 and p['limit']<=10
