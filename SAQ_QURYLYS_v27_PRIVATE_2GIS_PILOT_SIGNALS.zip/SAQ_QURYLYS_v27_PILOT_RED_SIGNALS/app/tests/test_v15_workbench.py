"""Isolated end-to-end evidence → verified factor → human decision → PDF tests."""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from app.database import Base, get_db
from app.main import app
from app.unified_registry import load_starter
from app.catalog_uka import load_catalog
from app.extra_problem_sites import load_extra

@pytest.fixture
def client():
    engine=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Local=sessionmaker(bind=engine,expire_on_commit=False)
    with Local() as db:
        load_starter(db);load_catalog(db);load_extra(db)
    def db_override():
        with Local() as db:yield db
    app.dependency_overrides[get_db]=db_override
    try:
        with TestClient(app) as c:yield c
    finally:
        app.dependency_overrides.clear()
        engine.dispose()


def choose(c,name):
    x=next(p for p in c.get('/api/workbench/cases').json() if p['name']==name)
    return x['id']


def test_real_40_and_training_strictly_separate(client):
    c=client
    assert c.get('/workbench').status_code==200
    assert len(c.get('/api/workbench/cases').json())==40
    assert c.get('/api/workbench/training/load',).status_code==405
    x=c.post('/api/workbench/training/load').json()
    assert x['created'] and x['projects']==8 and x['ads']==12
    assert not c.post('/api/workbench/training/load').json()['created']
    assert len(c.get('/api/workbench/cases').json())==40
    assert all('DEMO' not in x['name'] for x in c.get('/api/v8/catalog').json())
    demo=[p for p in c.get('/api/projects').json() if p['demo']]
    assert len(demo)==8
    byname={p['name']:p for p in demo}
    a=byname['ЖК DEMO «Альфа»'];b=byname['ЖК DEMO «Бета»'];g=byname['ЖК DEMO «Гамма»']
    assert (a['score'],a['zone'])==(35,'yellow')
    assert (b['score'],b['zone'])==(70,'red')
    assert (g['score'],g['zone'])==(10,'green')
    assert c.get('/api/projects/'+str(b['id'])).json()['factors']


def test_end_to_end_real_unknown_to_red(client):
    c=client
    project=choose(c,'ЖК AINALAIYN')
    initial=c.get(f'/api/workbench/cases/{project}').json()
    assert initial['score']==0 and initial['zone']=='green' and initial['risk']['legal']['status']=='unknown'
    assert 'Не проверено' not in (initial['risk']['factors'] or [])
    ad=c.post('/api/v8/ads',json={'building_id':project,
       'text':'ЖК AINALAIYN. Строящийся жилой комплекс. Продажа квартир, платная бронь 200000 тенге, первоначальный взнос.',
       'url':'https://example.org/proof/test-real-ad','platform':'website'}).json()
    pending=c.get(f'/api/workbench/cases/{project}').json()
    assert pending['score']==0 and pending['risk']['hypotheses']
    assert pending['triage_score']==35 and pending['triage_zone']=='yellow'
    assert not any(x['code']=='R1' for x in pending['risk']['factors'])
    rv=c.post(f"/api/workbench/ads/{ad['id']}/review",json={'status':'accepted','analyst':'Тест МИО'})
    assert rv.status_code==200
    accepted=c.get(f'/api/workbench/cases/{project}').json()
    assert accepted['score']==25 and accepted['zone']=='yellow'
    assert [f['code'] for f in accepted['risk']['factors']]==['R2']
    bad=c.post(f'/api/workbench/cases/{project}/legal',json={'status':'verified_absent','stage_status':'under_construction','analyst':'Тест МИО','note':'Нет документа'})
    assert bad.status_code==422
    stage=c.post(f'/api/workbench/cases/{project}/legal',json={
        'status':'unknown','stage_status':'under_construction','analyst':'Тест МИО',
        'evidence_url':'https://example.org/official/inspection','note':'Сверена стадия строительства конкретного корпуса по акту строительства.'})
    assert stage.status_code==200
    before=c.get(f'/api/workbench/cases/{project}').json()
    assert before['score']==35 and set(f['code'] for f in before['risk']['factors'])=={'R2','R3'}
    assert c.post(f'/api/workbench/cases/{project}/legal',json={
        'status':'verified_absent','stage_status':'under_construction','analyst':'Тест МИО',
        'evidence_url':'https://example.org/official/inspection','note':'Это учебный тест проверки отсутствия применимого основания для данного корпуса.'}).status_code==200
    high=c.get(f'/api/workbench/cases/{project}').json()
    assert high['score']==70 and high['zone']=='red'
    sig=c.post(f'/api/workbench/cases/{project}/signals',json={'analyst':'Тест МИО','note':'Проверить указанный платеж'}).json()
    assert sig['score']==70 and sig['status']=='pending'
    pdf=c.get(f"/api/workbench/signals/{sig['id']}/report.pdf")
    assert pdf.status_code==200 and pdf.content.startswith(b'%PDF-')
    dec=c.post(f"/api/workbench/signals/{sig['id']}/decision",json={'analyst':'Руководитель','status':'returned','note':'Проверить источник ещё раз'})
    assert dec.status_code==200 and dec.json()['reviewed_at']
    assert c.post(f"/api/workbench/signals/{sig['id']}/decision",json={'analyst':'Руководитель','status':'confirmed','note':'Повтор'}).status_code==409
    log=c.get(f'/api/workbench/cases/{project}').json()['actions']
    assert {'ad_review','legal_review','signal_created','signal_decision'} <= {x['action'] for x in log}


def test_verified_guarantee_never_red_by_itself(client):
    c=client;id=choose(c,'ЖК ORDA')
    ad=c.post('/api/v8/ads',json={'building_id':id,'url':'https://example.org/proof/orda',
            'platform':'website','text':'ЖК ORDA продажа квартир, платная бронь 200000 тенге'}).json()
    c.post(f"/api/workbench/ads/{ad['id']}/review",json={'status':'accepted','analyst':'Тест МИО'})
    out=c.post(f'/api/workbench/cases/{id}/legal',json={'status':'verified_guarantee','stage_status':'under_construction',
       'analyst':'Тест МИО','evidence_url':'https://example.org/official/guarantee',
       'note':'Установлена действующая гарантия для проверяемой очереди ЖК.'})
    assert out.status_code==200
    score=c.get(f'/api/workbench/cases/{id}').json()
    assert score['score']==35 and score['zone']=='yellow'
    assert 'R1' not in {f['code'] for f in score['risk']['factors']}


def test_documented_progress_needs_two_sources(client):
    c=client;id=choose(c,'ЖК ORDA')
    payload={'code':'R5','analyst':'Тест МИО','note':'Зафиксировано различие готовности по акту и рекламе',
             'evidence_url':'https://example.org/official/progress','second_source':'https://example.org/marketing',
             'reported_progress':70,'verified_progress':49}
    assert c.post(f'/api/workbench/cases/{id}/factor',json=payload).status_code==200
    data=c.get(f'/api/workbench/cases/{id}').json()['risk']
    assert data['score']==10 and any(f['code']=='R5' for f in data['factors'])
    payload['verified_progress']=60
    assert c.post(f'/api/workbench/cases/{id}/factor',json=payload).status_code==422


def test_optional_basic_auth(client,monkeypatch):
    monkeypatch.setenv('SAQ_ADMIN_USER','reviewer');monkeypatch.setenv('SAQ_ADMIN_PASSWORD','secret-password-local-test')
    try:
        assert client.get('/workbench').status_code==401
        assert client.get('/api/workbench/cases',auth=('reviewer','wrong')).status_code==401
        assert client.get('/api/workbench/cases',auth=('reviewer','secret-password-local-test')).status_code==200
    finally:
        monkeypatch.delenv('SAQ_ADMIN_USER');monkeypatch.delenv('SAQ_ADMIN_PASSWORD')
