"""Regression: open source evidence is not a legal verdict or an automatic link."""
from sqlalchemy import create_engine, select, func
from sqlalchemy.pool import StaticPool
from sqlalchemy.orm import Session
from app.database import Base
from app.models import Project, RegistryPermit  # load legacy models, too
from app.unified_registry import (RegistryBuilding, RegistryCompany, RegistryEvidence, RegistryAuthorization,
  load_starter, import_ashyq_rows, import_buildings_csv,import_companies_csv,import_documents_csv,building_payload)


def session():
    engine=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(engine)
    return Session(engine)

def test_starter_contains_real_and_completed():
    with session() as db:
        assert load_starter(db)==14
        assert load_starter(db)==0
        assert db.scalar(select(func.count()).select_from(RegistryBuilding))==14
        statuses={x.stage_reported for x in db.scalars(select(RegistryBuilding))}
        assert statuses=={'construction','commissioned'}
        assert all(x.stage_verified=='unknown' for x in db.scalars(select(RegistryBuilding)))

def test_public_documents_not_law_enforcement_conclusions():
    with session() as db:
        load_starter(db)
        auth=db.scalars(select(RegistryAuthorization)).all()
        assert len(auth)==7
        assert {a.status for a in auth}=={'reported_official','reported_third_party'}
        assert not any(a.status in {'verified_valid','illegal','absent'} for a in auth)
        assert all(b.latitude is None and b.longitude is None for b in db.scalars(select(RegistryBuilding)))

def test_hashed_bin_permits_unmatched():
    with session() as db:
        load_starter(db)
        r={'permission_number':'МИО-TEST-1','builder_name':'ТОО НАУАН Корп','builder_bin_hashed':'xxxxx',
           'object_location':'Кайсенова 55/1','issue_date':'2025-02-02'}
        result=import_ashyq_rows(db,[r], 'https://ashyq.data.gov.kz/dataset/example')
        assert result['added']==1
        assert import_ashyq_rows(db,[r], 'https://ashyq.data.gov.kz/dataset/example')['added']==0
        a=db.scalar(select(RegistryAuthorization).where(RegistryAuthorization.document_number=='МИО-TEST-1'))
        assert a.building_id is None and a.company_id is None
        assert a.status=='official_dataset_unmatched'

def test_csv_buildings_are_not_marked_legal():
    with session() as db:
        content='name,address,developer,stage,source_url\nЖК Тест,Усть-Каменогорск улица 1,ТОО Тест,construction,https://homeportal.kz/x\n'.encode()
        assert import_buildings_csv(db,content,'homeportal')['added']==1
        assert import_buildings_csv(db,content,'homeportal')['added']==0
        b=db.scalar(select(RegistryBuilding))
        assert building_payload(db,b)['authorizations']==[]

def test_csv_company_bin_not_confused_with_proof():
    with session() as db:
        content='name,bin,source_url\nТОО Тест,123456789012,https://egov.kz/x\n'.encode()
        assert import_companies_csv(db,content,'egov')['added']==1
        c=db.scalar(select(RegistryCompany))
        assert c.legal_identity_status=='csv_needs_verification'
        assert c.bin=='123456789012'

def test_csv_licenses_are_unlinked_until_review():
    with session() as db:
        content='authorization_type,document_number,company_name,source_url\nconstruction_license,СТР-55,ТОО Тест,https://elicense.kz/x\n'.encode()
        assert import_documents_csv(db,content,'elicense')['added']==1
        a=db.scalar(select(RegistryAuthorization))
        assert a.building_id is None and a.company_id is None
        assert a.status=='imported_needs_verification'
