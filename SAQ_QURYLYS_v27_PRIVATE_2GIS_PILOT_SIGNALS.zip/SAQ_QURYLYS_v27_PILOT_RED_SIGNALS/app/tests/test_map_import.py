"""Regression tests for the real-map workflow and evidence-safe data imports."""
from io import BytesIO
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from app.database import Base, get_db
from app.main import app
from app.seed import seed_demo
from app.analyzer import analyze_text
from app.scoring import score_project
from app.models import Project, Advertisement


def test_ukg_real_source_and_coordinate_workflow():
    eng = create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(eng)
    Factory=sessionmaker(bind=eng,expire_on_commit=False)
    with Factory() as session: seed_demo(session)
    def override():
        with Factory() as session: yield session
    app.dependency_overrides[get_db]=override
    try:
        with TestClient(app) as c:
            csv_data = ('name;address;developer;bin;latitude;longitude;stage;completion;source_url\n'
                'ЖК Золотой квадрат;Усть-Каменогорск Кайсенова 55/1;ТОО НАУАН Корп;970640000190;;;Строится;42;https://www.homeportal.kz/ru/projects/1141\n')
            response = c.post('/api/import/projects.csv',files={'file':('kzhk.csv',csv_data.encode('utf-8'),'text/csv')})
            assert response.status_code == 200, response.text
            assert response.json()['added'] == 1
            imported = next(p for p in c.get('/api/projects').json() if p['name']=='ЖК Золотой квадрат')
            assert imported['latitude'] is None and imported['longitude'] is None
            assert imported['registry_url'].endswith('/1141')
            assert imported['legal_status']=='unknown' and imported['score']==0
            pid=imported['id']
            bad = c.post(f'/api/projects/{pid}/location',json={'latitude':49.955,'longitude':82.615,'source':'fake','reviewer':'Аналитик'})
            assert bad.status_code==422
            geo=c.post(f'/api/projects/{pid}/location',json={'latitude':49.955,'longitude':82.615,'source':'https://www.openstreetmap.org/#map=16/49.955/82.615','reviewer':'Аналитик'})
            assert geo.status_code==200,geo.text
            assert geo.json()['latitude']==49.955
            assert geo.json()['coordinate_source'].startswith('https://www.openstreetmap.org')
            assert geo.json()['score']==0
    finally:
        app.dependency_overrides.clear();eng.dispose()


def test_csv_ads_are_pending_and_deduplicated():
    eng = create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(eng)
    Factory=sessionmaker(bind=eng,expire_on_commit=False)
    with Factory() as session: seed_demo(session)
    def override():
        with Factory() as session:yield session
    app.dependency_overrides[get_db]=override
    try:
        with TestClient(app) as c:
            csv_data=('platform;source_url;project_name;text\n'
                      'olx;https://example.org/source/001;ЖК DEMO «Эпсилон»;Продаётся квартира ЖК DEMO Эпсилон. Внесите депозит 20 000 ₸\n'
                      'instagram;https://example.org/source/002;;Продаётся новая квартира по выгодной цене 19 млн ₸\n')
            r=c.post('/api/import/ads.csv',files={'file':('ads.csv',csv_data.encode('utf-8'),'text/csv')})
            assert r.status_code==200,r.text
            assert r.json()['added']==2 and r.json()['unmatched']>=1
            assert c.post('/api/import/ads.csv',files={'file':('ads.csv',csv_data.encode('utf-8'),'text/csv')}).json()['skipped']==2
            new=next(a for a in c.get('/api/ads').json() if a['source_url']=='https://example.org/source/001')
            assert new['review_status']=='pending'
            assert new['analysis']['payment']['found']
            assert c.get('/api/projects/5').json()['score']==10  # no unsupervised R2
    finally:
        app.dependency_overrides.clear();eng.dispose()


def test_kazakh_payment_parsing_and_unknown_stage_never_claims_advertising_confirmed():
    analysis=analyze_text('Құрылыс жүріп жатыр. Пәтер сатылады. Алдын ала төлем 500 000 ₸.',[])
    assert analysis['payment']['found'] and analysis['advertising']['found']
    negative=analyze_text('Пәтер сатылады, депозитсіз, тегін брондау',[])
    assert not negative['payment']['found']
    p=Project(id=900,name='Тест',aliases=[],address='Тест',developer='Тест',latitude=None,longitude=None,stage='Не уточнено',legal_status='unknown')
    a=Advertisement(text='Продается квартира!',analysis={'advertising':{'found':True,'snippet':'Продается квартира!'}},review_status='accepted',source_url='demo://1')
    assert score_project(p,[a])['score']==0

def test_offline_kzhk_example_is_real_but_legally_unverified():
    eng=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(eng)
    Factory=sessionmaker(bind=eng,expire_on_commit=False)
    with Factory() as session:seed_demo(session)
    def override():
        with Factory() as session:yield session
    app.dependency_overrides[get_db]=override
    try:
        with TestClient(app) as c:
            imported=c.post('/api/import/kzhk-uka-example',json={})
            assert imported.status_code==200,imported.text
            item=imported.json()['project']
            assert item['name']=='ЖК Золотой квадрат'
            assert item['demo'] is False and item['registry_url'].endswith('/1141')
            assert item['legal_status']=='unknown' and item['score']==0
            assert item['latitude'] is None
            assert c.post('/api/import/kzhk-uka-example',json={}).json()['added']==0
    finally:
        app.dependency_overrides.clear();eng.dispose()
