"""Pilot red: no certified basis on priced named 2026+; anonymous newbuilds flagged."""
from sqlalchemy import select
from app.tests.test_v26_official_and_ads import session_fixture,seed
from app.ad_archive_v24 import PublicAd, save_ad
from app.ad_monitor_v25 import ad_public, ads, summary
from app.ad_intelligence_v25 import name_from_text
from app.pilot_rules_v27 import priced_offer
from app.unified_registry import RegistryBuilding
from app.auto_decisions import evaluate_building


def test_price_only_not_year_area_and_document():
    assert not priced_offer('ЖК строится 2027 год 60 квадратных метров')['found']
    assert priced_offer('Квартира 26 500 000 ₸ сдача 2027 года')['found']
    assert not priced_offer('РНН: 9010000 год постройки 2027')['found']


def test_missing_or_generic_jk_name_is_not_a_proper_name():
    assert name_from_text('Новостройка. Цена 26 000 000 ₸')['source']=='Нет надёжного названия ЖК'
    assert name_from_text('ЖК без названия, цена 26 000 000 ₸')['source']=='Нет надёжного названия ЖК'
    assert name_from_text('ЖК 2027 г., новостройка 26 000 000 ₸')['source']=='Нет надёжного названия ЖК'
    assert name_from_text('ЖК Ясный, цена 26 000 000 ₸')['source'].startswith('Название заявлено')


def test_anonymous_newbuild_in_red_signal_feed_even_if_year_unknown():
    eng,Local=session_fixture()
    try:
        with Local() as db:
            seed(db)
            a,_=save_ad(db,url='https://www.olx.kz/d/obyavlenie/qa-name-less-1',
                text='Продам квартиру в новостройке от застройщика! Цена 23 500 000 ₸',feed='test')
            result=ad_public(db,a)
            assert result['year']['status']=='review'
            assert result['legal_assessment']['color']=='red'
            assert result['legal_assessment']['signal_queue']
            assert 'ЖК не назван' in result['legal_assessment']['label']
            assert any(x['id']==a.id for x in ads(view='signals',platform='',color='',limit=500,db=db))
            assert all(x['id']!=a.id for x in ads(view='active',platform='',color='',limit=500,db=db))
            assert summary(db)['anonymous_signals']>=1
    finally:eng.dispose()


def test_no_false_red_for_old_or_used_housing_or_no_price():
    eng,Local=session_fixture()
    try:
        with Local() as db:
            seed(db)
            samples=['Квартира вторичка, дом сдан. Новостройка 2025 год, цена 27 000 000 ₸',
                     'Квартира в новостройке, сдача 2027, площадь 60 кв.м.']
            for i,txt in enumerate(samples):
                a,_=save_ad(db,url=f'https://www.olx.kz/d/obyavlenie/qa-exclude-{i}',text=txt,feed='test')
                result=ad_public(db,a)
                assert result['legal_assessment']['color']!='red'
                assert not result['legal_assessment']['signal_queue']
    finally:eng.dispose()


def test_existing_official_jk_is_green_and_missing_project_proof_may_be_red():
    eng,Local=session_fixture()
    try:
        with Local() as db:
            seed(db)
            ad,_=save_ad(db,url='https://krisha.kz/a/show/987651238',
                         text='ЖК ORDA. Сдача 2027 года, цена 24 000 000 ₸',feed='test')
            result=ad_public(db,ad)
            assert result['legal_assessment']['color']=='green'
            # A project with an unspecified authorization status is not approved.
            # The test uses an existing unverified building and a real local observation.
            b=next((b for b in db.scalars(select(RegistryBuilding))
                    if b.name=='ЖК ЖАНЫМ'),None)
            assert b is not None
            assert evaluate_building(db,b)[0]['map_color'] in ('yellow','red')
    finally:eng.dispose()


def test_named_but_unknown_project_is_signal_without_geopinning():
    eng,Local=session_fixture()
    try:
        with Local() as db:
            seed(db)
            ad,_=save_ad(db,url='https://krisha.kz/a/show/987654319',
                  text='ЖК Вымышленный Неизвестный. Срок сдачи 2028 год. Цена 30 000 000 ₸.',feed='test')
            result=ad_public(db,ad)
            assert result['building_id'] is None
            assert result['legal_assessment']['color']=='red'
            assert result['legal_assessment']['unlinked_signal']['matches']
            assert result['legal_assessment']['signal_queue']
    finally:eng.dispose()
