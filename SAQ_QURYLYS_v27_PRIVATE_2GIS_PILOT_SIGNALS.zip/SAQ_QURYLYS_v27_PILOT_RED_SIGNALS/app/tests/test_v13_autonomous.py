"""No network and no fake records in the shipped project: synthetic fixtures only."""
import pytest
from types import SimpleNamespace
from app.autonomous_monitor import parse_rss, host_allowed, risk_category, source_feeds
from app.v13_geolocate import classify, named_candidate, direct_id


def test_rss_parsing_does_not_need_manual_upload():
    raw=b'<rss><channel><item><title>JK ORDA</title><link>https://www.olx.kz/d/obyavlenie/example.html</link><description>Advance payment</description></item></channel></rss>'
    result=parse_rss(raw)
    assert result[0]['link'].endswith('example.html')
    assert 'JK ORDA' in result[0]['text']
    with pytest.raises(ValueError):parse_rss(b'<!DOCTYPE rss><rss/>')


def test_rss_public_search_urls_are_generated_automatically():
    feeds=source_feeds()
    assert len(feeds)>=8
    assert all('bing.com/search' in url or 'detail-rss' in url for _,url in feeds)
    assert host_allowed('www.olx.kz')
    assert host_allowed('krisha.kz')
    assert not host_allowed('fake-olx.kz.evil.org')


def test_signal_is_not_legal_verdict():
    assert risk_category({'project':{'id':2},'risk_signal':'requires_review','status':'no_recorded_basis'})=='potential_equity_collection_no_basis_in_local_db'
    assert risk_category({'project':None,'risk_signal':'requires_review','status':'no_recorded_basis'})=='unresolved_project'


def test_named_building_card_requires_same_street():
    p=SimpleNamespace(name='ЖК AINALAIYN',address='Усть-Каменогорск, ул. Есенберлина, 5/1')
    good={'name':'ЖК AINALAIYN','address_name':'улица Ильяса Есенберлина, 5/1','point':{'lat':49.9,'lon':82.6},'id':'1234567891'}
    bad={**good,'address_name':'улица Кайсенова, 5/1'}
    assert named_candidate(good,p)
    assert not named_candidate(bad,p)
    assert classify(p,[good])[1]=='named_catalog_entity' or classify(p,[good])[1]=='exact_house'
    assert classify(p,[bad])[1]=='unresolved'


def test_geocoder_never_places_unknown_name():
    p=SimpleNamespace(name='ЖК Test Building',address='Усть-Каменогорск, ул. Кайсенова, 55/1')
    item={'name':'ЖК AINALAIYN','address_name':'улица Кайсенова, 17','point':{'lat':49.9,'lon':82.6},'id':'1234567890'}
    assert classify(p,[item])[0] is None
    assert direct_id('https://2gis.kz/ustkam/firm/70000001059877798')=='70000001059877798'
    assert direct_id('https://2gis.kz/ustkam/geo/70030076312915772')=='70030076312915772'


def test_direct_public_listings_are_parsed_without_manual_rss():
    from app.autonomous_monitor import ListingAnchorParser,DIRECT_CATALOGS
    markup='''<html><div><a href="/d/obyavlenie/zhk-ainalaiyn-IDabc.html">Продам ЖК AINALAIYN</a></div><a href="/wrong/path">Не объявление</a></html>'''
    parser=ListingAnchorParser('https://www.olx.kz/nedvizhimost/prodazha-kvartiry/ust-kamenogorsk/')
    parser.feed(markup)
    items=parser.parsed()
    assert len(items)==1 and 'AИNALAIYN' not in items[0]['title']
    assert items[0]['link'].startswith('https://www.olx.kz/d/obyavlenie/')
    assert 'olx.kz' in DIRECT_CATALOGS[0][1]
    assert 'krisha.kz' in DIRECT_CATALOGS[1][1]


def test_approximate_name_not_accepted_for_disputed_diamond():
    item={'name':'ЖК Diamond','address_name':'улица Увалиева, 7стр','point':{'lat':49.889947,'lon':82.614964}}
    p=SimpleNamespace(name='ЖК Diamond',address='Усть-Каменогорск, ул. Увалиева, 7стр')
    assert named_candidate(item,p) is False
