'use strict';
const fs=require('fs'), vm=require('vm'), assert=require('assert');
const code=fs.readFileSync(__dirname+'/../static/v11.js','utf8');
const calls=[];
let detailsId=null, badgeClick=null;
const catalog=[
 {id:1,name:'ЖК Easton',latitude:49.97,longitude:82.60,stage_reported:'construction',address:'Усть-Каменогорск, ул. Есенберлина, 38/3'},
 {id:2,name:'ЖК Diamond',latitude:null,longitude:null,stage_reported:'reported_unfinished',address:'Неопределённый участок'},
 {id:3,name:'ЖК ORDA',latitude:49.98,longitude:82.62,stage_reported:'construction',address:'Усть-Каменогорск, Кокжал Барака, 17'}
];
const context={
  st:{mapType:'2gis',map:{getZoom:()=>11},markers:[],projects:catalog,page:'map',selected:null},
  mapView:()=>'<div id="map-message" class="map-error" hidden></div><button class="btn blue" id="v10-retry">Привязать здания автоматически</button>',
  renderMarkers:()=>calls.push('polygons'), updateMapList:()=>{},updateGeoContent:async()=>{},render:()=>{},clearMap:()=>{},
  filteredProjects:()=>catalog,located:p=>Number.isFinite(p.latitude)&&Number.isFinite(p.longitude),
  geoCentroid:g=>[82.6,49.9],geometryLinks:()=>[],
  E:s=>String(s),details:id=>{detailsId=id},
  $:()=>null,console,setTimeout,clearTimeout,sessionStorage:{getItem:()=>1,setItem:()=>{}},fetch:async()=>({ok:true,json:async()=>({})}),
  window:{mapgl:{HtmlMarker:class{
    constructor(map,opts){calls.push({kind:'badge',coords:opts.coordinates,html:opts.html,options:opts});}
    getContent(){return {querySelector(){return {addEventListener(event,handler){badgeClick=handler}}}}}
    destroy(){}
  }}},
};
vm.createContext(context);vm.runInContext(code,context);
assert.equal(vm.runInContext('v11Position(st.projects[1])',context),null);
assert.equal(vm.runInContext('v11Position(st.projects[0])[0]',context),82.60);
vm.runInContext('renderMarkers(st.projects)',context);
assert.equal(calls.filter(x=>x.kind==='badge').length,2,'both located ЖК must be clickable even at zoom 11');
assert(calls.filter(x=>x.kind==='badge').every(x=>x.options.labeling.type==='invincible'));
assert(vm.runInContext('v11DockHtml()',context).includes('Diamond'),'unlocated ЖК must remain clickable within map');
assert(!calls.some(x=>x.kind==='badge'&&x.html.includes('Diamond')),'must not fake Diamond position');
assert(vm.runInContext('mapView()',context).includes('id="v11-map-dock"'));
assert(vm.runInContext('mapView()',context).includes('id="v11-city-count"'));
badgeClick({preventDefault(){},stopPropagation(){}});
assert.equal(detailsId,3,'click should open project card');
console.log('v11 citywide map: 7 checks passed');
