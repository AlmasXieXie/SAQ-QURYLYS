"""v22 acceptance: 2GIS colors and legal documents joined by exact project, not BIN alone."""
from sqlalchemy import create_engine, select, func
from sqlalchemy.pool import StaticPool
from sqlalchemy.orm import sessionmaker
from fastapi.testclient import TestClient
from app.database import Base, get_db
from app.main import app
from app.unified_registry import RegistryBuilding, RegistryAuthorization, RegistryCompany, load_starter
from app.catalog_uka import load_catalog
from app.extra_problem_sites import load_extra
from app.registry_bridge import ProjectLegalParty, reconcile, official_sources_for
from app.signal_map import snapshot


def test_kzhk_sources_are_linked_to_real_catalog_preserving_provenance():
    engine=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Local=sessionmaker(engine,expire_on_commit=False)
    with Local() as db:
        load_starter(db);load_catalog(db);load_extra(db)
        before=db.scalar(select(func.count()).select_from(RegistryBuilding))
        r=reconcile(db)
        assert r['official_rows']==5 and r['missing']==['ЖК Crystal']
        assert r['parties_added']==10
        assert reconcile(db)['parties_added']==0
        assert db.scalar(select(func.count()).select_from(RegistryBuilding))==before
        # Two legal parties of a document are distinct from a marketing brand.
        gold=db.scalar(select(RegistryBuilding).where(RegistryBuilding.name=='ЖК Золотой квадрат'))
        gold_link=official_sources_for(db,gold)
        assert gold_link['status']=='official_project'
        assert gold_link['eligible_green'] is True
        assert {p['bin'] for p in gold_link['parties']}=={'970640000190','211140032196'}
        assert {p['role'] for p in gold_link['parties']}=={'developer','authorized_company'}
        assert all(p['source_url'].startswith('https://') for p in gold_link['parties'])
        # Official source is preserved separately from third party listing.
        janm=db.scalar(select(RegistryBuilding).where(RegistryBuilding.name=='ЖК ЖАНЫМ'))
        x=official_sources_for(db,janm)
        assert x['status']=='official_scoped' and not x['eligible_green']
        assert {p['bin'] for p in x['parties']}=={'171240023488','230340036850'}
        # A guarantee case is NOT equivalent to a risk-free current build.
        for name,alias in [('ЖК Diamond','ЖК Престиж'),('ЖК Престиж','ЖК Diamond')]:
            b=db.scalar(select(RegistryBuilding).where(RegistryBuilding.name==name))
            y=official_sources_for(db,b)
            assert y['status']=='guarantee_event'
            assert y['aliases']==[alias]
            assert y['supporting_source_url'].startswith('https://khc.kz/')
            assert not y['eligible_green']
            assert 'гарантийн' in y['warning'].lower()
        prest=db.scalar(select(RegistryBuilding).where(RegistryBuilding.name=='ЖК Престиж'))
        # Krisha's supplemental agreement does not get "official" upgraded
        # just because KZhK documents the *parent* project's guarantee case.
        statuses={d.document_number:d.status for d in db.scalars(select(RegistryAuthorization).where(RegistryAuthorization.building_id==prest.id))}
        assert statuses['ДС №1 к ДПГ-22-16-055/120']=='reported_third_party'
        assert statuses['ДПГ-22-16-055/120']=='official_guarantee_event'
        assert db.scalar(select(func.count()).select_from(ProjectLegalParty))==10
    def override():
        with Local() as db:yield db
    app.dependency_overrides[get_db]=override
    try:
        with TestClient(app) as client:
            resp=client.get('/api/signal-map/snapshot')
            assert resp.status_code==200
            data=resp.json()
            assert data['total']==40
            assert data['counts']=={'red':0,'yellow':38,'green':2}
            assert data['official_documents']==5
            assert data['third_party_documents']==4
            byname={b['name']:b for b in data['items']}
            assert byname['ЖК Золотой квадрат']['map_color']=='green'
            assert byname['ЖК Золотой квадрат']['registry_status']=='official_project'
            assert byname['ЖК ЖАНЫМ']['map_color']=='yellow'
            assert byname['ЖК Diamond']['map_color']=='yellow'
            assert 'гарантийн' in byname['ЖК Diamond']['color_reason'].lower()
            assert byname['ЖК Престиж']['registry_aliases']==['ЖК Diamond']
            assert byname['ЖК AINALAIYN']['registry_status']=='reported_only'
            assert byname['ЖК AINALAIYN']['map_color']=='yellow'
            # AN Groups has multiple ЖК. One permit MUST NOT greenwash every project.
            assert byname['ЖК ASYLTAS']['registry_status']=='unknown'
            assert byname['ЖК ASYLTAS']['map_color']=='yellow'
            s=client.get('/api/registry-linkage/summary').json()
            assert (s['official_project'],s['official_scoped'],s['guarantee_event'],s['reported_only'])==(2,1,2,3)
            g=byname['ЖК Золотой квадрат']
            details=client.get('/api/workbench/cases/'+str(g['id'])).json()
            assert details['linked_registry']['eligible_green'] is True
            assert len(details['linked_registry']['parties'])==2
            assert details['risk']['legal']['status']=='unknown' # no forged human signature
            assert client.get('/api/registry-linkage/buildings/'+str(g['id'])).status_code==200
            assert client.post('/api/registry-linkage/reconcile').json()['parties_added']==0
            after=client.get('/api/signal-map/snapshot').json()
            assert after['counts']==data['counts']
    finally:
        app.dependency_overrides.clear();engine.dispose()


def test_upgrade_retains_old_map_points_and_existing_analyst_decision():
    """Migrating a v21 dataset may add legal links but must not reset geo/reviews."""
    from app.workbench import LegalCheck
    engine=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Local=sessionmaker(engine,expire_on_commit=False)
    with Local() as db:
        load_starter(db);load_catalog(db);load_extra(db)
        buildings=db.scalars(select(RegistryBuilding).order_by(RegistryBuilding.id)).all()
        for idx,b in enumerate(buildings[:25]):
            # Synthetic QA coordinates; never exported into the shipped database.
            b.latitude=49.92+(idx%5)*0.005
            b.longitude=82.59+(idx//5)*0.006
            b.coordinate_source='QA_v21_geocoder'
        selected=next(b for b in buildings if b.name=='ЖК Золотой квадрат')
        db.add(LegalCheck(building_id=selected.id,status='verified_mio',stage_status='under_construction',
                          evidence_url='https://example.org/qa-only',reviewer='QA user',
                          note='QA previously accepted analyst decision'))
        db.commit()
        before={b.id:(b.latitude,b.longitude,b.coordinate_source) for b in buildings}
        assert sum(x[0] is not None for x in before.values())==25
        r=reconcile(db)
        assert r['official_rows']==5
        after={b.id:(b.latitude,b.longitude,b.coordinate_source) for b in db.scalars(select(RegistryBuilding))}
        assert before==after
        reviewed=db.scalar(select(LegalCheck).where(LegalCheck.building_id==selected.id))
        assert reviewed.status=='verified_mio' and reviewed.reviewer=='QA user'
        assert official_sources_for(db,selected)['status']=='official_project'
        assert reconcile(db)['parties_added']==0
    engine.dispose()
