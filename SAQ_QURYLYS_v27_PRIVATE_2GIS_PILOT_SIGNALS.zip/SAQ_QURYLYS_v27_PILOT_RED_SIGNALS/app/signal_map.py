"""Signal-first live map projection of analyst evidence.

The map does not judge legality. Pending model observations are amber.
Only a human-verified R1+R2 combination can turn an object red.
Unknown local authorizations are never interpreted as verified absence.
"""
from __future__ import annotations
from datetime import datetime, timezone
from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.database import get_db
from app.extra_problem_sites import all_real_keys
from app.unified_registry import RegistryBuilding
from app.workbench import LegalCheck, case_out
from app.autonomous_monitor import STATE
from app.registry_bridge import official_sources_for
from app.auto_decisions import evaluate_building

router = APIRouter(prefix='/api/signal-map', tags=['Сигнальная карта'])

DOCUMENTED = {'verified_guarantee', 'verified_mio', 'verified_bank'}


def visual_state(case, legal_status='unknown'):
    """Stable, interpretable map signal. This is *not* a legal determination.

    red:    formally verified R1+R2 and score >=60;
    yellow: ad hypothesis needing review or confirmed moderate risk;
    green: verified applicable legal basis and no conflicting evidence;
    yellow: also when documents are unknown (a check is needed, not a violation).
    Score 0 alone must NEVER become green.
    """
    score = case.get('score', 0)
    triage = case.get('triage_score', 0)
    confirmed_zone = case.get('zone', 'green')
    if confirmed_zone == 'red' and score >= 60:
        return 'red'
    if confirmed_zone == 'yellow' or score >= 25 or triage >= 25:
        return 'yellow'
    if case.get('pending_ads', 0) > 0 and triage >= 10:
        return 'yellow'
    if legal_status in DOCUMENTED:
        return 'green'
    return 'yellow'


def visual_reason(case, state, legal_status='unknown'):
    messages = {
        'red': 'Приоритетный сигнал: проверенные факторы риска. Не заключение о нарушении.',
        'yellow': ('Есть подозрительные рекламные признаки или факторы риска: проверить документы и объявления.'
                   if case.get('score',0)>=25 or case.get('triage_score',0)>=10 or case.get('pending_ads',0)>0
                   else 'Нет подтверждения применимого правового основания. Нужна проверка; это НЕ признак нарушения.'),
        'green': 'Правовое основание проверено аналитиком; продолжается мониторинг.',
    }
    return messages[state]


@router.get('/snapshot')
def snapshot(db: Session = Depends(get_db)):
    keys = all_real_keys()
    buildings = [b for b in db.scalars(select(RegistryBuilding).order_by(RegistryBuilding.name)).all() if b.building_key in keys]
    legal = {x.building_id: x for x in db.scalars(select(LegalCheck)).all()}
    rows=[]
    for b in buildings:
        c=case_out(db,b)
        lc=legal.get(b.id)
        status=lc.status if lc else 'unknown'
        linked=official_sources_for(db,b)
        # A single project-level decision dominates marketing-keyword triage;
        # it never overrides a verified legal conflict or independent harm.
        result,linked=evaluate_building(db,b)
        color=result['map_color']
        rows.append({**c,
            **result,
            'legal_status':status,
            'registry_status':linked['status'],
            'registry_official_count':linked['official_count'],
            'registry_reported_count':linked['reported_count'],
            'registry_parties':linked['parties'],
            'registry_aliases':linked['aliases'],
            'legal_checked_at':lc.checked_at.isoformat() if lc and lc.checked_at else None,
            'has_coordinates':c['latitude'] is not None and c['longitude'] is not None,
            'coordinate_source':b.coordinate_source or '',
            'coordinate_accuracy':('address_or_named_point' if b.coordinate_source else 'not_geolocated'),
            'evidence_kind':'verified_project_basis' if result['authorization_verified'] else 'human_verified' if c['score']>0 else 'automatic_hypothesis' if c['triage_score']>0 else 'missing_or_verified_zero',
        })
    counts={s:sum(r['map_color']==s for r in rows) for s in ('red','yellow','green')}
    return {
        'items':sorted(rows,key=lambda c:({'red':0,'yellow':1,'green':2}[c['map_color']],-c['triage_score'],c['name'].casefold())),
        'total':len(rows),'mapped':sum(r['has_coordinates'] for r in rows),
        'without_coordinates':sum(not r['has_coordinates'] for r in rows),
        'counts':counts,
        'unverified':sum(not r['authorization_verified'] for r in rows),
        'official_documents':sum(r['registry_official_count']>0 for r in rows),
        'third_party_documents':sum(r['registry_reported_count']>0 for r in rows),
        'pending_ads':sum(r['pending_ads'] for r in rows),
        'review_queue':sum(r['map_color'] in ('yellow','red') for r in rows),
        'scanned_at':datetime.now(timezone.utc).isoformat(),
        'monitor':{'running':STATE.get('running',False),'last_run':STATE.get('last_run'),
                   'last_error':STATE.get('last_error',''),'feeds_checked':STATE.get('feeds_checked',0),
                   'saved':STATE.get('saved',0)},
        'visibility_issue':('no_coordinates' if not any(r['has_coordinates'] for r in rows) else 'partial_coordinates' if any(not r['has_coordinates'] for r in rows) else None),
        'warning':'Пилотный красный: найдено объявление с ценой на ЖК 2026+, но разрешение/гарантия не подтверждены в локальном срезе открытых источников; это НЕ доказательство нарушения. Жёлтый — проверить обстоятельства. Зелёный — применимое основание подтверждено. Не все объявления доступны.'
    }
