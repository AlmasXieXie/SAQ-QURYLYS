"""Seed deterministic fictional objects. Safe to re-run without duplicates."""
import json
from pathlib import Path
from sqlalchemy.orm import Session
from app.models import Project, Advertisement
from app.analyzer import analyze_text

DEMO_PATH = Path(__file__).resolve().parent.parent / "data" / "demo.json"

def seed_demo(db: Session):
    fixtures = json.loads(DEMO_PATH.read_text(encoding="utf-8"))
    if db.query(Project).filter(Project.name == fixtures["projects"][0]["name"]).first():
        return False
    projects = {}
    for obj in fixtures["projects"]:
        p = Project(**obj, demo=True)
        # Single transparently fictional polygon for offline teaching/drawing.
        # This does NOT claim construction exists at the mapped location.
        if obj['name'].startswith('ЖК DEMO «Бета»'):
            lon,lat=obj['longitude'],obj['latitude']
            ring=[[lon-.0015,lat-.0008],[lon+.0015,lat-.0008],[lon+.0015,lat+.0008],[lon-.0015,lat+.0008],[lon-.0015,lat-.0008]]
            p.boundary_geojson={'type':'Polygon','coordinates':[ring]}
            p.boundary_source='DEMO: fictional illustration, NOT a real construction footprint'
            p.boundary_checked_by='Учебные данные'
            p.boundary_checked_at='2026-10-17'

        db.add(p)
        db.flush()
        projects[p.name] = p
    for obj in fixtures["advertisements"]:
        project_name = obj["project"]
        text = obj["text"]
        data = {k: v for k, v in obj.items() if k not in ["project", "review_status"]}
        ad = Advertisement(**data, project_id=projects[project_name].id,
                           review_status=obj["review_status"],
                           analysis=analyze_text(text, list(projects.values())), demo=True,
                           source_url=f"demo://publication/{len(db.new)+1}")
        db.add(ad)
    db.commit()
    return True
