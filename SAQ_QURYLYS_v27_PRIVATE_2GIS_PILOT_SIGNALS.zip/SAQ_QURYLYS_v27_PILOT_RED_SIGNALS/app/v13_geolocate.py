"""Automatic licensed 2GIS catalog/address lookup for 40 *real* project cards.

Stores only returned points, with explicit accuracy provenance. Never fabricates
footprints, GPS coordinates, or a map position from a neighboring building.
"""
from __future__ import annotations
import asyncio
import os
import re
from datetime import datetime, timezone
from threading import Lock
from urllib.parse import urlsplit
import httpx
from fastapi import APIRouter, BackgroundTasks, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.database import SessionLocal,get_db
from app.extra_problem_sites import all_real_keys
from app.unified_registry import RegistryBuilding,insert_evidence
from app.geocode_2gis import compare,normalize,parts
from app.real_geocode import is_local_point
from app.v8_api import catalog

router=APIRouter(prefix='/api/v13/geolocate',tags=['Автоматическая геопривязка ЖК'])
LOCK=Lock()
STATE={'running':False,'scheduled':False,'total':0,'processed':0,'new_exact':0,
       'new_named':0,'unresolved':0,'ambiguous':0,'errors':0,'last_error':'',
       'last_run':None,'note':'Поиск по адресу и по реальным карточкам ЖК 2ГИС; предполагаемая точка НЕ является доказанным контуром стройки.'}
API='https://catalog.api.2gis.com/3.0/items'
ITEMS_BY_ID='https://catalog.api.2gis.com/3.0/items/byid'
FIELDS='items.point,items.address,items.geometry.centroid'
PROBLEM={'diamond','astoria','asylym','gran via','orda','престиж'}


def project_name(name):
    return re.sub(r'^\s*(?:жк|жилой комплекс)\s+','',name,flags=re.I).strip()


def canonical_street(s):
    s=re.sub(r'(?iu)\b(?:проспект|пр|пр-кт|улица|ул|көшесі|имени|им|ильяса|каныша|юрий|ю)\.?\b',' ',s)
    return normalize(s)


def streets_of(address):
    segments=[x.strip() for x in (address or '').split(',')]
    if len(segments)<2:return []
    # Last chunk may contain housenumber; list all street sections, do not
    # use the city or numeric-only part as evidence for a named match.
    return [canonical_street(s) for s in segments[1:] if re.search(r'[а-яА-Яa-zA-Z]',s) and not s.casefold().startswith(('18а','18б','18в'))]


def named_candidate(item,project):
    """Accept a 2GIS catalog entity only if name AND project street match."""
    point=item.get('point') or {}
    try:lat,lon=float(point['lat']),float(point['lon'])
    except (ValueError,KeyError,TypeError):return False
    if not is_local_point(lat,lon):return False
    name=project_name(project.name)
    label=item.get('name') or item.get('full_name') or ''
    if normalize(name)!=normalize(re.sub(r'^\s*(жк|жилой комплекс)\s+','',label,flags=re.I)):
        return False
    item_address=canonical_street((item.get('address_name') or item.get('full_name') or ''))
    # Addresses in commercial catalogs can have 1-3 separate buildings;
    # match the street, but do not claim exact building. Exclude generic labels.
    streets=[s for s in streets_of(project.address) if len(s)>4]
    if not any(s in item_address for s in streets):return False
    # Strictly avoid contested names / addresses unless verified by operator.
    if normalize(name) in {normalize(x) for x in PROBLEM}:return False
    return True


def direct_id(url):
    return (re.search(r'/(?:firm|geo)/(\d{10,20})',url or '') or [None,None])[1]


def check_response(r):
    if r.status_code in (401,402,403,429):raise PermissionError('2ГИС Places API: HTTP '+str(r.status_code))
    r.raise_for_status()
    data=r.json();code=(data.get('meta') or {}).get('code')
    if code not in (200,None):raise ValueError('2ГИС вернул код '+str(code))
    return ((data.get('result') or {}).get('items') or [])


async def query(client,url,params):
    r=await client.get(url,params=params,follow_redirects=False)
    return check_response(r)


def classify(project,items):
    """Return unique direct address vs named ЖК point; fail closed on conflicts."""
    unique={str(x.get('id') or str(x.get('point'))):x for x in items if x.get('point')}
    exact=[x for x in unique.values() if compare(x,project.address)] if parts(project.address) else []
    if len(exact)==1:return exact[0],'exact_house'
    if len(exact)>1:return None,'ambiguous'
    named=[x for x in unique.values() if named_candidate(x,project)]
    if len(named)==1:return named[0],'named_catalog_entity'
    return None,'ambiguous' if len(named)>1 else 'unresolved'


def store(project_id,item,precision):
    point=item['point'];lat=float(point['lat']);lon=float(point['lon'])
    if not is_local_point(lat,lon):return False
    with SessionLocal() as db:
        b=db.get(RegistryBuilding,project_id)
        if not b or b.building_key not in all_real_keys() or b.latitude is not None:return False
        b.latitude=lat;b.longitude=lon
        b.coordinate_source=('2GIS_EXACT_HOUSE:' if precision=='exact_house' else '2GIS_NAMED_JK_APPROX:')+str(item.get('id',''))
        url='https://2gis.kz/ustkam/firm/'+str(item.get('id','')) if item.get('id') else 'https://2gis.kz/ustkam'
        insert_evidence(db,'2gis',url,
            ('Точная адресная точка 2ГИС, не контур стройки.' if precision=='exact_house'
             else 'Положение именованной карточки ЖК из 2ГИС со совпадающей улицей. Геометрия корпуса НЕ подтверждена.'),
            'exact_address_geocoded' if precision=='exact_house' else 'named_entity_geocoded',
            b.id,raw_fields={'item_name':item.get('name'),'address_2gis':item.get('address_name'),
                             'latitude':lat,'longitude':lon,'precision':precision})
        db.commit();return True


def start_once():
    with LOCK:
        if STATE['running'] or STATE['scheduled']:return False
        STATE['scheduled']=True
    return True


async def resolve_all():
    with LOCK:
        if STATE['running']:return
        STATE.update(running=True,scheduled=False,total=0,processed=0,new_exact=0,
                     new_named=0,unresolved=0,ambiguous=0,errors=0,last_error='')
    try:
        key=os.getenv('SAQ_2GIS_KEY','').strip()
        if not key:
            STATE['last_error']='API-ключ 2ГИС не задан'
            return
        with SessionLocal() as db:
            from app.v8_api import record
            projects=[record(db,b) for b in db.scalars(select(RegistryBuilding)).all()
                      if b.building_key in all_real_keys() and b.latitude is None]
        STATE['total']=len(projects)
        async with httpx.AsyncClient(timeout=httpx.Timeout(13,connect=5),trust_env=False) as client:
            for data in projects:
                from types import SimpleNamespace
                p=SimpleNamespace(**data)
                try:
                    collected=[]
                    linked=direct_id((p.profile or {}).get('map_links',{}).get('2gis') or '')
                    if linked:
                        collected+=await query(client,ITEMS_BY_ID,{'id':linked,'fields':FIELDS,'key':key})
                    # Two independent searches: address and named new-build card.
                    if parts(p.address):
                        collected+=await query(client,API,{'q':p.address+', Усть-Каменогорск',
                                      'type':'building','page_size':8,'fields':FIELDS,'key':key})
                    collected+=await query(client,API,{'q':p.name+', Усть-Каменогорск',
                                      'page_size':10,'fields':FIELDS,'key':key})
                    item,precision=classify(p,collected)
                    if item and store(p.id,item,precision):
                        STATE['new_exact' if precision=='exact_house' else 'new_named']+=1
                    else:STATE['ambiguous' if precision=='ambiguous' else 'unresolved']+=1
                except PermissionError as e:
                    STATE['last_error']=str(e);break
                except Exception as e:
                    STATE['errors']+=1;STATE['last_error']=str(e)[:160]
                finally:STATE['processed']+=1
                await asyncio.sleep(.35)
    finally:
        STATE['last_run']=datetime.now(timezone.utc).isoformat()
        with LOCK:STATE['running']=False;STATE['scheduled']=False


async def background_daily():
    if os.getenv('SAQ_AUTO_GEO','1').lower() in ('0','false','no'):return
    await asyncio.sleep(10)
    while True:
        if start_once():
            try:await resolve_all()
            except Exception as e:STATE['last_error']='Системная ошибка: '+str(e)[:180]
        await asyncio.sleep(24*3600)


@router.get('/status')
def status(db:Session=Depends(get_db)):
    cards=catalog(db)
    return {**STATE,'all':len(cards),'located':sum(c.get('latitude') is not None for c in cards),
            'missing':sum(c.get('latitude') is None for c in cards),
            'approximate':sum('APPROX' in (c.get('coordinate_source') or '') for c in cards),
            'message':'Координаты отсутствующего ЖК нельзя достоверно назначить принудительно без адресных геоданных.'}

@router.post('/start')
def start(tasks:BackgroundTasks):
    if start_once():tasks.add_task(resolve_all)
    return dict(STATE)
