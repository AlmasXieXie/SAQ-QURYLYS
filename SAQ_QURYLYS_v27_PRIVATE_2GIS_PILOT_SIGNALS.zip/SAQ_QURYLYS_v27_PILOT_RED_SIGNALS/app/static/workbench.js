'use strict';
const $=q=>document.querySelector(q);
const safe=v=>String(v===null||v===undefined?'':v).replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const link=(u,label)=>u&&/^https:\/\//i.test(u)?`<a class="ext" href="${safe(u)}" target="_blank" rel="noopener noreferrer">${safe(label||u)} ↗</a>`:safe(label||'Источник не указан');
const statusLabel={unknown:'Не проверено',verified_absent:'Отсутствие установлено проверкой',verified_guarantee:'Гарантия КЖК проверена',verified_mio:'Разрешение МИО проверено',verified_bank:'Банковская схема проверена',under_construction:'Строительство проверено',commissioned:'Ввод подтверждён',red:'Красная',yellow:'Жёлтая',green:'Зелёная',pending:'На проверке',accepted:'Принято',rejected:'Отклонено',confirmed:'Подтверждено',returned:'Возвращено'};
const st={mode:'real',cases:[],selected:null,detail:null,busy:false,signals:[]};
function msg(s,err=false){const el=$('#message');el.hidden=!s;el.textContent=s;el.className='message'+(err?' error':'');}
async function api(url,opts={}){const r=await fetch(url,opts);let x;try{x=await r.json()}catch{x={detail:'HTTP '+r.status}}if(!r.ok)throw Error((typeof x.detail==='string'?x.detail:JSON.stringify(x.detail))||'HTTP '+r.status);return x;}
const json=data=>({method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
function actor(){const s=$('#actor').value.trim();if(s.length<2){msg('Укажи имя аналитика (минимум 2 символа)',true);throw Error('Введите имя аналитика')}return s;}
function scoreClass(x){return ['red','yellow','green'].includes(x)?x:'green';}
async function scanHealth(){
 try{const x=await api('/api/v13/monitor/status');
 const el=$('#system-status');
 if(!el)return;
 const health=x.running?'Сбор публикаций…':x.last_run?(x.feeds_failed?`Последний сбор: ${x.feeds_failed} ошибок`:`Сбор: ${x.total_saved||0} записей`):'Сканер ожидает первого запуска';
 el.textContent=health;el.title=x.last_error||'Публичные источники ограничены: это не полный охват Instagram/OLX';
 }catch{const el=$('#system-status');if(el)el.textContent='Статус сканера недоступен'}
}
async function load(){
 try{
  msg('');st.detail=null;st.selected=null;$('#casepanel').innerHTML='<div class="placeholder">Выбери объект слева для работы с материалами</div>';
  if(st.mode==='signals'){await signalList();return;}
  let rows=st.mode==='real'?await api('/api/workbench/cases'):await api('/api/projects');
  if(st.mode==='training')rows=rows.filter(x=>x.demo&&x.name.startsWith('ЖК DEMO «'));
  st.cases=rows;$('#real-total').textContent=st.mode==='real'?rows.length:'40';
  $('#learning').hidden=st.mode!=='training';$('#columns').hidden=false;$('#signals-panel').hidden=true;
  $('#list-title').textContent=st.mode==='training'?'Учебные объекты A/B/C':'Реальные ЖК — очередь';
  $('#list-subtitle').textContent=st.mode==='training'?'Фиктивные данные из исходного ТЗ':'Реклама и документы, требующие человеческой проверки';
  renderList();metrics();scanHealth();
 }catch(e){msg('Ошибка загрузки: '+e.message,true)}
}
function metrics(){
 const cases=st.cases,ads=cases.reduce((n,x)=>n+(x.ad_count||0),0),pending=cases.reduce((n,x)=>n+(x.pending_ads||0),0),red=cases.filter(x=>x.zone==='red').length;
 const training=st.mode==='training';
 const names=training?['Фиктивных ЖК','Фиктивных публикаций','Красная зона','Непроверенных публикаций']:['Реальных ЖК','Связанных объявлений','Красная зона','Объявлений на проверке'];
 const vals=[cases.length,ads,red,pending];
 $('#metrics').innerHTML=vals.map((v,i)=>`<div class="metric"><div class="number">${v}</div><div class="caption">${names[i]}</div></div>`).join('');
}
function renderList(){
 const q=$('#search').value.trim().toLocaleLowerCase('ru'),z=$('#zone-filter').value;
 const rows=st.cases.filter(c=>(!z||c.zone===z)&&(!q||`${c.name} ${c.address} ${c.developer}`.toLocaleLowerCase('ru').includes(q)));
 $('#cases').innerHTML=rows.length?rows.map(x=>`<button class="case-choice ${st.selected===x.id?'active':''}" type="button" data-case="${x.id}"><div class="line"><strong>${safe(x.name)}</strong><span class="risk-pill ${scoreClass(x.zone)}">${x.score}/100</span></div><small>${safe(x.address||'Адрес не указан')}</small><small>Реклама: ${x.ad_count||0} · Непроверено: ${x.pending_ads||0}${st.mode==='real'&&x.triage_score>x.score?' · ИИ-приоритет: '+x.triage_score+'?':''}</small></button>`).join(''):'<div class="placeholder">Объектов по фильтру нет</div>';
}
async function pick(id){
 st.selected=id;renderList();$('#casepanel').innerHTML='<div class="spinner">Загружаю источники и риск-оценку…</div>';
 try{
  st.detail=await api(st.mode==='real'?`/api/workbench/cases/${id}`:`/api/projects/${id}`);
  $('#casepanel').innerHTML=st.mode==='real'?renderReal(st.detail):renderTraining(st.detail);
 }catch(e){msg('Карточка: '+e.message,true)}
}
function kb(x){return x&&x.trim()?safe(x):'<span class="status-unknown">Не установлено</span>'}
function docRows(reg){let docs=[...(reg.authorizations||[]),...(reg.additional_permits||[])];
 return docs.length?docs.map(d=>`<div class="fact"><b>${safe(d.type||d.authorization_type||'Документ')}</b> · ${safe(d.number||d.document_number||'без номера')}<small>Заявленный статус: ${safe(d.status||d.status_in_registry||'не проверено')} · ${safe(d.date||d.issued_on||'дата неизвестна')}</small>${link(d.source_url||d.url||'', 'Первичный источник')}<small>Наличие записи каталога не подтверждает действие разрешения для этой очереди.</small></div>`).join(''):'<p class="banner">В локальной базе нет связанных документов. Это НЕ означает, что разрешение отсутствует.</p>';
}
function realAd(ad){return `<article class="fact ${ad.status==='pending'?'pending':'confirmed'}"><div class="sectionhead"><b>${safe(ad.platform)} · #${ad.id}</b><span class="tag">${safe(statusLabel[ad.status]||ad.status)}</span></div><div class="muted">Источник: ${link(ad.url,'открыть оригинал')} · ${safe(ad.added_at.slice(0,16))}</div><p class="small">${safe(ad.text.slice(0,420))}</p>${ad.payment_excerpt?`<div class="text-excerpt">Возможная оплата: «${safe(ad.payment_excerpt)}»</div>`:''}${ad.advertising_excerpt?`<div class="text-excerpt">Реклама: «${safe(ad.advertising_excerpt)}»</div>`:''}<div class="actions">${ad.status!=='accepted'?`<button class="primary" data-review="${ad.id}" data-status="accepted">Принять фрагмент</button>`:''}${ad.status!=='rejected'?`<button class="secondary" data-review="${ad.id}" data-status="rejected">Отклонить</button>`:''}</div></article>`}
function renderReal(c){const d=c.registry,dev=d.developer||{},r=c.risk,lg=r.legal;
 const legalOptions=[['unknown','Не проверено'],['verified_guarantee','Проверена гарантия КЖК'],['verified_mio','Проверено разрешение МИО'],['verified_bank','Проверена банковская схема'],['verified_absent','Установлено отсутствие применимого основания']];
 return `<div class="section"><span class="sectiontitle">Застройщик / заявленная компания</span><h2 class="project-title">${safe(dev.name||c.developer)}</h2><div class="detailgrid"><div><small>БИН / юридическая идентичность</small><strong>${kb(dev.bin||dev.registered_bin||'')}</strong></div><div><small>Источник сведений</small><strong>${safe(dev.identity_level||'Коммерческий каталог')}</strong></div></div><div class="actions">${link(dev.site||'', 'Сайт застройщика')}${link(dev.instagram||'', 'Instagram')}</div></div>
 <div class="section"><span class="sectiontitle">Конкретный объект</span><h2 class="project-title">${safe(c.name)}</h2><p class="muted">⌖ ${safe(c.address)}</p><div class="detailgrid"><div><small>Стадия по каталогу</small><strong>${safe(d.stage_reported||'unknown')}</strong></div><div><small>Стадия, проверенная аналитиком</small><strong>${safe(statusLabel[lg.stage_status]||lg.stage_status)}</strong></div><div><small>Документальный статус</small><strong>${safe(statusLabel[lg.status]||lg.status)}</strong></div><div><small>Контур / точка</small><strong>${c.latitude===null?'Точная точка неизвестна':'Есть координата'}</strong></div></div></div>
 <div class="section"><div class="sectionhead"><span class="sectiontitle">Приоритет и объяснение</span><span class="risk-pill ${scoreClass(r.zone)}">${safe(statusLabel[r.zone])}: ${r.score}/100</span></div>${r.factors.length?r.factors.map(f=>`<div class="fact confirmed"><b>${f.code} · +${f.points}: ${safe(f.label)}</b><div class="text-excerpt">${safe(f.evidence)}</div><small>Доказательство: ${link(f.source,'открыть')}</small></div>`).join(''):'<p class="muted">Принятых подтверждённых факторов пока нет. 0 баллов не означает законность или безопасность.</p>'}${r.preliminary_factors?.length?`<div class="banner"><b>ИИ-приоритет: ${r.triage_score}/100 (предварительно)</b><br>Не входит в подтверждённый балл: сигналы из ещё не принятых публикаций, без R1 и юридического вывода.</div>`:''}${r.hypotheses.map(h=>`<div class="fact pending"><b>Гипотеза ИИ · объявление #${h.ad_id}</b><div class="text-excerpt">${safe(h.text)}</div><small>Не начисляется в балл до решения аналитика.</small></div>`).join('')}${r.missing.map(x=>`<p class="muted">◌ ${safe(x)}</p>`).join('')}</div>
 <div class="section"><span class="sectiontitle">Реклама и доказательства (${r.ads.length})</span>${r.ads.length?r.ads.map(realAd).join(''):'<p class="banner">Публикации этому ЖК ещё не сопоставлены. Фоновый сбор не гарантирует полного покрытия OLX/Instagram. Для демонстрации используй учебный тренажёр.</p>'}</div>
 <div class="section"><span class="sectiontitle">Основания из реестра</span>${docRows(d)}</div>
 <div class="section"><span class="sectiontitle">Человеческая сверка правового основания и стадии</span><p class="muted">Нельзя выбирать «отсутствует», если в локальной базе просто нет записи. Нужна независимая проверка конкретного корпуса/очереди и письменное свидетельство.</p><form id="legal-form" class="mini-form"><label>Правовое основание<select name="status">${legalOptions.map(([v,t])=>`<option value="${v}" ${lg.status===v?'selected':''}>${safe(t)}</option>`).join('')}</select></label><label>Стадия объекта<select name="stage_status"><option value="unknown">Не проверена</option><option value="under_construction" ${lg.stage_status==='under_construction'?'selected':''}>Строится — проверено</option><option value="commissioned" ${lg.stage_status==='commissioned'?'selected':''}>Введён — проверено</option></select></label><label class="wide">Ссылка на проверенный источник HTTPS<input name="evidence_url" value="${safe(lg.source||'')}" placeholder="https://..." type="url"></label><label class="wide">Что проверено: документ, БИН, корпус, очередь<textarea name="note" placeholder="Опиши проверку документа и её результат">${safe(lg.note||'')}</textarea></label><div class="actions"><button class="primary" type="submit">Сохранить проверку и пересчитать риск</button></div></form></div>
 <div class="section"><span class="sectiontitle">Дополнительные проверенные факторы R4–R6</span><form id="factor-form" class="mini-form"><label>Фактор<select name="code"><option value="R4">R4 — коллективное обращение</option><option value="R5">R5 — расхождение готовности ≥20 п.п.</option><option value="R6">R6 — документированный простой</option></select></label><label>Источник доказательства<input name="evidence_url" type="url" placeholder="https://..."></label><label class="wide">Содержание проверки<textarea name="note" placeholder="Факт и документ, который его подтверждает"></textarea></label><label>Заявлено, % (только R5)<input name="reported_progress" type="number" min="0" max="100" step="1"></label><label>Проверено, % (только R5)<input name="verified_progress" type="number" min="0" max="100" step="1"></label><label class="wide">Второй источник (только R5)<input name="second_source" type="url" placeholder="https://..."></label><div class="actions"><button class="secondary" type="submit">Зафиксировать проверенный фактор</button></div></form></div>
 <div class="section"><span class="sectiontitle">Сигнальная карточка / решение МИО</span><p class="muted">В отчёт войдут только подтверждённые факторы R1–R6, источники, неопределённость и снимок текущих доказательств.</p><div class="actions"><button class="primary" id="create-signal" type="button">Сформировать сигнал</button></div>${c.signals.map(s=>signalCard(s,false)).join('')}</div>
 <div class="section"><span class="sectiontitle">Журнал действий</span>${c.actions.length?c.actions.map(a=>`<div class="audit">${safe(a.at.slice(0,19))} · ${safe(a.actor)} · ${safe(a.action)}</div>`).join(''):'<p class="muted">Действий аналитика пока нет</p>'}</div>`;
}
function signalCard(s,training){const file=training?`/api/projects/${s.project_id}/report.pdf?signal_id=${s.id}`:`/api/workbench/signals/${s.id}/report.pdf`;
 return `<div class="fact"><div class="sectionhead"><b>Сигнал №${s.id} · ${s.score}/100</b><span class="tag">${safe(statusLabel[s.status]||s.status)}</span></div><div class="muted">Автор: ${safe(s.author)} · ${safe((s.created_at||'').slice(0,19))}</div><div class="actions"><a class="secondary" style="text-decoration:none" href="${file}" target="_blank" rel="noopener">PDF ↗</a>${s.status==='pending'?`<button class="primary" data-decision="${s.id}" data-accept="confirmed">Подтвердить</button><button class="secondary" data-decision="${s.id}" data-accept="returned">Вернуть</button>`:''}</div></div>`}
function renderTraining(c){const s=c,sc=s.factors||[];return `<div class="banner"><strong>СИНТЕТИЧЕСКИЙ ПРИМЕР — НЕ РЕАЛЬНАЯ КОМПАНИЯ</strong><div>Используется для показа воспроизводимых сценариев A/B/C из ТЗ.</div></div><div class="section"><span class="sectiontitle">Учебная карточка</span><h2 class="project-title">${safe(c.name)}</h2><p class="muted">${safe(c.address)} · ${safe(c.developer)}</p><p>Правовая проверка: <b>${safe(c.legal_status)}</b> · ${safe(c.legal_basis)}</p><p class="muted">Источник: ${safe(c.legal_source||'не проверено')}</p></div><div class="section"><div class="sectionhead"><span class="sectiontitle">Детерминированная оценка по ТЗ</span><span class="risk-pill ${scoreClass(c.zone)}">${c.score}/100 · ${safe(statusLabel[c.zone])}</span></div>${sc.map(f=>`<div class="fact confirmed"><b>${f.code} +${f.points}</b> · ${safe(f.label)}<div class="text-excerpt">${safe(f.evidence)}</div><small>${safe(f.source)}</small></div>`).join('')}${!sc.length?'<p class="muted">Нет подтверждённых факторов</p>':''}${(c.missing||[]).map(x=>`<p class="muted">◌ ${safe(x)}</p>`).join('')}</div><div class="section"><span class="sectiontitle">Демонстрационные объявления</span>${(c.ads||[]).map(ad=>`<div class="fact"><b>№${ad.id} · ${safe(ad.platform)} · ${safe(statusLabel[ad.review_status])}</b><div class="text-excerpt">${safe(ad.text)}</div><div class="actions">${ad.review_status!=='accepted'?`<button class="primary" data-review="${ad.id}" data-status="accepted">Принять фрагмент</button>`:''}${ad.review_status!=='rejected'?`<button class="secondary" data-review="${ad.id}" data-status="rejected">Отклонить</button>`:''}</div></div>`).join('')}</div><div class="section"><span class="sectiontitle">Решение и PDF</span><button class="primary" id="create-signal">Создать учебную сигнальную карточку</button>${(c.signals||[]).map(s=>signalCard(s,true)).join('')}</div>`}
async function signalList(){
 $('#columns').hidden=true;$('#learning').hidden=true;$('#signals-panel').hidden=false;$('#metrics').innerHTML='';
 let all=await api('/api/workbench/signals');$('#signals-panel').innerHTML=`<h2>Реальные сигнальные карточки (${all.length})</h2><p class="muted">Никакой отправки в государственные органы не происходит автоматически.</p>${all.map(s=>`<div class="signal-panel"><b>${safe(s.name)} · ${s.score}/100</b>${signalCard(s,false)}</div>`).join('')||'<div class="signal-panel">Решений пока нет. Открой ЖК, проверь свидетельства и сформируй сигнал.</div>'}`;
}
async function setMode(mode){st.mode=mode;document.querySelectorAll('[data-tab]').forEach(x=>x.classList.toggle('selected',x.dataset.tab===mode));$('#search').value='';$('#zone-filter').value='';await load()}
async function perform(fn){if(st.busy)return;st.busy=true;try{await fn();msg('Операция выполнена, изменения сохранены с отметкой времени.');await load();if(st.selected)await pick(st.selected)}catch(e){msg(e.message,true)}finally{st.busy=false}}
async function onAction(e){
 const tab=e.target.closest('[data-tab]');if(tab){setMode(tab.dataset.tab);return}
 const choose=e.target.closest('[data-case]');if(choose){pick(Number(choose.dataset.case));return}
 if(e.target.closest('#reload')){await load();return}
 if(e.target.closest('#seed-training')){perform(async()=>{const x=await api('/api/workbench/training/load',{method:'POST'});msg(`Учебных ЖК ${x.projects}, объявлений ${x.ads}`)});return}
 const rev=e.target.closest('[data-review]');if(rev){const id=Number(rev.dataset.review),status=rev.dataset.status,sel=st.selected,mode=st.mode;await perform(async()=>{await api(mode==='real'?`/api/workbench/ads/${id}/review`:`/api/ads/${id}/review`,json(mode==='real'?{status,analyst:actor()}: {status,reviewer:actor()}))});if(sel)await pick(sel);return}
 if(e.target.closest('#create-signal')){const id=st.selected,mode=st.mode;await perform(async()=>{await api(mode==='real'?`/api/workbench/cases/${id}/signals`:`/api/projects/${id}/signals`,json(mode==='real'?{analyst:actor(),note:'Сигнальная карточка создана для дополнительной проверки'}:{author:actor(),note:'Учебная карточка — синтетические данные'}))});if(id)await pick(id);return}
 const dec=e.target.closest('[data-decision]');if(dec){const id=dec.dataset.decision,status=dec.dataset.accept,mode=st.mode,selected=st.selected;const note=prompt(status==='confirmed'?'Комментарий к подтверждению сигнала':'Причина возврата на доработку','Требуется дополнительная проверка источников');if(note===null)return;await perform(async()=>{await api(mode==='real'?`/api/workbench/signals/${id}/decision`:`/api/signals/${id}/decision`,json(mode==='real'?{analyst:actor(),note,status}:{author:actor(),note,status}))});if(selected)await pick(selected);return}
}
async function onSubmit(e){
 if(!['legal-form','factor-form'].includes(e.target.id))return;
 e.preventDefault();const form=e.target,obj=Object.fromEntries(new FormData(form).entries()),id=st.selected;
 await perform(async()=>{
  if(form.id==='legal-form')await api(`/api/workbench/cases/${id}/legal`,json({...obj,analyst:actor()}));
  else {for(const f of ['reported_progress','verified_progress'])obj[f]=obj[f]===''?null:Number(obj[f]);await api(`/api/workbench/cases/${id}/factor`,json({...obj,analyst:actor()}))}
 });if(id)await pick(id);
}
document.addEventListener('click',onAction);document.addEventListener('submit',onSubmit);$('#search').addEventListener('input',renderList);$('#zone-filter').addEventListener('change',renderList);load();
