'use strict';
window.SAQ_V14_GEO=true;
/* v14: Automatic multi-source geocoder, map badges update as soon as real
   coordinates arrive. UI does not create or hallucinate marker positions. */
const v14={lastLocated:-1,lastProcessed:-1,timer:null};
const v14MapViewPrevious=mapView;
mapView=function(){
 let h=v14MapViewPrevious();
 h=h.replace('Адрес можно открыть в 2ГИС','Автоматически ищем по картографическим источникам');
 h=h.replace('Нужна геопривязка','Ожидают подтверждённых координат');
 h=h.replace('<div id="v13-locator"', '<div id="v14-status" class="saq-geo-progress" role="status">Проверяем координаты через 2ГИС и открытую базу OSM…</div><div id="v13-locator"');
 return h;
};
async function v14GetStatus(){
 if(st.page!=='map')return;
 let el=document.getElementById('v14-status');if(!el)return;
 try{
  const resp=await fetch('/api/v14/geofill/status');if(!resp.ok)throw Error('HTTP '+resp.status);
  const s=await resp.json();
  const found=s.resolved_2gis_exact+s.resolved_2gis_named+s.resolved_osm_exact+s.resolved_osm_named;
  const errorEntries=Object.entries(s.errors||{}).sort((a,b)=>b[1]-a[1]);
  const err=errorEntries[0]?.[0]||'';
  el.textContent=`Автопривязка: ${s.located} из ${s.all} ЖК на карте · без координат ${s.missing}. `+
   (s.running||s.scheduled?`Сейчас проверяем ${s.processed}/${s.total}, новых точек ${found}.`:
    s.last_finished?'Цикл завершён. Новых точек за цикл: '+found+'.':'Поиск запустится автоматически после загрузки сервера.')+
    (err?' Источник: '+err:'');
  if(v14.lastLocated!==s.located){v14.lastLocated=s.located;await updateGeoContent();}
  v14.lastProcessed=s.processed;
 }catch(e){el.textContent='Состояние поиска недоступно: '+e.message;}
}
const v14RenderPrevious=render;
render=function(){
 v14RenderPrevious();
 if(st.page==='map'){
  // The backend starts a geocoding job by itself. These older one-off search
  // buttons are unnecessary and could launch overlapping third-party requests.
  ['#do-geocode','#v11-geocode','#v13-geosearch','#v10-retry'].forEach(sel=>{
    const btn=document.querySelector(sel);if(btn)btn.hidden=true;
  });
  v14GetStatus();
 }
};
setInterval(v14GetStatus,4500);
