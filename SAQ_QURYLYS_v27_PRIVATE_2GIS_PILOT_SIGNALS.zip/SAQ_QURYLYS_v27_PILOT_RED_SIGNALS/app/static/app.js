/* SAQ QURYLYS: no build step or secret tokens needed. All untrusted text is escaped. */
'use strict';
const API='/api';
const $=s=>document.querySelector(s);
const esc=(x)=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const statusLabels={unknown:'Не проверено',verified_absent:'Подтверждено отсутствие основания',verified_guarantee:'Гарантия КЖК проверена',verified_permit:'Разрешение МИО проверено'};
const zoneNames={green:'Низкий',yellow:'Повышенный',red:'Высокий'};
const reviewNames={accepted:'Подтверждено',rejected:'Отклонено',pending:'На проверке',confirmed:'Подтверждён',returned:'Возвращён'};
const state={page:'dashboard',projects:[],dashboard:{},ads:[],signals:[],sources:[],zoneFilter:'all',adFilter:'all',search:'',drawer:null,preview:null,ocrPath:'',mapZone:'all',mapQuery:'',showOSMZones:true,showProjectZones:true,zoneStatus:'Слой ожидает загрузки',zoneCount:0,projectZoneCount:0,sourceStatus:[]};
let activeLeafletMap=null;
let activeMapMarkers=new Map();
let activeZoneLayers=[];
let mapOverlayGeneration=0;
let leafletRetryTimer=null;
let leafletRetryCount=0;
let drawVertices=[];
let drawGuide=null;
let drawing=false;
const legalLabel=s=>statusLabels[s]||s;
const riskBadge=(zone)=>`<span class="risk-badge ${esc(zone)}"><span class="risk-dot"></span>${zoneNames[zone]}</span>`;
const statusPill=(status)=>`<span class="status-pill ${esc(status)}">${reviewNames[status]||status}</span>`;
const riskColor=z=>({red:'#d95458',yellow:'#e0a23d',green:'#27986e'}[z]||'#778');
const formatDate=s=>{if(!s)return '—';try {return new Date(s.slice(0,10)+'T12:00:00').toLocaleDateString('ru-RU',{day:'2-digit',month:'short',year:'numeric'});}catch {return s;}};
const navNames={dashboard:'Центр мониторинга',projects:'Реестр объектов',map:'Карта Усть-Каменогорска',ads:'Мониторинг рекламы',signals:'Сигнальные карточки',sources:'Источники данных'};
async function req(path,options={}){
  const resp=await fetch(API+path,{...options,headers:options.body instanceof FormData ? options.headers : {'Content-Type':'application/json',...(options.headers||{})}});
  if(!resp.ok){let msg=`Ошибка ${resp.status}`;try {const data=await resp.json();msg=typeof data.detail==='string'?data.detail:JSON.stringify(data.detail);}catch{}throw Error(msg);}
  return resp.json();
}
function toast(message,error=false){const host=$('#toast-host');const div=document.createElement('div');div.className='toast'+(error?' error':'');div.textContent=message;host.appendChild(div);setTimeout(()=>div.remove(),4400);}
function showError(err){console.error(err);toast(err.message||'Ошибка выполнения операции',true);}
async function refresh(){
  const [dashboard,projects,ads,signals,sources]=await Promise.all([req('/dashboard'),req('/projects'),req('/ads'),req('/signals'),req('/sources')]);
  Object.assign(state,{dashboard,projects,ads,signals,sources});
  $('#nav-pending').textContent=dashboard.pending_ads||'';
  render();
}
function header(title,desc,actions='') {return `<div class="page-heading"><div><div class="eyebrow">SAQ QURYLYS / АНАЛИТИКА</div><h1>${title}</h1><p>${desc}</p></div><div class="heading-actions">${actions}</div></div>`;}
const ribbon=`<div class="demo-ribbon"><strong>◎ ЛОКАЛЬНЫЙ РЕЖИМ</strong> Начальные 8 ЖК и 12 публикаций — вымышленные. Импортированные записи отображаются отдельно; сведения из внешних источников должны проверяться аналитиком.</div>`;
function render(){
  $('#breadcrumb').textContent=navNames[state.page];
  document.querySelectorAll('[data-page]').forEach(el=>el.classList.toggle('active',el.dataset.page===state.page));
  if(leafletRetryTimer){clearTimeout(leafletRetryTimer);leafletRetryTimer=null;}
  leafletRetryCount=0;
  mapOverlayGeneration++;
  if(activeLeafletMap){activeLeafletMap.remove();activeLeafletMap=null;activeMapMarkers.clear();activeZoneLayers=[];drawing=false;drawVertices=[];}
  const views={dashboard:dashboardView,projects:projectsView,map:mapView,ads:adsView,signals:signalsView,sources:sourcesView};
  $('#main-content').innerHTML=(views[state.page]||dashboardView)();
  if(state.page==='dashboard'||state.page==='map') setTimeout(initMap,40);
}
function metric(title,value,foot,symbol){return `<div class="card metric"><div class="metric-top"><span>${title}</span><span class="metric-icon">${symbol}</span></div><div class="metric-value">${value}</div><div class="metric-foot">${foot}</div></div>`;}
function dashboardView(){
  const d=state.dashboard;
  const top=d.highest_risk||[];
  const ranking=top.map((p,i)=>`<div class="ranked-row" data-project="${p.id}"><span class="ranked-index">${String(i+1).padStart(2,'0')}</span><div class="ranked-detail"><strong>${esc(p.name)}</strong><span>${esc(p.district)}</span></div>${riskBadge(p.zone)}<div class="risk-score">${p.score}<small>/100</small></div></div>`).join('');
  return header('Центр мониторинга','Единое пространство для выявления и проверки рисков в долевом строительстве.',`<button class="btn" data-page="projects">⌂ Реестр ЖК</button><button class="btn btn-primary" data-action="new-ad">＋ Проверить объявление</button>`)+ribbon+
    `<div class="metric-grid">${metric('Всего объектов',d.project_count||0,'На контрольной карте','⌂')}${metric('Высокий риск',d.zones?.red||0,'Требуют приоритетного рассмотрения','⚑')}${metric('Публикаций найдено',d.ad_count||0,'Включая проверенные и новые','▣')}${metric('Ожидают аналитика',d.pending_ads||0,'<strong>Нужна ручная проверка</strong>','☑')}</div>
    <div class="split-main"><section class="card"><div class="panel-header"><div><h2>География объектов</h2><p>Улицы города · зоны строительства · источники геоданных</p></div><button class="tiny-link" data-page="map">На весь экран ↗</button></div><iframe title="Реальная карта Усть-Каменогорска" class="map-area" src="/geo?embed=1" style="display:block;width:100%;border:0;height:360px"></iframe></section>
    <section class="card"><div class="panel-header"><div><h2>Приоритетные объекты</h2><p>Ранжирование по подтверждённым факторам риска</p></div><span class="risk-badge yellow">TOP 5</span></div><div class="ranked-list">${ranking}</div></section></div>
    <section class="card"><div class="panel-header"><div><h2>Последние публикации</h2><p>Входящий поток рекламы с ручной проверкой ИИ-гипотез</p></div><button class="tiny-link" data-page="ads">Все публикации ↗</button></div>${state.ads.slice(0,3).map(ad=>adItem(ad,true)).join('')}</section>`;
}
const UKA_CENTER=[49.955,82.615];
const OSM_LINK='https://www.openstreetmap.org/#map=12/49.955/82.615';
const MAP_BBOX='82.51%2C49.895%2C82.73%2C50.03';
const locOk=p=>Number.isFinite(p.latitude)&&Number.isFinite(p.longitude)&&p.latitude>=-90&&p.latitude<=90&&p.longitude>=-180&&p.longitude<=180;
const osmAt=p=>`https://www.openstreetmap.org/?mlat=${encodeURIComponent(p.latitude)}&mlon=${encodeURIComponent(p.longitude)}#map=16/${encodeURIComponent(p.latitude)}/${encodeURIComponent(p.longitude)}`;
function mappedProjects(){return state.projects.filter(p=>(state.mapZone==='all'||p.zone===state.mapZone)&&((p.name+' '+p.address+' '+p.developer).toLowerCase().includes(state.mapQuery.toLowerCase())));}
function mapView(){
  const filtered=mappedProjects();const shown=filtered.filter(locOk);const unknown=filtered.filter(p=>!locOk(p));
  return header('Карта Усть-Каменогорска','Зоны строительства по геоданным OSM и подтверждённым контурам ЖК.',`<a class="btn" href="${OSM_LINK}" target="_blank" rel="noopener noreferrer">↗ Открыть в OpenStreetMap</a><button class="btn btn-primary" data-page="ads">＋ Проверить рекламу</button>`)+ribbon+
  `<div class="map-filter-card card"><div class="map-filter-left"><label class="searchbox">⌕ <input id="map-search" placeholder="ЖК, улица, застройщик" value="${esc(state.mapQuery)}"/></label><button class="btn btn-small" data-action="map-search">Найти</button></div><div class="tabs">${['all','red','yellow','green'].map(z=>`<button class="tab ${z===state.mapZone?'active':''}" data-map-zone="${z}">${z==='all'?'Все объекты':zoneNames[z]}</button>`).join('')}</div></div>
   <div class="zone-toolbar">
     <label class="zone-toggle"><input type="checkbox" id="layer-osm" ${state.showOSMZones?'checked':''}/> Строительные участки OSM</label>
     <label class="zone-toggle"><input type="checkbox" id="layer-project" ${state.showProjectZones?'checked':''}/> Контуры ЖК</label>
     <span class="zone-load" id="zone-layer-status">OSM: ${esc(state.zoneStatus)} · ${state.zoneCount} | ЖК: ${state.projectZoneCount} контуров</span>
     <button class="btn btn-small" id="zone-refresh" type="button">↻ Обновить зоны</button>
     <button class="btn btn-small" id="zone-draw-toggle" type="button">＋ Нанести контур</button>
   </div>
   <div class="zone-draw-panel" id="zone-draw-panel" hidden>
     <strong>Нанесение контура ЖК</strong><span>Нажмите минимум три точки на карте; завершите полигон. Это ручная геопривязка, а не автоматическое кадастровое подтверждение.</span>
     <select id="draw-project">${state.projects.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select>
     <input id="draw-source" type="url" placeholder="Ссылка на источник границ (https://...)" />
     <input id="draw-reviewer" type="text" placeholder="Имя аналитика" value="Аналитик МИО" />
     <button class="btn btn-primary btn-small" id="zone-finish" type="button">Сохранить контур</button>
     <button class="btn btn-small" id="zone-clear" type="button">Очистить точки</button>
   </div>
   <div class="geo-layout"><section class="card geo-stage"><div id="map-container" class="map-area geo-map" role="region" aria-label="Интерактивная карта Усть-Каменогорска"></div><div class="map-instruction">Заштрихованные полигоны OSM — картографические сведения, не официальные разрешения или кадастровые границы. Демо-контуры имеют пунктирную границу. Непроверенные объекты не признаются нарушителями.</div></section><aside class="card geo-list"><div class="geo-list-head"><strong>Объекты на карте</strong><span>${shown.length} / ${state.projects.length}</span></div>${shown.map(p=>`<div class="geo-entry"><div class="geo-entry-top">${riskBadge(p.zone)}<span>${p.score}/100</span>${p.demo?'<span class="demo-tag">ДЕМО</span>':''}</div><strong>${esc(p.name)}</strong><p>${esc(p.address)}</p><div class="geo-entry-actions"><button class="tiny-link" data-map-focus="${p.id}">⌖ Найти</button><button class="tiny-link" data-project="${p.id}">Карточка ↗</button></div></div>`).join('')||'<p class="inline-info">Объектов с координатами нет.</p>'}${unknown.length?`<div class="geo-no-coords"><b>Без координат (${unknown.length})</b><p>Сохранены в реестре и не размещены на карте по вымышленным точкам.</p>${unknown.slice(0,8).map(p=>`<button data-project="${p.id}" class="tiny-link">${esc(p.name)} ↗</button>`).join('')}</div>`:''}</aside></div>`;
}
// The public map must NEVER use state.projects (seeded fictitious coordinates).
mapView=function(){return header('Реальная карта Усть-Каменогорска','Действительные ЖК из совокупного реестра; ни одной учебной метки.',`<a class="btn btn-primary" href="/geo">Открыть интерактивную карту ↗</a>`)+`<iframe title="Карта реальных ЖК" src="/geo?embed=1" style="height:76vh;min-height:550px;width:100%;border:1px solid #e3e9ea;border-radius:9px;background:#e9eff0"></iframe><div style="margin-top:15px"><a class="btn btn-primary" href="/geo">Список ЖК, адреса, сайты, Instagram и три картографических сервиса ↗</a></div>`};
function osmEmbed(){
  return `<iframe class="osm-embed" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" title="Карта OpenStreetMap: Усть-Каменогорск" src="https://www.openstreetmap.org/export/embed.html?bbox=${MAP_BBOX}&amp;layer=mapnik"></iframe><div class="map-load-notice"><b>OpenStreetMap — карта Усть-Каменогорска</b><span>Для загрузки карты нужен интернет. В расширенном режиме показаны отметки ЖК.</span><a href="${OSM_LINK}" target="_blank" rel="noopener noreferrer">Открыть карту ↗</a></div>`;
}
function mapLegend(){return `<div class="map-legend"><span><i class="pin-key red"></i>Высокий риск</span><span><i class="pin-key yellow"></i>Повышенный</span><span><i class="pin-key green"></i>Низкий</span><span><i class="zone-key"></i>OSM: стройплощадка</span><span class="legend-demo">Демо-зоны пунктиром</span></div>`;}
function setZoneInfo(text,count){
  state.zoneStatus=text;state.zoneCount=count;
  const node=$('#zone-layer-status');
  if(node)node.textContent=`OSM: ${text} · ${count} | ЖК: ${state.projectZoneCount} контуров`;
}
function setProjectZoneInfo(count){state.projectZoneCount=count;setZoneInfo(state.zoneStatus,state.zoneCount);}
function visibleMapWarning(message){
  const mapRoot=$('#map-container');if(!mapRoot)return;
  let notice=mapRoot.querySelector('.map-failure-warning');
  if(!notice){notice=document.createElement('div');notice.className='map-failure-warning';mapRoot.appendChild(notice);}
  notice.textContent=message;
}
// Each overlay requests data independently. A slow/unreachable Overpass server must
// never prevent project boundaries from appearing. Stale async responses are ignored.
function loadZonesOnMap(map,refresh=false,version=mapOverlayGeneration){
  const isCurrent=()=>activeLeafletMap===map && version===mapOverlayGeneration;
  const osm=async()=>{
    if(!state.showOSMZones){if(isCurrent())setZoneInfo('Скрыты',0);return;}
    if(isCurrent())setZoneInfo('Загружаются…',0);
    try{
      const geo=await req('/map/construction-zones'+(refresh?'?refresh=true':''));
      if(!isCurrent())return;
      if(geo.type!=='FeatureCollection'||!Array.isArray(geo.features))throw new Error('Неверный GeoJSON OSM');
      const layer=L.geoJSON(geo,{style:{color:'#7b8490',weight:1.8,fillColor:'#7b8793',fillOpacity:.28,dashArray:'5,3'},
        onEachFeature(feature,shape){const pr=feature.properties||{};shape.bindPopup(`<div class="map-popup"><b>${esc(pr.name||'Объект строительства OSM')}</b><p>Контур OSM, не официальный документ</p><a href="${esc(pr.source_url||OSM_LINK)}" target="_blank" rel="noopener noreferrer">Открыть в OSM ↗</a></div>`);}});
      layer.addTo(map);activeZoneLayers.push({kind:'osm',layer});
      const labels={cached:'Кэш OSM',live:'OSM обновлён',stale:'Кэш OSM (офлайн)',unavailable:'OSM недоступен'};
      const status=labels[geo.status]||geo.status||'Загружены';
      setZoneInfo(status,geo.features.length);
      if(!geo.features.length&&geo.status==='unavailable')visibleMapWarning('Сервис строительных зон OSM временно недоступен. Контуры ЖК и метки работают отдельно.');
    }catch(err){if(isCurrent()){setZoneInfo('Ошибка OSM',0);visibleMapWarning('Не удалось загрузить стройплощадки OSM. Контуры ЖК и метки остаются доступны.');}console.warn('OSM overlay:',err);}
  };
  const projects=async()=>{
    if(!state.showProjectZones){if(isCurrent())setProjectZoneInfo(0);return;}
    try{
      const geo=await req('/map/project-boundaries');
      if(!isCurrent())return;
      if(geo.type!=='FeatureCollection'||!Array.isArray(geo.features))throw new Error('Неверный GeoJSON ЖК');
      const layer=L.geoJSON(geo,{
        style(feature){const p=state.projects.find(q=>q.id===feature.properties?.project_id);const isDemo=Boolean(feature.properties?.demo);return {color:p?riskColor(p.zone):'#347f78',weight:3,fillColor:p?riskColor(p.zone):'#347f78',fillOpacity:isDemo ? 0.10 : 0.20,dashArray:isDemo?'8,6':null};},
        onEachFeature(feature,shape){const pr=feature.properties||{};shape.bindPopup(`<div class="map-popup"><b>${esc(pr.name)}</b><small>${pr.demo?'ДЕМО: условный контур':'Контур привязан аналитиком'}</small><p>Источник: ${esc(pr.source_url||'не указан')}</p><button class="btn btn-small" data-project="${Number(pr.project_id)}">Открыть ЖК ↗</button></div>`);}
      });
      layer.addTo(map);activeZoneLayers.push({kind:'project',layer});
      setProjectZoneInfo(geo.features.length);
    }catch(err){if(isCurrent()){setProjectZoneInfo(0);visibleMapWarning('Не удалось загрузить контуры ЖК. Проверьте API /api/map/project-boundaries.');}console.warn('Project boundary overlay:',err);}
  };
  // Starts both immediately rather than waiting 20–30 s for an Overpass timeout.
  return Promise.allSettled([osm(),projects()]);
}
function refreshMapZones(refresh=false){
  if(!activeLeafletMap)return;
  const version=++mapOverlayGeneration;
  for(const entry of activeZoneLayers)activeLeafletMap.removeLayer(entry.layer);
  activeZoneLayers=[];
  loadZonesOnMap(activeLeafletMap,refresh,version);
}
function beginDraw(){
  const panel=$('#zone-draw-panel');if(!panel||!activeLeafletMap)return;
  drawing=!drawing;panel.hidden=!drawing;drawVertices=[];
  if(drawGuide){drawGuide.remove();drawGuide=null;}
  if(drawing){drawGuide=L.polyline([],{color:'#257b75',weight:3,dashArray:'5,5'}).addTo(activeLeafletMap);toast('Нанесите на карте минимум три вершины контура.');}
}
async function saveDrawnBoundary(){
  if(drawVertices.length<3)throw new Error('Нужно минимум 3 вершины контура');
  const id=Number($('#draw-project').value),source=$('#draw-source').value.trim(),reviewer=$('#draw-reviewer').value.trim();
  if(!source.startsWith('https://')&&!source.startsWith('http://'))throw new Error('Укажите ссылку на картографический источник');
  const ring=drawVertices.map(p=>[Number(p.lng.toFixed(6)),Number(p.lat.toFixed(6))]);ring.push([...ring[0]]);
  await req(`/projects/${id}/boundary`,{method:'POST',body:JSON.stringify({geometry:{type:'Polygon',coordinates:[ring]},source,reviewer})});
  drawing=false;drawVertices=[];if(drawGuide){drawGuide.remove();drawGuide=null;}
  const panel=$('#zone-draw-panel');if(panel)panel.hidden=true;
  toast('Контур сохранён с источником и именем аналитика');await refresh();
}
function initMap(){
  const root=$('#map-container');if(!root)return;
  // REAL geographical streets in both modes; never draw fictitious roads or a pretend basemap.
  root.innerHTML=osmEmbed()+mapLegend();
  if(!window.L){
    visibleMapWarning('Интерактивная карта Leaflet не загрузилась: показана только подложка OSM без меток. Проверьте доступ к unpkg.com или jsdelivr.net.');
    // A backup CDN may finish loading slightly later. Try again without refreshing.
    if(!leafletRetryTimer && leafletRetryCount<8){leafletRetryCount++;leafletRetryTimer=setTimeout(()=>{leafletRetryTimer=null;if($('#map-container')===root)initMap();},1250);}
    return;
  }
  leafletRetryCount=0;
  const fallback=root.innerHTML;
  try{
    root.innerHTML='<div class="map-leaflet" id="map-view"></div>'+mapLegend();
    const map=L.map('map-view',{zoomControl:false,attributionControl:true,scrollWheelZoom:true,wheelDebounceTime:60,preferCanvas:true}).setView(UKA_CENTER,12);
    activeLeafletMap=map;
    let successes=0,failures=0;
    const tiles=L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{
      minZoom:9,maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap contributors</a>',
      crossOrigin:true
    });
    tiles.on('tileload',()=>{successes++;});
    tiles.on('tileerror',()=>{
      failures++;
      // Never remove Leaflet here: replacing it with an iframe also destroys
      // all markers, zones and interactive drawing controls.
      if(failures===6&&!successes&&activeLeafletMap===map){
        visibleMapWarning('Тайлы OpenStreetMap временно не загружаются. Метки и строительные контуры продолжают работать.');
      }
    });
    tiles.addTo(map);
    activeMapMarkers.clear();
    const pts=(state.page==='map'?mappedProjects():state.projects).filter(locOk);
    pts.forEach(p=>{
      const icon=L.divIcon({className:'leaflet-div-icon',html:`<div class="leaflet-custom-pin ${esc(p.zone)} ${p.demo?'demo':''}">${p.score}</div>`,iconSize:[38,38],iconAnchor:[19,19]});
      const popup=`<div class="map-popup"><b>${esc(p.name)}</b><small>${p.demo?'ДЕМО: положение условное':'Координаты из импортированной записи'}</small><p>${esc(p.address)}</p><div class="map-popup-bottom">${riskBadge(p.zone)} <b>${p.score}/100</b></div><button class="btn btn-small" data-project="${p.id}">Карточка ЖК ↗</button><a href="${esc(osmAt(p))}" target="_blank" rel="noopener noreferrer">Открыть точку в OSM</a></div>`;
      const marker=L.marker([p.latitude,p.longitude],{icon}).addTo(map).bindPopup(popup,{maxWidth:270});
      activeMapMarkers.set(p.id,marker);
    });
    if(state.page==='map'&&pts.length){map.fitBounds(L.latLngBounds(pts.map(p=>[p.latitude,p.longitude])),{padding:[55,55],maxZoom:13});}
    map.on('click',event=>{if(!drawing)return;drawVertices.push(event.latlng);if(drawGuide)drawGuide.setLatLngs(drawVertices);setZoneInfo('Вершин контура: '+drawVertices.length,state.zoneCount);});
    loadZonesOnMap(map,false,++mapOverlayGeneration);
    L.control.zoom({position:'bottomright'}).addTo(map);
    L.control.scale({metric:true,imperial:false,position:'bottomleft'}).addTo(map);
    setTimeout(()=>{if(activeLeafletMap===map)map.invalidateSize();},120);
  }catch(e){console.error('Leaflet initialization failed',e);if(activeLeafletMap){activeLeafletMap.remove();activeLeafletMap=null;}root.innerHTML=fallback;visibleMapWarning('Ошибка Leaflet: интерактивные метки недоступны. '+e.message);}
}
function projectsView(){
  const filtered=state.projects.filter(p=>(state.zoneFilter==='all'||p.zone===state.zoneFilter) && (p.name+' '+p.developer+' '+p.address).toLowerCase().includes(state.search.toLowerCase())).sort((a,b)=>b.score-a.score);
  return header('Реестр жилых комплексов','Документы, строительные площадки, публикации и подтверждённые риски.',`<button class="btn btn-primary" data-action="new-ad">＋ Добавить публикацию</button>`)+ribbon+
    `<div class="filterbar"><label class="searchbox">⌕ <input id="project-search" placeholder="Поиск по ЖК, застройщику, адресу..." value="${esc(state.search)}"/></label><div class="tabs">${['all','red','yellow','green'].map(z=>`<button class="tab ${z===state.zoneFilter?'active':''}" data-zone="${z}">${z==='all'?'Все объекты':zoneNames[z]}</button>`).join('')}</div></div>
    <div class="card table-wrap"><table class="project-table"><thead><tr><th>Объект / местоположение</th><th>Застройщик</th><th>Стадия</th><th>Готовность</th><th>Документы</th><th>Риск</th><th>Баллы</th></tr></thead><tbody>${filtered.length?filtered.map(p=>`<tr data-project="${p.id}"><td><div class="project-name">${esc(p.name)}</div><div class="project-address">${esc(p.address)}</div></td><td>${esc(p.developer)}</td><td>${esc(p.stage)}</td><td><div>${p.completion}%</div><div class="progress-track" style="margin-top:7px"><div class="progress-fill" style="width:${p.completion}%"></div></div></td><td><span class="section-caption">${legalLabel(p.legal_status)}</span></td><td>${riskBadge(p.zone)}</td><td><strong>${p.score}</strong><span class="muted">/100</span></td></tr>`).join(''):`<tr><td colspan="7" class="empty-help">Объекты не найдены. Измените фильтр.</td></tr>`}</tbody></table></div><p class="section-caption">Найдено объектов: ${filtered.length}. Нажмите на строку, чтобы открыть карточку и источники доказательств.</p>`;
}
function adItem(ad,compact=false){
  const a=ad.analysis||{};
  return `<div class="ad-row"><div class="platform-icon ${esc(ad.platform)}">${ad.platform==='instagram'?'◎':ad.platform==='telegram'?'✈':ad.platform==='olx'?'OLX':'✎'}</div><div><div class="ad-title"><strong>${esc(ad.project_name||'Не привязано к ЖК')}</strong><span>${esc(ad.platform)} · ${formatDate(ad.posted_at||ad.captured_at)}</span></div><div class="ad-content">${esc(ad.text.slice(0,compact?155:500))}${ad.text.length>(compact?155:500)?'…':''}</div><div class="ad-meta"><span>${esc(ad.account||'ручное добавление')}</span>${a.payment?.found?'<span class="evidence-tag">₸ Возможная оплата</span>':''}${a.advertising?.found?'<span class="evidence-tag neutral">◉ Продажа</span>':''}${ad.image_path?'<span class="evidence-tag neutral">▣ Скриншот</span>':''}${statusPill(ad.review_status)}${ad.source_url?.startsWith('https://')?`<a class="tiny-link ad-direct-link" href="${esc(ad.source_url)}" target="_blank" rel="noopener noreferrer">↗ Оригинал ${ad.platform==='instagram'?'Instagram':ad.platform==='olx'?'OLX':'публикации'}</a>`:'<span class="demo-mini">Без публичной ссылки</span>'}</div></div><div class="ad-actions">${ad.review_status==='pending'?`<button class="btn btn-small" data-ad-review="${ad.id}">Проверить ↗</button>`:`<button class="btn btn-small btn-ghost" data-project="${ad.project_id||''}">Объект ↗</button>`}</div></div>`;
}
function adsView(){
  const ads=state.ads.filter(a=>state.adFilter==='all'||a.review_status===state.adFilter);
  return header('Мониторинг рекламы','Анализ текста и скриншотов Instagram, OLX и других источников.',`<button class="btn btn-primary" data-action="new-ad">＋ Новая публикация</button>`)+ribbon+
    `<div class="review-split"><div class="card form-card"><h2>ИИ-анализ новой публикации</h2><p>Вставьте текст объявления или загрузите скриншот. Система найдёт признаки оплаты и предложит связанный ЖК.</p><div class="form-group"><label>Текст объявления</label><textarea id="ad-text" class="field" placeholder="Например: ЖК DEMO Бета. Продажа квартир от 20 млн ₸. Внесите депозит 300 000 ₸ для бронирования..."></textarea></div>
      <div class="form-grid"><div class="form-group"><label>Площадка</label><select class="field" id="ad-platform"><option value="instagram">Instagram</option><option value="olx">OLX</option><option value="telegram">Telegram</option><option value="manual">Ручной ввод</option></select></div><div class="form-group"><label>ЖК (необязательно)</label><select class="field" id="ad-project"><option value="">Определить автоматически</option>${state.projects.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select></div></div><div class="form-grid"><div class="form-group"><label>Ссылка на источник</label><input class="field" id="ad-url" placeholder="https://..."/></div><div class="form-group"><label>Аккаунт / автор публикации</label><input class="field" id="ad-account" placeholder="@example"/></div></div>
      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap"><button class="btn btn-primary" id="analyze-btn" data-action="analyze">◈ Анализировать</button><button class="btn" data-action="save-ad">＋ Добавить на проверку</button><label class="btn" for="ocr-upload">▣ OCR скриншота</label><input type="file" id="ocr-upload" accept="image/png,image/jpeg,image/webp" hidden/></div><div class="form-tip">Распознавание новых объявлений работает без платного LLM API. Результаты ИИ требуют подтверждения аналитиком.</div></div>
      <div class="card analysis-card"><h2>Результат интеллектуального анализа</h2><p>Гипотезы с проверяемыми текстовыми фрагментами</p><div id="analysis-result">${renderAnalysis(state.preview)}</div></div></div>
    <div class="ad-csv-strip"><div><b>Массовый импорт объявлений</b><p>CSV с текстами OLX / Instagram / Telegram из разрешённых источников. После импорта все записи требуют ручного подтверждения.</p><a href="/static/ads_import_template.csv" download>↓ Шаблон CSV</a></div><label class="btn" for="ads-csv-upload">↑ Загрузить CSV</label><input type="file" hidden id="ads-csv-upload" accept=".csv,text/csv" /></div>
    <div class="card" style="margin-top:21px"><div class="panel-header"><div><h2>Лента публикаций</h2><p>${state.ads.length} публикаций · ${state.dashboard.pending_ads} ожидают проверки</p></div><div class="tabs">${['all','pending','accepted','rejected'].map(f=>`<button class="tab ${state.adFilter===f?'active':''}" data-ad-filter="${f}">${({all:'Все',pending:'Новые',accepted:'Принятые',rejected:'Отклонённые'})[f]}</button>`).join('')}</div></div>${ads.length?ads.map(ad=>adItem(ad)).join(''):'<div class="empty-help">Публикаций с таким статусом пока нет.</div>'}</div>`;
}
function renderAnalysis(a){
  if(!a)return `<div class="analysis-empty"><div><span class="analysis-symbol">⌕</span><strong>Ожидаем входные данные</strong>Загрузите публикацию и нажмите «Анализировать».<br>Здесь появятся признаки и основания.</div></div>`;
  const m=a.matching||{};
  return `<div class="result-block"><div class="result-title">◈ Сопоставление с объектом <span class="tag">ML · TF-IDF</span></div><p>${m.project_name?`Вероятный ЖК: <strong>${esc(m.project_name)}</strong>`:'Точное соответствие не определено. Выберите ЖК вручную.'}</p><p>Оценка текстового сходства: <b>${Math.round((m.confidence||0)*100)}%</b>. Это не вероятность нарушения.</p></div>
  <div class="result-block"><div class="result-title">₸ Привлечение денег ${a.payment?.found?'<span class="evidence-tag">Найден признак</span>':'<span class="tag">Не обнаружено</span>'}</div><p>${esc(a.payment?.reason)}</p>${a.payment?.snippet?`<div class="quote">«${esc(a.payment.snippet)}»</div>`:''}</div>
  <div class="result-block"><div class="result-title">⌂ Реклама квартир ${a.advertising?.found?'<span class="evidence-tag">Есть признаки</span>':'<span class="tag">Недостаточно данных</span>'}</div><p>${esc(a.advertising?.reason)}</p>${a.advertising?.snippet?`<div class="quote good">«${esc(a.advertising.snippet)}»</div>`:''}</div>
  <div class="result-block"><div class="result-title">◎ Дополнительные признаки</div><div class="tag-row" style="margin-top:10px">${a.price?.found?`<span class="tag">Цена: ${esc(a.price.snippet)}</span>`:''}<span class="tag">${a.construction_mention?.found?'Строительство упомянуто':'Стадия не указана'}</span></div></div><div class="state-banner">ИИ формирует гипотезу. Публикация не влияет на подтверждённый риск до проверки аналитиком.</div>`;
}
function signalsView(){
  return header('Сигнальные карточки','История проверки потенциальных нарушений, решения аналитика и PDF-отчёты.',`<button class="btn" data-page="projects">⌂ Выбрать объект</button>`)+ribbon+
    `<div class="card"><div class="panel-header"><div><h2>Журнал решений</h2><p>Фиксируется автор, дата, статус и баллы на момент формирования</p></div><span class="tag">${state.signals.length} записей</span></div>${state.signals.length?state.signals.map(s=>`<div class="signal-row"><div><strong>№ ${s.id} · ${esc(s.project_name)}</strong><p>${formatDate(s.created_at)} · ${esc(s.author)} · ${esc(s.note.slice(0,140))}</p><div class="tag-row" style="margin-top:8px">${riskBadge(s.zone)} <span class="tag">${s.score} баллов</span>${statusPill(s.status)}</div></div><div class="signal-action"><a class="btn btn-small" href="${API}/projects/${s.project_id}/report.pdf?signal_id=${s.id}" target="_blank" rel="noopener">↓ PDF</a>${s.status==='pending'?`<button class="btn btn-small btn-primary" data-signal="${s.id}" data-decision="confirmed">Подтвердить</button><button class="btn btn-small" data-signal="${s.id}" data-decision="returned">Вернуть</button>`:''}</div></div>`).join(''):`<div class="signal-empty"><span style="font-size:37px">☷</span><b>Сигналы ещё не созданы</b>Откройте ЖК в реестре и нажмите «Создать сигнальную карточку».<br><button class="btn btn-primary" style="margin-top:16px" data-project="2">Показать пример высокого риска ↗</button></div>`}</div>`;
}

async function loadConnectors(){
  const host=$('#connector-status');if(!host)return;
  try{
    const result=await req('/registries/status');if(!$('#connector-status'))return;
    host.innerHTML=result.connectors.map(s=>`<div class="connector-entry"><div class="connector-heading"><strong>${esc(s.name)}</strong><span class="connector-indicator ${s.configured?'ready':'offline'}">${s.configured?'Настроен':'Нужен доступ'}</span></div><p>${esc(s.scope)}</p><div class="connector-actions"><a class="tiny-link" target="_blank" rel="noopener noreferrer" href="${esc(s.url)}">Открыть источник ↗</a>${s.id==='ashyq'?'<button class="btn btn-primary btn-small" data-collect="ashyq">↻ Синхронизировать CSV</button>':`<button class="btn btn-small" ${s.configured?'':'disabled'} data-collect="${s.id}">Получить публикации</button>`}</div></div>`).join('');
    $('#permit-results').textContent=`Сохранено разрешений: ${result.permits_stored}. Выполните поиск или синхронизацию.`;
  }catch(e){host.textContent='Статусы источников временно недоступны.';}
}
async function collectSource(id){
  toast(`Запрашиваю ${id}…`);
  const endpoint=id==='ashyq'?'/registries/ashyq/sync':`/collect/${id}`;
  const result=await req(endpoint,{method:'POST'});
  toast(`Получено: ${result.fetched??result.total_seen??0}, добавлено: ${result.added}. Все новые данные требуют проверки.`);
  await refresh();
  if(state.page==='sources')loadConnectors();
}
async function searchPermits(){
  const q=$('#registry-query')?.value.trim()||'';
  const rows=await req('/registries/permits?q='+encodeURIComponent(q));
  $('#permit-results').innerHTML=rows.length?rows.map(p=>`<div class="permit-row"><strong>${esc(p.permission_number||'Без номера')}</strong><span>${esc(p.project_name||'Местоположение не указано')}</span><span>${esc(p.developer||'Нет данных о застройщике')}</span><a class="tiny-link" href="${esc(p.source_url)}" target="_blank" rel="noopener noreferrer">Реестр ↗</a></div>`).join(''):'Совпадения отсутствуют. Это НЕ означает отсутствие разрешения.';
}
async function uploadPermitCSV(file){const f=new FormData();f.append('file',file);const result=await req('/registries/ashyq/import.csv',{method:'POST',body:f});toast(`Разрешений добавлено: ${result.added}`);loadConnectors();searchPermits();}

function sourcesView(){
  return header('Источники информации','Публичные реестры и текущий статус интеграций.',`<a class="btn" href="/api/docs" target="_blank" rel="noopener">⌘ Открыть API ↗</a>`)+ribbon+
    `<div class="connector-panel card"><div class="panel-header"><div><h2>Живые источники · контролируемые подключения</h2><p>Синхронизация не равна проверке разрешения. Все найденные записи проходят человеческую верификацию.</p></div><span class="tag">API / CSV</span></div><div id="connector-status" class="connector-grid"><p class="section-caption">Загрузка статусов…</p></div></div><div class="registry-explorer card"><h2>Разрешения МИО · Ashyq Data</h2><p>Загруженные разрешения из официальной CSV, не автоматические вердикты по ЖК.</p><div class="filterbar"><input class="registry-query" id="registry-query" placeholder="Поиск по номеру разрешения, объекту или застройщику"/><button class="btn btn-small" data-action="registry-search">Поиск</button><label class="btn btn-small" for="permit-csv">↑ CSV разрешений</label><input hidden id="permit-csv" type="file" accept=".csv,text/csv" /></div><div id="permit-results" class="permit-results">Найдите разрешение или выполните синхронизацию.</div></div><div class="card" style="padding:18px 22px;margin-bottom:18px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap"><div><strong>Реальные публичные карточки · Усть-Каменогорск</strong><p class="section-caption">11 ЖК из каталога Krisha, объявления OLX и карточки Krisha с прямыми ссылками. Снимок 17.10.2026; без вымышленных координат и юридических обвинений.</p></div><button class="btn btn-primary" data-action="load-uka-real">＋ Загрузить реальные данные</button></div><div class="state-banner">По умолчанию загружаются учебные данные. Вы можете импортировать сведения из официальной CSV-выгрузки; это НЕ означает подключение к государственному API и НЕ подтверждает законность объекта.</div><div class="card" style="padding:18px 22px;margin-bottom:18px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap"><div><strong style="font-size:13px">Публичный пример КЖК: ЖК «Золотой квадрат»</strong><p class="section-caption" style="margin:6px 0 0">Реальный объект на ул. Кайсенова 55/1. Локальный снимок данных КЖК на 31.08.2026; не live API. Координаты и правовой статус проверяются отдельно.</p><a class="tiny-link" href="https://www.homeportal.kz/ru/projects/1141" target="_blank" rel="noopener noreferrer">Исходная карточка КЖК ↗</a></div><button class="btn btn-primary" data-action="load-kzhk-example">＋ Импортировать объект</button></div><div class="card" style="padding:18px 22px;margin-bottom:18px;display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap"><div><strong style="font-size:13px">Импорт официального CSV</strong><p class="section-caption" style="margin:6px 0 0">Установить источники, загрузить данные без юридических вердиктов.</p></div><div><label class="btn btn-primary" for="registry-upload">↑ Импортировать ЖК (CSV)</label><input type="file" hidden id="registry-upload" accept=".csv,text/csv"/></div></div><div class="source-grid">${state.sources.map((s,i)=>`<div class="card source-card"><div class="source-icon">${['⌂','▤','≋'][i]||'▦'}</div><strong>${esc(s.name)}</strong><p>Официальный источник для последующей верификации правового статуса и сведений об объектах.</p><a href="${esc(s.url)}" rel="noopener noreferrer" target="_blank">Открыть первоисточник ↗</a><br><span class="source-status">${s.live?"Синхронизация возможна по запросу":"Проверка вручную / через CSV"}</span></div>`).join('')}</div><section class="card" style="padding:21px;margin-top:18px"><h2 style="font-size:15px;margin-top:0">Как добавить реальные данные?</h2><p class="section-caption" style="line-height:1.9">Базовая архитектура допускает импорт JSON/CSV через отдельный ETL-адаптер и PostgreSQL. Для каждого документа обязательно сохранять источник и дату проверки. Отсутствие результата поиска не является доказательством отсутствия разрешения.</p><a class="btn" href="https://homeportal.kz" target="_blank" rel="noopener noreferrer">Жилищный портал КЖК ↗</a></section>`;
}
async function openProject(id){
  if(!id)return;
  const p=await req('/projects/'+id);
  state.drawer=p.id;
  const circumference=p.score*3.6;
  const legalCtrl=`<div class="state-banner">${p.demo?'Учебный объект. ':''}Правовой статус меняет только аналитик на основе проверенного документа.</div><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn-small" data-action="edit-legal" data-id="${p.id}">✎ Проверить документы</button><button class="btn btn-small" data-action="edit-location" data-id="${p.id}">⌖ Уточнить геометку</button><a class="btn btn-small" href="${API}/projects/${p.id}/report.pdf" target="_blank" rel="noopener">↓ Скачать PDF</a></div>`;
  $('#drawer-host').innerHTML=`<div class="drawer-backdrop" id="drawer-backdrop"><aside class="drawer" role="dialog" aria-modal="true" aria-label="Карточка ЖК"><div class="drawer-head"><div class="eyebrow" style="margin:0">КАРТОЧКА ОБЪЕКТА / #${String(p.id).padStart(3,'0')}</div><button class="close-x" data-action="close-drawer" aria-label="Закрыть">×</button></div><div class="drawer-body"><div class="tag-row">${riskBadge(p.zone)}${p.demo?'<span class="tag">ДЕМО</span>':'<span class="tag">ИМПОРТ</span>'}<span class="tag">${esc(p.stage)}</span></div><h2 class="drawer-title">${esc(p.name)}</h2><div class="drawer-sub">⌖ ${esc(p.address)}</div><div class="score-hero" style="margin-top:22px"><div class="score-ring" style="background:conic-gradient(${riskColor(p.zone)} ${circumference}deg,#e9eff0 0deg)"><span>${p.score}<small>из 100</small></span></div><div class="score-info"><strong>Риск: ${zoneNames[p.zone]}</strong>${riskBadge(p.zone)}<p>${p.zone==='red'?'Подтверждена комбинация R1 + R2; приоритетно для специалиста.':p.zone==='yellow'?'Нужна углублённая ручная проверка.':'Плановый мониторинг; отсутствие риска не доказано.'}</p></div></div>
    <div class="drawer-section"><h3>Сведения об объекте</h3><div class="detail-grid"><div class="detail-item"><label>Застройщик</label><strong>${esc(p.developer)}</strong></div><div class="detail-item"><label>БИН ${p.demo?'(демо)':''}</label><strong>${esc(p.bin)}</strong></div><div class="detail-item"><label>Стадия строительства</label><strong>${esc(p.stage)}</strong></div><div class="detail-item"><label>Текущая готовность</label><strong>${p.completion}%</strong></div></div></div>
    <div class="drawer-section"><h3>Правовые основания и подтверждения</h3><div class="detail-grid"><div class="detail-item"><label>Статус проверки</label><strong>${esc(legalLabel(p.legal_status))}</strong></div><div class="detail-item"><label>Основание</label><strong>${esc(p.legal_basis||'Нет сведений')}</strong></div><div class="detail-item"><label>Источник</label><strong>${esc(p.legal_source||'Нет подтверждённого источника')}</strong></div><div class="detail-item"><label>Дата проверки</label><strong>${esc(p.legal_checked_at||'Не проверено')}</strong></div>${p.registry_url?`<div class="detail-item"><label>Карточка реестра / источник импорта</label><a href="${esc(p.registry_url)}" target="_blank" rel="noopener noreferrer">Первоисточник ↗</a></div>`:''}<div class="detail-item"><label>Координаты</label><strong>${locOk(p)?`${p.latitude.toFixed(5)}, ${p.longitude.toFixed(5)}`:'Не указаны — метка на карте отсутствует'}</strong></div>${p.coordinate_source?`<div class="detail-item"><label>Источник геометки</label><strong>${esc(p.coordinate_source)}</strong></div>`:''}</div>${legalCtrl}</div>
    <div class="drawer-section"><h3>Объяснение риск-скоринга (${p.factors.length})</h3>${p.factors.length?p.factors.map(f=>`<div class="factor-item"><div class="factor-code">${f.code}</div><div><div class="factor-title">${esc(f.label)}</div><div class="factor-desc">${esc(f.evidence)}</div><div class="factor-desc">Источник: ${esc(f.source||'не указан')}</div></div><span class="factor-points">+${f.points}</span></div>`).join(''):'<div class="inline-info">Подтверждённых факторов пока нет. Это не означает, что нарушений нет.</div>'}${p.missing.length?`<div class="state-banner">◷ Нужна проверка: ${esc(p.missing.join('; '))}</div>`:''}</div>
    <div class="drawer-section"><h3>Связанные публикации (${p.ads.length})</h3>${p.ads.length?p.ads.map(a=>`<div class="mini-ad"><div class="mini-ad-top"><span class="tag">${esc(a.platform)}</span>${statusPill(a.review_status)}<span class="section-caption">${formatDate(a.posted_at)}</span></div><div class="mini-ad-text">${esc(a.text)}</div>${a.analysis?.payment?.found?`<div class="quote">«${esc(a.analysis.payment.snippet)}»</div>`:''}${a.image_path?`<div style="margin-top:8px"><a class="tiny-link" href="${esc(a.image_path)}" target="_blank" rel="noopener">▣ Смотреть сохранённый скриншот ↗</a></div>`:''}${a.source_url?.startsWith('https://')?`<div><a class="tiny-link" href="${esc(a.source_url)}" target="_blank" rel="noopener noreferrer">↗ Перейти к публикации в ${esc(a.platform)}</a></div>`:''}<div class="mini-ad-actions">${a.review_status==='pending'?`<button class="btn btn-small btn-primary" data-accept="${a.id}" data-object="${p.id}">✓ Подтвердить</button><button class="btn btn-small btn-danger" data-reject="${a.id}" data-object="${p.id}">× Отклонить</button>`:''}</div></div>`).join(''):'<div class="inline-info">Публикации отсутствуют.</div>'}</div>
    <div class="drawer-section"><h3>Решение аналитика</h3>${p.signals.length?`<div class="inline-info">Сигнальные карточки: ${p.signals.map(s=>'№'+s.id+' ('+(reviewNames[s.status]||s.status)+')').join(', ')}.</div>`:''}<button class="btn btn-primary" style="width:100%;margin-top:12px" data-action="create-signal" data-id="${p.id}">＋ Создать сигнальную карточку</button><p class="section-caption">Система формирует аналитический сигнал, не устанавливает факт нарушения и ничего не отправляет автоматически.</p></div></div></aside></div>`;
}
function closeDrawer(){state.drawer=null;$('#drawer-host').innerHTML='';}
function closeModal(){$('#modal-host').innerHTML='';}
function showModal(inner){$('#modal-host').innerHTML=`<div class="modal-backdrop" id="modal-backdrop"><div class="modal" role="dialog" aria-modal="true">${inner}</div></div>`;}
function modalButton(t){return `<button class="btn" data-action="close-modal">Отмена</button><button class="btn btn-primary" type="submit">${t}</button>`;}
function legalModal(id){
  const p=state.projects.find(x=>x.id===id);
  showModal(`<form id="legal-form" data-id="${id}"><h2>Проверить документы ЖК</h2><p>${esc(p.name)} · укажите статус после проверки первоисточника. Без источника подтверждение невозможно.</p><div class="form-group"><label>Статус правового основания</label><select class="field" name="status">${Object.keys(statusLabels).map(k=>`<option value="${k}" ${k===p.legal_status?'selected':''}>${esc(statusLabels[k])}</option>`).join('')}</select></div><div class="form-group"><label>Номер / вид документа</label><input class="field" name="basis" value="${esc(p.legal_basis)}"/></div><div class="form-group"><label>Источник документа (обязательно для проверки)</label><input class="field" name="source" value="${esc(p.legal_source)}" placeholder="Например, DEMO: акт проверки № ..."/></div><div class="form-group"><label>ФИО / оператор</label><input class="field" name="reviewer" value="Аналитик МИО" required/></div><div class="modal-actions">${modalButton('Сохранить проверку')}</div></form>`);
}
function locationModal(id){
  const p=state.projects.find(x=>x.id===id);if(!p)return;
  showModal(`<form id="location-form" data-id="${id}"><h2>Уточнить геометку ЖК</h2><p>Укажите реальное расположение из проверенного источника. Нельзя использовать предположение ИИ вместо координат.</p><div class="form-grid"><div class="form-group"><label>Широта</label><input class="field" type="number" step="any" name="latitude" value="${p.latitude??''}" required placeholder="49.955"/></div><div class="form-group"><label>Долгота</label><input class="field" type="number" step="any" name="longitude" value="${p.longitude??''}" required placeholder="82.615"/></div></div><div class="form-group"><label>Источник координат (ссылка OSM / кадастр)</label><input class="field" type="text" name="source" value="${esc(p.coordinate_source||'')}" placeholder="https://www.openstreetmap.org/..." required/></div><div class="form-group"><label>Аналитик</label><input class="field" name="reviewer" value="Аналитик МИО" required/></div><div class="state-banner"><a href="${OSM_LINK}" target="_blank" rel="noopener noreferrer">Открыть карту Усть-Каменогорска ↗</a>. В OpenStreetMap нажмите правой кнопкой на нужную точку и выберите «Показать адрес», чтобы получить координаты.</div><div class="modal-actions">${modalButton('Сохранить метку')}</div></form>`);
}
function signalModal(id){
  showModal(`<form id="signal-form" data-id="${id}"><h2>Новая сигнальная карточка</h2><p>Фиксируется текущий риск, проверенные факторы и источники. Решение по материалам принимает человек.</p><div class="form-group"><label>Оператор</label><input class="field" name="author" value="Аналитик МИО" required/></div><div class="form-group"><label>Комментарий</label><textarea class="field" name="note" placeholder="Основание для создания сигнала..." style="min-height:85px"></textarea></div><div class="modal-actions">${modalButton('Сформировать')}</div></form>`);
}
function decisionModal(id,status){
  showModal(`<form id="decision-form" data-id="${id}" data-status="${status}"><h2>${status==='confirmed'?'Подтверждение сигнала':'Вернуть на доработку'}</h2><p>Решение будет сохранено с именем проверяющего и временем.</p><div class="form-group"><label>Аналитик</label><input class="field" name="author" value="Аналитик МИО" required/></div><div class="form-group"><label>Обоснование решения</label><textarea class="field" name="note" style="min-height:100px" required placeholder="Краткое пояснение"></textarea></div><div class="modal-actions">${modalButton('Сохранить решение')}</div></form>`);
}
async function reviewAd(id,status,projectId){
  const payload={status,reviewer:'Аналитик МИО'};
  if(projectId)payload.project_id=Number(projectId);
  await req(`/ads/${id}/review`,{method:'POST',body:JSON.stringify(payload)});
  toast(status==='accepted'?'Публикация подтверждена. Риск пересчитан.':'Публикация отклонена. Риск пересчитан.');
  await refresh();if(state.drawer)await openProject(state.drawer);
}
function addAdModal(){state.page='ads';state.preview=null;render();const el=$('#ad-text');el?.focus();}
async function analyze(){const input=$('#ad-text');const text=input?.value.trim()||'';if(text.length<5){toast('Введите текст длиной от 5 символов',true);return;} const a=await req('/analyze',{method:'POST',body:JSON.stringify({text})});state.preview=a;$('#analysis-result').innerHTML=renderAnalysis(a);toast('Объявление проанализировано. Проверьте фрагменты-основания.');}
async function saveAd(){
  const text=$('#ad-text')?.value.trim();if(!text||text.length<5)throw Error('Введите текст объявления');
  const payload={text,platform:$('#ad-platform').value,project_id:$('#ad-project').value?Number($('#ad-project').value):null,source_url:$('#ad-url').value.trim(),account:$('#ad-account').value.trim(),image_path:state.ocrPath};
  const ad=await req('/ads',{method:'POST',body:JSON.stringify(payload)});
  state.preview=null;state.ocrPath='';toast('Публикация №'+ad.id+' отправлена аналитику. Факторы пока не подтверждены.');await refresh();
  if(ad.project_id)await openProject(ad.project_id);
}
async function uploadOCR(file){const f=new FormData();f.append('file',file);toast('Распознаю текст на скриншоте…');const data=await req('/ocr',{method:'POST',body:f});state.ocrPath=data.image_path;$('#ad-text').value=data.text;toast(`OCR извлёк ${data.length} символов. Проверьте текст перед анализом.`);}
function adReviewModal(id){
  const a=state.ads.find(x=>x.id===id);if(!a)return;
  showModal(`<form id="ad-review-form" data-id="${id}"><h2>Проверить публикацию №${id}</h2><p>Источник: ${esc(a.platform)} · ИИ предлагает связь, окончательное решение за аналитиком.</p><div class="quote">${esc(a.text)}</div><div class="form-group" style="margin-top:14px"><label>Связанный жилой комплекс</label><select class="field" name="project_id"><option value="">Не установлен</option>${state.projects.map(p=>`<option value="${p.id}" ${p.id===a.project_id?'selected':''}>${esc(p.name)}</option>`).join('')}</select></div><div class="state-banner">${a.analysis?.payment?.found?'ИИ нашёл возможное предложение внесения денег.':'Прямого предложения внесения денег не выявлено.'} Подтвердите только при наличии достоверной фиксации публикации.</div><div class="modal-actions"><button class="btn" type="button" data-action="close-modal">Отмена</button><button class="btn btn-danger" type="button" data-review-choice="rejected">Отклонить</button><button class="btn btn-primary" type="button" data-review-choice="accepted">Подтвердить</button></div></form>`);
}
async function importAdsCSV(file){
 const form=new FormData();form.append('file',file);
 const result=await req('/import/ads.csv',{method:'POST',body:form});
 toast(`Импортировано объявлений: ${result.added}; без сопоставления: ${result.unmatched}; ошибок: ${result.errors.length}`);
 await refresh();
}
async function importCSV(file){
 const payload=new FormData();payload.append('file',file);
 const result=await req('/import/projects.csv',{method:'POST',body:payload});
 toast(`Импортировано ЖК: ${result.added}; пропущено: ${result.skipped}; ошибок: ${result.errors.length}`);
 await refresh();
}
function goPage(page){state.page=page;state.drawer=null;closeDrawer();closeModal();render();if(page==='sources')loadConnectors();window.scrollTo(0,0);}
document.addEventListener('click',async e=>{
  if(e.target.closest('#zone-refresh')){refreshMapZones(true);return;}
  if(e.target.closest('#zone-draw-toggle')){beginDraw();return;}
  if(e.target.closest('#zone-clear')){drawVertices=[];if(drawGuide)drawGuide.setLatLngs([]);return;}
  if(e.target.closest('#zone-finish')){try{await saveDrawnBoundary();}catch(err){showError(err);}return;}
  if(e.target.closest('[data-collect]')){try{await collectSource(e.target.closest('[data-collect]').dataset.collect);}catch(err){showError(err);}return;}
  if(e.target.closest('[data-action=registry-search]')){try{await searchPermits();}catch(err){showError(err);}return;}

  const target=e.target.closest('[data-page],[data-project],[data-action],[data-zone],[data-ad-filter],[data-ad-review],[data-accept],[data-reject],[data-signal],[data-review-choice],[data-map-zone],[data-map-focus]');
  if(!target){if(e.target.id==='drawer-backdrop')closeDrawer();if(e.target.id==='modal-backdrop')closeModal();return;}
  try{
    if(target.dataset.page){goPage(target.dataset.page);return;}
    if(target.dataset.mapZone){state.mapZone=target.dataset.mapZone;render();return;}
    if(target.dataset.mapFocus){const pid=Number(target.dataset.mapFocus);const marker=activeMapMarkers.get(pid);if(marker&&activeLeafletMap){activeLeafletMap.flyTo(marker.getLatLng(),15,{duration:0.6});marker.openPopup();}else{const p=state.projects.find(x=>x.id===pid);if(p&&locOk(p))window.open(osmAt(p),'_blank','noopener,noreferrer');}return;}
    if(target.dataset.project){await openProject(Number(target.dataset.project));return;}
    if(target.dataset.zone){state.zoneFilter=target.dataset.zone;render();return;}
    if(target.dataset.adFilter){state.adFilter=target.dataset.adFilter;render();return;}
    if(target.dataset.adReview){adReviewModal(Number(target.dataset.adReview));return;}
    if(target.dataset.accept){await reviewAd(Number(target.dataset.accept),'accepted',target.dataset.object);return;}
    if(target.dataset.reject){await reviewAd(Number(target.dataset.reject),'rejected',target.dataset.object);return;}
    if(target.dataset.signal){decisionModal(Number(target.dataset.signal),target.dataset.decision);return;}
    if(target.dataset.reviewChoice){const form=$('#ad-review-form');const id=Number(form.dataset.id);const projectId=Number(form.querySelector('[name=project_id]').value);await reviewAd(id,target.dataset.reviewChoice,projectId);closeModal();return;}
    switch(target.dataset.action){
      case 'new-ad':addAdModal();break;
      case 'map-search':state.mapQuery=$('#map-search')?.value.trim()||'';render();break;
      case 'load-uka-real':{const result=await req('/import/uka-real-snapshot',{method:'POST',body:'{}'});await refresh();toast(`Реальные данные: ${result.projects_added} ЖК, ${result.publications_added} публикаций`);break;}
      case 'load-kzhk-example':{const result=await req('/import/kzhk-uka-example',{method:'POST',body:'{}'});await refresh();toast(result.added?'Пример КЖК импортирован в реестр.':'Объект КЖК уже есть в реестре.');if(result.project?.id)await openProject(result.project.id);break;}
      case 'close-drawer':closeDrawer();break;
      case 'close-modal':closeModal();break;
      case 'analyze':await analyze();break;
      case 'save-ad':await saveAd();break;
      case 'edit-legal':legalModal(Number(target.dataset.id));break;
      case 'edit-location':locationModal(Number(target.dataset.id));break;
      case 'create-signal':signalModal(Number(target.dataset.id));break;
    }
  }catch(err){showError(err);}
});
document.addEventListener('submit',async e=>{
  const form=e.target;if(!['legal-form','location-form','signal-form','decision-form'].includes(form.id))return;
  e.preventDefault();
  const values=Object.fromEntries(new FormData(form));
  try{
    if(form.id==='legal-form'){await req(`/projects/${form.dataset.id}/legal`,{method:'POST',body:JSON.stringify(values)});toast('Юридический статус обновлён. Риск пересчитан.');}
    if(form.id==='location-form'){values.latitude=Number(values.latitude);values.longitude=Number(values.longitude);await req(`/projects/${form.dataset.id}/location`,{method:'POST',body:JSON.stringify(values)});toast('Координаты сохранены. ЖК появился на карте.');}
    if(form.id==='signal-form'){const s=await req(`/projects/${form.dataset.id}/signals`,{method:'POST',body:JSON.stringify(values)});toast('Сигнальная карточка №'+s.id+' создана. Доступна PDF-выгрузка.');}
    if(form.id==='decision-form'){values.status=form.dataset.status;await req(`/signals/${form.dataset.id}/decision`,{method:'POST',body:JSON.stringify(values)});toast('Решение аналитика зафиксировано.');}
    closeModal();await refresh();if(state.drawer)await openProject(state.drawer);
  }catch(err){showError(err);}
});
document.addEventListener('input',e=>{
  if(e.target.id==='map-search'&&e.inputType==='insertLineBreak'){state.mapQuery=e.target.value;render();return;}
  if(e.target.id==='project-search'){
    state.search=e.target.value;
    // Update only the table rows, preserving search focus.
    const next=new DOMParser().parseFromString(projectsView(),'text/html');
    const current=$('.project-table tbody'),newBody=next.querySelector('.project-table tbody');
    if(current&&newBody) current.innerHTML=newBody.innerHTML;
  }
});
document.addEventListener('change',async e=>{
  if(e.target.id==='layer-osm'){state.showOSMZones=e.target.checked;refreshMapZones();return;}
  if(e.target.id==='layer-project'){state.showProjectZones=e.target.checked;refreshMapZones();return;}
  if(e.target.id==='permit-csv'&&e.target.files?.[0]){try{await uploadPermitCSV(e.target.files[0]);}catch(err){showError(err);}return;}
if(e.target.id==='ads-csv-upload'&&e.target.files?.[0]){try{await importAdsCSV(e.target.files[0]);}catch(err){showError(err);}} if(e.target.id==='ocr-upload'&&e.target.files?.[0]){try{await uploadOCR(e.target.files[0]);}catch(err){showError(err);}} if(e.target.id==='registry-upload'&&e.target.files?.[0]){try{await importCSV(e.target.files[0]);}catch(err){showError(err);}}});
$('#today').textContent=new Intl.DateTimeFormat('ru-RU',{day:'numeric',month:'long',year:'numeric'}).format(new Date());
refresh().catch(err=>{$('#main-content').innerHTML=`<div class="card empty-help">Не удалось подключиться к API. Перезапустите сервер и обновите страницу.<p>${esc(err.message)}</p></div>`;showError(err);});
