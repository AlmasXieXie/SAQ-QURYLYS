'use strict';
/* Evidence-first map: only API unified buildings; never reads /api/projects demo. */
const api='/api/unified';
const $=(s)=>document.querySelector(s);
const escapeHTML=(s)=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const safeURL=(s)=>/^https:\/\//.test(s||'')?escapeHTML(s):'#';
const htmlLink=(u,label)=>/^https:\/\//.test(u||'')?`<a href="${safeURL(u)}" target="_blank" rel="noopener noreferrer">${escapeHTML(label)} ↗</a>`:'';
const state={buildings:[],query:'',stage:'construction',selected:null,map:null,markers:new Map(),geocodeStarted:false,geocodeTimer:null,zonesLayer:null,zonesLoaded:false};
const stageNames={construction:'Строится',commissioned:'Сдан',unknown:'Неизвестно'};
const isLocated=b=>Number.isFinite(b.latitude)&&Number.isFinite(b.longitude)&&b.latitude>=49.72&&b.latitude<=50.22&&b.longitude>=82.24&&b.longitude<=82.98;
const stageClass=b=>['construction','commissioned'].includes(b.stage_reported)?b.stage_reported:'unknown';
const badge=(s,label)=>`<span class="pill ${escapeHTML(s)}">${escapeHTML(label)}</span>`;
const linkRow=(p)=>Object.entries(p.map_links||{}).map(([key,url])=>htmlLink(url,key==='yandex'?'Яндекс Карты':key==='google'?'Google Maps':key==='2gis'?'2ГИС':'OSM')).join('');
async function request(path,options={}){
 const res=await fetch(api+path,{...options}); if(!res.ok){let reason='HTTP '+res.status;try{let o=await res.json();reason=o.detail||reason}catch{}throw Error(reason)}return res.json();
}
function filtered(){return state.buildings.filter(b=> (state.stage==='all'||b.stage_reported===state.stage)&&[b.name,b.address,b.developer_label,b.company?.bin||'',b.profile?.brand_bin||''].join(' ').toLocaleLowerCase().includes(state.query));}
function allInfo(){const x=state.buildings;$('#stat-total').textContent=x.length;$('#stat-mapped').textContent=x.filter(isLocated).length;$('#stat-construction').textContent=x.filter(b=>b.stage_reported==='construction').length;$('#stat-unmapped').textContent=x.filter(b=>!isLocated(b)).length;}
function renderList(){const x=filtered();$('#count-label').textContent=`${x.length} объектов · ${x.filter(isLocated).length} с координатами`;
 $('#items').innerHTML=x.length?x.map(b=>`<article class="item ${state.selected===b.id?'selected':''}" data-select="${b.id}"><div class="item-name">${escapeHTML(b.name)}</div><div class="item-address">${escapeHTML(b.address)} · ${escapeHTML(b.developer_label)}</div><div class="item-meta">${badge(stageClass(b),stageNames[stageClass(b)])}${badge('real',isLocated(b)?(b.profile?.location_precision==='confirmed_by_analyst'?'⌖ Проверено аналитиком':'⌖ Адресная точка'):'⊘ Адрес есть, точка уточняется')}</div><div class="item-links">${htmlLink(b.profile?.map_links?.['2gis'],'2ГИС')}${htmlLink(b.profile?.map_links?.yandex,'Яндекс')}${htmlLink(b.profile?.map_links?.google,'Google')}${htmlLink(b.evidence?.[0]?.url,'Источник')}</div></article>`).join(''):'<div class="placeholder">Объекты не найдены</div>';
 }
function mapPopup(b){return `<div class="popup"><strong>${escapeHTML(b.name)}</strong><p>${escapeHTML(b.address)}<br>${escapeHTML(b.developer_label)}</p>${badge(stageClass(b),stageNames[stageClass(b)])}<p>${escapeHTML(b.profile?.coordinates_note||'')}</p><div class="links">${htmlLink(b.profile?.map_links?.['2gis'],'2ГИС')}${htmlLink(b.profile?.map_links?.yandex,'Яндекс')}${htmlLink(b.profile?.map_links?.google,'Google')}</div><button type="button" onclick="window.openBuilding(${Number(b.id)})">Подробная карточка ↗</button></div>`;}
function markerHtml(b){return `<div class="pin-shape ${stageClass(b)}"><span>⌂</span></div>`;}
function renderMap(){if(!state.map)return;
 state.markers.forEach(m=>state.map.removeLayer(m));state.markers.clear();
 const x=filtered().filter(isLocated);
 for(const b of x){const icon=L.divIcon({className:'geo-pin',html:markerHtml(b),iconSize:[31,34],iconAnchor:[13,28]});const m=L.marker([b.latitude,b.longitude],{icon}).addTo(state.map).bindPopup(mapPopup(b),{maxWidth:310});state.markers.set(b.id,m);}
 }
function focus(id){const b=state.buildings.find(b=>b.id===id);if(!b)return;
 state.selected=id;renderList();
 if(isLocated(b)&&state.map){state.map.setView([b.latitude,b.longitude],16,{animate:true});state.markers.get(id)?.openPopup();}
 else openBuilding(id);
 }
const plain=(value)=>escapeHTML(value||'—');
function openBuilding(id){const b=state.buildings.find(x=>x.id===id);if(!b)return;state.selected=id;renderList();
 const p=b.profile||{};const permits=(b.authorizations||[]).map(a=>`<div class="ref"><b>${plain(a.type)}</b> · ${plain(a.number)} <span class="muted">${plain(a.date)}</span><div>${plain(a.status)} · ${htmlLink(a.source_url,'Документ')}<br><span class="muted">${plain(a.notes)}</span></div></div>`).join('')||'<p>Сведения о документах отсутствуют. Это не доказывает отсутствия разрешения.</p>';
 const sources=(b.evidence||[]).map(e=>`<div class="ref">${htmlLink(e.url,e.source)} <span class="muted">· ${plain(e.level)} · ${plain(e.collected_on)}</span><div class="muted">${plain(e.description)}</div></div>`).join('');
 const extra=(p.source_links||[]).map(([title,url])=>`<div class="ref">${htmlLink(url,title)}</div>`).join('');
 const entities=(p.related_entities||[]).map(e=>`<div class="ref"><b>${plain(e.name)}</b> · ${plain(e.role)} ${e.bin?'· БИН '+plain(e.bin):''} ${htmlLink(e.url,'Источник')}</div>`).join('');
 const warnings=[...(p.notes||[]),...(p.alternative_addresses||[]).map(a=>'Другой адрес источника: '+a)];
 $('#modal-body').innerHTML=`<div class="eyebrow">РЕАЛЬНЫЙ РЕЕСТР · ЗАПИСЬ #${Number(id)}</div><h2>${plain(b.name)}</h2><p>${plain(b.address)}<br>${plain(b.developer_label)}</p>${badge(stageClass(b),stageNames[stageClass(b)])} ${badge('real',isLocated(b)?plain(p.location_precision):'Геопривязка не выполнена')}<div class="linkrow">${linkRow(p)}</div>
  ${p.developer_website||p.developer_instagram||p.brand_bin?`<h3>Девелопер и контакты</h3><div class="ref">${htmlLink(p.developer_website,'Официальный сайт')} ${htmlLink(p.developer_instagram,'Instagram')} ${p.brand_bin?'БИН бренда/юрлица: <b>'+plain(p.brand_bin)+'</b> '+htmlLink(p.brand_bin_url,'Подтверждение'):''}<div class="muted">БИН бренда не равен доказательству, что именно это юрлицо — уполномоченный застройщик объекта.</div></div>`:''}
  ${entities?'<h3>Юридические роли</h3>'+entities:''}${warnings.map(s=>`<p class="warning">${plain(s)}</p>`).join('')}<h3>Разрешительные сведения</h3>${permits}<h3>Первоисточники</h3>${sources}${extra}
  <div class="manual"><h3 style="margin-top:0">Точная геопривязка с подтверждением</h3><p>${plain(p.coordinates_note)}</p><small>Чтобы отметить место именно этого ЖК, получи координаты из 2ГИС/Яндекс/Google, приложи прямую ссылку и укажи проверяющего. Эта операция не меняет юридический риск.</small><input type="number" step="any" id="manual-lat" placeholder="Широта (49.x)" value="${isLocated(b)?b.latitude:''}"/><input type="number" step="any" id="manual-lon" placeholder="Долгота (82.x)" value="${isLocated(b)?b.longitude:''}"/><input id="manual-source" type="url" placeholder="https://... ссылка на объект в карте"/><input id="manual-reviewer" value="Аналитик МИО" placeholder="Кто проверил"/><button class="btn action" id="manual-submit" data-id="${Number(b.id)}">Сохранить проверенную точку</button><div id="manual-message" class="muted"></div></div>`;
 $('#modal').hidden=false;
 $('#manual-submit').onclick=async()=>{const values={latitude:Number($('#manual-lat').value),longitude:Number($('#manual-lon').value),source_url:$('#manual-source').value.trim(),reviewer:$('#manual-reviewer').value.trim()};const message=$('#manual-message');
 if(!$('#manual-lat').value||!$('#manual-lon').value){message.textContent='Заполни обе координаты.';return;}
 try{const updated=await request(`/buildings/${id}/coordinates`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(values)});state.buildings=state.buildings.map(x=>x.id===id?updated:x);renderList();renderMap();allInfo();message.textContent='Сохранено, геометка появилась на карте.';}catch(e){message.textContent=e.message;}
 };
}
window.openBuilding=openBuilding;
function mapSetup(){if(!window.L){$('#map-fallback').hidden=false;return;}
 const map=L.map('map',{scrollWheelZoom:true,zoomControl:false,preferCanvas:true}).setView([49.955,82.615],12);state.map=map;
 L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,minZoom:9,attribution:'© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap contributors</a>'}).addTo(map);
 L.control.zoom({position:'bottomright'}).addTo(map);
 L.control.scale({imperial:false,position:'bottomleft'}).addTo(map);
 window.setTimeout(()=>map.invalidateSize(),150);
 }
// Optional OSM polygons: independent from real building markers; never linked to a developer automatically.
async function toggleConstructionZones(){
 const enabled=$('#zones-toggle').checked;
 if(!state.map){return;}
 if(!enabled){if(state.zonesLayer)state.map.removeLayer(state.zonesLayer);return;}
 if(state.zonesLayer){state.zonesLayer.addTo(state.map);return;}
 const n=$('#map-progress');n.hidden=false;n.classList.remove('error');n.textContent='Загрузка реальных контуров строительства OSM (до 25 секунд)…';
 try{
  const res=await fetch('/api/map/construction-zones');
  if(!res.ok)throw Error('Источник OSM не ответил: '+res.status);
  const fc=await res.json();
  const features=fc.features||[];
  if(!features.length){n.textContent='В OSM не обнаружены доступные строительные полигоны. Это не означает отсутствие строек. '+(fc.note||'');return;}
  state.zonesLayer=L.geoJSON(fc,{style:()=>({color:'#b9835e',weight:1.7,fillColor:'#dda06e',fillOpacity:0.2}),
    onEachFeature:(f,layer)=>{const props=f.properties||{};layer.bindPopup(`<b>Строительная территория OSM</b><p>Не сопоставлена с конкретным ЖК, не кадастровая граница.</p>${htmlLink(props.source_url,'Первоначальный контур')}`)}});
  if($('#zones-toggle').checked)state.zonesLayer.addTo(state.map);
  n.textContent=`Загружено ${features.length} участков OSM. Важно: их связь с конкретными ЖК не установлена.`;
 }catch(e){n.classList.add('error');n.textContent='Не удалось загрузить полигоны: '+e.message+'; метки ЖК остаются доступны.';}
}
async function refresh(){try{state.buildings=await request('/construction-catalog');allInfo();renderList();renderMap();}
 catch(e){$('#items').innerHTML=`<div class="placeholder">Не удалось подключиться к API: ${plain(e.message)}<br>Запустите сервер через RUN_WINDOWS.bat.</div>`;}}
async function pollGeo(){try{const s=await request('/geocode/status');const n=$('#map-progress');const btn=$('#geo-start');
 btn.disabled=Boolean(s.running||s.scheduled);
 if(s.running||s.scheduled){n.hidden=false;n.classList.remove('error');n.textContent=`Поиск точных адресов: ${s.processed}/${s.total} · найдено ${s.resolved} · не подтверждено ${s.unresolved}. Может занять до минуты.`;
   await refresh();state.geocodeTimer=setTimeout(pollGeo,1800);}
 else{if(state.geocodeStarted){n.hidden=false;n.classList.toggle('error',!!s.error);n.textContent=`Геопривязка: обработано ${s.processed}/${s.total} адресов; добавлено точных точек ${s.resolved}, не найдены или спорны ${s.unresolved}. ${s.error||'Остальные адреса оставлены без меток.'}`;state.geocodeStarted=false;await refresh();}}
 }catch(e){const n=$('#map-progress');n.hidden=false;n.classList.add('error');n.textContent=e.message;$('#geo-start').disabled=false;}}
async function startGeo(){try{state.geocodeStarted=true;await request('/geocode/start',{method:'POST'});$('#map-progress').hidden=false;$('#map-progress').textContent='Запуск геокодирования…';pollGeo();}catch(e){$('#map-progress').hidden=false;$('#map-progress').textContent=e.message;state.geocodeStarted=false;}}
async function init(){const embedded=new URLSearchParams(location.search).has('embed');if(embedded){document.body.classList.add('embed');}
 mapSetup();await refresh();$('#search').addEventListener('input',e=>{state.query=e.target.value.toLocaleLowerCase();renderList();renderMap();});
 $('#stage').addEventListener('change',e=>{state.stage=e.target.value;renderList();renderMap();});
 $('#items').addEventListener('click',e=>{if(e.target.closest('a'))return;const row=e.target.closest('[data-select]');if(row)focus(Number(row.dataset.select));});
 $('#reload').onclick=refresh;$('#zones-toggle').onchange=toggleConstructionZones;$('#geo-start').onclick=startGeo;$('#modal-close').onclick=()=>$('#modal').hidden=true;$('#modal').addEventListener('click',e=>{if(e.target===$('#modal'))$('#modal').hidden=true;});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')$('#modal').hidden=true;});
 const s=await request('/geocode/status').catch(()=>null);
 if(s?.running||s?.scheduled){state.geocodeStarted=true;pollGeo();}
 else if(!embedded&&state.buildings.some(b=>!isLocated(b))){
   // One automatic pass per browser session to avoid hammering public Nominatim.
   // The database caches exact matches and a manual retry remains possible.
   let attempted=false;
   try{attempted=sessionStorage.getItem('saq_geo_v7_attempted')==='1';}catch{}
   if(!attempted){try{sessionStorage.setItem('saq_geo_v7_attempted','1');}catch{}startGeo();}
 }

 }
// Wait for deferred CDN fallback before deciding whether Leaflet is unavailable.
if (document.readyState === 'complete') init();
else window.addEventListener('load', init, {once:true});
