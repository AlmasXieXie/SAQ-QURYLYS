'use strict';
const $=q=>document.querySelector(q);
const E=s=>String(s??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
let last=null;
const date=()=>new Date().toLocaleString('ru-RU');
$('#current-time').textContent=date();
const warn=t=>{$('#error').textContent=t;$('#error').hidden=false};
const resetError=()=>{$('#error').hidden=true;$('#error').textContent=''};
const busy=v=>{$('#busy').hidden=!v;document.querySelectorAll('button.primary').forEach(x=>x.disabled=v);resetError()};
async function request(path,init){const r=await fetch('/api/v12/'+path,init);let data;try{data=await r.json()}catch{throw Error('Некорректный ответ сервера (HTTP '+r.status+')')}if(!r.ok)throw Error(typeof data.detail==='string'?data.detail:JSON.stringify(data.detail));return data}
const json=data=>({method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
const link=(url,label)=>{try{let u=new URL(url);if(['https:','http:'].includes(u.protocol))return `<a class="result-link" href="${E(u.toString())}" rel="noopener noreferrer" target="_blank">${E(label)} ↗</a>`}catch{}return '—'};
const labels={'documents_require_check':'Есть сведения о документах — проверить','no_recorded_basis':'В базе нет подтверждения — проверить','project_not_identified':'ЖК не найден в реестре','ambiguous_project':'Неоднозначное совпадение','no_payment_signal':'Нет прямых слов о привлечении денег'};
const statusColor={documents_require_check:'neutral',no_recorded_basis:'warn',project_not_identified:'warn',ambiguous_project:'warn',no_payment_signal:'neutral'};
const statuses={reported_third_party:'Заявлено в коммерческом каталоге — проверить в госреестре',reported_official:'Сведения с официального портала — проверить актуальность',official_dataset_unmatched:'Запись официального набора, не сопоставлена с ЖК',imported_needs_verification:'Импортированный документ — сверить оригинал'};
const authTypes={mio_equity_permit:'Разрешение МИО на привлечение денег дольщиков',kzhk_guarantee:'Гарантия КЖК',bank_participation:'Участие банка'};
function draw(data){last=data;$('#current-time').textContent=date();
 if(data.processed){$('#result').innerHTML=`<div class="result-section"><span class="pill neutral">Обработано: ${data.count} · сохранено: ${data.saved||0}</span><p class="muted">${E(data.note)}</p></div><div style="overflow-x:auto"><table class="rss-table"><thead><tr><th>Заголовок</th><th>ЖК</th><th>Статус</th><th>Источник</th></tr></thead><tbody>${data.processed.map(x=>`<tr><td>${E(x.title)}</td><td>${E(x.project||'Не установлен')}</td><td>${E(labels[x.status]||x.status)}</td><td>${link(x.url,'Открыть')}</td></tr>`).join('')}</tbody></table></div>`;return}
 const p=data.project,dev=p?.developer||{},ds=data.document_evidence||[],kw=data.keywords||[];
 $('#result').innerHTML=`<div class="result-section"><span class="pill ${statusColor[data.status]||'neutral'}">${E(labels[data.status]||data.status)}</span><p class="muted">${E(data.explanation)}</p><p class="muted"><b>Режим:</b> ${data.selection_mode==='manual'?'объект выбран аналитиком':'автоматическое сопоставление'}</p></div>
 <div class="result-section"><h3>Установленный объект</h3>${p?`<div class="result-title">${E(p.name)}</div><div class="kv"><span>Застройщик</span><b>${E(dev.name||'Не установлен')}</b></div><div class="kv"><span>Адрес</span><b>${E(p.address)}</b></div><div class="kv"><span>БИН по источнику</span><b>${E(dev.bin||dev.registered_bin||'Не подтверждён')}</b></div><div class="kv"><span>Стадия</span>${E(p.stage_reported||'Неизвестна')} (по каталогу)</div>${dev.site?`<p>${link(dev.site,'Сайт компании')}</p>`:''}<p><a class="result-link" href="/geo" target="_blank">Открыть карту ↗</a></p>`:'<p class="muted">Точное совпадение отсутствует. Можно выбрать ЖК из предложенных совпадений.</p>'}</div>
 ${data.candidates?.length?`<div class="result-section"><h3>Возможные совпадения</h3>${data.candidates.map(c=>`<div class="candidate">${E(c.name)} · ${c.score}% <button data-select="${Number(c.id)}">Проверить этот ЖК</button></div>`).join('')}</div>`:''}
 <div class="result-section"><h3>Признаки в рекламе</h3><div class="keywords">${kw.length?kw.map(k=>`<span>${E(k)}</span>`).join(''):'<span style="background:#edf4f9;color:#60798b">Прямые слова о платеже не найдены</span>'}</div><p class="muted">${data.construction_language?'Есть терминология строительства/новостроек.':'Строительная тематика может быть не выражена явно.'}</p></div>
 <div class="result-section"><h3>Правовые основания в совокупном реестре</h3>${ds.length?ds.map(d=>`<div class="doc"><b>${E(authTypes[d.type]||d.type)}</b><small>Номер: ${E(d.number||'Не указан')} · дата: ${E(d.date||'не указана')}</small><p class="muted">Статус записи: ${E(statuses[d.status_in_registry]||d.status_in_registry||'не установлен')} — срок действия, юридическое лицо и корпус нужно сверить</p>${link(d.source_url,'Первичный источник записи')}</div>`).join(''):'<p class="muted">Привязанных записей о праве привлекать деньги дольщиков в нашей базе нет. Это не доказательство отсутствия документов.</p>'}<p class="note">${E(data.advice)}</p></div>
 <div class="result-section"><h3>Извлечённый текст ${data.ocr_used?'(OCR)':''}</h3><div class="recognized">${E(data.text)}</div><button id="copy-text" class="primary" type="button">Скопировать текст</button>${data.source_url&&data.source_url.startsWith('http')?` <button id="send-monitor" class="primary" type="button">Сохранить в мониторинг →</button>`:''}${data.source_url?`<p>${link(data.source_url,'Открыть объявление')}</p>`:''}${data.image_url?`<p>${link(data.image_url,'Ссылка на изображение')}</p>`:''}<p class="muted">${E(data.disclaimer)}</p></div>`;
 document.querySelectorAll('[data-select]').forEach(b=>b.onclick=async()=>{busy(true);try{draw(await request('verify/text',json({text:last.text,source_url:last.source_url||'',selected_project_id:Number(b.dataset.select)})))}catch(err){warn(err.message)}finally{busy(false)}});
 $('#copy-text').onclick=()=>navigator.clipboard?.writeText(data.text);
 const save=$('#send-monitor');if(save)save.onclick=async()=>{try{const u=new URL(data.source_url);if(!['https:','http:'].includes(u.protocol))throw Error('Нужен публичный HTTP(S)-адрес');const platform=u.hostname.includes('olx')?'olx':u.hostname.includes('krisha')?'krisha':u.hostname.includes('instagram')?'instagram':'website';const r=await fetch('/api/v8/ads',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({building_id:data.project?.id||null,url:data.source_url,text:data.text,platform})});const j=await r.json();if(!r.ok)throw Error(j.detail||'Не удалось сохранить');save.textContent='✓ Сохранено для проверки';save.disabled=true}catch(err){warn(err.message)}};
}
async function doCheck(promise){busy(true);try{draw(await promise())}catch(err){warn(err.message)}finally{busy(false)}}
document.querySelectorAll('[data-tab]').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('[data-tab]').forEach(x=>x.classList.toggle('active',x===btn));document.querySelectorAll('[data-panel]').forEach(x=>x.hidden=x.dataset.panel!==btn.dataset.tab)}));
$('#photo').onchange=e=>{let f=e.target.files[0],preview=$('#preview');if(!f){preview.textContent='Изображение не выбрано';return}if(!['image/jpeg','image/png','image/webp'].includes(f.type)){warn('Нужно изображение JPG/PNG/WEBP');return}let u=URL.createObjectURL(f);preview.innerHTML='';let i=document.createElement('img');i.onload=()=>URL.revokeObjectURL(u);i.src=u;preview.append(i)};
$('#form-screenshot').onsubmit=e=>{e.preventDefault();const f=$('#photo').files[0];if(!f)return;const d=new FormData();d.append('file',f);d.append('extra_text',$('#extra').value);d.append('source_url',$('#photo-url').value.trim());doCheck(()=>request('verify/screenshot',{method:'POST',body:d}))};
$('#form-url').onsubmit=e=>{e.preventDefault();doCheck(()=>request('verify/url',json({url:$('#link').value.trim(),extra_text:$('#url-text').value.trim()})))};
$('#form-text').onsubmit=e=>{e.preventDefault();doCheck(()=>request('verify/text',json({text:$('#text').value.trim(),source_url:$('#text-link').value.trim()})))};
$('#form-rss').onsubmit=e=>{e.preventDefault();const f=$('#rss').files[0];if(!f)return;const d=new FormData();d.append('file',f);d.append('save',$('#rss-save').checked?'true':'false');doCheck(()=>request('rss/import',{method:'POST',body:d}))};

// v13 autonomous ad scanner (manual screenshots remain as an optional fallback).
async function v13RefreshVerify(){
 try{
  const [s,items]=await Promise.all([
    fetch('/api/v13/monitor/status').then(r=>r.json()),
    fetch('/api/v13/monitor/findings?limit=25').then(r=>r.json())]);
  const summary=$('#v13-status');if(!summary)return;
  summary.textContent=`${s.running?'Поиск выполняется':'Фоновый мониторинг '+(s.enabled?'включён':'отключён')} · найдено ${s.total_saved}, на проверке ${s.total_pending}, источников успешно ${s.feeds_checked}, ошибок ${s.feeds_failed}. `+(s.last_error||'');
  $('#v13-found').innerHTML=items.length?items.map(f=>`<div class="result-section" style="padding:8px 0"><b>${E(f.project_name||'ЖК не установлен')}</b> · ${E(f.assessment)} · ${link(f.url,'Объявление')}<p class="muted">${E(f.title)} ${f.ocr_used==='yes'?'· OCR':''}</p></div>`).join(''):'<p class="muted">Найденных публикаций пока нет. Первый автоматический проход начнётся после запуска сервера при наличии интернета.</p>';
 }catch(e){const n=$('#v13-status');if(n)n.textContent='Мониторинг: '+e.message;}
}
$('#v13-run').onclick=async()=>{const b=$('#v13-run');b.disabled=true;try{const r=await fetch('/api/v13/monitor/start',{method:'POST'});if(!r.ok)throw Error('HTTP '+r.status);await v13RefreshVerify()}catch(e){warn(e.message)}finally{b.disabled=false}};
v13RefreshVerify();setInterval(v13RefreshVerify,14000);
