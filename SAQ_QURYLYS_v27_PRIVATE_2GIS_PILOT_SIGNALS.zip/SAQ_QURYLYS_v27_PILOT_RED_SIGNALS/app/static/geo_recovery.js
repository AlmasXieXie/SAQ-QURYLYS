'use strict';
/* Extra browser geocoder, independent of Docker's outbound network.
 * Only exact street/house or unique named project features are persisted.
 * Never create artificial city coordinates. Never store a key in this file.
 */
(function(){
 const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 let busy=false;
 async function sourceJSON(url,ms=9500){
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),ms);
  try{const r=await fetch(url,{signal:controller.signal,credentials:'omit',redirect:'error',cache:'no-store'});
   if(!r.ok)throw Error('HTTP '+r.status);
   return await r.json();
  }finally{clearTimeout(timer)}
 }
 async function candidate(p,source,data){
  try{const r=await fetch('/api/geo/browser/candidate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({building_id:p.id,source,data})});
   if(r.ok){const a=await r.json();if(a.saved)return a;}
  }catch(e){}return null;
 }
 const enc=encodeURIComponent;
 async function attempt2gis(p,key){
  if(!key)return {found:null,error:'Ключ 2ГИС не установлен'};
  const api='https://catalog.api.2gis.com/3.0/items';
  const queries=[p.name+' Усть-Каменогорск'];
  if(p.address&&!/без номера|позици|\s\/\s/i.test(p.address))queries.push(p.address);
  for(const q of queries){
   const url=api+'?q='+enc(q)+'&page_size=8&fields='+enc('items.point,items.geometry.centroid,items.address')+'&key='+enc(key);
   let payload;try{payload=await sourceJSON(url,9500)}catch(e){return {found:null,error:'2ГИС: '+e.message}}
   const items=payload?.result?.items||[];
   if(payload?.meta?.code&&payload.meta.code!==200)return {found:null,error:'2ГИС: ответ '+payload.meta.code};
   for(const item of items){const found=await candidate(p,'2gis',item);if(found)return {found,error:null}}
   await sleep(270);
  }
  return {found:null,error:null}
 }
 async function attemptPhoton(p){
  const queries=[p.name+' Усть-Каменогорск'];
  if(p.address&&!/без номера|позици/i.test(p.address))queries.unshift(p.address+' Казахстан');
  for(const q of queries){
   let payload;try{payload=await sourceJSON('https://photon.komoot.io/api/?q='+enc(q)+'&limit=8&bbox=82.24,49.72,82.98,50.22',10500)}
   catch(e){return {found:null,error:'OSM Photon: '+e.message}}
   for(const f of payload.features||[]){const found=await candidate(p,'photon',f);if(found)return {found,error:null}}
  }
  return {found:null,error:null}
 }
 async function attemptNominatim(p){
  if(!p.address||/без номера|позици/i.test(p.address))return {found:null,error:null};
  let payload;try{payload=await sourceJSON('https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=5&countrycodes=kz&q='+enc(p.address),11500)}
  catch(e){return {found:null,error:'OSM Nominatim: '+e.message}}
  for(const f of payload||[]){const found=await candidate(p,'nominatim',f);if(found)return {found,error:null}}
  return {found:null,error:null}
 }
 async function start(options){
  if(busy)return;busy=true;
  const items=(options.items||[]).filter(x=>x.latitude==null||x.longitude==null);
  const errors=[];let count=0,found=0;
  const update=()=>options.onProgress?.({count,found,total:items.length,errors:[...new Set(errors)].slice(0,5),finished:false});
  update();
  let twoGIS=!!options.key,photon=true,nominatim=true;
  try{for(const p of items){
   if(options.cancelled?.())break;
   let result=null;
   if(twoGIS){const out=await attempt2gis(p,options.key);result=out.found;
    if(out.error){errors.push(out.error);twoGIS=false}}
   if(!result&&photon){const out=await attemptPhoton(p);result=out.found;
    if(out.error){errors.push(out.error);photon=false}}
   if(!result&&nominatim){const out=await attemptNominatim(p);result=out.found;
    if(out.error){errors.push(out.error);nominatim=false}}
   if(result){found++;options.onSaved?.(p,result)}
   count++;update();
   await sleep(1150); // Public OSM services should never be hit in rapid bursts.
   if(!twoGIS&&!photon&&!nominatim)break;
  }}finally{busy=false;options.onProgress?.({count,found,total:items.length,errors:[...new Set(errors)].slice(0,5),finished:true})}
 }
 window.SAQGeoRecovery={start, isBusy:()=>busy};
})();
