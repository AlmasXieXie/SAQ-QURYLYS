'use strict';
/* v9 geospatial overlay. Loaded AFTER v8.js, before the window load event.
   No synthetic building footprints or automatic ЖК ↔ OSM assignments. */
const v9 = {
  links:[], zones:[], status:'ожидаем данные', loading:false, loadDone:false,
  mode:'', projectId:null, hookedMap:null, refreshOsm:false, lastPolygonClick:0,
  includeSites:true, includeUnlinked:true, hasNativeStyle:false
};
const geometryLinks = id=>v9.links.filter(x=>x.building_id===id);
const featureLinks = (provider,id)=>v9.links.find(x=>x.provider===provider&&x.feature_id===String(id));
const geoCentroid = g=>{
  const r=g?.coordinates?.[0];if(!Array.isArray(r)||r.length<4)return null;
  const pts=r.slice(0,-1);return [pts.reduce((x,p)=>x+p[0],0)/pts.length,pts.reduce((x,p)=>x+p[1],0)/pts.length];
};
const zoneLabel = p=>p.classification==='building_abandoned'?'Заброшенное здание по OSM':p.classification==='building_construction'?'Строящееся здание по OSM':'Строительная территория по OSM';
function v9Banner(){
  const c=v9.zones.filter(f=>f.properties.classification!=='construction_landuse').length;
  return `<div class="shape-legend"><span class="shape-key linked"></span>Связано с ЖК (${v9.links.length}) <span class="shape-key other"></span>Стройобъекты OSM (${c}) <span class="shape-key site"></span>Участки строительства (${v9.zones.length-c})</div>`;
}
const v8MapView=mapView;
mapView=function(){
 let html=v8MapView();
 html=html.replace('Карта реальных ЖК','Здания и строительные площадки');
 html=html.replace('Все 38 записей доступны в списке. Маркеры появляются только после сопоставления с конкретным адресом 2ГИС. Никаких демонстрационных точек.',
  'Нажимай на здание 2ГИС: приложение попытается открыть соответствующий ЖК по точному адресу. Автоматически сопоставленные здания подсвечиваются; спорные адреса не связываются.');
 html=html.replace('⌖ Найти адреса через 2ГИС','Уточнить адреса (2ГИС)');
 html=html.replace('<button class="btn" id="refresh-points">↻ Обновить</button>',
  '<button class="btn" id="refresh-points">↻ Обновить</button><button class="btn blue" id="refresh-osm">▱ Загрузить контуры OSM</button><button class="btn blue" id="v10-retry">Привязать здания автоматически</button>');
 html=html.replace('<div id="map-projects" class="map-results"></div>',
  `<div class="layer-controls"><label><input type="checkbox" id="toggle-unlinked" checked> Неизвестные стройобъекты</label><label><input type="checkbox" id="toggle-sites" checked> Строительные территории</label></div><div id="map-projects" class="map-results"></div><div class="osm-section"><b>Другие объекты незавершённого строительства</b><small id="osm-count">Загрузка…</small><div id="osm-list"></div></div>`);
 html=html.replace('<div id="map-message" class="map-error" hidden></div>',
  '<div class="shape-overlay" id="shape-overlay">'+v9Banner()+'</div><div id="v10-link-status" class="map-progress" role="status">Готовим автоматическую привязку 2ГИС…</div><div id="link-action" class="link-action" hidden></div><div id="map-message" class="map-error" hidden></div>');
 html=html.replace('<div class="note warn" style="margin-top:14px">Маркер — центр найденного адресного объекта. Контур площадки, граница земельного участка, документы на конкретный блок и фактическая готовность требуют отдельной проверки. Если Geocoder API не включён в ключ, карта 2ГИС всё равно может загружаться, но точки нужно подтверждать вручную.</div>',
  '<div class="note warn" style="margin-top:14px"><b>Точность карты:</b> контур OSM означает, что кто-то обозначил этот объект как строящийся или заброшенный; это не подтверждение текущего состояния, прав на землю и законности строительства. Автоматическая связь с ЖК допускается только при единственном совпадении номера дома и улицы в 2ГИС. Такая привязка ещё не означает кадастровую проверку или доказательство фактического строительства.</div>');
 return html;
};
const v8AnalyticsView=analyticsView;
analyticsView=function(){
 let html=v8AnalyticsView();
 html=html.replace('Нанесены на карту','Связано с корпусами');
 html=html.replace('По проверенному адресу, не контуру','Точные адресные совпадения и ручные привязки');
 const linkedBuildings=new Set(v9.links.map(x=>x.building_id)).size;
 html=html.replace(/(<div class="stat-top"><span>Связано с корпусами<\/span>[\s\S]*?<div class="stat-value">)\d+(<\/div>)/,(_,before,after)=>before+linkedBuildings+after);
 html=html.replace('По коммерческому каталогу Krisha','Каталог Krisha, не госреестр');
 return html;
};
const v8Details=details;
details=function(id){
 v8Details(id);
 const l=geometryLinks(id);
 const node=$('#drawer-body');if(!node)return;
 const block=`<section class="detail-block"><h3>Геометрия и корпуса · ${l.length} привязок</h3>`+
 (l.length?l.map(x=>`<div class="detail-source"><b>${x.provider==='2gis'?'Здание на векторной карте 2ГИС':'Контур из OSM'}</b><br>ID: ${E(x.feature_id)} · ${E(x.linked_by)}<br><small>${x.association_method?.startsWith('auto_')?'Автоматическое совпадение точного адреса; нуждается в проверке корпуса':'Визуальная привязка аналитика; не кадастровое подтверждение'}</small><br>${external(x.source_url,'Картографический источник')} <button class="btn sm" data-unlink="${x.id}">Отвязать</button></div>`).join(''):'<p class="small">Точный корпус пока не связан. Адресная точка не является границей здания.</p>')+`</section>`;
 node.insertAdjacentHTML('beforeend',block);
 node.querySelectorAll('[data-unlink]').forEach(b=>b.onclick=()=>v9Unlink(Number(b.dataset.unlink)));
};
const v8UpdateMapList=updateMapList;
updateMapList=function(){
 v8UpdateMapList();
 const list=$('#map-projects');if(!list)return;
 for(const b of list.querySelectorAll('[data-map-id]')){
   const id=Number(b.dataset.mapId),n=geometryLinks(id).length;
   const short=b.querySelector('.row-bottom');
   if(short){short.innerHTML=`<span>${n?'▰ '+n+' контур(а)/здания':'Здание автоматически уточняется'}</span>`;}
   const wrap=document.createElement('div');wrap.className='project-shape-tools';
   wrap.innerHTML=`<button class="btn sm bind-button" data-bind-project="${id}" title="Выбери здание на карте и свяжи с этим ЖК">↗ Исправить вручную</button>`;
   b.insertAdjacentElement('afterend',wrap);
 }
 const overlay=$('#shape-overlay');if(overlay)overlay.innerHTML=v9Banner();
 v9UpdateOsmList();
};
function v9UpdateOsmList(){
 const holder=$('#osm-list');if(!holder)return;
 const features=v9.zones.filter(f=>!featureLinks('osm',f.properties.osm_id)&& (v9.includeSites||f.properties.classification!=='construction_landuse'));
 const counter=$('#osm-count');if(counter)counter.textContent=`${features.length} без связи с ЖК · ${v9.status}`;
 holder.innerHTML=features.slice(0,600).map(f=>`<button class="osm-row" data-osm-id="${f.properties.osm_id}"><strong>${E(f.properties.name||zoneLabel(f.properties))}</strong><small>${E(f.properties.osm_address||'Адрес отсутствует в OSM')} · OSM way ${f.properties.osm_id}</small></button>`).join('')||'<p class="small osm-empty">Пока нет загруженных объектов. Нажми «Загрузить контуры OSM».</p>';
 holder.querySelectorAll('[data-osm-id]').forEach(b=>b.onclick=()=>{
   const f=v9.zones.find(x=>String(x.properties.osm_id)===b.dataset.osmId);
   if(f){v9FocusPolygon(f.geometry);v9UnlinkedDetails(f);}
 });
}
const v8RenderMarkers=renderMarkers;
// Deliberately replace all pin creation. Real polygons / native 2GIS vector IDs only.
renderMarkers=function(items){
 if(!st.map)return;
 clearMarkers();
 const visible=filteredProjects();
 for(const link of v9.links){
   if(!link.polygon||!visible.find(p=>p.id===link.building_id))continue;
   v9DrawPolygon(link.polygon,'#05A78E66','#008E83',()=>details(link.building_id));
 }
 if(v9.includeUnlinked){
   for(const feature of v9.zones){
     const f=feature.properties;if(featureLinks('osm',f.osm_id))continue;
     if(!v9.includeSites&&f.classification==='construction_landuse')continue;
     const building=f.classification!=='construction_landuse';
     v9DrawPolygon(feature.geometry,building?'#EAA33445':'#E5B46624',building?'#C98B31':'#B39B68',()=>{
       v9.lastPolygonClick=Date.now();
       if(v9.mode){v9Connect('osm',String(f.osm_id),null,feature.geometry)}else v9UnlinkedDetails(feature);
     });
   }
 }
 v9HighlightNative();
 const legend=$('#shape-overlay');if(legend)legend.innerHTML=v9Banner();
};
function v9DrawPolygon(geometry,fill,outline,handler){
 if(!geometry?.coordinates?.[0]||geometry.coordinates[0].length<4)return;
 try{
  if(st.mapType==='2gis'){
    const p=new window.mapgl.Polygon(st.map,{coordinates:geometry.coordinates,color:fill,strokeColor:outline,strokeWidth:2,interactive:true});
    p.on('click',(evt)=>{v9.lastPolygonClick=Date.now();try{evt.originalEvent?.stopPropagation()}catch{};handler()});
    st.markers.push(p);
  }else if(st.mapType==='osm'){
    const color=outline;
    const p=window.L.polygon(geometry.coordinates[0].map(([lon,lat])=>[lat,lon]),{color,fillColor:color,fillOpacity:fill.endsWith('24')?.14:.28,weight:2}).addTo(st.map);
    p.on('click',(evt)=>{v9.lastPolygonClick=Date.now();try{window.L.DomEvent.stopPropagation(evt)}catch{};handler()});
    st.markers.push(p);
  }
 }catch(err){console.warn('Контур:',err)}
}
function v9FocusPolygon(g){const pos=geoCentroid(g);if(!pos||!st.map)return;
 try{st.mapType==='2gis'?(st.map.setCenter(pos),st.map.setZoom(17)):st.map.setView([pos[1],pos[0]],17)}catch{}}
const v8FocusProject=focusProject;
focusProject=function(id){
 const project=projectById(id);if(!project)return;
 const osm=geometryLinks(id).find(l=>l.polygon);
 const native=geometryLinks(id).find(l=>l.provider==='2gis'&&l.position);
 if(osm)v9FocusPolygon(osm.polygon);
 else if(native&&st.map){try{if(st.mapType==='2gis'){st.map.setCenter(native.position);st.map.setZoom(17)}else st.map.setView([native.position[1],native.position[0]],17)}catch{}}
 else if(located(project)&&st.map){try{if(st.mapType==='2gis'){st.map.setCenter([project.longitude,project.latitude]);st.map.setZoom(17)}else st.map.setView([project.latitude,project.longitude],17)}catch{}}
 st.selected=id;details(id);updateMapList();
};
function v9UnlinkedDetails(feature){
 const p=feature.properties;
 $('#drawer-body').innerHTML=`<section class="detail-block"><div class="eyebrow">01 / ЗАСТРОЙЩИК</div><h2 class="detail-heading">Не установлен</h2><p class="small">Это объект OSM, не связанный с юридическим лицом или ЖК нашего каталога.</p></section><section class="detail-block"><div class="eyebrow">02 / ОБЪЕКТ КАРТЫ</div><h2 class="detail-heading">${E(p.name||zoneLabel(p))}</h2><p class="detail-sub">${E(p.osm_address||'Адрес не указан')}</p><div class="detail-kv"><span>Тип разметки</span><strong>${E(zoneLabel(p))}</strong></div><div class="detail-kv"><span>OSM way</span><strong>${E(p.osm_id)}</strong></div><div class="note warn">Отметка OSM могла устареть. Здесь нет подтверждения фактической незавершённости, документов, застройщика или нарушения.</div><div class="detail-links">${external(p.source_url,'Открыть полигон OSM','btn sm')}</div></section><section class="detail-block"><h3>03 / Первичный источник</h3><p class="small">Контур и атрибуты получены из открытой картографии OpenStreetMap / Overpass, без искусственной геометрии. Для включения в реестр ЖК нужен документированный адрес и проверка соответствия.</p></section>`;
 $('#drawer').hidden=false;$('#drawer-backdrop').hidden=false;document.body.style.overflow='hidden';
}
function v9SetMode(id){
 if(!projectById(id))return;
 v9.mode='select';v9.projectId=id;
 const name=projectById(id).name;
 const h=$('#link-action');if(h){h.hidden=false;h.innerHTML=`<b>Привязка: ${E(name)}</b><span>Кликни по нужному зданию 2ГИС или контуру OSM, затем подтверди.</span><button class="btn sm" id="cancel-link">Отмена</button>`;$('#cancel-link').onclick=v9CancelMode;}
 toast('Режим привязки: выбери конкретное здание на карте.');
}
function v9CancelMode(){v9.mode='';v9.projectId=null;const h=$('#link-action');if(h)h.hidden=true}
async function v9Connect(provider,featureId,lngLat,geometry){
 if(v9.mode!=='select'||!v9.projectId)return;
 const p=projectById(v9.projectId);if(!p)return;
 if(featureLinks(provider,featureId)){toast('Этот контур уже связан с ЖК');return;}
 if(!confirm(`Привязать ${provider==='osm'?'этот контур OSM':'это выбранное здание 2ГИС'} к ${p.name}? Убедись, что перед тобой именно нужный корпус. Это ВИЗУАЛЬНАЯ привязка, не юридическая проверка.`))return;
 const reviewer=prompt('Кто проверил соответствие здания и ЖК? (не менее 2 символов)');if(!reviewer||reviewer.trim().length<2)return;
 const sourceUrl=provider==='osm'?'':`https://2gis.kz/ust-kamenogorsk/search/${encodeURIComponent(p.address)}`;
 const payload={building_id:p.id,provider,feature_id:String(featureId),linked_by:reviewer.trim(),source_url:sourceUrl,click_coordinates:lngLat||null,note:'Визуальное сопоставление корпуса оператором на картографическом слое'};
 try{
  const row=await fetch('/api/v9/links',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  const result=await row.json();if(!row.ok)throw Error(result.detail||'Ошибка '+row.status);
  v9.links.push(result);v9CancelMode();updateMapList();details(p.id);toast('Корпус привязан к ЖК и сохранён');
 }catch(err){toast(err.message)}
}
async function v9Unlink(id){
 if(!confirm('Отвязать этот контур от ЖК? Исходные данные карты не удаляются.'))return;
 const reviewer=prompt('Укажите, кто снимает привязку');if(!reviewer||reviewer.trim().length<2)return;
 try{const r=await fetch('/api/v9/links/'+id,{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({linked_by:reviewer.trim()})});const result=await r.json();if(!r.ok)throw Error(result.detail||r.status);v9.links=v9.links.filter(x=>x.id!==id);closeDrawer();updateMapList();toast('Связь здания удалена')}
 catch(err){toast(err.message)}
}
function v9HighlightNative(){
 if(st.mapType!=='2gis'||!st.map)return;
 const ids=v9.links.filter(l=>l.provider==='2gis'&&!l.polygon).map(l=>l.feature_id);
 try{
  // Official MapGL vector-building selected-state mechanism.
  st.map.setSelectedObjects(ids);
  st.map.patchStyleState?.({hoverId:ids});
 }catch(e){console.warn('2GIS highlighting not ready',e)}
}
function v9EnableNativeLayer(){
 if(st.mapType!=='2gis'||!st.map||v9.hasNativeStyle)return;
 v9.hasNativeStyle=true;
 const apply=()=>{
  if(!st.map||st.mapType!=='2gis')return;
  const ids=v9.links.filter(l=>l.provider==='2gis'&&!l.polygon).map(l=>l.feature_id);
  try{
   st.map.patchStyleState({wallColorDown:'rgba(2,159,148,0.82)',wallColorTop:'rgba(94,236,189,0.78)',strokeColor:'rgba(0,121,119,1)',hoverId:ids});
   st.map.addLayer({id:'saq-verified-native-buildings',type:'polygonExtrusion',style:{topColor:['to-color',['global','wallColorTop']],sideColor:['to-color',['global','wallColorDown']],visibility:'visible',strokeColor:['to-color',['global','strokeColor']],strokeWidth:1},filter:['in',['get','db_id'],['global','hoverId']]});
   st.map.setSelectedObjects(ids);
  }catch(e){console.warn('2GIS native styling skipped',e);try{st.map.setSelectedObjects(ids)}catch{}}
 };
 st.map.on('styleload',apply);
 // Some MapGL builds fire styleload before the external callback attaches.
 try{apply()}catch{}
}
let v10Clicked=new Set();
async function v9OnMapClick(ev){
 if(Date.now()-v9.lastPolygonClick<200)return;
 const id=String(ev?.target?.id||ev?.targetData?.id||'');
 if(!/^\d{1,32}$/.test(id))return;
 const existing=featureLinks('2gis',id);
 if(existing){details(existing.building_id);return;}
 if(v9.mode==='select'){v9Connect('2gis',id,ev.lngLat||null);return;}
 if(v10Clicked.has(id))return;
 v10Clicked.add(id);
 try{
  const r=await fetch('/api/v10/native/'+encodeURIComponent(id));
  if(!r.ok)throw Error('HTTP '+r.status);
  const data=await r.json();
  if(data.linked){await v10RefreshLinks();details(data.building_id);v9HighlightNative();}
  else{toast(data.reason||'В реестре нет подтверждённого совпадения с этим зданием');}
 }catch(e){toast('2ГИС: не удалось сверить адрес: '+e.message)}
 finally{v10Clicked.delete(id)}
}
async function v10RefreshLinks(){
 let changed=false;
 try{const r=await fetch('/api/v9/links');if(r.ok){const next=await r.json();changed=JSON.stringify(next)!==JSON.stringify(v9.links);v9.links=next}}catch{}
 if(changed&&st.page==='map'){updateMapList();v9HighlightNative()}
}
let v10PollTimer=null;
async function v10StartAutomatic(){
 // Once per browser session, begin matching the complete catalogue automatically.
 let started=false;
 try{started=sessionStorage.getItem('saq_v10_auto_started')==='1';sessionStorage.setItem('saq_v10_auto_started','1')}catch{}
 try{
  if(!started){await fetch('/api/v10/autolink/start',{method:'POST'});}
  await v10PollAutomatic();
 }catch(e){console.warn('Автопривязка 2ГИС:',e)}
}
async function v10PollAutomatic(){
 if(st.page!=='map')return;
 try{
  const r=await fetch('/api/v10/autolink/status');if(!r.ok)return;
  const d=await r.json();
  const note=$('#v10-link-status');
  if(note){note.textContent=d.running||d.scheduled
   ?`Автоматический поиск реальных зданий: 2ГИС ${d.processed}/${d.total}, совпадений ${d.linked+d.without_geometry}; OSM ${d.osm_running?'проверка контуров':'ожидание'}`
   :`Автопривязка: 2ГИС ${d.linked+d.without_geometry}, OSM ${d.osm_linked||0}; неоднозначных ${d.ambiguous}, исключено ${d.skipped}. ${d.last_error||d.osm_error||''}`;
   note.classList.toggle('error',!!d.last_error);}
  await v10RefreshLinks();
  if(d.running||d.scheduled){clearTimeout(v10PollTimer);v10PollTimer=setTimeout(v10PollAutomatic,2100)}
 }catch(e){console.warn(e)}
}

async function v9Load(refresh=false){
 if(v9.loading)return;
 v9.loading=true;v9.status=refresh?'обновление':'загрузка';v9UpdateOsmList();
 try{
  const r=await fetch('/api/v9/construction'+(refresh?'?refresh=true':''));
  if(!r.ok)throw Error('HTTP '+r.status);
  const d=await r.json();v9.zones=(d.features||[]).filter(x=>x.geometry?.type==='Polygon');
  v9.status=d.status==='unavailable'?'источник недоступен':d.status==='cached'?'кэш OSM':d.status==='stale'?'устаревший кэш':'данные OSM';
  if(d.status==='unavailable')showMapError('Не удалось загрузить контуры Overpass. Карта 2ГИС и каталог доступны. Повтори позже.');
  else if(d.status==='stale')showMapError('Overpass недоступен, показан старый кэш OSM.');
 }catch(e){v9.status='нет связи с OSM';showMapError('Границы OSM: '+e.message)}
 finally{v9.loading=false;v9.loadDone=true;v9UpdateOsmList();renderMarkers(filteredProjects().filter(located));}
}
const v8CreateMap=createMap;
createMap=async function(){
 await v8CreateMap();
 if(!st.map)return;
 if(v9.hookedMap!==st.map){
  v9.hookedMap=st.map;
  if(st.mapType==='2gis'){st.map.on('click',v9OnMapClick);v9EnableNativeLayer();}
 }
 if(!v9.loadDone)await v9Load(false);
 else renderMarkers(filteredProjects());
};
const v8ClearMap=clearMap;
clearMap=function(){v8ClearMap();v9.hookedMap=null;v9.hasNativeStyle=false;v9CancelMode();if(v10PollTimer)clearTimeout(v10PollTimer)};
const v8RefreshData=refreshData;
refreshData=async function(){
 await v8RefreshData();
 try{const response=await fetch('/api/v9/links');if(response.ok)v9.links=await response.json()}catch{}
};
const v8Render=render;
render=function(){
 v8Render();
 if(st.page==='map'){
   const b=$('#refresh-osm');if(b)b.onclick=()=>v9Load(true);
   const u=$('#toggle-unlinked');if(u)u.onchange=e=>{v9.includeUnlinked=e.target.checked;renderMarkers(filteredProjects())};
   const s=$('#toggle-sites');if(s)s.onchange=e=>{v9.includeSites=e.target.checked;renderMarkers(filteredProjects());v9UpdateOsmList()};
   $('#map-projects')?.addEventListener('click',e=>{
    const b=e.target.closest('[data-bind-project]');if(b){e.stopPropagation();v9SetMode(Number(b.dataset.bindProject))}
   });
   const retry=$('#v10-retry');if(retry)retry.onclick=async()=>{sessionStorage.removeItem('saq_v10_auto_started');await v10StartAutomatic()};
  v9UpdateOsmList();
  v10StartAutomatic();
 }
};
