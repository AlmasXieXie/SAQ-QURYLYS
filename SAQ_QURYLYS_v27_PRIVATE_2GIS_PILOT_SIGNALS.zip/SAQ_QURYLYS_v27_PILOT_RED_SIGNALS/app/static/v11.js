'use strict';
/* v11: city-scale clickable labels independent of detailed building footprints.
 * IMPORTANT: unresolved addresses are NEVER placed at guessed coordinates. */
const v11={resolvedRun:false,pollTimer:null,shown:true,stop:false,mapBound:null};
function v11Position(project){
 if(located(project))return [project.longitude,project.latitude];
 const linked=geometryLinks(project.id);
 for(const link of linked){
   if(Array.isArray(link.position)&&link.position.length===2&&Number.isFinite(link.position[0])&&Number.isFinite(link.position[1]))return link.position;
   if(link.polygon){const c=geoCentroid(link.polygon);if(c)return c}
 }
 return null;
}
function v11Mapped(project){return v11Position(project)!==null}
function v11CloseEnough(c){return c && c[0]>=82.24&&c[0]<=82.98&&c[1]>=49.72&&c[1]<=50.22}
function v11Color(p){return p.stage_reported==='reported_unfinished'?'problem':p.stage_reported==='reported_problem_site'?'warning':'normal'}
function v11MapCardClick(id){st.selected=id;details(id);updateMapList()}
function v11DrawPersistentBadge(p,coords){
 if(!st.map||!v11CloseEnough(coords))return;
 const style=v11Color(p);
 const estimated=(p.coordinate_source||'').includes('APPROX');
 const prefix=estimated?'≈ ':'▦ ';
 const precision=estimated?' · точка ЖК по каталогу, НЕ границы корпуса':'';
 const name=p.name.replace(/^ЖК\s+/i,'');
 try{
  if(st.mapType==='2gis' && window.mapgl?.HtmlMarker){
    const marker=new window.mapgl.HtmlMarker(st.map,{
      coordinates:coords,interactive:true,preventMapInteractions:true,zIndex:800,
      anchor:[-9,-9],labeling:{type:'invincible',width:0,height:0},
      html:`<button type="button" class="saq-building-badge ${style}" aria-label="Открыть ${E(p.name)}" title="${E(p.name)} · ${E(p.address)}${precision}"><span class="saq-badge-icon">${estimated?'≈':'▦'}</span><span class="saq-badge-name">${E(name)}</span></button>`
    });
    const content=marker.getContent();
    content?.querySelector('button')?.addEventListener('click',evt=>{
      evt.preventDefault();evt.stopPropagation();v11MapCardClick(p.id);
    });
    st.markers.push(marker);
  }else if(st.mapType==='2gis'){
    const b=new window.mapgl.CircleMarker(st.map,{coordinates:coords,diameter:24,
      color:style==='problem'?'#df6064':style==='warning'?'#e4a54b':'#04ac9b',
      strokeColor:'#ffffff',strokeWidth:3,interactive:true,zIndex:800});
    b.on('click',()=>v11MapCardClick(p.id));st.markers.push(b);
  }else if(st.mapType==='osm'){
    const icon=window.L.divIcon({className:'saq-leaflet-icon',html:`<button type="button" class="saq-building-badge ${style}" title="${E(p.name)}${precision}">${prefix}${E(name)}</button>`,iconSize:[120,24],iconAnchor:[9,9]});
    const marker=window.L.marker([coords[1],coords[0]],{icon,zIndexOffset:999}).addTo(st.map);
    marker.on('click',()=>v11MapCardClick(p.id));st.markers.push(marker);
  }
 }catch(error){console.warn('City-scale ЖК label:',error)}
}
const v11RenderPolygons=renderMarkers;
renderMarkers=function(items){
  v11RenderPolygons(items); // actual 2GIS/OSM surveyed polygons are retained
  if(!st.map)return;
  // ALWAYS render clickable building labels, regardless of zoom level. MapGL
  // building polygons alone disappear visually on a city-scale viewport.
  for(const p of filteredProjects()){
    const coords=v11Position(p);
    if(v11CloseEnough(coords))v11DrawPersistentBadge(p,coords);
  }
  v11UpdateDock();
};
function v11DockHtml(){
 const all=filteredProjects();
 const unmapped=all.filter(p=>!v11CloseEnough(v11Position(p)));
 return `<div class="saq-map-dock-head"><b>Объекты без координат: ${unmapped.length}</b><button class="saq-dock-toggle" id="v11-toggle-dock" type="button" aria-expanded="${v11.shown}">${v11.shown?'Свернуть':'Развернуть'}</button></div>`+
  (v11.shown?`<div class="saq-map-dock-items">${unmapped.map(p=>`<button class="saq-dock-item" type="button" data-v11-id="${p.id}" title="${E(p.address)}">${E(p.name.replace(/^ЖК\s+/i,''))}</button>`).join('')||'<span class="saq-dock-empty">Все видимые ЖК имеют координаты</span>'}</div><div class="saq-map-dock-foot">Без точного адреса нельзя честно поставить объект на карту города. Карточки открываются здесь сразу.</div>`:'');
}
function v11UpdateDock(){
 const n=$('#v11-map-dock');if(!n)return;
 n.innerHTML=v11DockHtml();
 n.querySelector('#v11-toggle-dock')?.addEventListener('click',()=>{v11.shown=!v11.shown;v11UpdateDock()});
 for(const btn of n.querySelectorAll('[data-v11-id]'))btn.addEventListener('click',()=>v11MapCardClick(Number(btn.dataset.v11Id)));
 const count=$('#v11-city-count');if(count){
   const p=filteredProjects();count.textContent=`${p.filter(v11Mapped).length}/${p.length} ЖК на карте · при любом масштабе`;
 }
}
const v11OriginalMapView=mapView;
mapView=function(){
 let html=v11OriginalMapView();
 html=html.replace('Здания и строительные площадки','Карта ЖК · видны на масштабе города');
 html=html.replace('Нажимай на здание 2ГИС: приложение попытается открыть соответствующий ЖК по точному адресу. Автоматически сопоставленные здания подсвечиваются; спорные адреса не связываются.',
  'Нажми на название ЖК поверх карты: карточка откроется даже на масштабе всего города. Настоящие контуры показываются дополнительно; отсутствие координат обозначено отдельно.');
 html=html.replace('<button class="btn" id="refresh-points">↻ Обновить</button>',
   '<button class="btn" id="refresh-points">↻ Обновить</button>');
 html=html.replace('<button class="btn blue" id="v10-retry">Привязать здания автоматически</button>',
  '<button class="btn blue" id="v10-retry">Привязать здания автоматически</button><button class="btn blue" id="v11-geocode">Уточнить остальные адреса (OSM)</button><button class="btn" id="v11-fit">Весь город</button>');
 html=html.replace('<div id="map-message" class="map-error" hidden></div>',
  '<div class="saq-city-count" id="v11-city-count" role="status">Готовим ЖК…</div><div id="v11-map-dock" class="saq-map-dock"></div><div id="v11-geostatus" class="saq-geo-progress" role="status" hidden></div><div id="map-message" class="map-error" hidden></div>');
 html=html.replace('Есть геометка','Адресные точки').replace('Без точной точки','Нужна геопривязка');
 return html;
};
const v11UpdateListOriginal=updateMapList;
updateMapList=function(){v11UpdateListOriginal();v11UpdateDock()};
const v11GeoUpdate=updateGeoContent;
updateGeoContent=async function(){await v11GeoUpdate();v11UpdateDock()};
async function v11StartFallback(){
 const n=$('#v11-geostatus');if(n){n.hidden=false;n.textContent='Запущен дополнительный поиск точных адресов через OSM…'}
 try{
   const r=await fetch('/api/v11/geocode/start',{method:'POST'});
   if(!r.ok)throw Error('HTTP '+r.status);
   v11PollFallback();
 }catch(err){if(n)n.textContent='Не удалось запустить поиск: '+err.message}
}
async function v11PollFallback(){
 if(st.page!=='map')return;
 try{
  const r=await fetch('/api/v11/geocode/status');if(!r.ok)throw Error('HTTP '+r.status);
  const s=await r.json();const n=$('#v11-geostatus');
  if(n){n.hidden=false;n.textContent=(s.running||s.scheduled?`OSM: ${s.checked}/${s.total}, новых точек ${s.resolved}`:`OSM: получено новых точек ${s.resolved}, нет точного совпадения ${s.missing+s.ambiguous}`)+(s.last_error?` · ${s.last_error}`:'');}
  // Update all badges as soon as a match is stored, not just at completion.
  await updateGeoContent();
  if(s.running||s.scheduled){clearTimeout(v11.pollTimer);v11.pollTimer=setTimeout(v11PollFallback,3200)}
 }catch(err){const n=$('#v11-geostatus');if(n){n.hidden=false;n.textContent='OSM: '+err.message}}
}
const v11RenderOriginal=render;
render=function(){
 v11RenderOriginal();
 if(st.page!=='map')return;
 const go=$('#v11-geocode');if(go)go.onclick=v11StartFallback;
 const fit=$('#v11-fit');if(fit)fit.onclick=()=>{
  if(!st.map)return;
  try{if(st.mapType==='2gis'){st.map.setCenter([82.612,49.956]);st.map.setZoom(12)}
  else st.map.setView([49.956,82.612],12)}catch{}
 };
 v11UpdateDock();
 // Run missing-address search once per browser session; no infinite repeated
 // public-provider requests or guessed points.
 let tried=false;
 try{tried=sessionStorage.getItem('saq_v11_osm_started')==='1';sessionStorage.setItem('saq_v11_osm_started','1')}catch{}
 if(!tried && !window.SAQ_V14_GEO && st.projects.some(p=>!v11Mapped(p)))v11StartFallback();
 else fetch('/api/v11/geocode/status').then(r=>r.json()).then(s=>{if(s.running||s.scheduled)v11PollFallback()}).catch(()=>{});
};
const v11ClearMapOriginal=clearMap;
clearMap=function(){clearTimeout(v11.pollTimer);v11ClearMapOriginal()};
