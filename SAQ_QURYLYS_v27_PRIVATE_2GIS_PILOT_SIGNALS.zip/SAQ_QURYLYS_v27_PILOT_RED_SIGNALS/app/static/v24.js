'use strict';
/* v24 public-ad evidence archive, exact project/legal-party reconciliation. */
let v24Busy=false;
function v24Pill(item){
 const c=item.legal_assessment?.color||'yellow';
 const mark=c==='green'?'🟢':c==='red'?'🔴':'🟡';
 return `<span title="${E(item.legal_assessment?.reason||'')}">${mark} ${E(item.legal_assessment?.label||'Проверить')}</span>`;
}
async function v24LoadArchive(){
 const root=document.querySelector('#v24-archive');if(!root)return;
 if(v24Busy)return;v24Busy=true;
 try{
  const [summary,rows]=await Promise.all([
    fetch('/api/v24/ads/summary').then(r=>{if(!r.ok)throw Error('HTTP '+r.status);return r.json()}),
    fetch('/api/v24/ads?limit=150').then(r=>{if(!r.ok)throw Error('HTTP '+r.status);return r.json()})]);
  if(!document.querySelector('#v24-archive'))return;
  const s=document.querySelector('#v24-summary');
  if(s)s.textContent=`${summary.total} реальных публикаций · Krisha: ${summary.by_platform.krisha||0} · OLX: ${summary.by_platform.olx||0} · Instagram: ${summary.by_platform.instagram||0} · точно сопоставлены: ${summary.matched} · требуют привязки: ${summary.need_attribution}`;
  const body=document.querySelector('#v24-archive-results');
  if(body)body.innerHTML=rows.length?rows.map(x=>`<tr>
    <td>${external(x.url, (x.platform||'источник').toUpperCase())}<div class="small">${E(x.source_kind||'')} · наблюдений ${Number(x.seen_count||0)}</div></td>
    <td><b>${E(x.project_name||'Не удалось сопоставить')}</b><div class="small">${E(x.method||'')}; уверенность: ${E(x.confidence||'—')}</div></td>
    <td>${E(x.organization_related||'—')}<div class="small">${x.organization_bin?'БИН '+E(x.organization_bin):'Юридическая роль не подтверждена'}</div><div class="small">Автор публикации не верифицирован</div></td>
    <td>${v24Pill(x)}</td>
    <td>${E((x.text||'').slice(0,160))}</td>
   </tr>`).join(''):'<tr><td colspan="5">Ожидаются реальные ссылки из индексов или разрешённых API.</td></tr>';
 }catch(e){const s=document.querySelector('#v24-summary');if(s)s.textContent='Ошибка архива: '+e.message;}
 finally{v24Busy=false}
}
const v24PriorAds=adsView;
adsView=function(){
 const html=v24PriorAds();
 const panel=`<section class="panel" id="v24-archive">
   <div class="panel-title"><h3>Архив объявлений · фиксация источника и организации</h3><button class="btn sm" id="v24-refresh" type="button">↻ Обновить</button></div>
   <p class="small" id="v24-summary">Получение сведений…</p>
   <p class="small">В архиве сохраняются первичная ссылка, платформа, версия текста и даты наблюдений. Связь объявления с ЖК не подтверждает, что рекламодатель — его застройщик.</p>
   <div style="overflow:auto"><table class="table"><thead><tr><th>Публикация</th><th>ЖК / атрибуция</th><th>Связанная организация</th><th>Право на долевое участие</th><th>Фрагмент</th></tr></thead><tbody id="v24-archive-results"><tr><td colspan="5">Загрузка…</td></tr></tbody></table></div>
 </section>`;
 return html.replace('В этой версии добавление рекламы — вручную по конкретной ссылке. Автоматический сбор Instagram, Krisha или OLX не включён без согласованного доступа к их источникам. Система не выдумывает публикации и не делает автоматических обвинений.', 'v24: автоматический мониторинг открытых индексов Krisha/OLX/Instagram и подключаемых API. Покрытие зависит от доступности внешних источников; новые публикации сохраняются с первичной ссылкой и историей изменений.')
            .replace('<div class="ads-shell">',panel+'<div class="ads-shell">');
};
const v24PriorRender=render;
render=function(){
 v24PriorRender();
 if(st.page==='ads'){
  document.querySelector('#v24-refresh')?.addEventListener('click',v24LoadArchive);
  v24LoadArchive();
 }
};

/* Office evidence queue: the legal outcome always comes from one server rule,
   never from an independent JS heuristic or developer-name similarity. */
let v24AuditBusy=false;
async function v24LoadAudit(){
 const root=document.querySelector('#v24-registry-audit');
 if(!root||v24AuditBusy)return;
 v24AuditBusy=true;
 try{
  const [report,sync]=await Promise.all([
   fetch('/api/v24/registry/audit').then(r=>{if(!r.ok)throw Error('HTTP '+r.status);return r.json()}),
   fetch('/api/v24/registry/sync-status').then(r=>{if(!r.ok)throw Error('HTTP '+r.status);return r.json()})]);
  const info=document.querySelector('#v24-audit-info');
  if(info)info.textContent=`${report.total} реальных ЖК · ${report.green} с подтверждённым правовым основанием · ${report.total-report.green} требуют проверки · последний успешный импорт МИО: ${sync.succeeded_at||'не выполнялся'}`;
  const tbody=document.querySelector('#v24-audit-list');
  if(tbody)tbody.innerHTML=report.all.map(p=>`<tr>
   <td>${p.color==='green'?'🟢':p.color==='red'?'🔴':'🟡'} <b>${E(p.name)}</b><div class="small">${E(p.address)}</div></td>
   <td>${E(p.developer_label||'—')}</td>
   <td>${E(p.registry_status||'unknown')}<div class="small">${E(p.priority||'')}</div></td>
   <td>${(p.documents||[]).map(d=>`<div>${E(d.number||'без номера')} (${E(d.status||'')}) ${d.url?external(d.url,'источник'):''}</div>`).join('')||'Нет подтверждённого документа в локальной базе'}</td>
   </tr>`).join('');
  const err=document.querySelector('#v24-mio-sync-note');if(err)err.textContent=sync.error?`Ошибка последнего импорта МИО: ${sync.error}`:'';
 }catch(e){const info=document.querySelector('#v24-audit-info');if(info)info.textContent='Ошибка загрузки проверки: '+e.message;}
 finally{v24AuditBusy=false;}
}
async function v24StartMioSync(){
 const btn=document.querySelector('#v24-mio-sync');if(!btn||btn.disabled)return;
 const note=document.querySelector('#v24-mio-sync-note');btn.disabled=true;
 if(note)note.textContent='Запрос официального набора МИО…';
 try{
  const r=await fetch('/api/v24/registry/sync-public-mio',{method:'POST'});
  const x=await r.json();
  if(!r.ok)throw Error(x.detail||('HTTP '+r.status));
  if(note)note.textContent=`МИО: ${x.import.total||0} строк, новых совпадений ${x.reconciliation.matched.length}. Проверка точной применимости документа обязательна.`;
  await v24LoadAudit();
 }catch(e){if(note)note.textContent='Синхронизация не удалась: '+e.message;}
 finally{btn.disabled=false;}
}
if(typeof developerView==='function'){
 const v24PriorDevelopers=developerView;
 developerView=function(){
  const old=v24PriorDevelopers();
  return `<section class="panel" id="v24-registry-audit">
   <div class="panel-title"><h3>Углублённая проверка документов · 40 ЖК</h3><button class="btn sm" id="v24-mio-sync" type="button">⟳ Сверить реестр МИО</button></div>
   <p class="small" id="v24-audit-info">Получение документов…</p>
   <p class="small" id="v24-mio-sync-note"></p>
   <p class="small">Зелёный присваивается конкретному ЖК по официальному документу. Строительная лицензия или документ на другой ЖК не дают права автоматически подтвердить долевую продажу.</p>
   <div style="max-height:440px;overflow:auto"><table class="table"><thead><tr><th>ЖК</th><th>Бренд / организация</th><th>Статус</th><th>Основания и источники</th></tr></thead><tbody id="v24-audit-list"></tbody></table></div>
  </section>`+old;
 };
 const v24BeforeRender=render;
 render=function(){
  v24BeforeRender();
  if(st.page==='developers'){
   document.querySelector('#v24-mio-sync')?.addEventListener('click',v24StartMioSync);
   v24LoadAudit();
  }
 };
}
