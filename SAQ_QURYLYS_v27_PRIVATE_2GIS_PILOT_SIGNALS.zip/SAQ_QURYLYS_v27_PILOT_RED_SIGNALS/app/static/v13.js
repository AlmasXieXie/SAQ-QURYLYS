'use strict';
/* v13: autonomous scan status and precision-aware city map; no invented GPS. */
const v13Assessment={
 potential_equity_collection_no_basis_in_local_db:'Есть слова о платеже, основание в нашей базе не найдено — проверить',
 document_claim_requires_official_verification:'Заявлен документ — проверить официальный реестр и корпус',
 review_required:'Требуется проверка',unresolved_project:'ЖК не распознан',context_only:'Информационная публикация'};
const v13Feed={busy:false,last:0};
async function v13LoadScan(){
 const rootEl=document.getElementById('v13-autoscanner');if(!rootEl)return;
 try{
  const [s,items]=await Promise.all([
   fetch('/api/v13/monitor/status').then(r=>r.json()),
   fetch('/api/v13/monitor/findings?limit=40').then(r=>r.json())]);
  if(!document.getElementById('v13-autoscanner'))return;
  const msg=s.running?'Идёт поиск публикаций':s.feeds_checked?'Последний цикл завершён':s.last_error?'Источники недоступны':'Ожидание запуска';
  const indicator=document.querySelector('#v13-auto-state');
  if(indicator)indicator.textContent=`${msg} · найдено ${s.total_saved} · на проверке ${s.total_pending} · индекс RSS ${s.discovered} публикаций`;
  const error=document.querySelector('#v13-auto-error');
  if(error)error.textContent=s.last_error?`Последняя ошибка источника: ${s.last_error}`:'Поиск по публичным RSS-индексам не гарантирует охват всех объявлений OLX, Krisha и Instagram.';
  const list=document.querySelector('#v13-auto-results');
  if(list)list.innerHTML=items.length?items.slice(0,30).map(it=>`<div class="v13-result">
    <div><b>${E(it.project_name||'ЖК не установлен')}</b><small> ${E(v13Assessment[it.assessment]||it.assessment)}${it.ocr_used==='yes'?' · OCR':''}</small></div>
    <div>${external(it.url,it.title||'Открыть объявление','v13-source')}</div></div>`).join(''):
    '<p class="small">Пока нет обнаруженных и сопоставленных публикаций. Первое сканирование запускается после запуска сервера; ошибки источников показываются выше.</p>';
 }catch(err){const indicator=document.querySelector('#v13-auto-state');if(indicator)indicator.textContent='Ошибка соединения с фоновым сканером: '+err.message;}
}
async function v13StartScan(){
 if(v13Feed.busy)return;v13Feed.busy=true;
 const btn=document.getElementById('v13-scan-now');if(btn)btn.disabled=true;
 try{const r=await fetch('/api/v13/monitor/start',{method:'POST'});if(!r.ok)throw Error('HTTP '+r.status);await v13LoadScan();toast('Проверка открытых RSS-источников поставлена в очередь')}
 catch(err){toast('Мониторинг: '+err.message)}finally{v13Feed.busy=false;if(btn)btn.disabled=false;}
}
const v13OldAdsView=adsView;
adsView=function(){
 let html=v13OldAdsView();
 const banner=`<section class="panel v13-auto" id="v13-autoscanner"><div class="panel-title"><h3>Автопоиск рекламы · OLX / Krisha / Instagram</h3><button type="button" class="btn blue" id="v13-scan-now">↻ Проверить сейчас</button></div>
 <p id="v13-auto-state" class="small">Запускаем поиск в публичных поисковых RSS-источниках…</p>
 <p id="v13-auto-error" class="small"></p><div id="v13-auto-results" class="v13-auto-list"></div>
 <p class="small">Автопоиск работает в фоне каждые 6 часов, пока сервер включён. OCR применяется к доступным превью. Отсутствие разрешения в локальной базе — основание для проверки, а не доказанный факт нарушения.</p></section>`;
 return html.replace('<div class="ads-shell">',banner+'<div class="ads-shell">')
 .replace('В этой версии добавление рекламы — вручную по конкретной ссылке. Автоматический сбор Instagram, Krisha или OLX не включён без согласованного доступа к их источникам. Система не выдумывает публикации и не делает автоматических обвинений.',
 'Автоматический поиск работает по публично индексируемым результатам. Он не обходит антибот-защиту и не обещает видеть все объявления площадок. Не найденное в нашей базе разрешение не считается отсутствующим официально.')
 .replace('Реальные публикации пока не загружены. Добавь прямую ссылку справа — она появится здесь.',
 'Подходящих публикаций пока не найдено. Фоновый сканер проверяет открытые источники по расписанию.');
};

const v13OldMapView=mapView;
mapView=function(){
 let html=v13OldMapView();
 return html.replace('<div id="v11-geostatus"',
  '<div id="v13-locator" class="saq-geo-progress" role="status">Автоматическая проверка адресов 2ГИС запланирована… <button class="btn sm" type="button" id="v13-geosearch">Повторить поиск</button></div><div id="v11-geostatus"');
};

async function v13GeoProgress(){
 if(st.page!=='map')return;
 const p=document.getElementById('v13-locator');if(!p)return;
 try{
  const s=await fetch('/api/v13/geolocate/status').then(r=>r.json());
  if(s.located!==st.projects.filter(p=>located(p)).length){
    await updateGeoContent();
  }
  p.firstChild.textContent=`2ГИС: точек ${s.located}/${s.all}, из них приблизительных ${s.approximate}. `+
    (s.running?`Геопоиск ${s.processed}/${s.total}… `:s.last_run?'Последняя проверка завершена. ':'Проверка запланирована. ')+
    (s.last_error?`Ошибка: ${s.last_error}. `:'')+
    'Без точного совпадения объект не размещается на чужом здании. ';
 }catch(e){p.firstChild.textContent='Геопоиск недоступен: '+e.message+' '}
}
const v13OldRender=render;
render=function(){
 v13OldRender();
 if(st.page==='ads'){
  document.getElementById('v13-scan-now')?.addEventListener('click',v13StartScan);
  v13LoadScan();
 }
 if(st.page==='map'){
  document.getElementById('v13-geosearch')?.addEventListener('click',async()=>{
   try{await fetch('/api/v13/geolocate/start',{method:'POST'});v13GeoProgress();toast('Автопоиск ЖК запущен')}
   catch(e){toast('2ГИС: '+e.message)}
  });
  v13GeoProgress();
 }
};
setInterval(()=>{
 if(st.page==='ads')v13LoadScan();
 if(st.page==='map')v13GeoProgress();
},14000);
