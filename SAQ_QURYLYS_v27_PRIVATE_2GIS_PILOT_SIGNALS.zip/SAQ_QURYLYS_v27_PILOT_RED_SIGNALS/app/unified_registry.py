"""Evidence-oriented unified register, deliberately independent of advertisement risk scores.

An object appearing in a commercial catalog never implies an official authorization.
No anonymous or hashed BIN is reconciled to a raw BIN.
"""
from __future__ import annotations
from datetime import datetime, timezone, date
import csv, hashlib, io, json, re
from typing import Optional
from sqlalchemy import Integer, String, Text, ForeignKey, DateTime, JSON, select, func
from sqlalchemy.orm import Mapped, mapped_column, Session
from app.database import Base

TODAY = '2026-10-17'
def now(): return datetime.now(timezone.utc)

def clean(value): return ' '.join(str(value or '').strip().split())
def keyify(value):
    v = clean(value).casefold().replace('ё','е')
    v = re.sub(r'[^\w]+','-',v, flags=re.UNICODE).strip('-')
    return v[:140]

def fp(*parts): return hashlib.sha256('|'.join(clean(x) for x in parts).encode('utf-8')).hexdigest()

class RegistryCompany(Base):
    __tablename__='unified_companies'
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    company_key: Mapped[str]=mapped_column(String(200), unique=True, index=True)
    name: Mapped[str]=mapped_column(String(250))
    bin: Mapped[str|None]=mapped_column(String(12), index=True, nullable=True)
    entity_type: Mapped[str]=mapped_column(String(30), default='developer_label') # may be trade name, not legal identity
    legal_identity_status: Mapped[str]=mapped_column(String(35), default='unverified')
    notes: Mapped[str]=mapped_column(Text, default='')
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

class RegistryBuilding(Base):
    __tablename__='unified_buildings'
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    building_key: Mapped[str]=mapped_column(String(220),unique=True,index=True)
    name: Mapped[str]=mapped_column(String(240))
    city: Mapped[str]=mapped_column(String(140), default='Усть-Каменогорск')
    address: Mapped[str]=mapped_column(String(350),default='')
    stage_reported: Mapped[str]=mapped_column(String(35), default='unknown')
    stage_verified: Mapped[str]=mapped_column(String(35), default='unknown')
    developer_label: Mapped[str]=mapped_column(String(250), default='')
    company_id: Mapped[int|None]=mapped_column(ForeignKey('unified_companies.id'),nullable=True)
    commission_reported: Mapped[str]=mapped_column(String(60),default='')
    latitude: Mapped[float|None]=mapped_column(nullable=True)
    longitude: Mapped[float|None]=mapped_column(nullable=True)
    coordinate_source: Mapped[str]=mapped_column(String(500),default='')
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

class RegistryEvidence(Base):
    __tablename__='unified_evidence'
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    digest: Mapped[str]=mapped_column(String(64), unique=True,index=True)
    source_code: Mapped[str]=mapped_column(String(60))
    source_url: Mapped[str]=mapped_column(String(800))
    collected_on: Mapped[str]=mapped_column(String(30),default=TODAY)
    description: Mapped[str]=mapped_column(Text)
    evidence_level: Mapped[str]=mapped_column(String(32),default='third_party_claim')
    building_id: Mapped[int|None]=mapped_column(ForeignKey('unified_buildings.id'), nullable=True,index=True)
    company_id: Mapped[int|None]=mapped_column(ForeignKey('unified_companies.id'),nullable=True,index=True)
    raw_fields: Mapped[dict]=mapped_column(JSON,default=dict)

class RegistryAuthorization(Base):
    __tablename__='unified_authorizations'
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    fingerprint: Mapped[str]=mapped_column(String(64),unique=True,index=True)
    authorization_type: Mapped[str]=mapped_column(String(50))
    document_number: Mapped[str]=mapped_column(String(180),default='')
    issued_on: Mapped[str]=mapped_column(String(30),default='')
    expires_on: Mapped[str]=mapped_column(String(30),default='')
    status: Mapped[str]=mapped_column(String(35),default='reported')
    activity: Mapped[str]=mapped_column(String(180),default='')
    building_id: Mapped[int|None]=mapped_column(ForeignKey('unified_buildings.id'),nullable=True,index=True)
    company_id: Mapped[int|None]=mapped_column(ForeignKey('unified_companies.id'),nullable=True,index=True)
    evidence_id: Mapped[int|None]=mapped_column(ForeignKey('unified_evidence.id'),nullable=True)
    source_code: Mapped[str]=mapped_column(String(60),default='')
    source_url: Mapped[str]=mapped_column(String(800),default='')
    subject_name: Mapped[str]=mapped_column(String(300),default='')
    location_text: Mapped[str]=mapped_column(String(350),default='')
    notes: Mapped[str]=mapped_column(Text,default='')

SOURCES=[
 ('homeportal','КЖК — Жилищный портал','https://homeportal.kz','official','Публичные карточки проектов; реестр гарантий.','individual_cards_and_import'),
 ('elicense','E-License','https://elicense.kz','official','Статус лицензий/разрешительных документов; часто нужен БИН и интерактивная проверка.','manual_or_export'),
 ('qazreestr','Qazreestr','https://qazreestr.kz','official','Долевое строительство и регистрация ДДУ; доступность API не подтверждена.','manual_or_export'),
 ('equrylys','eQurylys','https://reestr.equrylys.kz/organizations','official','Реестр строительных организаций; запись не означает наличие всех лицензий.','manual_or_export'),
 ('egov','eGov — юридические лица','https://egov.kz','official','Проверка юридического лица и БИН; может требовать авторизацию.','manual_or_export'),
 ('kgd','КГД','https://kgd.gov.kz','official','Сведения налоговых органов; наличие долгов не устанавливает нарушение в долевом строительстве.','manual_or_export'),
 ('rsp','Реестр субъектов предпринимательства','https://rsp.gov.kz','official','Статус субъекта предпринимательства, если данные доступны.','manual_or_export'),
 ('cadastre','Публичная кадастровая карта','https://map.gov4c.kz/egkn/','official','Кадастровые участки; кадастровое право не тождественно праву привлекать дольщиков.','manual_or_export'),
 ('dataegov','Открытые данные РК','https://data.egov.kz','official','Публикуемые наборы и выгрузки.','manual_or_export'),
 ('procurement','Недобросовестные участники госзакупок','https://procurement.gov.kz/ru/registry/rnu','official','Иные риски контрагента; не разрешение на продажу недвижимости.','manual_or_export'),
 ('ashyq','Ashyq Data — разрешения МИО','https://ashyq.data.gov.kz/dataset/magda-ds-b80110e9-218a-42ba-b8c8-01fa5e4c82c8','official','Открытый CSV разрешений; БИН застройщиков хеширован.','csv_sync_or_upload'),
 ('krisha','Krisha.kz — каталог ЖК','https://krisha.kz/complex/search/ust-kamenogorsk/','commercial','Сведения о строящихся/сданных ЖК и сообщения о документах; не официальный реестр.','individual_cards'),
 ('goszakup','Портал госзакупок — сведения о компании','https://old.goszakup.gov.kz/','official','Публичная карточка участника с БИН; не лицензия на строительство.','individual_cards'),
]

# Explicitly verified individual public pages. No imaginary BIN, completion percentage or coordinates.
# source_claim=marketplace report; official=the issuing agency/official company record.
STARTER=[
 dict(name='ЖК Золотой квадрат',address='Усть-Каменогорск, ул. Кайсенова, 55/1',developer='ТОО «НАУАН Корп»',stage='construction',source='homeportal',url='https://www.homeportal.kz/ru/projects/1141', level='official', commission='01.11.2026',authorization=dict(type='kzhk_guarantee',number='ДПГ-25-16-078/194',date='2025-08-18',activity='привлечение денег дольщиков по гарантии КЖК',status='reported_official')),
 dict(name='ЖК AINALAIYN',address='Усть-Каменогорск, ул. Есенберлина, 5/1',developer='AN Groups',stage='construction',source='krisha',url='https://krisha.kz/complex/show/ust-kamenogorsk/ainalayin/',authorization=dict(type='mio_equity_permit',number='KZ40VWE00002526',date='2025-07-15',status='reported_third_party')),
 dict(name='ЖК ASYLYM',address='Усть-Каменогорск, ул. Кокжал Барака, 18',developer='AN Groups (бренд)',stage='construction',source='krisha',url='https://www.plus.krisha.kz/complex/show/ust-kamenogorsk/asylym/',authorization=dict(type='kzhk_guarantee',number='ДПГ-25-16-082/200',date='2025-10-31',status='reported_third_party')),
 dict(name='ЖК ORDA',address='Усть-Каменогорск, ул. Кокжал Барака, 17',developer='CEO Group',stage='construction',source='krisha',url='https://krisha.kz/complex/show/ust-kamenogorsk/orda/',authorization=dict(type='mio_equity_permit',number='1383/МҚЗТ-С-331',date='2025-10-13',status='reported_third_party')),
 dict(name='ЖК Престиж',address='Усть-Каменогорск, ул. Увалиева, 7',developer='OKS Group — Усть-Каменогорск',stage='construction',source='krisha',url='https://krisha.kz/complex/show/ust-kamenogorsk/prestizh/',authorization=dict(type='kzhk_guarantee',number='ДС №1 к ДПГ-22-16-055/120',date='2024-05-10',status='reported_third_party')),
 dict(name='ЖК Asyl Tau',address='Усть-Каменогорск, ул. Кокжал Барака, 26',developer='Орда Трейдинг',stage='construction',source='krisha',url='https://krisha.kz/complex/show/ust-kamenogorsk/asyltau/',authorization=dict(type='bank_participation',number='KZ62VWE00002712',date='2026-04-10',status='reported_third_party')),
 dict(name='ЖК ЖАНЫМ',address='Усть-Каменогорск, ул. Ильяса Есенберлина, 92',developer='Группа компаний Biryza.kz',stage='construction',source='krisha',url='https://krisha.kz/complex/show/ust-kamenogorsk/v-club/',authorization=dict(type='kzhk_guarantee',number='ДПГ-23-16-068/155',date='2023-10-11',status='reported_third_party')),
 dict(name='ЖК Brick Town',address='Усть-Каменогорск, ул. И. Есенберлина, 11',developer='Kalina Group',stage='commissioned',source='krisha',url='https://krisha.kz/complex/show/ust-kamenogorsk/bricktown/'),
 dict(name='ЖК Altyn Uia',address='Усть-Каменогорск, пр. К. Сатпаева, 13Б',developer='ALTYN UIA',stage='commissioned',source='krisha',url='https://krisha.kz/complex/show/ust-kamenogorsk/altynuia/'),
 dict(name='ЖК Nomad',address='Усть-Каменогорск, ул. Сатпаева, 13В',developer='CEO Group',stage='commissioned',source='krisha',url='https://krisha.kz/complex/show/ust-kamenogorsk/nomad/'),
 dict(name='ЖК Crystal',address='Усть-Каменогорск, ул. Жастар, 13',developer='ATQ corporate',stage='commissioned',source='krisha',url='https://krisha.kz/complex/show/ust-kamenogorsk/crystal/'),
 dict(name='ЖК AB-RESIDENCE',address='Усть-Каменогорск, ул. Есенберлина, 90',developer='Asyl Bosaga',stage='commissioned',source='krisha',url='https://www.krisha.kz/complex/show/ust-kamenogorsk/abresidence/'),
 dict(name='ЖК Prime Home',address='Усть-Каменогорск, ул. Есенберлина, 28/1',developer='ТОО «Финтэк-Астана»',company_bin='040640013971',stage='commissioned',source='krisha',url='https://krisha.kz/complex/show/ust-kamenogorsk/primehome/'),
 dict(name='ЖК Айымжан',address='Усть-Каменогорск, ул. Казыбек Би, 1Б',developer='ТОО «Асыл Маржан»',stage='commissioned',source='krisha',url='https://krisha.kz/complex/show/ust-kamenogorsk/ayimzhan/'),
]

def upsert_company(db:Session, name:str, bin_value:str|None=None):
    name=clean(name)
    if not name or name.casefold() in ('не установлено','неизвестно'): return None
    # Brand label is never merged with legal entity merely by similarity.
    key=('bin:'+bin_value) if bin_value else ('label:'+keyify(name))
    company=db.scalar(select(RegistryCompany).where(RegistryCompany.company_key==key))
    if company is None:
        company=RegistryCompany(company_key=key,name=name,bin=bin_value,entity_type='legal_entity' if bin_value else 'developer_label',legal_identity_status='public_identifier' if bin_value else 'unverified')
        db.add(company);db.flush()
    return company

def insert_evidence(db, source_code, url, description, level='third_party_claim',building_id=None,company_id=None,raw_fields=None,collected_on=TODAY):
    digest=fp(source_code,url,description,building_id or '',company_id or '',json.dumps(raw_fields or {},ensure_ascii=False,sort_keys=True))
    e=db.scalar(select(RegistryEvidence).where(RegistryEvidence.digest==digest))
    if e:return e
    e=RegistryEvidence(digest=digest,source_code=source_code,source_url=url,description=description,evidence_level=level,building_id=building_id,company_id=company_id,collected_on=collected_on,raw_fields=raw_fields or {})
    db.add(e);db.flush();return e

def insert_authorization(db, *,authorization_type,document_number,source_code,source_url,building_id=None,company_id=None,evidence_id=None,status='reported',issued_on='',subject_name='',location_text='',activity='',notes='',expires_on=''):
    fingerprint=fp(source_code,document_number,authorization_type,source_url,subject_name,location_text)
    a=db.scalar(select(RegistryAuthorization).where(RegistryAuthorization.fingerprint==fingerprint))
    if a:return a,False
    a=RegistryAuthorization(fingerprint=fingerprint,authorization_type=authorization_type,document_number=document_number,source_code=source_code,source_url=source_url,building_id=building_id,company_id=company_id,evidence_id=evidence_id,status=status,issued_on=issued_on,subject_name=subject_name,location_text=location_text,activity=activity,notes=notes,expires_on=expires_on)
    db.add(a);db.flush();return a,True

def load_starter(db:Session):
    added=0
    for item in STARTER:
        key='uka:'+keyify(item['name'])
        b=db.scalar(select(RegistryBuilding).where(RegistryBuilding.building_key==key))
        if b is None:
            company=upsert_company(db,item['developer'],item.get('company_bin'))
            b=RegistryBuilding(building_key=key,name=item['name'],address=item['address'],developer_label=item['developer'],stage_reported=item['stage'],company_id=company.id if company else None,commission_reported=item.get('commission',''))
            db.add(b);db.flush();added+=1
        evidence=insert_evidence(db,item['source'],item['url'],f"Публичная карточка {item['name']}: {item['stage']}, {item['developer']}",item.get('level','third_party_claim'),b.id,b.company_id,raw_fields={'address':item['address'],'stage':item['stage']})
        if auth:=item.get('authorization'):
            insert_authorization(db,authorization_type=auth['type'],document_number=auth['number'],issued_on=auth.get('date',''),source_code=item['source'],source_url=item['url'],building_id=b.id,company_id=b.company_id,evidence_id=evidence.id,status=auth['status'],subject_name=item['developer'],location_text=item['address'],activity=auth.get('activity','привлечение денег дольщиков — заявленное основание'),notes='Связь по карточке ЖК; проверить покрытие конкретного блока/очереди и актуальность.')
    # Authoritative public company identifier from government procurement participant registry.
    prime=next((b for b in db.scalars(select(RegistryBuilding)).all() if b.building_key=='uka:'+keyify('ЖК Prime Home')),None)
    if prime:
        c=db.get(RegistryCompany,prime.company_id)
        insert_evidence(db,'goszakup','https://old.goszakup.gov.kz/ru/registry/show_supplier/387845','Государственный реестр закупок: ТОО «Финтэк-Астана», БИН 040640013971','official',company_id=c.id,raw_fields={'bin':'040640013971','name':'ТОО «Финтэк-Астана»'})
    db.commit();return added

def parse_csv(content:bytes):
    if len(content)>12_000_000: raise ValueError('CSV больше 12 МБ')
    for enc in ('utf-8-sig','utf-8','cp1251'):
        try:
            s=content.decode(enc)
            dialect=csv.Sniffer().sniff(s[:4096],delimiters=',;\t')
            return list(csv.DictReader(io.StringIO(s),dialect=dialect))
        except (UnicodeError,csv.Error):continue
    raise ValueError('Не удалось определить кодировку или разделитель CSV')

def import_buildings_csv(db,content:bytes,source_code:str):
    if source_code not in {s[0] for s in SOURCES}:raise ValueError('Неизвестный реестр')
    rows=parse_csv(content)
    if len(rows)>12000: raise ValueError('Слишком много строк')
    added=0; skipped=0
    for r in rows:
        name=clean(r.get('name') or r.get('ЖК') or r.get('Наименование ЖК'))
        address=clean(r.get('address') or r.get('Адрес'))
        url=clean(r.get('source_url') or r.get('url'))
        if not name or not address or not url.startswith('https://'):skipped+=1;continue
        city=clean(r.get('city') or 'Усть-Каменогорск')
        key='import:'+keyify(city)+':'+keyify(name)+':'+keyify(address)
        b=db.scalar(select(RegistryBuilding).where(RegistryBuilding.building_key==key))
        if b is None:
            dev=clean(r.get('developer') or r.get('Застройщик'))
            bin_value=clean(r.get('bin') or r.get('БИН'))
            # BIN from unknown CSV source is not recognized as confirmed legal identity.
            company=upsert_company(db,dev)
            b=RegistryBuilding(building_key=key,name=name,city=city,address=address,developer_label=dev,stage_reported=clean(r.get('stage') or 'unknown'),company_id=company.id if company else None)
            db.add(b);db.flush();added+=1
        insert_evidence(db,source_code,url,'Импорт CSV: запись о ЖК из указанного источника','imported_unverified',b.id,b.company_id,r)
    db.commit();return {'added':added,'skipped':skipped,'total':len(rows)}

def import_ashyq_rows(db,rows,source_url):
    added=0;skipped=0
    for r in rows:
        n=clean(r.get('permission_number') or r.get('Номер разрешения'))
        developer=clean(r.get('builder_name') or r.get('Застройщик'))
        location=clean(r.get('object_location') or r.get('Местоположение объекта'))
        if not n:skipped+=1;continue
        raw_bin=clean(r.get('builder_bin_hashed'))
        # DO NOT try to decode or match hashed BIN to clear legal entity.
        evidence=insert_evidence(db,'ashyq',source_url,'Исходная строка открытого набора разрешений МИО','official_dataset',raw_fields=r)
        _,created=insert_authorization(db,authorization_type='mio_equity_permit',document_number=n,issued_on=clean(r.get('issue_date')),source_code='ashyq',source_url=source_url,evidence_id=evidence.id,status='official_dataset_unmatched',subject_name=developer,location_text=location,activity='привлечение денег дольщиков',notes='Запись реестра не привязана к ЖК/БИН автоматически. Захешированный БИН несопоставим с открытым БИН.' + (' Хеш присутствует.' if raw_bin else ''))
        if created:added+=1
    db.commit();return {'added':added,'skipped':skipped,'total':len(rows)}

def building_payload(db,b):
    evidence=db.scalars(select(RegistryEvidence).where(RegistryEvidence.building_id==b.id)).all()
    auth=db.scalars(select(RegistryAuthorization).where(RegistryAuthorization.building_id==b.id)).all()
    company=db.get(RegistryCompany,b.company_id) if b.company_id else None
    return {'id':b.id,'name':b.name,'city':b.city,'address':b.address,'stage_reported':b.stage_reported,'stage_verified':b.stage_verified,'developer_label':b.developer_label,'company': {'id':company.id,'name':company.name,'bin':company.bin,'identity_status':company.legal_identity_status} if company else None,'commission_reported':b.commission_reported,'latitude':b.latitude,'longitude':b.longitude,'coordinate_source':b.coordinate_source,'evidence':[{'source':e.source_code,'url':e.source_url,'description':e.description,'level':e.evidence_level,'collected_on':e.collected_on} for e in evidence],'authorizations':[{'type':a.authorization_type,'number':a.document_number,'date':a.issued_on,'status':a.status,'activity':a.activity,'source_url':a.source_url,'notes':a.notes} for a in auth]}

AUTH_TYPES={
 'mio_equity_permit','kzhk_guarantee','bank_participation','construction_license',
 'design_license','survey_license','construction_start_notice','building_permit',
 'land_right','cadastral_record','commissioning_act','tax_status','legal_registration',
 'public_procurement_status','other_document'
}

def import_companies_csv(db:Session,content:bytes,source_code:str):
    if source_code not in {s[0] for s in SOURCES}:raise ValueError('Неизвестный источник')
    rows=parse_csv(content)
    if len(rows)>12000:raise ValueError('Превышен лимит строк')
    added=0;skipped=0
    for row in rows:
        name=clean(row.get('name') or row.get('Наименование') or row.get('company_name'))
        bin_value=clean(row.get('bin') or row.get('БИН'))
        url=clean(row.get('source_url') or row.get('url'))
        if not name or not re.fullmatch(r'\d{12}',bin_value) or not url.startswith('https://'):
            skipped+=1;continue
        key='bin:'+bin_value
        company=db.scalar(select(RegistryCompany).where(RegistryCompany.company_key==key))
        if company is None:
            company=RegistryCompany(company_key=key,name=name,bin=bin_value,entity_type='legal_entity',legal_identity_status='csv_needs_verification')
            db.add(company);db.flush();added+=1
        insert_evidence(db,source_code,url,'Импорт CSV: данные компании и БИН; подлинность строки требует проверки','imported_unverified',company_id=company.id,raw_fields=row)
    db.commit();return {'total':len(rows),'added':added,'skipped':skipped}


def import_documents_csv(db:Session,content:bytes,source_code:str):
    if source_code not in {s[0] for s in SOURCES}:raise ValueError('Неизвестный источник')
    rows=parse_csv(content)
    if len(rows)>12000:raise ValueError('Превышен лимит строк')
    added=0;skipped=0
    for row in rows:
        doc_type=clean(row.get('authorization_type') or row.get('document_type'))
        number=clean(row.get('document_number') or row.get('number'))
        url=clean(row.get('source_url') or row.get('url'))
        if doc_type not in AUTH_TYPES or not number or not url.startswith('https://'):
            skipped+=1;continue
        e=insert_evidence(db,source_code,url,'Импорт CSV: запись документа; необходима сверка оригинала','imported_unverified',raw_fields=row)
        _,created=insert_authorization(db,authorization_type=doc_type,document_number=number,source_code=source_code,source_url=url,evidence_id=e.id,status='imported_needs_verification',issued_on=clean(row.get('issued_on') or row.get('issue_date')),expires_on=clean(row.get('expires_on')),activity=clean(row.get('activity')),subject_name=clean(row.get('company_name') or row.get('developer')),location_text=clean(row.get('object_address') or row.get('address')),notes='БИН и название в импортированной строке не являются подтверждением связи документа с объектом. Требуется ручная сверка.')
        if created:added+=1
    db.commit();return {'total':len(rows),'added':added,'skipped':skipped}
