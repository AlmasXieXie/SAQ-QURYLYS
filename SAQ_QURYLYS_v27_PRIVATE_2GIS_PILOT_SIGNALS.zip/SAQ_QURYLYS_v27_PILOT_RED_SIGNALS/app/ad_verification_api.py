"""OCR, safe remote URL reading, and assessment of advertisements against project records."""
from __future__ import annotations
import hashlib
import html
import ipaddress
import os
import re
import socket
from html.parser import HTMLParser
from io import BytesIO
from urllib.parse import urljoin,urlsplit
from xml.etree import ElementTree as ET
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.v8_api import RegistryAd, check_url
from app.database import get_db
from app.ad_verification import verify_text

router=APIRouter(prefix='/api/v12',tags=['OCR и проверка рекламы'])
MAX_IMAGE=6*1024*1024
MAX_HTML=1_500_000

class TextRequest(BaseModel):
    text:str=Field(min_length=2,max_length=25000)
    source_url:str=Field(default='',max_length=2000)
    selected_project_id:int|None=None

class UrlRequest(BaseModel):
    url:str=Field(max_length=2000,min_length=10)
    extra_text:str=Field(default='',max_length=10000)

class PageParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.skip=0;self.parts=[];self.meta={};self.in_title=False;self.title=[]
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if tag in ('script','style','svg','noscript'):self.skip+=1
        if tag=='title':self.in_title=True
        if tag=='meta':
            k=(attrs.get('property') or attrs.get('name') or '').lower()
            if k in ('og:title','og:description','description','og:image','twitter:image'):
                self.meta[k]=attrs.get('content','')[:5000]
    def handle_endtag(self,tag):
        if tag in ('script','style','svg','noscript'):self.skip=max(0,self.skip-1)
        if tag=='title':self.in_title=False
    def handle_data(self,data):
        if self.skip:return
        if self.in_title:self.title.append(data)
        if data.strip():self.parts.append(data.strip())
    def get_text(self):
        parts=[' '.join(self.title)]+[self.meta.get(k,'') for k in ('og:title','og:description','description')]
        parts+=self.parts
        return ' '.join(parts)[:25000]


def public_url(url):
    try:
        p=urlsplit(url)
        if p.scheme not in ('https','http') or not p.hostname or p.username or p.password:return False
        host=p.hostname.lower().strip('.')
        if host in ('localhost','localhost.localdomain') or host.endswith(('.local','.internal','.localhost','.test')):return False
        if p.port and p.port not in (80,443):return False
        try:ips=[ipaddress.ip_address(host)]
        except ValueError:
            try:ips=[ipaddress.ip_address(x[4][0]) for x in socket.getaddrinfo(host,None,type=socket.SOCK_STREAM)]
            except (OSError,ValueError):return False
        return bool(ips) and all(x.is_global for x in ips)
    except (ValueError,TypeError):return False


def fetch_public(url,max_bytes=MAX_IMAGE):
    """Limit response size, redirects and URL hosts. No access to local/private networks."""
    import httpx
    current=url
    for _ in range(4):
        if not public_url(current):raise HTTPException(422,'Разрешены только публичные HTTP(S)-ссылки. Локальные и приватные адреса заблокированы.')
        try:
            # Disable environment proxies to avoid local network bypass, redirects handled manually.
            with httpx.Client(trust_env=False,follow_redirects=False,timeout=10,headers={'User-Agent':'SAQ-QURYLYS-evidence-review/1.0'}) as client:
                with client.stream('GET',current) as r:
                    if r.status_code in (301,302,303,307,308):
                        nxt=r.headers.get('location')
                        if not nxt:raise HTTPException(422,'Перенаправление без адреса')
                        current=urljoin(current,nxt);continue
                    if r.status_code>=400:raise HTTPException(422,f'Источник не отдал страницу: HTTP {r.status_code}. Загрузите скриншот или вставьте текст.')
                    ct=r.headers.get('content-type','').split(';')[0].lower()
                    if ct not in ('image/jpeg','image/png','image/webp','text/html','application/xhtml+xml'):
                        raise HTTPException(415,'Ссылка не ведёт на доступное изображение или HTML-страницу')
                    limit=MAX_HTML if ct.startswith(('text/','application/')) else max_bytes
                    chunks=[];size=0
                    for chunk in r.iter_bytes():
                        size+=len(chunk)
                        if size>limit:raise HTTPException(413,'Ответ источника слишком большой')
                        chunks.append(chunk)
                    return b''.join(chunks),ct,current
        except HTTPException:raise
        except (httpx.HTTPError, OSError) as exc:raise HTTPException(422,'Не удалось получить источник: '+type(exc).__name__) from exc
    raise HTTPException(422,'Слишком много перенаправлений')


def ocr_image(data):
    try:
        from PIL import Image,ImageOps,ImageEnhance
        import pytesseract
        # Locate the standard Windows binary even when it was not added to PATH.
        if os.name == 'nt':
            from pathlib import Path
            exe=os.getenv('SAQ_TESSERACT_PATH') or r'C:\Program Files\Tesseract-OCR\tesseract.exe'
            if Path(exe).is_file():pytesseract.pytesseract.tesseract_cmd=exe
        with Image.open(BytesIO(data)) as im:
            if im.width*im.height>24_000_000:raise HTTPException(413,'Изображение слишком большое по разрешению')
            if im.width<50 or im.height<50:raise HTTPException(422,'Изображение слишком маленькое')
            if im.format not in ('PNG','JPEG','WEBP'):raise HTTPException(415,'Формат изображения не поддерживается')
            im=ImageOps.exif_transpose(im).convert('RGB')
            if im.width<1200:
                im=im.resize((min(2400,im.width*2),min(4500,im.height*2)))
            gray=ImageEnhance.Contrast(ImageOps.grayscale(im)).enhance(1.3)
            try:return pytesseract.image_to_string(gray,lang='rus+eng+kaz',config='--psm 11').strip()
            except pytesseract.TesseractError:return pytesseract.image_to_string(gray,lang='rus+eng',config='--psm 11').strip()
    except HTTPException:raise
    except ImportError:raise HTTPException(503,'Модуль OCR не установлен: Pillow/pytesseract')
    except Exception as exc:
        if type(exc).__name__=='TesseractNotFoundError':raise HTTPException(503,'Tesseract OCR не установлен. Установите Tesseract с языками rus+eng (опционально kaz).')
        raise HTTPException(422,'Ошибка распознавания изображения: '+str(exc)[:180]) from exc


@router.post('/verify/text')
def text_check(body:TextRequest,db:Session=Depends(get_db)):
    
    try:return verify_text(body.text,db,source_url=body.source_url,selected_project_id=body.selected_project_id)
    except ValueError as exc:raise HTTPException(422,str(exc))

@router.post('/verify/screenshot')
async def screenshot_check(file:UploadFile=File(...), extra_text:str=Form(''), source_url:str=Form(''), db:Session=Depends(get_db)):
    if file.content_type not in ('image/jpeg','image/png','image/webp'):raise HTTPException(415,'Нужно изображение PNG, JPG или WEBP')
    raw=await file.read(MAX_IMAGE+1)
    if len(raw)>MAX_IMAGE:raise HTTPException(413,'Скриншот больше 6 МБ')
    detected=ocr_image(raw)
    if not detected.strip() and not extra_text.strip():raise HTTPException(422,'OCR не увидел текста. Попробуйте другой скриншот или добавьте текст вручную.')
    result=verify_text((detected+'\n'+extra_text).strip(),db,ocr_used=True,source_url=source_url.strip())
    result['image_sha256']=hashlib.sha256(raw).hexdigest()
    result['ocr_characters']=len(detected)
    return result

@router.post('/verify/url')
def url_check(body:UrlRequest,db:Session=Depends(get_db)):
    raw,content_type,final_url=fetch_public(body.url)
    image_url='';ocr_used=False
    if content_type.startswith('image/'):
        content=ocr_image(raw);image_url=final_url;ocr_used=True
    else:
        page=PageParser();page.feed(raw.decode('utf-8',errors='replace'))
        content=page.get_text()
        image_url=urljoin(final_url,page.meta.get('og:image','')) if page.meta.get('og:image') else ''
        # One explicitly advertised OG preview can contain banner text not present
        # in the HTML. Read no more than one image; failure is non-fatal.
        if image_url:
            try:
                preview,preview_type,_=fetch_public(image_url)
                if preview_type.startswith('image/'):
                    preview_text=ocr_image(preview)
                    if preview_text:
                        content+='\n'+preview_text
                        ocr_used=True
            except (HTTPException,ValueError,OSError):
                pass
    combined=(content+'\n'+body.extra_text).strip()
    if not combined:raise HTTPException(422,'На странице нет доступного текста. Скачайте скриншот и загрузите его.')
    result=verify_text(combined,db,source_url=body.url,image_url=image_url,ocr_used=ocr_used)
    result['fetched_url']=final_url
    result['retrieval_note']='Для HTML обработан текст страницы и, если доступно, одно OG-изображение через OCR; JavaScript, авторизация и антибот-защита не обходятся. Другие картинки в странице не сканируются.'
    return result

@router.post('/rss/import')
async def rss_import(file:UploadFile=File(...),save:bool=Form(False),db:Session=Depends(get_db)):
    """Import OLX-parser-produced RSS from an explicitly uploaded XML file; no third-party code embedded."""
    if not (file.filename or '').lower().endswith(('.xml','.rss')):raise HTTPException(415,'Загрузите RSS/XML файл')
    raw=await file.read(2_000_001)
    if len(raw)>2_000_000:raise HTTPException(413,'RSS больше 2 МБ')
    if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():raise HTTPException(422,'DTD/ENTITY запрещены')
    try:tree=ET.fromstring(raw)
    except ET.ParseError:raise HTTPException(422,'Неверный RSS/XML')
    items=tree.findall('.//item')[:100]
    if not items:items=tree.findall('.//{http://www.w3.org/2005/Atom}entry')[:100]
    results=[];inserted=0
    for item in items:
        title=(item.findtext('title') or item.findtext('{http://www.w3.org/2005/Atom}title') or '')
        desc=(item.findtext('description') or item.findtext('{http://www.w3.org/2005/Atom}summary') or '')
        link=item.findtext('link') or ''
        if not link:
            for a in item.findall('{http://www.w3.org/2005/Atom}link'):
                link=a.get('href','')
                if link:break
        html_parser=PageParser();html_parser.feed(desc)
        text=(title+' '+html_parser.get_text()).strip()
        if len(text)<3:continue
        found=verify_text(text,db,source_url=link)
        if save and check_url(link) and not db.scalar(select(RegistryAd).where(RegistryAd.url==link)):
            platform='olx' if 'olx.' in urlsplit(link).hostname.lower() else 'rss'
            rec=RegistryAd(building_id=found['project']['id'] if found['project'] else None,
                 platform=platform,url=link,text=text[:20000],status='pending')
            db.add(rec);db.flush();inserted+=1
        results.append({'url':link,'title':title[:250],'status':found['status'],
                        'project':found['project']['name'] if found['project'] else None,
                        'keywords':found['keywords'],'text':text[:1500]})
    if save:db.commit()
    return {'count':len(results),'saved':inserted,'processed':results,
            'note':('Записи сохранены со статусом проверки pending. ' if save else 'Предварительный анализ без сохранения. ')+
                   'Источник: предоставленная RSS-выгрузка, не независимая проверка доступности URL. Никаких автоматических юридических выводов.'}
