"""Verified corporate identities *by name*, with provenance.

These are not verified project-level SPV/authorized sales legal entities. Never
infer the right to collect share-construction deposits from the existence of BIN.
"""
from __future__ import annotations
from datetime import datetime, timezone
from sqlalchemy import select
from app.unified_registry import RegistryCompany, RegistryBuilding, keyify

# Corporate name or explicit catalog label -> legal BIN, official source, public name.
CORPORATE_BINS = {
    'Восток-Клио': ('040240001973','https://satypalu.gov.kz/kz/registry/show_supplier/216744','ТОО ВОСТОК-КЛИО'),
    'ATQ Corporate': ('210340024625','https://gosrating.com/gosreestr/210340024625','ТОО ATQ Corporate'),
    'ТОО ДСК-11': ('070540010413','https://ba.prg.kz/631010000-ust-kamenogorsk/070540010413-too-dsk-11/','ТОО ДСК-11'),
    'AN Groups': ('970340000010','https://old.goszakup.gov.kz/ru/registry/show_supplier/88690','ТОО AN Groups'),
    'Железобетонный комбинат': ('010340000498','https://old.goszakup.gov.kz/ru/registry/show_supplier/108335','ТОО Железобетонный комбинат'),
    'Tumar Group': ('040540018865','https://tumar-group.kz/company/','ТОО TUMAR Group'),
    'Орда Трейдинг / Tumar Group': ('040540018865','https://tumar-group.kz/company/','ТОО TUMAR Group (бренд; уполномоченная компания проекта может быть иной)'),
    'KZ155 Company': ('000540004862','https://www.goszakup.gov.kz/ru/register/supplierreg/show/373654','ТОО KZ155 Company'),
    'ТОО Elit Stroy group': ('190740008285','https://pro.mytenge.kz/company/190740008285','ТОО Elit Stroy group'),
    'ТОО OSKEMENBUILD': ('060940000280','https://www.goszakup.gov.kz/ru/registry/show_supplier/111249','ТОО OskemenBuild'),
    'ТОО VK Development group': ('160640005003','https://ppp.ecc.kz/ru/register/supplierreg/show/118448','ТОО VK development group'),
    'ТОО СК БЕКСТРОЙ 2050': ('050340011788','https://procurement.gov.kz/ru/registry/show_supplier/635007','ТОО СК БекСтрой 2050'),
    'ТОО НАУАН Корп': ('970640000190','https://www.homeportal.kz/ru/projects/1141','ТОО НАУАН Корп'),
    'Biryuza Development': ('171240023488','https://khc.kz/wp-content/uploads/2025/05/%D0%A0%D0%B5%D0%B5%D1%81%D1%82%D1%80-%D0%B4%D0%B5%D0%B9%D1%81%D1%82%D0%B2%D1%83%D1%8E%D1%89%D0%B8%D1%85-%D0%B4%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%BE%D0%B2-26.05.25.pdf','ТОО BIRYUZA DEVELOPMENT'),
    'TAZH Group Construction': ('110640001755','https://ba.prg.kz/631000300-menovnoe/110640001755-too-tazh-group-construction/','ТОО TAZH GROUP CONSTRUCTION'),
    'Премиум Строй НС': ('000940006645','https://ba.prg.kz/710000000-astana/000940006645-too-premium-stroy-ns/','ТОО Премиум Строй НС'),
}


def add_verified_company_bins(db):
    """Enrich by exact catalog entity label only; never associate a different company."""
    updated=0
    companies=db.scalars(select(RegistryCompany)).all()
    for c in companies:
        match=CORPORATE_BINS.get(c.name)
        if not match:continue
        number,source,legal_name=match
        if c.bin and c.bin!=number:continue
        if c.bin!=number:
            c.bin=number;updated+=1
        c.legal_identity_status='name_matched_official_source' if 'mytenge' not in source and 'prg.kz' not in source else 'name_matched_public_directory'
        c.notes=('Открытый БИН юридического лица с совпадающим названием. '+
                'НЕ подтверждает роль уполномоченной компании конкретного ЖК или наличие разрешения на привлечение денег. '+
                'Источник: '+source)
    if updated:db.commit()
    return {'updated':updated,'known':len(CORPORATE_BINS)}
