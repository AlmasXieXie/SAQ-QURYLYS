"""7 Sep 2026 UGAСК VKO public list, separate from numbered original permits.

Never manufacture permit numbers. Match explicitly curated project aliases only.
A permit for one project does not legalize a different phase or seller.
"""
from pathlib import Path
import json
from sqlalchemy import select
from app.unified_registry import (RegistryBuilding, RegistryAuthorization,
  insert_evidence, insert_authorization, keyify)
from app.registry_bridge import source_data

DATA=Path(__file__).resolve().parent.parent/'data'/'v26_uga_scoped_2026-09-07.json'


def registry_data():
    return json.loads(DATA.read_text(encoding='utf-8'))


def gov_keys():
    return {'uka:government:'+keyify(x['catalog_project']) for x in registry_data()['items']
        if x['catalog_project'] in ('ЖК TUMAR TOWERS OSKEMEN','ЖК BELGRAVIA','ЖК ECO POLIS','ЖК RENESANS')}


def seed_official_list(db):
    listing=registry_data(); report={'matched':[],'scoped':[],'added_projects':[]}
    for row in listing['items']:
        name=row['catalog_project']
        b=db.scalar(select(RegistryBuilding).where(RegistryBuilding.building_key=='uka:'+keyify(name)))
        if not b:
            b=db.scalar(select(RegistryBuilding).where(RegistryBuilding.building_key=='uka:government:'+keyify(name)))
        if not b:
            if ('uka:government:'+keyify(name)) not in gov_keys():
                report['scoped'].append(name);continue
            b=RegistryBuilding(building_key='uka:government:'+keyify(name),name=name,
                city='Усть-Каменогорск',address='Усть-Каменогорск (адрес требуется установить)',
                developer_label='Не установлен',stage_reported='construction_from_government_list',
                stage_verified='unknown',latitude=None,longitude=None)
            db.add(b);db.flush();report['added_projects'].append(name)
        # This is a September public list, not the permit itself, nor current-day verification.
        evidence=insert_evidence(db,'uga_vko',listing['source_url'],
            'Официальный перечень УГАСК ВКО: '+row['official_name']+'; способ '+row['legal_route'],
            'official_named_public_list',b.id,b.company_id,
            raw_fields={'official_name':row['official_name'],'route':row['legal_route'],
                        'date':listing['published_on'],'scope_confirmed':row['project_scope_confirmed']},
            collected_on=listing['published_on'])
        if row['legal_route']=='kzhk':
            # Detailed KZhK official row is already imported separately.
            report['matched'].append(name)
            continue
        status=('official_public_project_list' if row['project_scope_confirmed']
                else 'official_scoped_match')
        # Bank route requires the MIO permit, but the list does not give its number.
        notes=('Официальный перечень УГАСК ВКО от 07.09.2026; '+
             ('с участием БВУ' if row['legal_route']=='bank' else 'разрешение МИО')+
             '. Номер, дата выдачи и очередь НЕ опубликованы; проверить на homeportal.kz и в МИО. '+
             ('Публичное название SATTI CITY НЕ подтверждает автоматически очередь SATTI CITY 2.'
              if not row['project_scope_confirmed'] else ''))
        existing=db.scalar(select(RegistryAuthorization).where(
            RegistryAuthorization.building_id==b.id,
            RegistryAuthorization.authorization_type=='mio_equity_permit',
            RegistryAuthorization.source_code=='uga_vko'))
        if not existing:
            insert_authorization(db,authorization_type='mio_equity_permit',
                document_number='НЕ ОПУБЛИКОВАН (перечень УГАСК ВКО)',issued_on='',
                source_code='uga_vko',source_url=listing['source_url'],building_id=b.id,
                evidence_id=evidence.id,status=status,subject_name=row['official_name'],
                location_text=b.address,activity='долевое участие с БВУ' if row['legal_route']=='bank' else 'разрешение МИО',
                notes=notes)
        report['matched' if row['project_scope_confirmed'] else 'scoped'].append(name)
    db.commit();return report
