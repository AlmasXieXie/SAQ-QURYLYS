"""Automatic evidence-based links. No fabricated footprints."""
from fastapi import APIRouter, BackgroundTasks
from app import auto_buildings as ab

router=APIRouter(prefix='/api/v10',tags=['Автопривязка зданий'])

@router.get('/autolink/status')
def status():
    return ab.status()

@router.post('/autolink/start')
def start(tasks:BackgroundTasks):
    if ab.schedule():
        tasks.add_task(ab.run_all)
    return ab.status()

@router.get('/native/{feature_id}')
async def click_native(feature_id:str):
    return await ab.match_clicked(feature_id)
