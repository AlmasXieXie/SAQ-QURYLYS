"""Project-specific facts with explicit provenance. No inferred legal status.

Source is the *public Krisha listing* unless an official developer URL is shown.
Checked for the 2026-10-17 project snapshot. A stale planned commissioning
quarter is not evidence of a site being incomplete today.
"""

DEVELOPERS={
    'Железобетонный комбинат':{'site':'https://www.zhbk.kz/','project_page':'https://koktem-uk.kz/'},
    'Восток-Клио':{'bin':'040240001973','bin_source':'https://satypalu.gov.kz/kz/registry/show_supplier/216744','bin_role':'БИН юридического лица из госзакупок; отношение к отдельному корпусу и разрешению не подтверждено'},
    'ATQ Corporate':{'bin':'210340024625','bin_source':'https://gosrating.com/gosreestr/210340024625','bin_role':'БИН ТОО ATQ Corporate в открытом реестре; не подтверждает разрешение конкретного ЖК'},
    'ТОО ДСК-11':{'bin':'070540010413','bin_source':'https://ba.prg.kz/631010000-ust-kamenogorsk/070540010413-too-dsk-11/','bin_role':'БИН юридического лица по данным государственного реестра в агрегаторе; роль по ЖК не проверена'},
    'BS Holding':{'site':'https://bs-holding.kz/?page_id=35'},
    'AN Groups':{'site':'https://angroups.kz/','instagram':'https://www.instagram.com/an.groups/','bin':'970340000010','bin_source':'https://old.goszakup.gov.kz/ru/registry/show_supplier/88690','bin_role':'БИН компании с похожим наименованием; связь с юридическим лицом каждого ЖК не доказана'},
    'Tumar Group':{'site':'https://tumar-group.kz/','instagram':'https://www.instagram.com/tumar.oskemen/','bin':'040540018865','bin_source':'https://tumar-group.kz/','bin_role':'БИН указан на сайте девелопера; юридический застройщик отдельной очереди может отличаться'},
    'Железобетонный комбинат':{'site':'https://www.zhbk.kz/','bin':'010340000498','bin_source':'https://old.goszakup.gov.kz/ru/registry/show_supplier/108335','bin_role':'БИН юридического лица по госреестру; проверяйте роль компании по каждой очереди'},
    'KZ155 Company':{'bin':'000540004862','bin_source':'https://www.goszakup.gov.kz/ru/register/supplierreg/show/373654'},
    'ТОО Elit Stroy group':{'bin':'190740008285','bin_source':'https://pro.mytenge.kz/company/190740008285'},
    'ТОО OSKEMENBUILD':{'bin':'060940000280','bin_source':'https://www.goszakup.gov.kz/ru/registry/show_supplier/111249'},
    'ТОО VK Development group':{'site':'https://vkdevgroup.kz/','bin':'160640005003','bin_source':'https://ppp.ecc.kz/ru/register/supplierreg/show/118448'},
    'ТОО СК БЕКСТРОЙ 2050':{'bin':'050340011788','bin_source':'https://procurement.gov.kz/ru/registry/show_supplier/635007'},
    'ТОО НАУАН Корп':{'bin':'970640000190','bin_source':'https://www.homeportal.kz/ru/projects/1141'},
    'Премиум Строй НС':{'bin':'000940006645','bin_source':'https://ba.prg.kz/710000000-astana/000940006645-too-premium-stroy-ns/'},
    'TAZH Group Construction':{'bin':'110640001755','bin_source':'https://ba.prg.kz/631000300-menovnoe/110640001755-too-tazh-group-construction/'},
    'Biryuza Development':{'bin':'171240023488','bin_source':'https://khc.kz/wp-content/uploads/2025/05/%D0%A0%D0%B5%D0%B5%D1%81%D1%82%D1%80-%D0%B4%D0%B5%D0%B9%D1%81%D1%82%D0%B2%D1%83%D1%8E%D1%89%D0%B8%D1%85-%D0%B4%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%BE%D0%B2-26.05.25.pdf','site':'https://biryuza.kz/','project_page':'https://biryuza.kz/appartament/14'},
}
# Canonical grouping is for UI ONLY. It is not a corporate affiliation registry.
ALIASES={'Орда Трейдинг / Tumar Group':'Tumar Group','Biryuza Development':'Biryuza Development',
         'AN Groups':'AN Groups','Железобетонный комбинат':'Железобетонный комбинат'}

# Basic property parameters are typed as listings' claims, NOT verified data.
PROJECT_FACTS={
 'ЖК Diamond':{'data_warning':'КЖК 22.01.2026 описала гарантийный случай и незавершённое строительство. Прежняя геометка Diamond отозвана; адрес 2ГИС Увалиева 7стр и описание КЖК на перекрёстке Увалиева/Кокжал Барака следует сопоставлять отдельно. Нет подтверждения завершённости на октябрь 2026.', 'developer':'ATQ Corporate (указано в 2ГИС; юридическая роль не подтверждена)'},
 'ЖК Astoria':{'data_warning':'Сообщения 2026 года о проблемной стройке и возобновлении работ. Адрес 18а-в пересекается с адресами ЖК ASYLYM из Krisha: нельзя автоматически объединять объекты и корпуса. Текущая стадия не подтверждена.', 'developer':'ТОО «Дейнека» (по данным Korter; требуется проверка роли)'},
 'ЖК ASYLYM':{'data_warning':'Krisha указывает блоки Кокжал Барака 18а-в. Korter также указывает эти адреса ЖК Astoria. Связь корпусов с ЖК и владельцем требует первичного документа.'},
 'ЖК Easton':{'developer':'BS Holding','floors':'9','ceiling':'3.2 м','class':'бизнес','planned_handover':'IV квартал 2027','construction':'монолит','price_from_per_m2':'510 000 ₸'},
 'ЖК ORDA':{'developer':'CEO Group','floors':'9','apartments':'128','ceiling':'3 м','class':'бизнес','planned_handover':'IV квартал 2026','construction':'монолит','price_from_per_m2':'485 000 ₸','data_warning':'Адрес 17 на титульной странице Krisha и 19а в описании противоречат друг другу: геометка требует проверки очереди.'},
 'ЖК Viva Life':{'developer':'BTS Architects','floors':'9','apartments':'120','ceiling':'3 м','class':'комфорт','planned_handover':'IV квартал 2027','construction':'монолит','price_from_per_m2':'475 000 ₸','additional_permits':[{'type':'Участие БВУ','number':'597/МҚЗТ-К-83у','date':'08.05.2026','source':'https://krisha.kz/complex/show/ust-kamenogorsk/vivalife/'}]},
 'ЖК Altyn Uia 2':{'developer':'ALTYN UIA','floors':'9','apartments':'76','ceiling':'3 м','class':'бизнес','planned_handover':'III квартал 2026','construction':'монолит','price_from_per_m2':'409 000 ₸'},
 'ЖК Muztau':{'developer':'Премиум Строй НС','floors':'9','apartments':'85','ceiling':'3 м','class':'бизнес','planned_handover':'II квартал 2026','construction':'кирпич'},
 'ЖК Birinshi ui':{'developer':'KZ155 Company','floors':'5','apartments':'144','ceiling':'2.45 м','class':'эконом','planned_handover':'II квартал 2024','construction':'кирпич'},
 'ЖК Park Line':{'developer':'ТОО Elit Stroy group','floors':'9','apartments':'116','ceiling':'3 м','class':'комфорт','planned_handover':'Очереди: IV кв. 2024 / II кв. 2025 / II кв. 2026','construction':'монолит'},
 'ЖК Позиция 35':{'developer':'Компания Восток-Строй','floors':'9','apartments':'36','ceiling':'2.5 м','class':'эконом','planned_handover':'I квартал 2023','construction':'монолит'},
 'ЖК Emeralds':{'developer':'ATQ Corporate','floors':'7','apartments':'168','ceiling':'2.8 м','class':'комфорт','planned_handover':'IV квартал 2023','construction':'кирпич'},
 'ЖК Gran Via':{'data_warning':'Адрес Жибек жолы, 6/2 из Krisha расходится с Есенберлина, 43 и блоками в 2ГИС/kn.kz. Не сопоставлять точки без проверки.', 'developer':'TAZH Group Construction','floors':'5','apartments':'20','ceiling':'3 м','class':'бизнес','planned_handover':'II квартал 2023','construction':'кирпич'},
 'ЖК Green Leaf':{'developer':'ТОО VK Development group','floors':'12','apartments':'73','ceiling':'2.8 м','class':'бизнес','planned_handover':'III квартал 2023','construction':'монолит'},
 'ЖК Satti City 2':{'developer':'Satti','floors':'7','apartments':'108','ceiling':'3 м','class':'бизнес','planned_handover':'Очереди: IV кв. 2023 / IV кв. 2024 / IV кв. 2026','construction':'монолит'},
 'ЖК Коктем':{'developer':'Железобетонный комбинат','floors':'10','apartments':'74','ceiling':'2.75 м','class':'комфорт','planned_handover':'Очереди: II кв. 2022 / I кв. 2023 / II кв. 2024','construction':'монолит'},
 'ЖК Krilova':{'developer':'Железобетонный комбинат','floors':'9','apartments':'40','ceiling':'3 м','class':'комфорт','planned_handover':'II квартал 2023','construction':'монолит'},
 'ЖК Ulan-Tau':{'developer':'ТОО ДСК-11','floors':'9','apartments':'225','ceiling':'2.5 м','class':'бизнес','planned_handover':'I квартал 2023','construction':'монолит'},
 'ЖК Avenue':{'developer':'ТОО OSKEMENBUILD','floors':'9','apartments':'81','ceiling':'2.8 м','class':'бизнес','planned_handover':'III квартал 2022','construction':'монолит'},
 'ЖК Чистое небо':{'developer':'ТОО СК БЕКСТРОЙ 2050','floors':'5','apartments':'56','ceiling':'3 м','class':'бизнес','planned_handover':'IV квартал 2022','construction':'кирпич'},
 'ЖК Riviera Residence':{'developer':'Восток-Клио','floors':'5','apartments':'450','ceiling':'3 м','class':'эконом','planned_handover':'Очереди: IV кв. 1993 / II кв. 2018','construction':'монолит','data_warning':'По описанию и объявлению о продаже этот комплекс может быть давно сдан, хотя каталог относит его к «строящимся». Проверить фактическую стадию.'},
 'ЖК ЖАНЫМ':{'developer':'Biryuza Development','floors':'9','apartments':'126','ceiling':'3 м','class':'бизнес','planned_handover':'Очереди: I кв. 2025 / III кв. 2025','construction':'монолит'},
}

def decorate(payload):
    raw_label=payload.get('developer_label') or ''
    facts=PROJECT_FACTS.get(payload['name'],{})
    label=facts.get('developer') or raw_label
    company_group=ALIASES.get(label,label) or 'Не установлен'
    dev={**DEVELOPERS.get(company_group,{})}
    if dev.get('bin') and not dev.get('bin_role'):
        dev['bin_role']='БИН компании с совпадающим названием; договорная роль и разрешение на конкретный ЖК не установлены'
    dev.update({'name':company_group,'source_name':label, 'identity_level':'developer_brand_or_listing',
                'company_name':(payload.get('company') or {}).get('name'),
                'registered_bin':(payload.get('company') or {}).get('bin'),
                'registered_bin_status':(payload.get('company') or {}).get('identity_status')})
    project={k:v for k,v in facts.items() if k not in ('developer','additional_permits')}
    project['source']=('КЖК, официальное сообщение 22.01.2026' if payload['name']=='ЖК Diamond' else 'СМИ и коммерческий каталог Korter; стадия требует проверки' if payload['name']=='ЖК Astoria' else 'Krisha.kz (публичная карточка; требует независимой сверки)')
    return dev,project,facts.get('additional_permits',[])
