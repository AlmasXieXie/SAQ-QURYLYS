"""Evidence-oriented match of advertising against the real registry, not a legal verdict."""
from __future__ import annotations
import re
import unicodedata
from datetime import date
from urllib.parse import urlparse
from difflib import SequenceMatcher
from app.v8_api import catalog

EQUITY_TYPES = {'mio_equity_permit', 'kzhk_guarantee', 'bank_participation'}
# Words signalling possible collection of money, not proof of an unlawful transaction.
PAYMENT_PATTERNS = {
 'долевое участие': r'долев\w*\s+(?:участи\w*|строительств\w*)|дду\b|үлестік',
 'предоплата / аванс': r'предоплат\w*|аванс\w*|первоначальн\w*\s+взнос|алғашқы\s+жарна',
 'бронь': r'брони\w*|бронь|заброниров\w*',
 'рассрочка': r'рассроч\w*|бөліп\s+төлеу',
 'оплата / взнос': r'внес\w*\s+(?:деньг\w*|оплат\w*)|взнос\w*|оплат\w*|төлем',
 'продажа недвижимости': r'прода[её]т\w*|продаж\w*|купить\s+квартир\w*|покупк\w*\s+квартир\w*|пәтер\w*\s+сат',
}
CONSTRUCTION_RE = re.compile(r'стро[яийк]\w*|строительств\w*|котлован\w*|сдач\w*|срок\s+сдачи|дол[ьяе]\w*|новострой\w*|жаңа\s+үй|жк\b', re.I)


def normalize(text):
    s=unicodedata.normalize('NFKC', str(text or '')).casefold().replace('ё','е')
    s=re.sub(r'[^\w]+',' ',s,flags=re.UNICODE)
    return ' '.join(s.split())


def base_jk_name(name):
    return normalize(re.sub(r'^\s*(?:жилой\s+комплекс|жк|тұрғын\s+үй\s+кешені)\s*[«"\']?', '', name, flags=re.I))


def _word_match(needle, hay):
    if len(needle)<4:return False
    return bool(re.search(r'(?<!\w)'+re.escape(needle)+r'(?!\w)',hay))


def match_catalog(text, records):
    """Strict name matching; no fictitious confident matches for ambiguous short words."""
    hay=normalize(text)
    matches=[]
    for p in records:
        name=base_jk_name(p['name'])
        tokens=[t for t in name.split() if len(t)>=3]
        # Avoid generic single-word labels; only count their exact occurrences and require >=4 chars.
        if name and _word_match(name,hay):
            score=100
        elif len(tokens)>=2 and all(_word_match(t,hay) for t in tokens if len(t)>=4) and sum(len(t)>=4 for t in tokens)>=2:
            score=90
        else:continue
        matches.append({'id':p['id'],'name':p['name'],'score':score,'match':'точное упоминание названия'})
    # Match company only when linked to exactly one project in the catalog; otherwise no auto-identity.
    if not matches:
        groups={}
        for p in records:
            dev=p.get('developer') or {}
            n=normalize(dev.get('name','') if isinstance(dev,dict) else str(dev))
            if len(n)>=6 and n not in ('не установлен','застройщик не установлен'):
                groups.setdefault(n,[]).append(p)
        for name,items in groups.items():
            if len(items)==1 and _word_match(name,hay):
                p=items[0];matches.append({'id':p['id'],'name':p['name'],'score':65,'match':'только уникальное название девелопера; проверить объект'})
    matches.sort(key=lambda x:(-x['score'],x['name']))
    return matches


def assess_authorizations(project, payment_keywords, under_construction):
    records=(project.get('authorizations') or [])+(project.get('additional_permits') or [])
    eligible=[]
    for d in records:
        typ=d.get('type') or d.get('authorization_type') or ''
        if typ not in EQUITY_TYPES:continue
        source=d.get('source_url') or d.get('url') or ''
        src=d.get('source') or ''
        reported=d.get('status') or ''
        eligible.append({'type':typ,'number':d.get('number') or d.get('document_number') or '',
                         'status_in_registry':reported,'source_url':source,'source':src,
                         'date':d.get('date') or d.get('issued_on') or '',
                         'note':'Проверить срок, БИН уполномоченной компании, очередь и корпус ЖК.'})
    # Catalog/third-party claims do not establish a current legal right.
    if eligible:
        return ('documents_require_check','В реестре есть сведения об основаниях; действительность и применимость к этому ЖК/корпусу не подтверждены автоматически.',eligible)
    if not payment_keywords:
        return ('no_payment_signal','Не обнаружено прямого предложения привлечения денег. По скриншоту нельзя установить законность сделки.',[])
    return ('no_recorded_basis','В нашей базе нет связанного подтверждённого основания на привлечение денег дольщиков. Это НЕ означает, что разрешения нет в официальных реестрах.',[])


def verify_text(text, db, *,source_url='',image_url='',ocr_used=False,selected_project_id=None):
    content=(text or '').strip()
    if not content:raise ValueError('Не удалось извлечь текст — добавьте текст объявления вручную или загрузите более чёткий скриншот')
    entries=catalog(db)
    matches=match_catalog(content,entries)
    found={p['id']:p for p in entries}
    keywords=[name for name,rx in PAYMENT_PATTERNS.items() if re.search(rx,content,re.I)]
    # A sale listing alone (especially a finished apartment) does not imply an equity-payment offer.
    strong_keywords=[x for x in keywords if x!='продажа недвижимости']
    if re.search(r'без\s+предоплаты|без\s+аванса|бронь\s+не\s+требуется|предоплата\s+не\s+требуется',content,re.I):
        strong_keywords=[x for x in strong_keywords if x not in ('предоплата / аванс','бронь','оплата / взнос')]
    ongoing=bool(CONSTRUCTION_RE.search(content))
    selected=found.get(matches[0]['id']) if len(matches)==1 and matches[0]['score']>=80 else None
    if selected_project_id is not None:
        selected=found.get(int(selected_project_id))
        if not selected:raise ValueError('Выбранного ЖК нет в рабочем реестре')
    ambiguity=len(matches)>1 or (len(matches)==1 and matches[0]['score']<80)
    if selected:
        code,explain,docs=assess_authorizations(selected,strong_keywords,ongoing)
        if selected.get('stage_reported')=='commissioned':
            explain+=' В каталоге ЖК отмечен как сданный; отдельно установите, относится ли реклама к готовой квартире или к ещё строящейся очереди.'
    else:
        code='ambiguous_project' if ambiguity else 'project_not_identified'
        explain=('Обнаружено несколько возможных ЖК / только девелопер: выберите конкретный объект вручную.' if ambiguity else 'ЖК из нашего реестра не установлен: проверьте название, адрес и застройщика.')
        docs=[]
    return {
        'status':code,'explanation':explain,'project':{'id':selected['id'],'name':selected['name'],'address':selected['address'],
            'developer':selected.get('developer',{}),'stage_reported':selected.get('stage_reported','')} if selected else None,
        'candidates':matches[:12],'keywords':keywords,'construction_language':ongoing,
        'risk_signal':'requires_review' if strong_keywords else 'no_direct_payment_terms',
        'document_evidence':docs,'source_url':source_url,'image_url':image_url,'ocr_used':ocr_used,
        'text':content[:20000], 'selection_mode':'manual' if selected_project_id is not None else 'automatic', 'advice':'Проверить Homeportal / разрешения МИО / Qazreestr, БИН уполномоченной компании, действительность документа и применимость к корпусу/очереди. Скриншот не доказывает факт получения денег.',
        'disclaimer':'Автоматический анализ НЕ устанавливает нарушение, отсутствие разрешения или факт законного привлечения денег.'}
