"""Pilot decision policy for public advertisements about uncommissioned housing.

RED means: a priced, project-attributed 2026+ offer was found, but no applicable
official KZhK/MIO project authorization was confirmed in our LOCAL dated snapshot.
It does NOT assert official nationwide absence, criminality, or seller misconduct.

Keep this logic independent of evaluate_building to avoid recursive lookups.
"""
from __future__ import annotations
import re
from sqlalchemy import select

PILOT_POLICY = 'pilot_v27_open_registry_nonconfirmation'
# A number denoting floor, size, building year or permit is not an asking price.
CURRENCY_PRICE = re.compile(r'(?iu)(?<!\w)\d[\d\s\u00a0\u202f.,]{0,22}\s*(?:млн\.?|тыс\.?|миллион(?:ов|а)?|мың)?\s*(?:₸|тенге\b|тг\b|kzt\b)|(?<!\w)\d[\d\s\u00a0\u202f.,]{0,22}\s*₸')
NAMED_PRICE = re.compile(r'(?iu)\b(?:цена|стоимость|за\s+квартиру|бағасы|ценник)\s*[:\-]?\s*\d[\d\s\u00a0\u202f.,]{3,22}\s*(?:млн|тыс)?')


def priced_offer(text:str)->dict:
    text=text or ''
    match=CURRENCY_PRICE.search(text) or NAMED_PRICE.search(text)
    if not match:return {'found':False,'fragment':'','rule':'Числовая цена квартиры не распознана'}
    fragment=match.group(0).strip()
    return {'found':True,'fragment':fragment[:100], 'rule':'Найдена денежная цена в тексте объявления'}


def has_official_basis(linked:dict)->bool:
    # Historical/phase-scoped documents mean a separate check is required:
    # never treat them as proof that no document exists.
    return bool(linked.get('official_count',0))


def red_ad_candidate(ad,year:dict,linked:dict,decision:dict)->dict:
    price=priced_offer(ad.latest_text)
    reasons=[]
    if year.get('status')!='active':reasons.append('нет подтверждения строящегося ЖК со сдачей 2026+')
    if not ad.building_id or ad.attribution_level!='high':reasons.append('нет однозначной привязки к ЖК')
    if not price['found']:reasons.append('в сохранённом тексте не найдена цена')
    if has_official_basis(linked) or decision.get('authorization_verified'):
        reasons.append('найден официальный документ или основание на проверке')
    if linked.get('guarantee_event'):
        reasons.append('гарантийный случай КЖК: отдельный предупреждающий статус')
    return {'matches':not reasons,'price':price,'exclusions':reasons,'policy':PILOT_POLICY}


# Independent detection for an anonymous offer: do not lose it simply because
# the name-matcher cannot tie it to a project, or the project year is absent.
NEWBUILD_OFFER = re.compile(r'(?iu)\b(?:новостро\w*|строящ\w*|строительств\w*|от\s+застройщика|долев\w*\s+участ\w*|жк\b|жилой\s+комплекс|первичн\w*\s+(?:рынок|жиль\w*)|үлестік|жаңа\s+тұрғын)')

def anonymous_ad_signal(ad, year:dict, claimed_name:dict)->dict:
    """Red *investigation signal*, not an allegation of fraud.

    Explicitly reject old/commissioned ads. For unknown years, flag an
    anonymous priced newbuild in the separate Signals tab, not as a verified
    member of the 2026+ catalogue.
    """
    price=priced_offer(ad.latest_text)
    nameless=(not ad.building_id or ad.attribution_level!='high') and claimed_name.get('source')=='Нет надёжного названия ЖК'
    newbuild=bool(NEWBUILD_OFFER.search(ad.latest_text or ''))
    eligible_year=year.get('status')!='excluded' and not year.get('finished')
    matches=bool(price['found'] and nameless and newbuild and eligible_year)
    return {'matches':matches,'policy':PILOT_POLICY,'price':price,
        'newbuild_context':newbuild,'construction_year_status':year.get('status'),
        'reason':('В ценовом предложении новостройки не распознано название ЖК; '
                  'проверить объект, продавца и документы. Не доказательство мошенничества.')}


def unlinked_named_ad_signal(ad, year:dict, claimed_name:dict)->dict:
    """Named new-build ad not matched to a specific catalogue project.

    No invented affiliation and no finding of criminality.
    """
    price=priced_offer(ad.latest_text)
    named=claimed_name.get('source')=='Название заявлено в тексте, совпадение с реестром не установлено'
    return {'matches':bool(price['found'] and named and year.get('status')=='active'
                          and (not ad.building_id or ad.attribution_level!='high')),
            'price':price,'claimed_name':claimed_name.get('name',''),
            'policy':PILOT_POLICY}


def building_pilot_evidence(db,building,linked,base_decision):
    """Return the first qualifying already-observed advert without fabricating hits."""
    if (base_decision.get('map_color')=='green' or has_official_basis(linked)
        or linked.get('guarantee_event') or
        building.stage_verified=='commissioned' or building.stage_reported=='commissioned'):
        return None
    from app.ad_archive_v24 import PublicAd
    from app.ad_monitor_v25 import AdYearEvidence
    from app.ad_intelligence_v25 import year_from_listing
    for ad in db.scalars(select(PublicAd).where(PublicAd.building_id==building.id,
                         PublicAd.attribution_level=='high').order_by(PublicAd.last_seen.desc())):
        evidence=db.get(AdYearEvidence,ad.id)
        year=year_from_listing(ad.latest_text,evidence.completion_year if evidence else None)
        if year['status']=='review' and building.commission_reported:
            m=re.search(r'(?<!\d)(20(?:2[0-9]|3[0-9]|4[0-5]))(?!\d)',building.commission_reported)
            if m:year=year_from_listing(ad.latest_text,int(m.group(1)))
        if red_ad_candidate(ad,year,linked,base_decision)['matches']:
            return {'ad_id':ad.id,'ad_url':ad.url,'price':priced_offer(ad.latest_text)['fragment'],
                    'year':year['year'],'first_seen':ad.first_seen.isoformat() if ad.first_seen else '',
                    'source_kind':ad.source_kind,'platform':ad.platform}
    return None


def apply_project_pilot(db,building,base_decision,linked):
    candidate=building_pilot_evidence(db,building,linked,base_decision)
    result=dict(base_decision)
    result.update(pilot_policy=PILOT_POLICY,pilot_red_evidence=candidate,
                  pilot_registry_limit='Срез открытых реестров неполный; «не найден» не равно юридическому отсутствию.')
    if not candidate:return result
    result.update(map_color='red',map_status_label='Пилот: цена + ЖК 2026+ + основание не найдено',
          authorization_verified=False,authorization_basis='pilot_open_registry_not_found',
          basis_source='',decision_method=PILOT_POLICY,
          color_reason=('ПИЛОТНЫЙ КРАСНЫЙ: обнаружено ценовое предложение строящегося ЖК '
                        'со сдачей 2026+; в сохранённых открытых реестрах не найдено '
                        'подтверждённого основания КЖК или МИО по этому объекту. '
                        'Не является доказательством незаконной продажи или мошенничества. '
                        'Объявление: '+candidate['ad_url']))
    return result
