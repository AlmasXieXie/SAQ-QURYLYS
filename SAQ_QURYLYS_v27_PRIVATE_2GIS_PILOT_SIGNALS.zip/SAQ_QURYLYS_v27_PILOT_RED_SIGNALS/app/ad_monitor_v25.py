"""Ads 2026+ monitoring API. The live decision is calculated at read time.
Old captured listings remain in the evidence archive, never silently deleted.
"""
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import Integer, String, ForeignKey, select
from sqlalchemy.orm import Mapped, mapped_column, Session
from app.database import Base, get_db
from app.ad_archive_v24 import PublicAd, save_ad
from app.ad_attribution_v24 import canonical_url
from app.ad_intelligence_v25 import classify_ad

router=APIRouter(prefix='/api/v25',tags=['Мониторинг рекламы ЖК 2026+'])

class AdYearEvidence(Base):
    __tablename__='v25_ad_year_evidence'
    ad_id:Mapped[int]=mapped_column(ForeignKey('v24_public_ads.id'),primary_key=True)
    completion_year:Mapped[int]=mapped_column(Integer)
    source_note:Mapped[str]=mapped_column(String(250),default='Поле года сдачи из источника')

class NewPublication(BaseModel):
    url:str=Field(min_length=12,max_length=1500)
    text:str=Field(min_length=8,max_length=20000)
    account:str=Field(default='',max_length=200)
    posted_at:str=Field(default='',max_length=80)
    completion_year:int|None=Field(default=None,ge=2000,le=2045)

def ad_public(db,a):
    evidence=db.get(AdYearEvidence,a.id)
    status=classify_ad(db,a,year_override=evidence.completion_year if evidence else None)
    return {
        'id':a.id,'url':a.url,'platform':a.platform,'posted_at':a.posted_at or '',
        'first_seen':a.first_seen.isoformat() if a.first_seen else '',
        'last_seen':a.last_seen.isoformat() if a.last_seen else '',
        'seen_count':a.seen_count,'source_kind':a.source_kind,
        'publisher':a.publisher,'publisher_verified':False,
        'building_id':a.building_id,'organization':a.organization_label,'bin':a.organization_bin,
        'attribution_confidence':a.attribution_level,'attribution_reason':a.attribution_reason,
        'text':a.latest_text[:2200],
        **status,
    }

def get_all(db):
    # v24 is the permanent evidence log. 2026+ listing is a filtered projection.
    return [ad_public(db,a) for a in db.scalars(select(PublicAd).order_by(PublicAd.last_seen.desc())).all()]

@router.get('/ads')
def ads(view:str=Query(default='active',pattern='^(active|review|excluded|all|signals)$'),
        platform:str='',color:str='',limit:int=Query(default=500,ge=1,le=2000),db:Session=Depends(get_db)):
    entries=get_all(db)
    if view=='signals':entries=[x for x in entries if x['legal_assessment'].get('signal_queue')]
    elif view!='all':entries=[x for x in entries if x['year']['status']==view]
    if platform:entries=[x for x in entries if x['platform']==platform]
    if color:entries=[x for x in entries if x['legal_assessment']['color']==color]
    return entries[:limit]

@router.get('/ads/summary')
def summary(db:Session=Depends(get_db)):
    rows=get_all(db)
    return {'total':len(rows),'active':sum(x['year']['status']=='active' for x in rows),
       'review':sum(x['year']['status']=='review' for x in rows),
       'excluded':sum(x['year']['status']=='excluded' for x in rows),
       'signals':sum(x['legal_assessment'].get('signal_queue',False) for x in rows),
       'anonymous_signals':sum(x['legal_assessment'].get('anonymous_signal',{}).get('matches',False) for x in rows),
       'unlinked_signals':sum(x['legal_assessment'].get('unlinked_signal',{}).get('matches',False) for x in rows),
       'colors':{c:sum(x['year']['status']=='active' and x['legal_assessment']['color']==c for x in rows)
                 for c in ('green','yellow','red')},
       'platforms':{p:sum(x['platform']==p and x['year']['status']=='active' for x in rows)
                     for p in ('krisha','olx','instagram')},
       'note':'Год сдачи 2026+ должен следовать из текста или структурированного поля объявления. Даты публикации не считаются годом строительства. Неиндексируемые объявления не охвачены.'}

@router.post('/ads/ingest',status_code=201)
def ingest_one(body:NewPublication,db:Session=Depends(get_db)):
    if not canonical_url(body.url):
        raise HTTPException(422,'Нужна прямая ссылка на объявление OLX, Krisha или публикацию Instagram')
    a,created=save_ad(db,url=body.url,text=body.text,feed='Ручной ввод / доверенный импорт',
         account=body.account,posted_at=body.posted_at,source_kind='operator_submission',
         completion_year=body.completion_year)
    db.commit();db.refresh(a)
    return {'new':created,'ad':ad_public(db,a)}
