"""Real, opt-in official adapters. No scraping around access controls.

All external requests target fixed official HTTPS hosts (no user-controlled fetch URLs).
Tokens never enter logs or JSON responses. Findings always become pending evidence.
"""
from __future__ import annotations
import csv
import io
import os
import re
import xml.etree.ElementTree as ET
from urllib.parse import urlparse
import httpx

ASHYQ_CSV = ('https://magda-minio-web.data.gov.kz/magda-datasets/miir_kazreestr_permission_du/'
             '%D0%A0%D0%B0%D0%B7%D1%80%D0%B5%D1%88%D0%B5%D0%BD%D0%B8%D1%8F%20%D0%BD%D0%B0%20'
             '%D0%BF%D1%80%D0%B8%D0%B2%D0%BB%D0%B5%D1%87%D0%B5%D0%BD%D0%B8%D0%B5%20%D0%B4%D0%B5%D0%BD%D0%B5%D0%B3%20'
             '%D0%B4%D0%BE%D0%BB%D1%8C%D1%89%D0%B8%D0%BA%D0%BE%D0%B2.csv')
ASHYQ_PAGE = 'https://ashyq.data.gov.kz/dataset/magda-ds-b80110e9-218a-42ba-b8c8-01fa5e4c82c8'

class ConnectorError(Exception):
    pass


def _get(url: str, *, headers=None, params=None, limit=5_000_000) -> bytes:
    with httpx.Client(timeout=httpx.Timeout(22, connect=8), follow_redirects=False) as c:
        r = c.get(url, headers=headers, params=params)
        r.raise_for_status()
        if len(r.content) > limit:
            raise ConnectorError('Ответ превышает безопасный размер')
        return r.content


def permits_csv():
    """Actual public export, fields kept as-is; no auto-confirmation of legal status."""
    body = _get(ASHYQ_CSV, limit=5_000_000)
    for enc in ('utf-8-sig','cp1251'):
        try:
            txt = body.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise ConnectorError('Не удалось определить кодировку CSV')
    dialect = csv.Sniffer().sniff(txt[:2000], delimiters=',;\t')
    records = list(csv.DictReader(io.StringIO(txt), dialect=dialect))
    if not records or not any('permission' in k.lower() or 'разрешен' in k.lower() for k in records[0]):
        raise ConnectorError('Формат публичного CSV изменился — требуется проверка')
    return records[:12000]


def instagram_hashtags() -> list[dict]:
    """Meta Graph API hashtag search, for authorized professional accounts only.

    Uses a narrow configured list (max 5 tags per run); doesn't harvest all Instagram.
    """
    token=os.getenv('SAQ_IG_ACCESS_TOKEN','').strip()
    user=os.getenv('SAQ_IG_USER_ID','').strip()
    if not token or not user:
        raise ConnectorError('Требуются SAQ_IG_ACCESS_TOKEN и SAQ_IG_USER_ID (Meta Professional account)')
    if not user.isdigit():
        raise ConnectorError('Недопустимый Meta Instagram ID')
    tags = [x.strip().lstrip('#') for x in os.getenv('SAQ_IG_HASHTAGS','новостройкиустькаменогорск,жкустькаменогорск').split(',') if x.strip()]
    tags = [t for t in tags[:5] if re.fullmatch(r'[\wа-яА-ЯёЁ]{2,45}',t)]
    # Explicit version setting; no token in query in our logs.
    version=os.getenv('SAQ_META_GRAPH_VERSION', 'v24.0')
    if not re.fullmatch(r'v\d{1,2}\.0',version):
        raise ConnectorError('Версия Meta API некорректна')
    base=f'https://graph.facebook.com/{version}'
    headers={'Authorization':f'Bearer {token}'}
    found=[]
    for tag in tags:
        try:
            result = _get(base+'/ig_hashtag_search',headers=headers,
                          params={'user_id':user,'q':tag},limit=200_000)
            import json
            results=json.loads(result).get('data',[])
            if not results:
                continue
            tag_id=str(results[0]['id'])
            if not tag_id.isdigit():
                continue
            posts=json.loads(_get(base+f'/{tag_id}/recent_media', headers=headers,
                                   params={'user_id':user,'fields':'id,caption,permalink,timestamp,media_type','limit':25},limit=400_000)).get('data',[])
            for item in posts:
                caption=str(item.get('caption') or '').strip()
                url=str(item.get('permalink') or '')
                if caption and url.startswith('https://www.instagram.com/'):
                    found.append({'platform':'instagram','account':'#'+tag,'source_url':url,
                                  'posted_at':str(item.get('timestamp') or ''),'text':caption})
        except (httpx.HTTPError, ValueError, KeyError) as exc:
            raise ConnectorError(f'Ошибка Meta API при поиске #{tag}: {type(exc).__name__} (проверьте доступ/разрешения)') from None
    return found


def olx_account_ads() -> list[dict]:
    """Fetch authorized account's adverts using OLX Partner API v2, NOT platform-wide search."""
    token=os.getenv('SAQ_OLX_ACCESS_TOKEN','').strip()
    if not token:
        raise ConnectorError('Требуется SAQ_OLX_ACCESS_TOKEN (OAuth пользователя OLX Partner API)')
    headers={'Authorization':f'Bearer {token}', 'Version':'2.0', 'Accept':'application/json'}
    try:
        import json
        payload=json.loads(_get('https://www.olx.kz/api/partner/adverts', headers=headers,
                                params={'offset':0,'limit':50}, limit=800_000))
        results=payload.get('data',[]) if isinstance(payload,dict) else payload
        if not isinstance(results,list):
            raise ConnectorError('OLX вернул неожиданный формат')
        items=[]
        for row in results[:50]:
            if not isinstance(row,dict):
                continue
            url=str(row.get('url') or '')
            if url and not url.startswith('https://'):
                continue
            txt=(str(row.get('title') or '')+'\n'+re.sub('<[^>]+>', ' ',str(row.get('description') or ''))).strip()
            if txt:
                items.append({'platform':'olx','account':'OAuth владелец объявления', 'source_url':url,
                              'posted_at':str(row.get('created_at') or ''), 'text':txt})
        return items
    except (httpx.HTTPError, ValueError, KeyError) as exc:
        raise ConnectorError(f'Ошибка OLX Partner API: {type(exc).__name__} (проверьте OAuth-права)') from None


def source_status():
    return [
      {'id':'ashyq','name':'Ashyq Data — разрешения МИО', 'url':ASHYQ_PAGE,'mode':'public_csv','configured':True,'scope':'Публичный реестр. Отсутствие совпадения ≠ отсутствие разрешения.'},
      {'id':'instagram','name':'Instagram / Meta Graph', 'url':'https://developers.facebook.com/docs/instagram-platform/', 'mode':'authorized_api',
       'configured':bool(os.getenv('SAQ_IG_ACCESS_TOKEN') and os.getenv('SAQ_IG_USER_ID')),'scope':'Доступные по разрешениям Meta публикации по выбранным хештегам, не все объявления.'},
      {'id':'olx','name':'OLX.kz Partner API', 'url':'https://developer.olx.kz/api/doc', 'mode':'authorized_api',
       'configured':bool(os.getenv('SAQ_OLX_ACCESS_TOKEN')),'scope':'Только объявления авторизованного аккаунта, не все объявления OLX.'},
      {'id':'rss','name':'RSS/Atom открытых площадок', 'url':'https://www.rssboard.org/rss-specification','mode':'optional_feed',
       'configured':bool(os.getenv('SAQ_RSS_FEED_URL')),'scope':'Только согласованный открытый RSS/Atom источник, заданный администратором.'},
    ]


def rss_items():
    """RSS from admin-configured HTTPS feed, not a bulk crawler of arbitrary user URLs."""
    url=os.getenv('SAQ_RSS_FEED_URL','').strip()
    p=urlparse(url)
    if not url or p.scheme!='https' or not p.hostname:
        raise ConnectorError('Нужен разрешённый HTTPS RSS: SAQ_RSS_FEED_URL')
    # Prevent SSRF to local-network, metadata endpoints, or internal hostnames.
    if (p.hostname in {'localhost','127.0.0.1','::1'} or p.hostname.endswith(('.local','.internal','.test')) or
        re.fullmatch(r'\d+\.\d+\.\d+\.\d+',p.hostname)):
        raise ConnectorError('Недопустимый хост RSS')
    # More robust restriction: operator must separately specify the exact external hostname.
    if p.hostname.lower()!=os.getenv('SAQ_RSS_ALLOWED_HOST','').strip().lower():
        raise ConnectorError('Для RSS необходимо задать SAQ_RSS_ALLOWED_HOST с разрешённым доменом')
    try:
        data=_get(url,limit=800_000)
        root=ET.fromstring(data)
        items=[]
        for item in list(root.findall('.//item'))[:60]:
            def get(name):return (item.findtext(name) or '').strip()
            title=get('title');text=(title+'\n'+re.sub('<[^>]+>',' ',get('description'))).strip()
            link=get('link');pub=get('pubDate')
            if link.startswith('https://') and text:
                items.append({'platform':'rss','account':p.hostname,'source_url':link,'text':text,'posted_at':pub[:30]})
        # Atom (where feeds are licensed for reuse). Namespace-aware fallback.
        ns={'a':'http://www.w3.org/2005/Atom'}
        for entry in root.findall('.//a:entry',ns)[:60]:
            title=(entry.findtext('a:title',default='',namespaces=ns) or '').strip()
            summary=(entry.findtext('a:summary',default='',namespaces=ns) or entry.findtext('a:content',default='',namespaces=ns) or '').strip()
            link=next((e.attrib.get('href','') for e in entry.findall('a:link',ns) if e.attrib.get('rel','alternate')=='alternate'), '')
            pub=entry.findtext('a:updated',default='',namespaces=ns) or ''
            txt=(title+'\n'+re.sub('<[^>]+>', ' ', summary)).strip()
            if link.startswith('https://') and txt:
                items.append({'platform':'rss','account':p.hostname,'source_url':link,'text':txt,'posted_at':pub[:30]})
        return items[:60]
    except (httpx.HTTPError, ValueError, ET.ParseError) as exc:
        raise ConnectorError(f'Не удалось прочитать RSS: {type(exc).__name__}') from None
