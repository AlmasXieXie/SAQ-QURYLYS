"""v9: evidence-linked construction geometries and 2GIS vector-building IDs.

A 2GIS feature ID selects a native rendered map object, NOT its downloadable
footprint. An OSM construction polygon is a mapping claim, NOT a verified
current construction status or legal/nonlegal determination. Associations are
explicit analyst judgements with source and audit timestamp.
"""
from __future__ import annotations
from datetime import datetime, timezone
import re
from urllib.parse import urlparse
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import Integer, String, ForeignKey, JSON, DateTime, select
from sqlalchemy.orm import Mapped, mapped_column, Session
from app.database import Base, get_db
from app.extra_problem_sites import all_real_keys as catalog_keys
from app.unified_registry import RegistryBuilding
from app.geo_zones import construction_zones

router = APIRouter(prefix='/api/v9', tags=['Геометрия зданий'])

class GeometryLink(Base):
    __tablename__ = 'saq_geometry_links'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    building_id: Mapped[int] = mapped_column(ForeignKey('unified_buildings.id'),index=True)
    provider: Mapped[str] = mapped_column(String(16),index=True)   # osm or 2gis
    feature_id: Mapped[str] = mapped_column(String(90),index=True)
    polygon: Mapped[dict|None] = mapped_column(JSON,nullable=True)
    position: Mapped[list|None] = mapped_column(JSON,nullable=True)
    source_url: Mapped[str] = mapped_column(String(600))
    linked_by: Mapped[str] = mapped_column(String(120))
    association_method: Mapped[str] = mapped_column(String(50),default='analyst_visual')
    note: Mapped[str] = mapped_column(String(400),default='')
    linked_at: Mapped[datetime] = mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))

class LinkRequest(BaseModel):
    building_id: int
    provider: str
    feature_id: str = Field(min_length=1,max_length=90)
    linked_by: str = Field(min_length=2,max_length=120)
    note: str = Field(default='',max_length=400)
    source_url: str = Field(default='',max_length=600)
    click_coordinates: list[float] | None = None

class UnlinkRequest(BaseModel):
    linked_by: str = Field(min_length=2,max_length=120)


def local_polygon(poly):
    """Reject placeholders, point circles and shapes outside the actual city."""
    if not isinstance(poly,dict) or poly.get('type')!='Polygon':return False
    rings=poly.get('coordinates')
    if not isinstance(rings,list) or len(rings)!=1:return False
    ring=rings[0]
    if not isinstance(ring,list) or len(ring)<4 or len(ring)>1000 or ring[0]!=ring[-1]:return False
    try:
        if not all(isinstance(pt,list) and len(pt)==2 and 82.2<=pt[0]<=83.05 and 49.65<=pt[1]<=50.25 for pt in ring):return False
    except (TypeError,ValueError):return False
    return len({(x,y) for x,y in ring})>=3


def validate_source(url):
    u=urlparse(url)
    return u.scheme=='https' and bool(u.hostname)


def link_out(row):
    return {'id':row.id,'building_id':row.building_id,'provider':row.provider,'feature_id':row.feature_id,
            'polygon':row.polygon,'position':row.position,'source_url':row.source_url,'linked_by':row.linked_by,
            'association_method':row.association_method,'note':row.note,
            'linked_at':row.linked_at.isoformat() if row.linked_at else None,
            'accuracy':'analyst_association_not_independently_verified'}

@router.get('/links')
def links(db:Session=Depends(get_db)):
    keys=catalog_keys()
    valid={b.id for b in db.scalars(select(RegistryBuilding)).all() if b.building_key in keys}
    return [link_out(r) for r in db.scalars(select(GeometryLink).order_by(GeometryLink.id)).all() if r.building_id in valid]

@router.get('/construction')
def construction(refresh:bool=False):
    """OSM buildings explicitly tagged as construction, plus construction landuse.
    Query is live or cached via Overpass; never return invented geometry.
    """
    return construction_zones(refresh=refresh)

@router.post('/links', status_code=201)
def create_link(req:LinkRequest, db:Session=Depends(get_db)):
    b=db.get(RegistryBuilding,req.building_id)
    if not b or b.building_key not in catalog_keys():
        raise HTTPException(422,'ЖК не входит в реальный каталог')
    if req.provider not in ('2gis','osm'):raise HTTPException(422,'Неподдерживаемый источник')
    feature_id=req.feature_id.strip()
    if not re.fullmatch(r'[0-9]{1,32}',feature_id):
        raise HTTPException(422,'Нужен цифровой ID настоящего объекта карты')
    other=db.scalar(select(GeometryLink).where(GeometryLink.provider==req.provider,GeometryLink.feature_id==feature_id))
    if other:
        if other.building_id==b.id:return link_out(other)
        raise HTTPException(409,'Этот контур уже связан с другим ЖК. Сначала проверьте данные.')
    if req.provider=='osm':
        zone=construction_zones()
        feature=next((f for f in zone['features'] if str(f['properties']['osm_id'])==feature_id),None)
        if not feature:raise HTTPException(422,'OSM-контур не найден в загруженной карте города')
        poly=feature['geometry']
        if not local_polygon(poly):raise HTTPException(422,'Контур неправильный или выходит за границы города')
        url=feature['properties']['source_url']
        position=None
    else:
        # 2GIS native vector object IDs are never assumed to equal Geocoder IDs.
        # User has to select the actual building directly on the rendered 2GIS map.
        poly=None
        position=req.click_coordinates
        if not isinstance(position,list) or len(position)!=2 or not (82.2<=position[0]<=83.05 and 49.65<=position[1]<=50.25):
            raise HTTPException(422,'Нужны координаты клика по зданию 2ГИС в Усть-Каменогорске')
        url=req.source_url.strip()
        if not validate_source(url) or urlparse(url).hostname not in ('2gis.kz','2gis.ru'):
            raise HTTPException(422,'Нужна ссылка на выбранный объект или карту 2ГИС')
    row=GeometryLink(building_id=b.id,provider=req.provider,feature_id=feature_id,
        polygon=poly,position=position,source_url=url,linked_by=req.linked_by.strip(),
        note=req.note,association_method='analyst_visual')
    db.add(row);db.commit();db.refresh(row)
    return link_out(row)

@router.delete('/links/{link_id}')
def unlink(link_id:int,body:UnlinkRequest,db:Session=Depends(get_db)):
    row=db.get(GeometryLink,link_id)
    if not row:raise HTTPException(404,'Привязка не найдена')
    db.delete(row);db.commit()
    return {'deleted':True,'link_id':link_id,'reviewer':body.linked_by}
