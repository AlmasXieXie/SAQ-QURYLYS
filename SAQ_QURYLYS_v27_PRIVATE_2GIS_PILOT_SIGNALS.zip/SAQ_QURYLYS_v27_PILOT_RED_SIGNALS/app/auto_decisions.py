"""Explainable, project-scoped automatic display decisions.

These statuses are a risk-triage aid, never permission for an actual payment.
Advertising for a project with verified equity fundraising grounds should not
become yellow solely because it advertises housing or mentions deposits.
"""
from __future__ import annotations
import re

VERIFIED_MANUAL = {'verified_guarantee', 'verified_mio', 'verified_bank'}
NEGATIVE_MANUAL = {'verified_absent'}
INDEPENDENT_RISKS = {'R4', 'R5', 'R6'}
# KZhK public entry for Zolotoy Kvadrat covers "Пятно 1", not other spots.
OTHER_SPOT = re.compile(r'(?iu)\bпятн(?:о|а|е|у|ом)\s*(?:№\s*)?([0-9]+)\b')


def decide_project(case: dict, legal: dict, linked: dict) -> dict:
    """One single decision for map, registry, case, and ads.

    Never propagate legal coverage from a company BIN to all its buildings.
    Preserve legally serious complaints/delays and human legal conflicts.
    Only ad-wording-related preliminary factors may be outweighed by a verified
    applicable authorization.
    """
    status = (legal or {}).get('status', 'unknown')
    has_manual_evidence = bool((legal or {}).get('evidence_url') or (legal or {}).get('source'))
    official = bool(linked.get('eligible_green'))
    manual = status in VERIFIED_MANUAL and has_manual_evidence
    basis = official or manual
    factor_codes = set(case.get('confirmed_factor_codes') or []) or {f.get('code') for f in (case.get('risk', {}).get('factors', [])
                                           or case.get('factors', []))}
    red = case.get('zone') == 'red' and case.get('score', 0) >= 60
    conflict = status in NEGATIVE_MANUAL or 'R1' in factor_codes
    guarantee_event = linked.get('guarantee_event', False)
    other_risk = bool(factor_codes & INDEPENDENT_RISKS)
    if red:
        color = 'red'; reason = 'Приоритетный сигнал: документально подтверждённый риск R1 + R2. Это не заключение о нарушении; необходима проверка аналитика.'
    elif guarantee_event:
        color = 'yellow'; reason = 'Зафиксирован гарантийный случай КЖК. Наличие старой гарантии не снимает проблем строительства.'
    elif conflict:
        color = 'yellow'; reason = 'Имеется противоречащая правовая проверка. Сопоставьте объект, срок и документ.'
    elif other_risk:
        color = 'yellow'; reason = 'Независимые подтверждённые факторы стройки (обращение, готовность, задержка) требуют проверки.'
    elif basis:
        color = 'green'
        reason = ('Для этого ЖК найдено официальное основание привлечения средств дольщиков;'
                  ' рекламные слова о продаже или взносе сами по себе не нарушение.'
                  ' Перед оплатой проверить очередь/корпус и зарегистрированный ДДУ.')
    elif case.get('zone') == 'yellow' or case.get('score', 0) >= 25 or case.get('triage_score', 0) >= 25 or (case.get('pending_ads', 0)>0 and case.get('triage_score', 0)>=10):
        color = 'yellow'; reason = 'Есть непроверенная реклама или факторы риска. Основание долевого участия пока не подтверждено.'
    else:
        color = 'yellow'; reason = ('Нет подтверждённого применимого основания в локальном срезе.'
                                    ' Это НЕ доказательство незаконного строительства.')
    source = ((legal or {}).get('evidence_url') or (legal or {}).get('source')) if manual else ''
    source = source or next((d.get('source') for d in linked.get('docs', []) if d.get('status') in ('official_public_project_list','official_project_match')), '')
    return {
        'map_color':color,'color_reason':reason,
        'map_status_label':('Подтверждённый высокий риск' if color=='red' else
                            'Право привлечения дольщиков подтверждено' if color=='green' else
                            'Гарантийный случай КЖК' if guarantee_event else
                            'Конфликт документов' if conflict else
                            'Другие подтверждённые риски' if other_risk else
                            'Проверить рекламу и документы'),
        'authorization_verified':color=='green',
        'authorization_basis':('official_uga_project_list' if official and linked.get('official_public_list') else 'kzhk_project_document' if official else 'analyst_verified_document' if manual else 'unverified'),
        'basis_source':source, 'source_as_of':linked.get('source_as_of'),
        'decision_scope':linked.get('scope') or 'Конкретный объект, указанный в проверенном документе',
        'decision_method':'deterministic_v23_project_specific',
    }


def decide_ad(ad:dict, decision:dict, linked:dict) -> dict:
    """Classify only an explicitly matched ad; no brand-only legal inheritance.

    A project-level green label does not certify an advertiser or an individual
    contract. Advertising for different declared spots must not inherit green.
    """
    if not ad.get('building_id'):
        return {'color':'yellow','label':'ЖК не сопоставлен','reason':'Нужна привязка объявления к конкретному ЖК и корпусу.'}
    if decision.get('map_color') != 'green':
        return {'color':decision.get('map_color', 'yellow'),'label':'Нужна проверка основания',
                'reason':decision.get('color_reason','Нет подтверждённого основания для объекта.')}
    text = ad.get('text','') or ''
    if linked.get('status') == 'official_project' and 'Пятно 1' in (linked.get('scope') or ''):
        if any(int(m.group(1)) != 1 for m in OTHER_SPOT.finditer(text)):
            return {'color':'yellow','label':'Очередь не покрыта документом',
                    'reason':'Документ КЖК относится к пятну 1; объявление указывает другое пятно.'}
    return {'color':'green','label':'Основание по ЖК подтверждено',
            'reason':'Объявление относится к ЖК с проверенным проектным основанием. Продавец, корпус и ДДУ требуют отдельной сверки.'}


def evaluate_building(db, building):
    """Compute a fresh server-side answer for reuse in all registries."""
    from sqlalchemy import select
    from app.workbench import case_out, LegalCheck
    from app.registry_bridge import official_sources_for
    case = case_out(db, building)
    lc = db.scalar(select(LegalCheck).where(LegalCheck.building_id == building.id))
    linked = official_sources_for(db, building)
    decision = decide_project(case, {'status': lc.status if lc else 'unknown',
                                     'evidence_url': lc.evidence_url if lc else ''}, linked)
    from app.pilot_rules_v27 import apply_project_pilot
    return apply_project_pilot(db, building, decision, linked), linked
