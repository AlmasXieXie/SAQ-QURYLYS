"""V25: target-year gate + project-grounded advertisement colour.

Explicit estimated commissioning/construction year >=2026 is required for active
monitoring. A posting date or permit document date is NOT a building year.
An ad pointing at a project with a verified legal basis is NOT a contract safety
certificate. Missing evidence in a limited public snapshot triggers PILOT red only for priced, matched 2026+ ads; this is never a finding of fraud.
"""
from __future__ import annotations
import re
from datetime import date
from sqlalchemy import select
from app.auto_decisions import evaluate_building,decide_ad
from app.ad_verification import PAYMENT_PATTERNS
from app.unified_registry import RegistryBuilding
from app.pilot_rules_v27 import red_ad_candidate, anonymous_ad_signal, unlinked_named_ad_signal, priced_offer, PILOT_POLICY

START_YEAR=2026
END_YEAR=2045
YEAR=r'(?:20(?:2[0-9]|3[0-9]|4[0-5]))'
# Require the year to be semantically attached to construction, handover,
# commissioning or planned completion, NOT just present in the listing.
YEAR_PATTERNS=(
 re.compile(r'(?iu)\b(?:срок[иа]?\s+)?(?:сдач[иауы]|ввод[ауы]?\s+в\s+эксплуатацию|срок\s+завершения|год\s+постройки|год\s+сдачи|планируемая\s+сдача|готовность|завершение\s+строительства|построен\s+в|построено\s+в|салынған\s+жылы|тапсыру\s+мерзімі)\b[\s\S]{0,55}?\b('+YEAR+r')\b'),
 re.compile(r'(?iu)\b('+YEAR+r')\s*(?:г\.?|год[а-я]*|жыл[ы]?)?\s*[,.;:]?\s*(?:года?\s+)?(?:постройки|сдач[иа]|ввод[ауы]?\s+в\s+эксплуатацию|тапсыру)\b'),
 re.compile(r'(?iu)\b(?:[1-4]|I|II|III|IV)\s*(?:кв(?:артал)?\.?|тоқсан)\s*('+YEAR+r')\b'),
)
FINISHED = re.compile(r'(?iu)\b(?:дом\s+сдан|жк\s+сдан|жилой\s+комплекс\s+сдан|ключи\s+на\s+руках|введ[её]н\s+в\s+эксплуатацию|вторичк[а-я]*|вторичное\s+жилье)\b')
SALE = re.compile(r'(?iu)(?:предоплат\w*|аванс\w*|бронь|бронир\w*|первоначальн\w*\s+взнос|дду\b|долев\w*\s+участ|оплат\w*|инвестирован\w*|рассроч\w*|жарна|үлестік)')
EXPLICIT_NO_PAYMENT = re.compile(r'(?iu)\b(?:без\s+(?:предоплаты|аванса)|бронь\s+не\s+требуется|предоплата\s+не\s+требуется)\b')
NAMED_JK = re.compile(r'(?iu)\b(?:жк|жилой\s+комплекс|тұрғын\s+үй\s+кешені)\s*[«"\']?([a-zа-яёәіңғүұқөһ0-9][a-zа-яёәіңғүұқөһ0-9\s-]{1,65})')

def year_from_listing(text:str,explicit_year=None)->dict:
    """Eligible only when commissioning year is explicitly attested.
    Unknown (including old index snippets) goes to review, not active.
    """
    content=str(text or '')
    hits=[]
    if explicit_year is not None and str(explicit_year).strip():
        try:
            year=int(explicit_year)
            if 2000<=year<=END_YEAR:hits.append((year,'Год сдачи из структурированного поля источника'))
        except (ValueError,TypeError):pass
    for regex in YEAR_PATTERNS:
        for match in regex.finditer(content):
            hits.append((int(match.group(1)),match.group(0).strip()[:130]))
    years={year for year,_ in hits}
    finished=bool(FINISHED.search(content))
    if not years:
        return {'status':'review','year':None,'evidence':'Год сдачи/постройки не подтверждён; дата публикации не учитывается',
                'finished':finished,'years':[]}
    if len(years)>1:
        return {'status':'review','year':None,'evidence':'Обнаружены противоречивые годы строительства/сдачи: '+', '.join(map(str,sorted(years))),
                'finished':finished,'years':sorted(years)}
    year=next(iter(years))
    evidence=next(src for val,src in hits if val==year)
    if year<START_YEAR:
        status='excluded';evidence+='; до 2026 года'
    elif finished:
        status='excluded';evidence+='; объявление описывает уже сданную/вторичную квартиру'
    else:
        status='active'
    return {'status':status,'year':year,'evidence':evidence,'finished':finished,'years':[year]}


def name_from_text(text:str, matched_name:str='')->dict:
    """Keep exact legal/project linkage distinct from claimed names in free text."""
    if matched_name:
        return {'name':matched_name,'source':'Точное совпадение в реестре ЖК'}
    m=NAMED_JK.search(text or '')
    if m:
        raw=m.group(1).strip().split('\n')[0]
        raw=re.split(r'\s*(?:[,;.!?]|\s+—\s+|\s+[-–]\s+|\s+(?:квартир[аы]|расположен|сдача|продажа|застройщик|адрес|год|202[0-9])\b)',raw,maxsplit=1,flags=re.I)[0]
        # Generic descriptors and years are not residential complex names.
        normalized=raw.strip().casefold()
        if normalized and not re.match(r'(?iu)^(?:20[2-4][0-9]\b|без\s+названи|названи|не\s+указан|новостройк|строящ|квартир|жилой\s+комплекс|сдач|продаж|первичн|дом\b)',normalized):
            return {'name':'ЖК '+raw[:64].strip(),'source':'Название заявлено в тексте, совпадение с реестром не установлено'}
    return {'name':'Не указан или не распознан','source':'Нет надёжного названия ЖК'}


def classify_ad(db,ad,*,year_override=None)->dict:
    """Evaluate at request time against *current* authorizations, not a stale stored flag."""
    b=db.get(RegistryBuilding,ad.building_id) if ad.building_id and ad.attribution_level=='high' else None
    year=year_from_listing(ad.latest_text,year_override)
    # An exact matched project with a published/planned commissioning date may
    # supply the year even when the ad omits it; a posting date never does.
    if b and year['status']=='review' and b.commission_reported:
        from datetime import datetime as _dt
        m=re.search(r'(?<!\d)(20(?:2[0-9]|3[0-9]|4[0-5]))(?!\d)',b.commission_reported)
        if m:year=year_from_listing(ad.latest_text,int(m.group(1)))
        if year.get('year'):year['evidence']='Плановый год ввода из реестра ЖК: '+b.commission_reported
    if b and (b.stage_verified=='commissioned' or b.stage_reported=='commissioned'):
        year['status']='excluded'
        year['evidence']+='; объект обозначен в реестре как сданный'
    name=name_from_text(ad.latest_text,b.name if b else '')
    base={'color':'yellow','label':'Требуется проверка','reason':'Нет точного совпадения ЖК с объектом официального реестра',
          'legal_basis':'','legal_document':'','legal_url':'','basis_as_of':'',
          'money_terms':bool(SALE.search(ad.latest_text) and not EXPLICIT_NO_PAYMENT.search(ad.latest_text)),
          'price':priced_offer(ad.latest_text),'policy':PILOT_POLICY}
    if b:
        decision,linked=evaluate_building(db,b)
        original=decide_ad({'building_id':b.id,'text':ad.latest_text},decision,linked)
        base.update(original)
        official=next((doc for doc in linked.get('docs',[]) if doc.get('status') in ('official_project_match','official_public_project_list')),None)
        base['legal_document']=official.get('number','') if official else ''
        if 'НЕ ОПУБЛИКОВАН' in base['legal_document']:base['legal_document']='Номер в официальной публикации не указан'
        base['legal_url']=official.get('source','') if official else decision.get('basis_source','')
        base['basis_as_of']=linked.get('source_as_of','')
        base['legal_basis']=decision.get('authorization_basis','')
        pilot=red_ad_candidate(ad,year,linked,decision)
        base['pilot_criteria']=pilot
        if pilot['matches']:
            base.update({'color':'red', 'label':'🔴 Пилот: основание не найдено',
                'reason':('ПИЛОТНЫЙ КРАСНЫЙ: объявление о ЖК со сдачей 2026+ содержит цену '+pilot['price']['fragment']+
                 ', объект точно установлен, но в сохранённых открытых реестрах КЖК и МИО '
                 'нет подтверждённого применимого документа. Это сигнал на проверку, '
                 'не доказательство мошенничества или нарушения закона.'),
                'legal_basis':'pilot_open_registry_not_found'})
    anonymous=anonymous_ad_signal(ad,year,name)
    base['anonymous_signal']=anonymous
    unlinked=unlinked_named_ad_signal(ad,year,name)
    base['unlinked_signal']=unlinked
    if year['status']!='active':
        # Preserve legal evidence in the archive, but no active red/green sale
        # verdict can be issued without knowing the 2026+ construction context.
        base['color']='yellow'
        base['label']='Год/стадия не подтверждены' if year['status']=='review' else 'Вне мониторинга 2026+'
        base['reason']=year['evidence']+'; правовой статус не является разрешением на конкретную сделку.'
    elif base['color']=='green':
        base['label']='Основание по ЖК подтверждено'
        base['reason']+=' Само объявление и продавец отдельно не проверены; до оплаты нужен зарегистрированный ДДУ.'
    else:
        base['reason']+=' Отсутствие документа в локальной базе не доказывает его отсутствие в государственных реестрах.' if base['color']=='yellow' else ''
    if anonymous['matches']:
        base.update({'color':'red','label':'🔴 Сигнал: ЖК не назван',
            'reason':('ПИЛОТНЫЙ СИГНАЛ: в объявлении о новостройке указана цена '
                      +anonymous['price']['fragment']+
                      ', но отсутствует распознаваемое название ЖК. '
                      'Привязка к объекту, разрешение и гарантия не проверены. '
                      'Это не доказательство мошенничества.'),
            'legal_basis':'pilot_anonymous_newbuild',
            'pilot_criteria':anonymous,
            'signal_queue':True})
    elif unlinked['matches']:
        base.update({'color':'red','label':'🔴 ЖК вне реестра',
            'reason':('ПИЛОТНЫЙ СИГНАЛ: заявлено '+unlinked['claimed_name']+
                      ' со сдачей 2026+, цена '+unlinked['price']['fragment']+
                      ', но точная привязка к каталогу и документ КЖК/МИО не установлены. '
                      'Это не доказательство отсутствия разрешения или мошенничества.'),
            'legal_basis':'pilot_unlinked_named_project','pilot_criteria':unlinked,
            'signal_queue':True})
    else:
        base['signal_queue']=bool(base.get('color')=='red')
    return {'year':year,'claimed_project':name,'legal_assessment':base}
