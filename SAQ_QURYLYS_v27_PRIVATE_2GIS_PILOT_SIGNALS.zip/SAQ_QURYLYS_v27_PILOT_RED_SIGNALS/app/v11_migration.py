"""One-way, tightly scoped import of real geocoded coordinates from earlier versions.

Only a sibling project directory, identical project key & address, and permitted
provenance are accepted. No demo pins and no old Diamond/ambiguous coordinates.
The original v10 SQLite database is never modified.
"""
from __future__ import annotations
import sqlite3
from pathlib import Path
from sqlalchemy import select
from app.unified_registry import RegistryBuilding
from app.extra_problem_sites import all_real_keys
from app.real_geocode import is_local_point

TRUSTED_PREFIXES=('2GIS_GEOCODE:', '2GIS_EXACT_ADDRESS_AUTO:',
                  'OSM_EXACT_ADDRESS_AUTO:', 'OSM_NOMINATIM_EXACT_HOUSE:', 'REVIEWED:',
                  '2GIS_NAMED_JK_APPROX:', '2GIS_EXACT_HOUSE:', 'OSM_PHOTON_EXACT_HOUSE:', 'OSM_NAMED_JK_APPROX:', 'MIGRATED_V10:')
CONFLICT_NAMES={'ЖК Diamond','ЖК Astoria','ЖК ASYLYM','ЖК Gran Via'}


def import_from_prior(db, current_folder:Path)->dict:
    imported=0;scanned=0
    current_folder=Path(current_folder).resolve()
    allowed=all_real_keys()
    by_key={r.building_key:r for r in db.scalars(select(RegistryBuilding)).all()
            if r.building_key in allowed and r.name not in CONFLICT_NAMES}
    # No broad home-directory scan; only immediately adjacent previous folders.
    parent=current_folder.parent
    choices=[file for version in (16,15,14,13,12,11,10,9)
             for directory in sorted(parent.glob(f'SAQ_QURYLYS_v{version}*'),reverse=True)
             for file in (directory/'saq.sqlite3',directory/'project'/'saq.sqlite3') if file.is_file()]
    for f in choices:
        if f.resolve()==(current_folder/'saq.sqlite3').resolve():continue
        try:
            if f.stat().st_size > 150_000_000:continue
            conn=sqlite3.connect(f'file:{f.as_posix()}?mode=ro',uri=True,timeout=2)
            try:
                rows=conn.execute('select building_key,address,latitude,longitude,coordinate_source from unified_buildings').fetchall()
            finally:conn.close()
        except (OSError,sqlite3.Error):continue
        scanned+=1
        for key,address,lat,lon,source in rows:
            target=by_key.get(key)
            if not target or target.address!=address or target.latitude is not None or target.longitude is not None:continue
            if not str(source or '').startswith(TRUSTED_PREFIXES):continue
            try:lat,lon=float(lat),float(lon)
            except (ValueError,TypeError):continue
            if not is_local_point(lat,lon):continue
            target.latitude=lat;target.longitude=lon
            target.coordinate_source=f'MIGRATED_V10:{source}'[:240]
            imported+=1
    if imported:db.commit()
    return {'imported':imported,'sources_checked':scanned}
