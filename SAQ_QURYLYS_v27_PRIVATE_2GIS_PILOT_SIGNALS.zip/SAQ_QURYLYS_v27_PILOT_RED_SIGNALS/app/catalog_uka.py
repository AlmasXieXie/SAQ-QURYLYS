"""Checked *catalog* list of 38 construction projects in Ust-Kamenogorsk.

Sources: Krisha catalog pages (1-4), checked 2026-10-17. Listings are
non-governmental reports, not legal findings or proof of today's works.

Coordinates are NEVER extrapolated from names or neighbouring projects.
"""
from pathlib import Path
import csv
from sqlalchemy import select
from app.unified_registry import RegistryBuilding, keyify, upsert_company, insert_evidence

CSV_FILE=Path(__file__).resolve().parent.parent/'data'/'verified_38_construction_catalog_2026-10-17.csv'

def catalog_keys():
    with CSV_FILE.open(encoding='utf-8-sig',newline='') as file:
        return {'uka:'+keyify(row['name']) for row in csv.DictReader(file)}



def load_catalog(db):
    """Idempotent; works on top of v6 DB without overwriting analyst decisions."""
    added=updated=0
    with CSV_FILE.open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    if len(rows)!=38:
        raise RuntimeError('В проверенном каталоге должно быть 38 строк')
    for row in rows:
        name=row['name'].strip()
        # Reuse v5/v6 building key, avoiding legacy import keys and duplicate ЖК.
        key='uka:'+keyify(name)
        b=db.scalar(select(RegistryBuilding).where(RegistryBuilding.building_key==key))
        if b is None:
            company=upsert_company(db,row.get('developer',''))
            b=RegistryBuilding(building_key=key,name=name,address=row['address'],
                developer_label=row.get('developer',''),stage_reported='construction',
                stage_verified='unknown',company_id=company.id if company else None)
            db.add(b);db.flush();added+=1
        else:
            # Preserve existing verified/legal data and manually reviewed coordinates.
            # Catalog stage is a *claim*, not an independent stage verification.
            if b.stage_reported not in ('construction','commissioned'):
                b.stage_reported='construction';updated+=1
            if row.get('developer') and b.developer_label != row['developer']:
                # Public catalog attribution only; preserve legal documents and evidence.
                company=upsert_company(db,row['developer'])
                b.developer_label=row['developer']
                if company and (not b.company_id or not db.get(__import__('app.unified_registry',fromlist=['RegistryCompany']).RegistryCompany,b.company_id).bin):
                    b.company_id=company.id
                updated+=1
        insert_evidence(db,'krisha',row['listing_url'],
            'Krisha — в каталоге строящихся ЖК зафиксирован объект '+name,
            'third_party_claim',b.id,b.company_id,
            raw_fields={'address_in_catalog':row['address'],'listed_stage':'construction',
                        'source_checked_on':'2026-10-17','page':row['source_page'],
                        'address_precision':row['address_precision'],'note':row['comment']})
        if row['source_url']!=row['listing_url']:
            insert_evidence(db,'krisha' if 'krisha.kz' in row['source_url'] else 'homeportal',
               row['source_url'],'Публичная карточка ЖК '+name,
               'third_party_claim' if 'krisha.kz' in row['source_url'] else 'official',b.id,b.company_id)
        if row.get('2gis_url'):
            insert_evidence(db,'2gis',row['2gis_url'],
               'Найдена карточка или поисковый запрос в 2ГИС; адрес/блок может отличаться',
               'third_party_claim',b.id,b.company_id)
    # Earlier v6 embedded coordinates for Diamond were supplied from a URL and
    # user reports the point does not match the construction site. Remove
    # ONLY that legacy pin; preserve a later human-reviewed correction.
    key='uka:'+keyify('ЖК Diamond')
    diamond=db.scalar(select(RegistryBuilding).where(RegistryBuilding.building_key==key))
    diamond_invalidated=False
    if diamond and diamond.coordinate_source.startswith('2GIS:'):
        insert_evidence(db,'georeview',
          'https://2gis.kz/ustkam/firm/70000001059877798',
          'Геопозиция Diamond из v6 отозвана: пользователь сообщил о неверном месте. Требуется ручная верификация.',
          'manual_review',diamond.id,diamond.company_id)
        diamond.latitude=None;diamond.longitude=None;diamond.coordinate_source=''
        diamond_invalidated=True
    # Diamond's v6 address is disputed: keep the record for audit but never
    # include it in the 38-object verified commercial catalog map.
    db.commit()
    return {'catalog_items':len(rows),'new':added,'updated':updated,
            'diamond_invalidated':diamond_invalidated,
            'status':'catalog_report_only'}
