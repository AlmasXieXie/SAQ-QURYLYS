"""Reproducible deterministic scoring per SAQ QURYLYS specification, §5."""

FACTOR_DEFS = {
    "R1": (35, "Подтверждено отсутствие применимого правового основания"),
    "R2": (25, "Прямое предложение внесения денежных средств"),
    "R3": (10, "Активная реклама строящегося жилья"),
    "R4": (15, "Подтверждённое коллективное обращение"),
    "R5": (10, "Несовпадение готовности от 20 п. п."),
    "R6": (5, "Документированный простой / просрочка"),
}


def score_project(project, ads):
    factors = []
    def add(code, evidence, source="", ad_id=None):
        points, label = FACTOR_DEFS[code]
        factors.append({"code": code, "points": points, "label": label,
                        "evidence": evidence, "source": source, "ad_id": ad_id})

    # Document status "unknown" must NEVER add R1.
    if project.legal_status == "verified_absent" and project.legal_source:
        add("R1", "Установлено документальной проверкой", project.legal_source)

    confirmed_ads = [ad for ad in ads if ad.review_status == "accepted"]
    deposits = [ad for ad in confirmed_ads if ad.analysis.get("payment", {}).get("found")]
    if deposits:
        ad = deposits[0]
        pay = ad.analysis["payment"]
        add("R2", pay.get("snippet") or "Зафиксировано предложение оплаты", ad.source_url or "Зафиксированный текст", ad.id)
    promoted = [ad for ad in confirmed_ads if ad.analysis.get("advertising", {}).get("found")]
    known_under_construction = project.stage and project.stage.lower().strip() not in {
        "введён в эксплуатацию", "введен в эксплуатацию", "сдан", "готов",
        "неизвестно", "не уточнено", "не указано", "—"
    }
    if promoted and known_under_construction:
        ad = promoted[0]
        add("R3", ad.analysis["advertising"].get("snippet") or "Реклама строящегося ЖК", ad.source_url or "Зафиксированный текст", ad.id)

    if project.verified_complaint and project.complaint_evidence:
        add("R4", "Коллективное обращение проверено", project.complaint_evidence)
    if (project.claimed_completion is not None and project.completion_source and project.claimed_source
            and abs(project.claimed_completion - project.completion) >= 20):
        add("R5", f"Заявлено {project.claimed_completion}%, установлено {project.completion}%",
            f"{project.claimed_source} · {project.completion_source}")
    if project.verified_delay and project.delay_evidence:
        add("R6", "Отклонение от сроков документировано", project.delay_evidence)

    score = min(100, sum(f["points"] for f in factors))
    codes = {f["code"] for f in factors}
    zone = "red" if score >= 60 and {"R1", "R2"} <= codes else ("yellow" if score >= 25 else "green")
    missing = []
    if project.legal_status == "unknown" or not project.legal_source:
        missing.append("Правовое основание не проверено")
    if not confirmed_ads:
        missing.append("Нет подтверждённых публикаций")
    return {"score": score, "zone": zone, "factors": factors, "missing": missing,
            "pending_ads": len([a for a in ads if a.review_status == "pending"])}
