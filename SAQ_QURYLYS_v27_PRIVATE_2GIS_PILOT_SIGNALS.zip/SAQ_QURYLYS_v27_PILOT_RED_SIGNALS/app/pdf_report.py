"""Generate a verifiable signal-card PDF using DejaVu Cyrillic fonts."""
from io import BytesIO
from datetime import datetime
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from xml.sax.saxutils import escape
import os

FONT_FILE = next((p for p in [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/dejavu/DejaVuSans.ttf",
    "/usr/local/share/fonts/DejaVuSans.ttf",
] if os.path.exists(p)), None)
if FONT_FILE:
    pdfmetrics.registerFont(TTFont("SAQ", FONT_FILE))
PDF_FONT = "SAQ" if FONT_FILE else "Helvetica"

def report_pdf(project, score_data, signal, ads):
    out = BytesIO()
    doc = SimpleDocTemplate(out, pagesize=(595, 842), rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
    styles = getSampleStyleSheet()
    normal = ParagraphStyle("SAQNormal", parent=styles["Normal"], fontName=PDF_FONT, fontSize=9, leading=14, spaceAfter=9)
    heading = ParagraphStyle("SAQHeading", parent=normal, fontSize=17, leading=23, spaceAfter=13, textColor=colors.HexColor("#0f3c45"))
    tiny = ParagraphStyle("SAQTiny", parent=normal, fontSize=8, leading=11)
    P = lambda s, style=normal: Paragraph(escape(str(s)), style)
    story = [P("SAQ QURYLYS / СИГНАЛЬНАЯ КАРТОЧКА", heading),
             P(f"№ {signal.id if signal else 'ПРЕДПРОСМОТР'} · {datetime.now().strftime('%d.%m.%Y %H:%M')} · Демонстрационные данные"),
             P(f"Объект: {project.name}"), P(f"Адрес: {project.address}"),
             P(f"Застройщик: {project.developer} | БИН: {project.bin or 'не указан'}"),
             P(f"Стадия: {project.stage} | готовность: {project.completion}%"),
             P(f"Правовой статус: {project.legal_status} | основание: {project.legal_basis or 'не установлено'}"),
             P(f"Источник документов: {project.legal_source or 'не представлен'}"),
             P(f"ОЦЕНКА РИСКА: {score_data['score']}/100 · ЗОНА: {score_data['zone'].upper()}", heading)]
    if score_data['factors']:
        rows = [[P("Код", tiny), P("Вес", tiny), P("Основание", tiny)]]
        for f in score_data['factors']:
            rows.append([P(f['code'], tiny), P("+" + str(f['points']), tiny), P(f['evidence'] + (" | " + f['source'] if f['source'] else ""), tiny)])
        tab = Table(rows, colWidths=[44, 46, 420], repeatRows=1, hAlign="LEFT")
        tab.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e6eef0")),
                                 ("VALIGN", (0, 0), (-1, -1), "TOP"),
                                 ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
                                 ("LINEBELOW", (0, -1), (-1, -1), .4, colors.grey)]))
        story += [tab, Spacer(1, 16)]
    else:
        story.append(P("Подтверждённые факторы риска не зарегистрированы."))
    if score_data['missing']:
        story.append(P("Требует дополнительной проверки: " + "; ".join(score_data['missing'])))
    story += [P("СВЯЗАННЫЕ МАТЕРИАЛЫ", heading)]
    for ad in ads[:8]:
        story.append(KeepTogether([P(f"[{ad.id}] {ad.platform} · {ad.review_status} · {ad.posted_at}"),
                                   P(ad.text[:440], tiny), P(ad.source_url or "Источник: зафиксированный демонстрационный материал", tiny)]))
    if signal:
        story += [P(f"Решение: {signal.status} | аналитик: {signal.author or 'не назначен'}"), P(f"Комментарий: {signal.note or '—'}")]
    story += [Spacer(1, 18), P("ВАЖНО: этот документ — аналитический сигнал, а не юридическое заключение. Демо-данные не описывают реальные компании.", tiny)]
    doc.build(story)
    return out.getvalue()
