"""Source-bound address fallback geocoding for the live city map.

Only points with exact building housenumber + normalized street may be stored.
The global Nominatim endpoint is queried on explicit user-initiated project runs,
sequentially and <= 1 request/s, with persistence for all successful coordinates.
No invented points, parcel outlines, street-centre fallbacks or unlicensed scraping.
"""
from __future__ import annotations

import asyncio
import os
import re
from datetime import datetime, timezone
from threading import Lock

import httpx
from fastapi import APIRouter, BackgroundTasks
from sqlalchemy import select

from app.database import SessionLocal
from app.extra_problem_sites import all_real_keys
from app.geocode_2gis import normalize, parts
from app.real_geocode import is_local_point
from app.unified_registry import RegistryBuilding, insert_evidence

router = APIRouter(prefix='/api/v11', tags=['Координаты реальных ЖК'])
URL = 'https://nominatim.openstreetmap.org/search'
GUARD = Lock()
STATE = dict(scheduled=False, running=False, total=0, checked=0, resolved=0,
             missing=0, ambiguous=0, errors=0, last_error='', last_run=None,
             provider='OSM Nominatim — точный дом, не контур')


def canonical_street(value: str) -> str:
    s = (value or '').casefold().replace('ё', 'е')
    s = re.sub(r'\b(?:улица|ул|проспект|пр-кт|пр|переулок|пер|имени|им)\b\.?', ' ', s)
    s = re.sub(r'\b(?:ильяса|каныша|юрия|ю)\b\.?', ' ', s)
    return normalize(s)


def exact_address(item: dict, target: str) -> bool:
    """Fail closed on unknown building number, street, or city coordinates."""
    expected = parts(target)
    if not expected:
        return False
    addr = item.get('address') or {}
    house = str(addr.get('house_number') or '').strip()
    street = str(addr.get('road') or addr.get('pedestrian') or addr.get('residential') or '').strip()
    if not street or not house:
        return False
    if normalize(house) != normalize(expected[1]):
        return False
    s1, s2 = canonical_street(street), canonical_street(expected[0])
    if not s1 or not s2 or s1 != s2:
        return False
    try:
        lat, lon = float(item['lat']), float(item['lon'])
    except (KeyError, TypeError, ValueError):
        return False
    return bool(is_local_point(lat, lon))


def nominatim_params(address: str):
    # Unstructured Russian query searches work better across Cyrillic spellings;
    # the response is still validated by exact road and house number.
    return dict(q=f'{address}, Казахстан', format='jsonv2', addressdetails=1, limit=8,
                viewbox='82.24,50.22,82.98,49.72', bounded=1)


def choose_one(items: list[dict], address: str):
    matching = [x for x in items if exact_address(x, address)]
    if len(matching) != 1:
        return None, 'ambiguous' if len(matching) > 1 else 'missing'
    return matching[0], 'resolved'


def scheduled():
    with GUARD:
        if STATE['scheduled'] or STATE['running']:
            return False
        STATE['scheduled'] = True
        return True


async def resolve_missing():
    with GUARD:
        if STATE['running']:
            return
        STATE.update(scheduled=False, running=True, total=0, checked=0, resolved=0,
                     missing=0, ambiguous=0, errors=0, last_error='')
    try:
        with SessionLocal() as db:
            missing = [(b.id, b.address) for b in db.scalars(select(RegistryBuilding)).all()
                       if b.building_key in all_real_keys() and
                       (b.latitude is None or b.longitude is None)]
        STATE['total'] = len(missing)
        if not missing:
            return
        # Respect public Nominatim usage: one worker, <=1 req/s, fixed UA and
        # successful results cached in database, no cron or repeated polling.
        agent = os.getenv('SAQ_GEOCODER_USER_AGENT', 'SAQ-Qurylys-local-educational-map/11 (user-initiated, cached, exact-address-only)')
        async with httpx.AsyncClient(timeout=19, follow_redirects=False,
                                     headers={'User-Agent':agent, 'Accept-Language':'ru'}) as client:
            for project_id, address in missing:
                parsed = parts(address)
                if not parsed:
                    STATE['ambiguous'] += 1
                    STATE['checked'] += 1
                    continue
                try:
                    response = await client.get(URL, params=nominatim_params(address))
                    if response.status_code in (403, 418, 429):
                        STATE['last_error'] = f'Открытый геокодер OSM отказал (HTTP {response.status_code}); повторно его не нагружаем.'
                        break
                    response.raise_for_status()
                    raw = response.json()
                    if not isinstance(raw, list):
                        raise ValueError('Неверный формат ответа геокодера')
                    item, outcome = choose_one(raw, address)
                    if item:
                        with SessionLocal() as db:
                            record = db.get(RegistryBuilding, project_id)
                            if record and record.latitude is None and record.longitude is None:
                                record.latitude = float(item['lat'])
                                record.longitude = float(item['lon'])
                                record.coordinate_source = 'OSM_NOMINATIM_EXACT_HOUSE:' + str(item.get('osm_id') or '')[:50]
                                source = 'https://www.openstreetmap.org/' + str(item.get('osm_type', 'way')) + '/' + str(item.get('osm_id'))
                                insert_evidence(db, 'osm_nominatim', source,
                                                'Точная адресная точка OSM (совпали улица и номер дома), НЕ проверенный контур корпуса.',
                                                'exact_address_geocoded', record.id,
                                                raw_fields={'address':address,'provider':'Nominatim','osm_id':item.get('osm_id')})
                                db.commit()
                                STATE['resolved'] += 1
                    else:
                        STATE[outcome] += 1
                except (ValueError, httpx.HTTPError) as err:
                    STATE['errors'] += 1
                    STATE['last_error'] = f'Сбой геокодирования: {type(err).__name__}: {str(err)[:100]}'
                    # Do not hammer unavailable service.
                    if isinstance(err, httpx.ConnectError):
                        break
                finally:
                    STATE['checked'] += 1
                await asyncio.sleep(1.15)
    finally:
        STATE['last_run'] = datetime.now(timezone.utc).isoformat()
        with GUARD:
            STATE['running'] = False
            STATE['scheduled'] = False


@router.get('/geocode/status')
def status():
    return dict(STATE)


@router.post('/geocode/start')
def start(tasks: BackgroundTasks):
    if scheduled():
        tasks.add_task(resolve_missing)
    return dict(STATE)
