"""Independent unified registry API; remains separate from violation scoring."""
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException, Query
from fastapi.responses import FileResponse
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from pathlib import Path
from app.database import get_db, SessionLocal
from app.auto_decisions import evaluate_building
from app.models import Project, RegistryPermit
from app.real_enrichment import enrich
from app.unified_registry import (RegistryCompany,RegistryBuilding,RegistryEvidence,RegistryAuthorization,
    SOURCES,building_payload,parse_csv,import_buildings_csv,import_ashyq_rows,import_companies_csv,import_documents_csv,load_starter,keyify)

router=APIRouter(prefix='/api/unified',tags=['Единый реестр'])
ROOT=Path(__file__).resolve().parent
ASHYQ_URL='https://ashyq.data.gov.kz/dataset/magda-ds-b80110e9-218a-42ba-b8c8-01fa5e4c82c8'

@router.get('/stats')
def stats(db:Session=Depends(get_db)):
    return {'buildings':db.scalar(select(func.count()).select_from(RegistryBuilding)),
            'companies_or_brands':db.scalar(select(func.count()).select_from(RegistryCompany)),
            'authorizations':db.scalar(select(func.count()).select_from(RegistryAuthorization)),
            'unmatched_authorizations':db.scalar(select(func.count()).select_from(RegistryAuthorization).where(RegistryAuthorization.building_id==None)),
            'evidence':db.scalar(select(func.count()).select_from(RegistryEvidence)),
            'coverage':'partial_public_snapshot','location':'Усть-Каменогорск (стартовый набор)',
            'warning':'Не полный национальный реестр и не автоматическая юридическая проверка.'}

@router.get('/sources')
def sources():
    return [{'code':v[0],'name':v[1],'url':v[2],'category':v[3], 'purpose':v[4],'ingestion':v[5],
             'sync_status':'manual_or_sample' if v[0]!='ashyq' else 'csv_adapter_available',
             'last_successful_full_sync':None} for v in SOURCES]

@router.get('/buildings')
def buildings(q:str='',stage:str='',limit:int=Query(200,ge=1,le=1000),db:Session=Depends(get_db)):
    records=db.scalars(select(RegistryBuilding).order_by(RegistryBuilding.name)).all()
    if q:records=[r for r in records if q.casefold() in (r.name+' '+r.address+' '+r.developer_label).casefold()]
    if stage:records=[r for r in records if r.stage_reported==stage]
    return [dict(payload,profile=enrich(payload),auto_decision=evaluate_building(db,r)[0]) for r in records[:limit] if (payload := building_payload(db,r))]

@router.get('/construction-catalog')
def construction_catalog(db:Session=Depends(get_db)):
    """Only the 38 publicly listed construction projects, excluding doubtful v6 pins."""
    from app.catalog_uka import catalog_keys
    keys=catalog_keys()
    records=db.scalars(select(RegistryBuilding).order_by(RegistryBuilding.name)).all()
    return [dict(payload,profile=enrich(payload)) for r in records if r.building_key in keys
            if (payload:=building_payload(db,r))]

@router.get('/construction-catalog/geojson')
def catalog_geojson(db:Session=Depends(get_db)):
    """Export *only verified saved geocoding results*. No invented coordinates."""
    from app.catalog_uka import catalog_keys
    features=[];keys=catalog_keys()
    for b in db.scalars(select(RegistryBuilding)).all():
        if b.building_key not in keys or b.latitude is None or b.longitude is None:continue
        if not rg.is_local_point(b.latitude,b.longitude):continue
        features.append({'type':'Feature','geometry':{'type':'Point','coordinates':[b.longitude,b.latitude]},
           'properties':{'id':b.id,'name':b.name,'address':b.address,
                         'source':b.coordinate_source,'note':'Точка адреса, не граница участка'}})
    return {'type':'FeatureCollection','features':features,'total_catalog':len(keys),'mapped':len(features)}

@router.get('/buildings/{building_id}')
def building(building_id:int,db:Session=Depends(get_db)):
    b=db.get(RegistryBuilding,building_id)
    if not b:raise HTTPException(404,'ЖК не найден')
    p=building_payload(db,b)
    return dict(p,profile=enrich(p),auto_decision=evaluate_building(db,b)[0])

@router.get('/companies')
def companies(q:str='',db:Session=Depends(get_db)):
    records=db.scalars(select(RegistryCompany).order_by(RegistryCompany.name)).all()
    records=[r for r in records if not q or q.casefold() in (r.name+' '+(r.bin or '')).casefold()]
    from app.registry_bridge import ProjectLegalParty
    output=[]
    for r in records:
        # Projects where this BIN appears as documented developer/authorized party;
        # no inference that company authorization covers unrelated projects.
        ids={b.id for b in db.scalars(select(RegistryBuilding).where(RegistryBuilding.company_id==r.id))}
        ids.update(db.scalars(select(ProjectLegalParty.building_id).where(ProjectLegalParty.company_id==r.id)).all())
        linked=[]
        for bid in sorted(ids):
            b=db.get(RegistryBuilding,bid)
            if b:
                status,_=evaluate_building(db,b)
                linked.append({'id':bid,'name':b.name,'map_color':status['map_color'],
                               'basis_source':status.get('basis_source'),'status_label':status['map_status_label']})
        output.append({'id':r.id,'name':r.name,'bin':r.bin,'identity_status':r.legal_identity_status,
                       'entity_type':r.entity_type,'related_buildings':linked,
                       'verified_project_count':sum(z['map_color']=='green' for z in linked),
                       'note':'Наличие разрешения на один ЖК не распространяется на другие объекты компании.'})
    return output

@router.get('/authorizations')
def authorizations(q:str='',unmatched:bool=False,limit:int=Query(500,ge=1,le=1000),db:Session=Depends(get_db)):
    records=db.scalars(select(RegistryAuthorization).order_by(RegistryAuthorization.id.desc())).all()
    if unmatched:records=[x for x in records if x.building_id is None]
    if q:records=[x for x in records if q.casefold() in (x.document_number+' '+x.subject_name+' '+x.location_text).casefold()]
    return [{'id':a.id,'type':a.authorization_type,'number':a.document_number,'date':a.issued_on,
             'status':a.status,'activity':a.activity,'source_code':a.source_code,'source_url':a.source_url,
             'building_id':a.building_id,'company_id':a.company_id,'subject_name':a.subject_name,
             'location_text':a.location_text,'notes':a.notes} for a in records[:limit]]

@router.get('/candidates')
def link_candidates(db:Session=Depends(get_db)):
    # Suggestions only; never alters old demo/real records or legal_status.
    old=db.scalars(select(Project).where(Project.demo==False)).all()
    new=db.scalars(select(RegistryBuilding)).all()
    suggestions=[]
    for p in old:
        for b in new:
            if keyify(p.name)==keyify(b.name):
                suggestions.append({'legacy_project_id':p.id,'registry_building_id':b.id,'name':b.name,
                  'legacy_address':p.address,'registry_address':b.address,'action':'human_review_required',
                  'match_type':'name_only' if keyify(p.address)!=keyify(b.address) else 'name_and_address'})
    return suggestions

@router.post('/import/buildings-csv')
async def import_buildings(source_code:str='dataegov',file:UploadFile=File(...),db:Session=Depends(get_db)):
    try:return import_buildings_csv(db,await file.read(),source_code)
    except ValueError as e:raise HTTPException(422,str(e)) from e

@router.post('/import/ashyq-csv')
async def import_ashyq(file:UploadFile=File(...),db:Session=Depends(get_db)):
    try:
        content=await file.read()
        if len(content)>12_000_000:raise ValueError('CSV больше 12 МБ')
        return import_ashyq_rows(db,parse_csv(content),ASHYQ_URL)
    except ValueError as e:raise HTTPException(422,str(e)) from e

@router.post('/import/ashyq-existing')
def import_existing_ashyq(db:Session=Depends(get_db)):
    """Adapter for previous /api/registries/ashyq/sync output. No automatic legality assumptions."""
    rows=[]
    for p in db.scalars(select(RegistryPermit)):
        raw=dict(p.metadata_original or {})
        raw.setdefault('permission_number',p.permission_number)
        raw.setdefault('object_location',p.project_name)
        raw.setdefault('builder_name',p.developer)
        raw.setdefault('issue_date',p.issue_date)
        rows.append(raw)
    return import_ashyq_rows(db,rows,ASHYQ_URL)

@router.post('/load-public-starter')
def starter(db:Session=Depends(get_db)):
    return {'new_buildings':load_starter(db),'note':'Публичные карточки с ссылками; отсутствие записи не доказывает отсутствие разрешений.'}

@router.post('/import/companies-csv')
async def import_companies(source_code:str='egov',file:UploadFile=File(...),db:Session=Depends(get_db)):
    try:return import_companies_csv(db,await file.read(),source_code)
    except ValueError as e:raise HTTPException(422,str(e)) from e

@router.post('/import/documents-csv')
async def import_documents(source_code:str='elicense',file:UploadFile=File(...),db:Session=Depends(get_db)):
    try:return import_documents_csv(db,await file.read(),source_code)
    except ValueError as e:raise HTTPException(422,str(e)) from e

# Map geocoding is deliberately kept independent from eligibility / legal scoring.
from fastapi import BackgroundTasks
from pydantic import BaseModel, Field
from app import real_geocode as rg

@router.get('/geocode/status')
def geocode_status():
    return {**rg.STATUS,'candidates':len(rg.CANDIDATES),'disclaimer':'Только совпадения точного номера дома. Адресная точка не означает границу строительства.'}

@router.post('/geocode/start')
def start_geocoding(background_tasks:BackgroundTasks):
    with rg.lock:
        if rg.STATUS['running'] or rg.STATUS['scheduled']:
            return dict(rg.STATUS)
        rg.STATUS['scheduled']=True
    background_tasks.add_task(rg.geocode_all_missing)
    return {**rg.STATUS,'message':'Запущена проверка адресов по OSM Nominatim (не быстрее 1 запроса/с).'}


@router.get('/geocode/candidates/{building_id}')
def geocode_candidates(building_id:int,db:Session=Depends(get_db)):
    if not db.get(RegistryBuilding,building_id):raise HTTPException(404,'ЖК отсутствует')
    return {'building_id':building_id,'candidates':rg.CANDIDATES.get(building_id,[]),
            'note':'Автоматически не применяются — точность и принадлежность стройплощадке требует подтверждения.'}

class ConfirmGeo(BaseModel):
    latitude:float=Field(ge=49.72,le=50.22)
    longitude:float=Field(ge=82.24,le=82.98)
    source_url:str=Field(min_length=12,max_length=500)
    reviewer:str=Field(min_length=2,max_length=120)

@router.post('/buildings/{building_id}/coordinates')
def confirm_coordinates(building_id:int,payload:ConfirmGeo,db:Session=Depends(get_db)):
    b=db.get(RegistryBuilding,building_id)
    if not b:raise HTTPException(404,'ЖК не найден')
    if not payload.source_url.startswith('https://'):raise HTTPException(422,'Необходима HTTPS-ссылка на точку объекта')
    b.latitude=payload.latitude;b.longitude=payload.longitude
    b.coordinate_source=f'REVIEWED:{payload.reviewer}: {payload.source_url}'
    from app.unified_registry import insert_evidence
    insert_evidence(db,'georeview',payload.source_url,f'Подтверждена геометка {payload.latitude}, {payload.longitude}; аналитик {payload.reviewer}',
                    'manual_review',building_id=b.id)
    db.commit()
    p=building_payload(db,b)
    return dict(p,profile=enrich(p))
