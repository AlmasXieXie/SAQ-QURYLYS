"""Construction polygon evidence: true OSM geometries, never inferred object footprints.

Overpass landuse/building=construction is a CARTOGRAPHIC observation, not evidence
that a development is illegal. Query bounded to Ust-Kamenogorsk region, cache 24h.
"""
from __future__ import annotations
import json
import os
from pathlib import Path
from datetime import datetime, timedelta, timezone
import httpx

CACHE_PATH = Path(os.getenv('SAQ_OSM_CACHE', 'data/osm_construction_cache.json'))
OVERPASS_URL = 'https://overpass-api.de/api/interpreter'
# BBox southern/western/northern/eastern: Ust-Kamenogorsk, region only.
QUERY = '''[out:json][timeout:20];(
 way["building"="construction"](49.80,82.30,50.10,82.90);
 way["building"="abandoned"](49.80,82.30,50.10,82.90);
 way["landuse"="construction"](49.80,82.30,50.10,82.90);
);out geom 600;'''


def to_geojson(data: dict, max_features: int = 600) -> dict:
    features = []
    for item in data.get('elements', []):
        if item.get('type') != 'way':
            continue
        positions = item.get('geometry') or []
        if len(positions) < 4:
            continue
        ring = []
        for pt in positions:
            lat, lon = pt.get('lat'), pt.get('lon')
            if not isinstance(lat, (int, float)) or not isinstance(lon, (int, float)) or not (49.65 <= lat <= 50.25 and 82.2 <= lon <= 83.05):
                ring = []
                break
            ring.append([lon, lat])
        # Only genuine closed OSM ways. Don't invent geometry from a point or unclosed line.
        if len(ring) < 4 or ring[0] != ring[-1]:
            continue
        tags = item.get('tags') or {}
        identifier = item.get('id')
        if not isinstance(identifier, int):
            continue
        features.append({'type':'Feature', 'geometry': {'type':'Polygon', 'coordinates':[ring]},
                         'properties': {'osm_id': identifier,
                                        'name': (tags.get('name') or '')[:180],
                                        'classification': 'construction_landuse' if tags.get('landuse') == 'construction' else ('building_abandoned' if tags.get('building') == 'abandoned' else 'building_construction'),
                                        'osm_address': ', '.join(x for x in [tags.get('addr:street', ''), tags.get('addr:housenumber','')] if x)[:250],
                                        'mapping_label': (tags.get('building') or tags.get('landuse') or '')[:100],
                                        'source_url': f'https://www.openstreetmap.org/way/{identifier}',
                                        'evidence': 'OSM mapping tags, not proof of an active or legally authorized construction site',
                                        'verified': False}})
        if len(features) >= max_features:
            break
    return {'type':'FeatureCollection', 'features': features}


def construction_zones(*, refresh=False) -> dict:
    now = datetime.now(timezone.utc)
    if CACHE_PATH.exists() and not refresh:
        try:
            cached = json.loads(CACHE_PATH.read_text(encoding='utf-8'))
            fetched = datetime.fromisoformat(cached['fetched_at'])
            if now - fetched < timedelta(hours=24):
                return {**cached, 'status':'cached'}
        except (OSError, ValueError, KeyError):
            pass
    try:
        with httpx.Client(timeout=httpx.Timeout(23, connect=7), follow_redirects=False) as client:
            response = client.post(OVERPASS_URL, data={'data':QUERY}, headers={'User-Agent':'SAQ-Qurylys/3.0 contact: local-demo'})
            response.raise_for_status()
            if len(response.content) > 8_000_000:
                raise ValueError('Overpass response too large')
            result = to_geojson(response.json())
        result.update({'status':'live', 'fetched_at':now.isoformat(), 'source':'OpenStreetMap / Overpass',
                       'note':'Границы из OSM, не официальные границы земельных участков. Не доказывают наличие или отсутствие разрешений.'})
        CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        CACHE_PATH.write_text(json.dumps(result, ensure_ascii=False), encoding='utf-8')
        return result
    except (httpx.HTTPError, ValueError, OSError) as exc:
        if CACHE_PATH.exists():
            try:
                stale = json.loads(CACHE_PATH.read_text(encoding='utf-8'))
                return {**stale, 'status':'stale', 'note':'Источник временно недоступен, показана сохранённая копия. ' + stale.get('note', '')}
            except (OSError, ValueError):
                pass
        return {'type':'FeatureCollection', 'features': [], 'status':'unavailable', 'fetched_at':None,
                'source':'OpenStreetMap / Overpass', 'note':'Сервис временно недоступен. Никакие зоны не были выдуманы.'}
