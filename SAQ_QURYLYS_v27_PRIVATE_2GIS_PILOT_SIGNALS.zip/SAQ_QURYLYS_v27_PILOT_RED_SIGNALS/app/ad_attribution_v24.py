"""Conservative, explainable publication-to-project and legal-party attribution.

Publication about a building != publication authored by its legal developer.
No cross-project grant of an authorization through shared brand/BIN.
"""
from __future__ import annotations
import hashlib
import re
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
from sqlalchemy import select
from app.ad_verification import normalize, base_jk_name, match_catalog

from app.registry_bridge import ProjectLegalParty
from app.unified_registry import RegistryCompany, RegistryBuilding

KNOWN_PLATFORMS = {'olx.kz':'olx', 'krisha.kz':'krisha', 'instagram.com':'instagram'}
ADDRESS_RX = re.compile(r'(?iu)(?:ул(?:ица|\.)?|пр(?:оспект|\.)?|мкр\.?|микрорайон|көшесі)\s+([\w-]+(?:\s+[\w-]+){0,3})\s*[,№д. ]+\s*(\d+[а-яa-z]?(?:[/\-]\d+[а-яa-z]?)?)')


def canonical_url(url):
    p = urlsplit(str(url or '').strip())
    if p.scheme not in {'http','https'} or not p.hostname or p.username or p.password:
        return ''
    host = p.hostname.lower().removeprefix('www.')
    if not any(host == d or host.endswith('.'+d) for d in KNOWN_PLATFORMS):return ''
    path=p.path.rstrip('/') or '/'
    if host.endswith('instagram.com'):
        if not re.fullmatch(r'/(?:p|reel|tv)/[\w-]+',path):return ''
    elif host.endswith('krisha.kz'):
        # Listing URL (complex info is not an advertisement).
        if not re.fullmatch(r'/(?:kz/)?a/show/\d+',path):return ''
    elif host.endswith('olx.kz'):
        if not re.search(r'/d/obyavlenie/|/obyavlenie/',path):return ''
    return urlunsplit(('https',host,path,'',''))


def platform_of(url):
    host=(urlsplit(url).hostname or '').removeprefix('www.')
    return next((name for d,name in KNOWN_PLATFORMS.items() if host==d or host.endswith('.'+d)),'other')


def address_parts(s):
    """Read named street and complete building number, retaining slash corpus.

    Using a bare street number is dangerous: Eсенберлина 5/1 != 51 or 5/2.
    """
    raw=str(s or '').casefold().replace('ё','е')
    m=re.search(r'(?:ул(?:ица)?\.?|пр(?:оспект)?\.?|мкр\.?|микрорайон)\s+([а-яёәіңғүұқөһ\w .-]+?)\s*[,№д. ]+\s*(\d+[а-яa-z]?(?:\s*[/\-]\s*\d+[а-яa-z]?)?)\s*$',raw)
    if not m:return None
    street=normalize(m.group(1))
    house=re.sub(r'\s+','',m.group(2))
    return (street,house)


def candidates_for(db, text, *, account='', source_url=''):
    """Return linked project only for one unambiguous independent signal.

    Address matching requires street plus precise house within an explicit street context.
    BIN matching establishes project connection only if BIN is unique to that project.
    Names are primary: competing exact project hits cause review instead of arbitrary pick.
    """
    from app.v8_api import catalog
    projects=catalog(db)
    raw=text or ''
    hay=normalize(raw)
    hay_addr=normalize(raw.replace('/', ' slash ').replace('-', ' dash '))
    matches=match_catalog(raw,projects)
    named=[m for m in matches if m['score']>=80]
    chosen=None;confidence='unmatched';method='Нет однозначного ЖК в тексте'
    if len(named)==1:
        chosen=named[0];confidence='high';method='Точное название ЖК в объявлении'
    elif len(named)>1:
        return {'building_id':None,'project_name':'','confidence':'ambiguous','method':'Несколько ЖК упомянуты в одном объявлении',
                'candidates':named,'related_organization':'','related_bin':'','advertiser_verified':False,'publisher':account}
    # Fallback on unique project address only; no word similarity.
    if not chosen:
        addresses=[]
        for p in projects:
            addr=address_parts(p.get('address',''))
            if addr and len(addr[0])>=5:
                # require exact street tokens + house marker, not arbitrary numbers
                street,number=addr
                street_rx=r'\b'+r'\s+'.join(re.escape(x) for x in street.split())+r'\b'
                number_rx=r'(?<!\d)'+re.escape(number.replace('/', ' slash ').replace('-', ' dash ')).replace(r'\ ',r'\s+')+r'(?!\d)'
                if re.search(street_rx,hay) and re.search(number_rx,hay_addr):addresses.append(p)
        if len(addresses)==1:
            p=addresses[0];chosen={'id':p['id'],'name':p['name'],'score':82};confidence='medium';method='Уникальное совпадение улицы и номера дома; требуется сверка'
    if not chosen:
        # BIN alone is not an ad-author identity and cannot safely disambiguate multiple projects.
        bins=set(re.findall(r'(?<!\d)\d{12}(?!\d)',raw))
        for binn in bins:
            related=db.scalars(select(ProjectLegalParty).join(RegistryCompany,RegistryCompany.id==ProjectLegalParty.company_id).where(RegistryCompany.bin==binn)).all()
            ids={r.building_id for r in related}
            if len(ids)==1:
                b=db.get(RegistryBuilding,next(iter(ids)))
                if b:
                    chosen={'id':b.id,'name':b.name,'score':75};confidence='medium';method='БИН юридического участника (не подтверждает автора рекламы)'
                    break
    if not chosen:
        return {'building_id':None,'project_name':'','confidence':'ambiguous' if matches else 'unmatched',
                'method':'Есть только бренд застройщика или нет точного совпадения',
                'candidates':matches[:8],'related_organization':'','related_bin':'','advertiser_verified':False,'publisher':account}
    b=db.get(RegistryBuilding,chosen['id'])
    # Legal entity from official KZhK link, otherwise unverified developer label.
    related=db.scalars(select(ProjectLegalParty).where(ProjectLegalParty.building_id==b.id,ProjectLegalParty.role=='developer')).all()
    legal=[db.get(RegistryCompany,x.company_id) for x in related]
    legal=[c for c in legal if c and c.bin]
    if len(legal)==1:
        related_org,related_bin=legal[0].name,legal[0].bin
    else:
        related_org,related_bin=b.developer_label,''
    return {'building_id':b.id,'project_name':b.name,'confidence':confidence,'method':method,
            'candidates':matches[:8],'related_organization':related_org,'related_bin':related_bin,
            'advertiser_verified':False,'publisher':account}


def digest_text(s):return hashlib.sha256((s or '').encode('utf-8')).hexdigest()
