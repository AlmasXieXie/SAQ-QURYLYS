"""Conservative reconciliation of government MIO CSV with claims for *exact* ЖК.

A tax ID alone, developer's general construction license, and missing dataset rows
are never sufficient to color every project green. Only direct, scoped evidence.
"""
from __future__ import annotations
import re
from datetime import datetime,timezone
from sqlalchemy import select
from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.unified_registry import RegistryBuilding,RegistryAuthorization,RegistryEvidence,import_ashyq_rows,clean
from app.extra_problem_sites import all_real_keys
from app.registry_bridge import official_sources_for
from app.auto_decisions import evaluate_building
from app.ad_verification import normalize

router=APIRouter(prefix='/api/v24/registry',tags=['Тщательная сверка официальных реестров'])


def doc_key(v):
    return re.sub(r'[^a-zа-яәіңғүұқөһ0-9]+','',normalize(v))


def location_key(v):
    x=normalize(v)
    x=re.sub(r'\b(?:улица|ул|проспект|пр|дом|д|участок|уч)\b',' ',x)
    return ' '.join(x.split())


def same_specific_site(a,b):
    """Require numbered street address, not merely Ust-Kamenogorsk + borough."""
    aa=location_key(a);bb=location_key(b)
    nums_a=re.findall(r'(?<!\d)\d{1,3}(?:\s*[/]\s*\d+)?(?!\d)',aa)
    nums_b=re.findall(r'(?<!\d)\d{1,3}(?:\s*[/]\s*\d+)?(?!\d)',bb)
    if not nums_a or not nums_b:return False
    # Last number is usually house number, with optional corpus; never use region 19 alone.
    if nums_a[-1].replace(' ','')!=nums_b[-1].replace(' ',''):return False
    common=set(aa.split()) & set(bb.split())
    common -= {'г','город','обл','область','усть','каменогорск','восточно','казахстанская','өскемен','вко','дом','участок'}
    return any(len(t)>=5 and not t.isdecimal() for t in common)


def reconcile_mio_exact(db:Session):
    """Promote governmental dataset record only when number AND unique exact site match.

    Date/status of the raw government row is kept; third-party claim is separate.
    This is a *matching* result, not a fresh guarantee about a particular sale.
    """
    official=db.scalars(select(RegistryAuthorization).where(
       RegistryAuthorization.source_code=='ashyq',
       RegistryAuthorization.authorization_type=='mio_equity_permit')).all()
    locals_=[x for x in db.scalars(select(RegistryBuilding)).all() if x.building_key in all_real_keys()]
    ids={b.id:b for b in locals_}
    claimed=db.scalars(select(RegistryAuthorization).where(
        RegistryAuthorization.authorization_type=='mio_equity_permit',
        RegistryAuthorization.building_id.in_(list(ids)))).all() if ids else []
    by_number={}
    for c in claimed:
        key=doc_key(c.document_number)
        if key and c.building_id in ids:
            by_number.setdefault(key,set()).add(c.building_id)
    results={'checked_official':len(official),'matched':[],'ambiguous':[],'number_only':[]}
    for d in official:
        if not d.document_number or d.status not in ('official_dataset_unmatched','official_number_candidate'):continue
        possible=[ids[x] for x in by_number.get(doc_key(d.document_number),set()) if x!=d.building_id]
        if not possible:continue
        site=[b for b in possible if same_specific_site(d.location_text,b.address)]
        if len(site)==1:
            b=site[0];d.building_id=b.id;d.status='official_project_match'
            d.notes=(d.notes+' Сопоставлено автоматически v24: тот же номер разрешения и точный адрес объекта в официальной CSV. Сверить очередь и статус перед ДДУ.')[:2000]
            results['matched'].append({'name':b.name,'number':d.document_number,'source':d.source_url})
        elif len(site)>1:results['ambiguous'].append(d.document_number)
        else:
            d.status='official_number_candidate'
            results['number_only'].append(d.document_number)
    db.commit()
    return results


@router.get('/audit')
def audit(db:Session=Depends(get_db)):
    items=[]
    for b in db.scalars(select(RegistryBuilding).order_by(RegistryBuilding.name)).all():
        if b.building_key not in all_real_keys():continue
        dec,linked=evaluate_building(db,b)
        authorizations=db.scalars(select(RegistryAuthorization).where(RegistryAuthorization.building_id==b.id)).all()
        leads=[{'number':a.document_number,'type':a.authorization_type,'status':a.status,
                'issuer_source':a.source_code,'url':a.source_url,'date':a.issued_on}
               for a in authorizations if a.authorization_type in ('mio_equity_permit','kzhk_guarantee','bank_participation')]
        attention='document_scope' if linked.get('status')=='official_scoped' else 'guarantee_incident' if linked.get('guarantee_event') else 'reported_document_check' if linked['reported_count'] else 'find_official_documents'
        items.append({'id':b.id,'name':b.name,'address':b.address,'developer_label':b.developer_label,
            'color':dec['map_color'],'registry_status':linked['status'],'priority':attention,
            'documents':leads,'company_parties':linked['parties'],'source_date':linked['source_as_of']})
    return {'total':len(items),'green':sum(x['color']=='green' for x in items),
           'priority_queue':[x for x in items if x['color']!='green'],
           'all':items,
           'rules':['Строительная лицензия не равна разрешению на привлечение средств',
                    'Совпадение одного БИН у бренда и стороннего ЖК не даёт зелёный',
                    'Официальная гарантия/разрешение подтверждаются для ЖК и очереди',
                    'Пилотный красный при ценовом объявлении 2026+ и отсутствии подтверждения в открытых реестрах; не юридический вывод']}

@router.post('/reconcile-mio')
def manual_match(db:Session=Depends(get_db)):
    return reconcile_mio_exact(db)


LAST_SYNC={'attempted_at':None,'succeeded_at':None,'rows':0,'error':'','matched':0}

def sync_public_mio(db:Session):
    from app import connectors
    LAST_SYNC['attempted_at']=datetime.now(timezone.utc).isoformat()
    try:
        rows=connectors.permits_csv()
        result=import_ashyq_rows(db,rows,connectors.ASHYQ_PAGE)
        verified=reconcile_mio_exact(db)
        LAST_SYNC.update(succeeded_at=datetime.now(timezone.utc).isoformat(),rows=len(rows),error='',matched=len(verified['matched']))
        return {'source':connectors.ASHYQ_PAGE,'import':result,'reconciliation':verified,'last_sync':dict(LAST_SYNC)}
    except Exception as exc:
        LAST_SYNC['error']=type(exc).__name__+': '+str(exc)[:180]
        raise

@router.post('/sync-public-mio')
def public_mio_sync(db:Session=Depends(get_db)):
    try:return sync_public_mio(db)
    except Exception as exc:raise HTTPException(status_code=502,detail='Невозможно обновить официальный реестр: '+type(exc).__name__+'; ранее сохранённые данные не считаются новой проверкой.')

@router.get('/sync-status')
def public_mio_status():
    return {'source':'официальный открытый набор МИО',**LAST_SYNC}
