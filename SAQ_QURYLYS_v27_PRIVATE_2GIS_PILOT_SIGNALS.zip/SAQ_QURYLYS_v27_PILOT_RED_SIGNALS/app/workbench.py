"""Real-registry analyst queue and auditable human-in-the-loop scoring.

No document's absence in our local tables is interpreted as an official absence.
Synthetic training records live in legacy Project/Advertisement and are never
included in this router's 40-real-project list or the live map.
"""
from __future__ import annotations
from datetime import datetime, timezone
from io import BytesIO
from collections import Counter
import re
from xml.sax.saxutils import escape
from sqlalchemy import Integer, String, Text, DateTime, ForeignKey, JSON, Float, select
from sqlalchemy.orm import Mapped, mapped_column, Session
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, Field, field_validator
from app.database import Base, get_db
from app.unified_registry import RegistryBuilding
from app.extra_problem_sites import all_real_keys
from app.v8_api import RegistryAd, record as registry_record
from app.scoring import FACTOR_DEFS
from app.models import Project, Advertisement
from app.seed import seed_demo
from app.scoring import score_project
from app.pdf_report import report_pdf, PDF_FONT

router=APIRouter(prefix='/api/workbench',tags=['Рабочее место аналитика'])

def now():return datetime.now(timezone.utc)

class LegalCheck(Base):
    __tablename__='analyst_legal_checks'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    building_id:Mapped[int]=mapped_column(ForeignKey('unified_buildings.id'),unique=True,index=True)
    status:Mapped[str]=mapped_column(String(35),default='unknown')
    stage_status:Mapped[str]=mapped_column(String(35),default='unknown')
    evidence_url:Mapped[str]=mapped_column(String(900),default='')
    note:Mapped[str]=mapped_column(Text,default='')
    reviewer:Mapped[str]=mapped_column(String(100),default='')
    checked_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

class VerifiedFactor(Base):
    __tablename__='analyst_verified_factors'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    building_id:Mapped[int]=mapped_column(ForeignKey('unified_buildings.id'),index=True)
    code:Mapped[str]=mapped_column(String(4))
    evidence_url:Mapped[str]=mapped_column(String(900))
    note:Mapped[str]=mapped_column(Text)
    second_source:Mapped[str]=mapped_column(String(900),default='')
    reported_progress:Mapped[float|None]=mapped_column(Float,nullable=True)
    verified_progress:Mapped[float|None]=mapped_column(Float,nullable=True)
    reviewer:Mapped[str]=mapped_column(String(100))
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

class AnalystSignal(Base):
    __tablename__='analyst_signals'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    building_id:Mapped[int]=mapped_column(ForeignKey('unified_buildings.id'),index=True)
    score:Mapped[int]=mapped_column(Integer)
    zone:Mapped[str]=mapped_column(String(20))
    factors:Mapped[list]=mapped_column(JSON,default=list)
    missing:Mapped[list]=mapped_column(JSON,default=list)
    materials:Mapped[list]=mapped_column(JSON,default=list)
    status:Mapped[str]=mapped_column(String(30),default='pending')
    author:Mapped[str]=mapped_column(String(100))
    note:Mapped[str]=mapped_column(Text,default='')
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
    reviewed_by:Mapped[str]=mapped_column(String(100),default='')
    reviewed_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True),nullable=True)

class AnalystAudit(Base):
    __tablename__='analyst_actions'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    building_id:Mapped[int|None]=mapped_column(ForeignKey('unified_buildings.id'),nullable=True,index=True)
    action:Mapped[str]=mapped_column(String(45))
    actor:Mapped[str]=mapped_column(String(100))
    details:Mapped[dict]=mapped_column(JSON,default=dict)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

class ReviewAdRequest(BaseModel):
    status:str
    analyst:str=Field(min_length=2,max_length=100)
    building_id:int|None=None
    @field_validator('status')
    @classmethod
    def valid_status(cls,v):
        if v not in ('accepted','rejected','pending'):raise ValueError('Только accepted, rejected, pending')
        return v

class LegalRequest(BaseModel):
    status:str='unknown'
    stage_status:str='unknown'
    evidence_url:str=''
    note:str=Field(default='',max_length=3000)
    analyst:str=Field(min_length=2,max_length=100)
    @field_validator('status')
    @classmethod
    def valid_legal(cls,v):
        if v not in ('unknown','verified_absent','verified_guarantee','verified_mio','verified_bank'):
            raise ValueError('Неизвестный статус правовой проверки')
        return v
    @field_validator('stage_status')
    @classmethod
    def valid_stage(cls,v):
        if v not in ('unknown','under_construction','commissioned'):
            raise ValueError('Неизвестная стадия')
        return v

class FactorRequest(BaseModel):
    code:str
    evidence_url:str
    note:str=Field(min_length=10,max_length=3000)
    analyst:str=Field(min_length=2,max_length=100)
    second_source:str=''
    reported_progress:float|None=None
    verified_progress:float|None=None
    @field_validator('code')
    @classmethod
    def factor_code(cls,v):
        if v not in ('R4','R5','R6'):raise ValueError('Ручная проверка доступна для R4, R5, R6')
        return v

class SignalRequest(BaseModel):
    analyst:str=Field(min_length=2,max_length=100)
    note:str=Field(default='',max_length=3000)

class DecisionRequest(SignalRequest):
    status:str
    @field_validator('status')
    @classmethod
    def valid_decision(cls,v):
        if v not in ('confirmed','returned'):raise ValueError('Подтвердить / вернуть')
        return v


def good_url(s):
    from urllib.parse import urlsplit
    try:
        x=urlsplit(s)
        return x.scheme=='https' and bool(x.hostname) and not x.username and not x.password and len(s)<900
    except ValueError:return False


def get_real(db,id):
    b=db.get(RegistryBuilding,id)
    if not b or b.building_key not in all_real_keys():raise HTTPException(404,'ЖК отсутствует в рабочем реестре')
    return b

PAY_RE=re.compile(r'(?iu)\b(?:предоплат\w*|аванс\w*|депозит\w*|первоначальн\w*\s+взнос|денежн\w*\s+взнос|дду\b|долев\w*\s+участи\w*|рассроч\w*|платн\w*\s+брон\w*|брон\w*.{0,28}(?:₸|тенге|тг|оплат\w*|взнос|\d{3,}))\b')
SALE_RE=re.compile(r'(?iu)(?:прода[её]т\w*|продаж\w*|купить|квартир\w*|новострой\w*|пәтер\w*|жк\b)')
NEG_RE=re.compile(r'(?iu)(?:без\s+(?:предоплат\w*|аванса|депозит\w*)|бесплатн\w*\s+брон\w*|брон\w*\s+бесплатн\w*)')


def excerpt(text,pattern):
    m=pattern.search(text or '')
    return (text[max(0,m.start()-85):min(len(text),m.end()+100)].strip() if m else '')


def ad_evidence(ad):
    payment=excerpt(ad.text,PAY_RE)
    # 'без предоплаты' is not a request for payment.
    if payment and NEG_RE.search(ad.text) and not re.search(r'(?iu)(?:депозит|взнос|дду|рассрочка|платная бронь)',ad.text):payment=''
    sale=excerpt(ad.text,SALE_RE)
    return {'id':ad.id,'url':ad.url,'text':ad.text[:18000],'platform':ad.platform,
            'account':ad.account,'status':ad.status,'reviewed_by':ad.reviewed_by,
            'added_at':ad.added_at.isoformat() if ad.added_at else '',
            'payment_excerpt':payment,'advertising_excerpt':sale,
            'payment_hypothesis':bool(payment),'promotion_hypothesis':bool(sale),
            'origin':'automatically_discovered_or_manually_added; verify source URL'}


def score_real(db,building, ads=None):
    ads=ads if ads is not None else db.scalars(select(RegistryAd).where(RegistryAd.building_id==building.id)).all()
    legal=db.scalar(select(LegalCheck).where(LegalCheck.building_id==building.id))
    manual=db.scalars(select(VerifiedFactor).where(VerifiedFactor.building_id==building.id).order_by(VerifiedFactor.id.desc())).all()
    ad_rows=[ad_evidence(a) for a in ads]
    accepted=[a for a in ad_rows if a['status']=='accepted']
    factors=[]; hypotheses=[]; missing=[]
    def add(code,snippet,source,**kwargs):
        points,label=FACTOR_DEFS[code]
        factors.append({'code':code,'points':points,'label':label,'evidence':snippet,'source':source,**kwargs})
    if legal and legal.status=='verified_absent' and good_url(legal.evidence_url):
        add('R1',legal.note,'Проверено аналитиком: '+legal.evidence_url)
    pay=next((x for x in accepted if x['payment_excerpt']),None)
    if pay:add('R2',pay['payment_excerpt'],pay['url'],ad_id=pay['id'])
    if legal and legal.stage_status=='under_construction':
        promoted=next((x for x in accepted if x['advertising_excerpt']),None)
        if promoted:add('R3',promoted['advertising_excerpt'],promoted['url'],ad_id=promoted['id'])
    seen=set()
    for f in manual:
        if f.code in seen or not good_url(f.evidence_url):continue
        if f.code=='R5' and (f.reported_progress is None or f.verified_progress is None
                or abs(f.reported_progress-f.verified_progress)<20 or not good_url(f.second_source)):
            continue
        seen.add(f.code)
        add(f.code,f.note,f.evidence_url,reviewed_by=f.reviewer)
    for a in ad_rows:
        if a['status']=='pending' and (a['payment_excerpt'] or a['advertising_excerpt']):
            hypotheses.append({'ad_id':a['id'],'text':a['payment_excerpt'] or a['advertising_excerpt'],
                               'label':'Непроверенная гипотеза ИИ: реклама/условия оплаты','source':a['url']})
    if not legal or legal.status=='unknown':
        from app.registry_bridge import official_sources_for
        if not official_sources_for(db, building)['eligible_green']:
            missing.append('Правовое основание не проверено: отсутствие записи не равно отсутствию разрешения')
    if not legal or legal.stage_status=='unknown':missing.append('Статус стройки не проверен по документам: R3 пока нельзя подтвердить')
    if not accepted:missing.append('Нет принятых аналитиком рекламных публикаций')
    # Automatic TRIAGE is deliberately separate from the deterministic, analyst-verified
    # R1–R6 score. A finding can be prioritized before a human accepts it, but cannot
    # receive R1 or a red LEGAL zone just because the local registry lacks data.
    pending_pay=next((a for a in ad_rows if a['status']=='pending' and a['payment_excerpt']),None)
    pending_sale=next((a for a in ad_rows if a['status']=='pending' and a['advertising_excerpt']),None)
    preliminary=[]
    if pending_pay and 'R2' not in {f['code'] for f in factors}:
        preliminary.append({'code':'P2','points':25,'evidence':pending_pay['payment_excerpt'],'url':pending_pay['url'],
                            'note':'ИИ-кандидат на R2, аналитик ещё не подтвердил'})
    if pending_sale and building.stage_reported in ('construction','reported_unfinished','reported_problem_site') and 'R3' not in {f['code'] for f in factors}:
        preliminary.append({'code':'P3','points':10,'evidence':pending_sale['advertising_excerpt'],'url':pending_sale['url'],
                            'note':'Стадия только из каталога, нужно подтвердить R3'})
    total=min(100,sum(f['points'] for f in factors))
    codes={f['code'] for f in factors}
    zone='red' if total>=60 and {'R1','R2'}<=codes else ('yellow' if total>=25 or total>=60 else 'green')
    triage_score=min(100,total+sum(x['points'] for x in preliminary))
    triage_zone='red' if zone=='red' else ('yellow' if triage_score>=25 else 'green')
    return {'score':total,'zone':zone,'triage_score':triage_score,'triage_zone':triage_zone,
            'preliminary_factors':preliminary,'factors':factors,'hypotheses':hypotheses,
            'missing':missing,'pending_ads':sum(a['status']=='pending' for a in ad_rows),
            'confirmed_factors':len(factors),'legal':legal_out(legal),'ads':ad_rows,
            'warning':'Балл — очередность проверки, а не вывод о законности. Неизвестные данные добавляют 0 баллов.'}


def legal_out(c):
    if not c:return {'status':'unknown','stage_status':'unknown','source':'','checked_at':'','reviewer':'','note':''}
    return {'status':c.status,'stage_status':c.stage_status,'source':c.evidence_url,
            'checked_at':c.checked_at.isoformat() if c.checked_at else '',
            'reviewer':c.reviewer,'note':c.note}


def case_out(db,b,*,detail=False):
    ads=db.scalars(select(RegistryAd).where(RegistryAd.building_id==b.id).order_by(RegistryAd.id.desc())).all()
    risk=score_real(db,b,ads)
    row={'id':b.id,'name':b.name,'address':b.address,'developer':b.developer_label or 'Не установлен',
         'stage_reported':b.stage_reported,'stage_verified':b.stage_verified,
         'latitude':b.latitude,'longitude':b.longitude,'score':risk['score'],'zone':risk['zone'],
         'triage_score':risk['triage_score'],'triage_zone':risk['triage_zone'],
         'pending_ads':risk['pending_ads'],'ad_count':len(ads),'missing_count':len(risk['missing']),
         'confirmed_factor_codes':[f['code'] for f in risk['factors']],
         'risk_level':'review_priority_not_illegality'}
    if detail:
        from app.registry_bridge import official_sources_for
        row.update({'risk':risk,'registry':registry_record(db,b),'linked_registry':official_sources_for(db,b),
                    'signals':[signal_out(s) for s in db.scalars(select(AnalystSignal).where(AnalystSignal.building_id==b.id)
                                                     .order_by(AnalystSignal.id.desc())).all()],
                    'actions':[{'action':a.action,'actor':a.actor,'at':a.created_at.isoformat(), 'details':a.details}
                               for a in db.scalars(select(AnalystAudit).where(AnalystAudit.building_id==b.id)
                                                   .order_by(AnalystAudit.id.desc()).limit(30)).all()]})
    return row


def signal_out(s):
    return {'id':s.id,'building_id':s.building_id,'score':s.score,'zone':s.zone,
            'factors':s.factors,'missing':s.missing,'materials':s.materials,
            'status':s.status,'author':s.author,'note':s.note,'reviewed_by':s.reviewed_by,
            'created_at':s.created_at.isoformat(),'reviewed_at':s.reviewed_at.isoformat() if s.reviewed_at else ''}


def audit(db,building_id,action,actor,**details):
    db.add(AnalystAudit(building_id=building_id,action=action,actor=actor,details=details))


@router.get('/cases')
def cases(q:str='',zone:str='',pending:bool=False,db:Session=Depends(get_db)):
    buildings=[b for b in db.scalars(select(RegistryBuilding).order_by(RegistryBuilding.name)).all() if b.building_key in all_real_keys()]
    result=[case_out(db,b) for b in buildings]
    if q:result=[x for x in result if q.casefold() in (x['name']+' '+x['address']+' '+x['developer']).casefold()]
    if zone in ('red','yellow','green'):result=[x for x in result if x['zone']==zone]
    if pending:result=[x for x in result if x['pending_ads']>0]
    return sorted(result,key=lambda x:(-x['triage_score'],-x['score'],-x['pending_ads'],x['name'].casefold()))

@router.get('/cases/{building_id}')
def one_case(building_id:int,db:Session=Depends(get_db)):
    from app.auto_decisions import decide_project, decide_ad
    b=get_real(db,building_id)
    result=case_out(db,b,detail=True)
    decision=decide_project(result, result['risk'].get('legal') or {}, result['linked_registry'])
    result['auto_decision']=decision
    for ad in result['risk']['ads']:
        ad['building_id']=b.id
        ad['legal_assessment']=decide_ad(ad,decision,result['linked_registry'])
    return result

@router.post('/ads/{ad_id}/review')
def review_ad(ad_id:int,body:ReviewAdRequest,db:Session=Depends(get_db)):
    ad=db.get(RegistryAd,ad_id)
    if not ad:raise HTTPException(404,'Публикация не найдена')
    if body.building_id is not None:ad.building_id=get_real(db,body.building_id).id
    if body.status=='accepted' and ad.building_id is None:raise HTTPException(422,'Для принятия нужно установить конкретный ЖК')
    if ad.building_id is not None:get_real(db,ad.building_id)
    before=ad.status;ad.status=body.status;ad.reviewed_by=body.analyst
    audit(db,ad.building_id,'ad_review',body.analyst,ad_id=ad.id,before=before,after=body.status,url=ad.url)
    db.commit()
    return ad_evidence(ad)

@router.post('/cases/{building_id}/legal')
def review_legal(building_id:int,body:LegalRequest,db:Session=Depends(get_db)):
    get_real(db,building_id)
    if body.status!='unknown' or body.stage_status!='unknown':
        if not good_url(body.evidence_url):raise HTTPException(422,'Для подтверждённого статуса требуется URL документа HTTPS')
        if len(body.note.strip())<20:raise HTTPException(422,'Опиши, какой именно документ и корпус проверены (20+ символов)')
    entry=db.scalar(select(LegalCheck).where(LegalCheck.building_id==building_id))
    if not entry:
        entry=LegalCheck(building_id=building_id)
        db.add(entry)
    before={'legal':entry.status,'stage':entry.stage_status}
    entry.status=body.status;entry.stage_status=body.stage_status;entry.evidence_url=body.evidence_url
    entry.note=body.note;entry.reviewer=body.analyst;entry.checked_at=now()
    audit(db,building_id,'legal_review',body.analyst,before=before,legal=entry.status,stage=entry.stage_status,source=entry.evidence_url)
    db.commit()
    return legal_out(entry)

@router.post('/cases/{building_id}/factor')
def record_factor(building_id:int,body:FactorRequest,db:Session=Depends(get_db)):
    get_real(db,building_id)
    if not good_url(body.evidence_url):raise HTTPException(422,'Нужна ссылка на проверенный источник HTTPS')
    if body.code=='R5':
        if not good_url(body.second_source) or body.reported_progress is None or body.verified_progress is None:
            raise HTTPException(422,'R5 требует два источника и два значения готовности')
        if not (0<=body.reported_progress<=100 and 0<=body.verified_progress<=100 and abs(body.reported_progress-body.verified_progress)>=20):
            raise HTTPException(422,'R5: разница должна быть не меньше 20 п.п.')
    rec=VerifiedFactor(building_id=building_id,**body.model_dump(exclude={'analyst'}),reviewer=body.analyst)
    db.add(rec);audit(db,building_id,'factor_verified',body.analyst,code=body.code,source=body.evidence_url)
    db.commit();return {'id':rec.id,'code':rec.code,'accepted':True}

@router.post('/cases/{building_id}/signals',status_code=201)
def create_signal(building_id:int,body:SignalRequest,db:Session=Depends(get_db)):
    b=get_real(db,building_id)
    risk=score_real(db,b)
    ads=[{'id':a['id'],'url':a['url'],'excerpt':(a['payment_excerpt'] or a['advertising_excerpt'])[:500],
          'review_status':a['status']} for a in risk['ads'][:30]]
    rec=AnalystSignal(building_id=building_id,score=risk['score'],zone=risk['zone'],
                      factors=risk['factors'],missing=risk['missing'],materials=ads,author=body.analyst,note=body.note)
    db.add(rec);db.flush();audit(db,building_id,'signal_created',body.analyst,signal_id=rec.id,score=rec.score,zone=rec.zone)
    db.commit();db.refresh(rec)
    return signal_out(rec)

@router.post('/signals/{signal_id}/decision')
def decide(signal_id:int,body:DecisionRequest,db:Session=Depends(get_db)):
    rec=db.get(AnalystSignal,signal_id)
    if not rec:raise HTTPException(404,'Сигнал не найден')
    if rec.status!='pending':raise HTTPException(409,'Решение уже принято; создайте новый сигнал для повторной оценки')
    rec.status=body.status;rec.reviewed_by=body.analyst;rec.reviewed_at=now()
    rec.note=(rec.note+'\nРешение: '+body.note).strip()
    audit(db,rec.building_id,'signal_decision',body.analyst,signal_id=rec.id,status=rec.status)
    db.commit();return signal_out(rec)

@router.get('/signals')
def signals(db:Session=Depends(get_db)):
    return [{**signal_out(s),'name':db.get(RegistryBuilding,s.building_id).name} for s in db.scalars(
            select(AnalystSignal).order_by(AnalystSignal.id.desc()).limit(200)).all()]

@router.get('/signals/{signal_id}/report.pdf')
def report(signal_id:int,db:Session=Depends(get_db)):
    s=db.get(AnalystSignal,signal_id)
    if not s:raise HTTPException(404,'Сигнал не найден')
    b=get_real(db,s.building_id)
    registry=registry_record(db,b)
    developer=registry.get('developer') or {}
    legal=db.scalar(select(LegalCheck).where(LegalCheck.building_id==b.id))
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, KeepTogether
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib import colors
    stream=BytesIO();doc=SimpleDocTemplate(stream,pagesize=(595,842),leftMargin=42,rightMargin=42,topMargin=38,bottomMargin=38)
    style=ParagraphStyle('saq',fontName=PDF_FONT,fontSize=9,leading=14,spaceAfter=9)
    hstyle=ParagraphStyle('h',parent=style,fontSize=16,leading=23,textColor=colors.HexColor('#155263'),spaceAfter=15)
    def p(t,h=False):return Paragraph(escape(str(t)),hstyle if h else style)
    story=[p('SAQ QURYLYS — СИГНАЛЬНАЯ КАРТОЧКА',True),
           p(f'№ {s.id} · {s.created_at.isoformat()} · ДАННЫЕ РЕАЛЬНОГО КАТАЛОГА; ВЫВОД АНАЛИТИКА'),
           p('ЖК: '+b.name),p('Адрес: '+b.address),p('Застройщик (по каталогу): '+(b.developer_label or 'не установлен')),
           p('Оценка необходимости проверки: '+str(s.score)+'/100, зона '+s.zone),
           p('Решение: '+s.status+'; аналитик: '+s.author+'; проверил: '+(s.reviewed_by or 'не назначен')),
           p('Дата решения: '+(s.reviewed_at.isoformat() if s.reviewed_at else 'нет')),
           p('Основания оценки',True)]
    if not s.factors:story.append(p('Подтверждённых факторов нет: балл 0 не означает отсутствия рисков.'))
    for f in s.factors:story.append(p(f['code']+' +'+str(f['points'])+' — '+f['label']+'; '+f['evidence']+'; '+f['source']))
    story.append(p('Неопределённость и проверки',True))
    for x in s.missing:story.append(p('• '+x))
    story.append(p('Ссылки и фрагменты рекламы',True))
    for a in s.materials:
        story.append(p('Объявление #'+str(a['id'])+' ('+a['review_status']+'): '+a['url']))
        story.append(p(a['excerpt'][:320]))
    story.extend([Spacer(1,12),p('Комментарий: '+(s.note or 'нет')),
      p('Аналитический сигнал, не юридическое заключение. Информация рекламной площадки и каталога может требовать независимой проверки; никакие материалы государственным органам автоматически не направляются.')])
    doc.build(story)
    return Response(stream.getvalue(),media_type='application/pdf',headers={'Content-Disposition':f'attachment; filename="saq_signal_{s.id}.pdf"'})

@router.post('/training/load')
def training_seed(db:Session=Depends(get_db)):
    # Legacy training tables are intentionally NOT part of the real 40-JK layer.
    created=seed_demo(db)
    return {'created':created,'projects':db.query(Project).filter(Project.demo==True).count(),
            'ads':db.query(Advertisement).filter(Advertisement.demo==True).count(),
            'note':'8 фиктивных ЖК / 12 фиктивных объявлений, только учебная зона'}
