"""Reproducible seed of actual observed links, never synthetic ads."""
import json
from pathlib import Path
from app.ad_archive_v24 import save_ad

DATA=Path(__file__).resolve().parent.parent/'data'/'real_public_ads_verified_2026-10-17.json'

def seed_real_publications(db):
    doc=json.loads(DATA.read_text(encoding='utf-8'))
    saved=0
    for item in doc['items']:
        # Re-running service should not fabricate subsequent sightings from the
        # same fixed historical snapshot. Live feeds alone increment seen_count.
        from app.ad_attribution_v24 import canonical_url
        from app.ad_archive_v24 import PublicAd
        from sqlalchemy import select
        url=canonical_url(item['url'])
        if db.scalar(select(PublicAd).where(PublicAd.url==url)) is None:
            _,created=save_ad(db,url=url,text=item['text'],feed='Проверенный публичный индекс 17.10.2026',
                      account=item['publisher'],posted_at=item.get('posted_at',''),source_kind='curated_web_snapshot')
            if created:saved+=1
    db.commit()
    return saved
