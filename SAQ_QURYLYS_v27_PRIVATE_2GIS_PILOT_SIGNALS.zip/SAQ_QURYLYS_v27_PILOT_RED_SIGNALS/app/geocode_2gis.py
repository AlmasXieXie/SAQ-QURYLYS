"""Opt-in address geocoding using licensed 2GIS Search API.

MapGL/Tiles and Geocoder are independent entitlements. Never invent or
persist points when key lacks the Search API service or address is ambiguous.
Only address centroids; no inferred construction-footprint polygons.
"""
import asyncio, os, re
from urllib.parse import quote
from datetime import datetime, timezone
from threading import Lock
import httpx
from sqlalchemy import select
from app.database import SessionLocal
from app.unified_registry import RegistryBuilding, insert_evidence
from app.extra_problem_sites import all_real_keys as catalog_keys
from app.real_geocode import is_local_point

URL='https://catalog.api.2gis.com/3.0/items/geocode'
lock=Lock()
STATUS={'scheduled':False,'running':False,'total':0,'processed':0,'resolved':0,'ambiguous':0,'not_found':0,'error':'','last_run':None}
CANDIDATES={}

def key_available():return bool(os.getenv('SAQ_2GIS_KEY','').strip())

def normalize(s):
    return re.sub(r'[^0-9a-zа-яёәғқңөұүһі]+','',str(s or '').lower().replace('ё','е').replace('ə','ә').replace('қ','к'))

def parts(address):
    """Require ONE unambiguous street + ONE number, no 'position' or multiple blocks."""
    if 'позици' in address.casefold() or 'без номера' in address.casefold() or ' / ' in address or '–' in address:
        return None
    seg=[x.strip() for x in address.split(',')]
    if len(seg)!=3:return None
    name=seg[1];num=seg[2]
    if not re.fullmatch(r'\d+\s*[а-яa-z]?\s*(?:[/\\]\s*\d+[а-яa-z]?)?',num,re.I):return None
    street=re.sub(r'(?i)^(проспект|пр\.|ул\.|улица|пр\s+|улица\s+|пр-кт\s+)', '',name).strip()
    street=re.sub(r'(?i)^(каныша|ильяса|им\.)\s+','',street)
    return street,num

def compare(item,address):
    expected=parts(address)
    if not expected:return False
    text=(item.get('full_name') or item.get('address_name') or '')
    if not text:return False
    textnorm=normalize(text)
    street,number=expected
    word=normalize(street)
    if len(word)<4 or word not in textnorm:return False
    # Address suffix checked as isolated number, not 55 matching 551.
    # Require normalized punctuation-/space-independent address number.
    expected_num=normalize(number)
    house=(item.get('address_name') or text).split(',')[-1].strip()
    house=re.sub(r'(?i)^(д\.|дом\s+)', '',house)
    if normalize(house)!=expected_num:return False
    point=item.get('point') or {}
    try: lat,lon=float(point['lat']),float(point['lon'])
    except (ValueError,TypeError,KeyError):return False
    if not is_local_point(lat,lon):return False
    # Some 2GIS responses include name with no city when locality inferred.
    return True

def request_params(address,key):return {'q':address+', Казахстан','fields':'items.point,items.geometry.centroid', 'page_size':5,'key':key}

async def run_geocoding():
    with lock:
        if STATUS['running']:return
        STATUS.update(scheduled=False,running=True,total=0,processed=0,resolved=0,ambiguous=0,not_found=0,error='')
    try:
        key=os.getenv('SAQ_2GIS_KEY','').strip()
        if not key:raise RuntimeError('Не настроен API-ключ 2ГИС.')
        with SessionLocal() as db:
            items=[(r.id,r.address) for r in db.scalars(select(RegistryBuilding)).all() if r.building_key in catalog_keys() and r.latitude is None]
        STATUS['total']=len(items)
        async with httpx.AsyncClient(timeout=14,follow_redirects=False) as client:
            for ident,address in items:
                if not parts(address):
                    STATUS['ambiguous']+=1;STATUS['processed']+=1;continue
                try:
                    r=await client.get(URL,params=request_params(address,key))
                    if r.status_code in (401,402,403,429):
                        raise RuntimeError(f'2ГИС вернул HTTP {r.status_code}. Проверьте доступ к Geocoder API, срок и лимиты ключа.')
                    r.raise_for_status();body=r.json()
                    if body.get('meta',{}).get('code') != 200:
                        raise RuntimeError('2ГИС отклонил запрос Geocoder API (код '+str(body.get('meta',{}).get('code'))+'). Возможно, услуга не включена в ключ.')
                    raw=body.get('result',{}).get('items') or []
                    valid=[i for i in raw if compare(i,address)]
                    if len(valid)!=1:
                        CANDIDATES[ident]=[{'name':i.get('full_name'),'address':i.get('address_name'),'point':i.get('point'),'id':i.get('id')} for i in raw[:5]]
                        if valid or len(raw)>1:STATUS['ambiguous']+=1
                        else:STATUS['not_found']+=1
                    else:
                        item=valid[0];point=item['point'];lat=float(point['lat']);lon=float(point['lon'])
                        with SessionLocal() as db:
                            b=db.get(RegistryBuilding,ident)
                            if b and b.latitude is None and b.longitude is None:
                                b.latitude=lat;b.longitude=lon;b.coordinate_source='2GIS_GEOCODE:'+str(item.get('id','address'))[:100]
                                insert_evidence(db,'2gis',f'https://2gis.kz/ust-kamenogorsk/search/{quote(address,safe="")}',
                                    'Сопоставлена адресная точка из Geocoder 2ГИС; не контур строительства.', 'geocoded_address',b.id,
                                    raw_fields={'2gis_item_id':item.get('id'),'geocode_address':item.get('address_name'),'request_address':address})
                                db.commit();STATUS['resolved']+=1
                except (httpx.HTTPError,ValueError) as exc:
                    raise RuntimeError('Geocoder 2ГИС недоступен: '+str(exc)[:150]) from exc
                finally:
                    STATUS['processed']+=1
                await asyncio.sleep(0.25)
    except Exception as exc:
        STATUS['error']=str(exc)
    finally:
        STATUS['last_run']=datetime.now(timezone.utc).isoformat()
        with lock: STATUS['running']=False;STATUS['scheduled']=False
