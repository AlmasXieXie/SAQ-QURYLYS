"""v14 unattended geocoding: 2GIS catalog IDs/name, OSM Photon + exact OSM address.

No fabricated positions. Named 2GIS project pins may differ from the project's
street label and are stored as catalogue approximate, not the building footprint.
Results are kept in the project's SQLite database and survive server restarts.
"""
from __future__ import annotations
import asyncio, os, re
from datetime import datetime, timezone
from threading import Lock
from urllib.parse import quote
import httpx
from fastapi import APIRouter, BackgroundTasks, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.database import SessionLocal, get_db
from app.extra_problem_sites import all_real_keys
from app.unified_registry import RegistryBuilding, insert_evidence
from app.geocode_2gis import compare, normalize, parts
from app.v13_geolocate import canonical_street, project_name, direct_id
from app.real_geocode import is_local_point
from app.v8_api import catalog,record

router=APIRouter(prefix='/api/v14/geofill', tags=['Автоматическая карта'])
LOCK=Lock()
STATE={'running':False,'scheduled':False,'total':0,'processed':0,
       'resolved_2gis_exact':0,'resolved_2gis_named':0,'resolved_osm_exact':0,'resolved_osm_named':0,
       'unresolved':0,'ambiguous':0,'errors':{},'last_finished':None,
       'message':'Проверка по публичным данным, не привязка кадастровых контуров.'}
API='https://catalog.api.2gis.com/3.0/items'
GEO='https://catalog.api.2gis.com/3.0/items/geocode'
BYID='https://catalog.api.2gis.com/3.0/items/byid'
PHOTON='https://photon.komoot.io/api/'
# Plural, duplicated or provisional building blocks must remain point-only until verified.
DISPUTED={'diamond','astoria','asylym','gran via','orda','престиж'}

def canonical_title(s):
    s=re.sub(r'(?iu)^(?:жк|жилой\s+комплекс|строящийся\s+жилой\s+комплекс|жилой\s+дом|түк)\s*[«\"\']?', '',(s or '').strip())
    s=re.sub(r'[»\"\']$','',s).strip()
    s=re.sub(r'(?iu),?\s*(?:строящийся|жилой|жилого|новый)\s+(?:жилой\s+)?(?:комплекс|дом)$','',s).strip()
    return normalize(s)

def point_of(item):
    """Normalize 2GIS point and WKT geometry.centroid (longitude latitude)."""
    raw=item.get('point') or (item.get('geometry') or {}).get('centroid')
    if isinstance(raw,dict) and 'lat' in raw and 'lon' in raw:return raw
    if isinstance(raw,str):
        match=re.fullmatch(r'\s*POINT\s*\(\s*([-+\d.eE]+)\s+([-+\d.eE]+)\s*\)\s*',raw,re.I)
        if match:return {'lon':float(match.group(1)),'lat':float(match.group(2))}
    return {}

def match_address_2gis(item,address):
    # Upstream can place city after the house or supply the structured address.
    if compare(item,address):return True
    expected=parts(address)
    if not expected:return False
    street,num=expected
    point=point_of(item)
    try:lat,lon=float(point['lat']),float(point['lon'])
    except (ValueError,TypeError,KeyError):return False
    if not is_local_point(lat,lon):return False
    a=item.get('address') or {}
    if isinstance(a,dict):
        street_name=str(a.get('street') or a.get('street_name') or '')
        house=str(a.get('house_number') or a.get('number') or '')
        if normalize(house)==normalize(num) and street_name and (canonical_street(street) in canonical_street(street_name) or canonical_street(street_name) in canonical_street(street)):
            return True
    display=str(item.get('address_name') or item.get('full_address_name') or item.get('full_name') or '')
    # A house number must be bounded; e.g. 55 cannot match 551.
    pats=re.findall(r'(?iu)(?:^|[,\s])(?P<n>\d+[а-яa-z]?(?:\s*/\s*\d+[а-яa-z]?)?)(?=$|[,\s])',display)
    return bool(normalize(num) in {normalize(x) for x in pats} and canonical_street(street) in canonical_street(display))

def unique_name(item, project, require_street=False):
    point=point_of(item)
    try:lat=float(point['lat']);lon=float(point['lon'])
    except (ValueError,TypeError,KeyError):return False
    if not is_local_point(lat,lon):return False
    names=[item.get('name') or '',item.get('full_name') or '']
    wanted=canonical_title(project.name)
    if len(wanted)<4 or not any(canonical_title(x)==wanted for x in names):return False
    # A firm named after a ЖК might be a showroom. Prefer actual housing listings
    # and require address corroboration for plain 'branch' results.
    typename=' '.join(str(item.get(k) or '') for k in ('type','purpose_name','rubric_name')).casefold()
    description=(item.get('full_name') or '')+' '+(item.get('address_name') or '')
    address_canonical=canonical_street(description)
    target_streets=[canonical_street(x) for x in project.address.split(',')[1:]
                    if len(canonical_street(x))>=6 and not re.match(r'^\d',x.strip())]
    same_street=any(x in address_canonical for x in target_streets if x)
    if require_street and not same_street:return False
    if item.get('type')=='branch' and not same_street and not re.search('строящ|жилой|жилого|новостро|residential',typename):
        return False
    return True

def choose(project, items):
    """Unique exact address, else uniquely named *project* point.

    A 2GIS citywide name search matching the specific project can be used as a
    rough point even if Krisha uses a different street. No mixed project names.
    """
    unique={str(i.get('id') or point_of(i)):i for i in items if point_of(i)}
    exact=[i for i in unique.values() if parts(project.address) and match_address_2gis(i,project.address)]
    if len(exact)==1:return exact[0],'2gis_exact'
    if len(exact)>1:return None,'ambiguous'
    named=[i for i in unique.values() if unique_name(i,project)]
    if len(named)==1:
        # Do not pin known disputed complexes solely by their label.
        if canonical_title(project.name) in {normalize(x) for x in DISPUTED}:
            return None,'ambiguous'
        return named[0],'2gis_named'
    return None,'ambiguous' if len(named)>1 else 'unresolved'

def photon_named(feature,project):
    p=feature.get('properties') or {}
    coords=(feature.get('geometry') or {}).get('coordinates') or []
    if len(coords)!=2:return False
    try:lon,lat=map(float,coords)
    except (ValueError,TypeError):return False
    if not is_local_point(lat,lon):return False
    name=canonical_title(str(p.get('name') or ''))
    target=canonical_title(project.name)
    if not target or len(target)<4 or name!=target:return False
    if target in {normalize(x) for x in DISPUTED}:return False
    city=normalize(str(p.get('city') or p.get('county') or ''))
    return not city or any(x in city for x in ('каменогорск','оскемен','өскемен','ustkamenogorsk','oskemen'))

def photon_match(feature, address):
    """Require exact house number + street, WGS84 city bounding box."""
    expected=parts(address)
    if not expected:return False
    p=feature.get('properties') or {}
    coords=(feature.get('geometry') or {}).get('coordinates') or []
    if len(coords)!=2:return False
    try:lon,lat=map(float,coords)
    except (ValueError,TypeError):return False
    if not is_local_point(lat,lon):return False
    house=normalize(str(p.get('housenumber') or ''))
    street=canonical_street(str(p.get('street') or ''))
    target=canonical_street(expected[0])
    city=normalize(str(p.get('city') or p.get('county') or p.get('district') or ''))
    if city and not any(x in city for x in ('каменогорск','оскемен','өскемен','ustkamenogorsk','oskemen')):
        return False
    return bool(house and house==normalize(expected[1]) and street and (street==target or target in street or street in target))


def save(project_id,item,precision):
    if precision in ('osm_exact','osm_named'):
        p=item['properties'];lon,lat=item['geometry']['coordinates']
        fid=str(p.get('osm_id') or p.get('id') or '')
        source='https://www.openstreetmap.org/'+str(p.get('osm_type') or 'way')+'/'+fid if fid else 'https://www.openstreetmap.org/'
        description=('Точная адресная точка Photon/OpenStreetMap; корпус не подтвержден.' if precision=='osm_exact' else 'Ориентировочная точка ЖК по совпадающему названию OSM, не корпус.')
        tag=('OSM_PHOTON_EXACT_HOUSE:' if precision=='osm_exact' else 'OSM_NAMED_JK_APPROX:')+fid
    else:
        point=point_of(item)
        lat,lon=point['lat'],point['lon'];fid=str(item.get('id') or '')
        source='https://2gis.kz/ust-kamenogorsk/firm/'+fid if fid else 'https://2gis.kz/ust-kamenogorsk'
        tag=('2GIS_EXACT_HOUSE:' if precision=='2gis_exact' else '2GIS_NAMED_JK_APPROX:')+fid
        description=('2ГИС: совпадение адреса.' if precision=='2gis_exact' else
                     '2ГИС: уникальная именованная карточка ЖК; адресный блок не подтверждён!')
    lat,lon=float(lat),float(lon)
    if not is_local_point(lat,lon):return False
    with SessionLocal() as db:
        b=db.get(RegistryBuilding,project_id)
        if not b or b.building_key not in all_real_keys() or b.latitude is not None or b.longitude is not None:return False
        b.latitude,b.longitude=lat,lon
        b.coordinate_source=tag[:500]
        insert_evidence(db,'photon_osm' if precision=='osm_exact' else '2gis',source,
                        description,'exact_address_geocoded' if precision in ('2gis_exact','osm_exact') else 'named_entity_geocoded',
                        b.id,raw_fields={'precision':precision,'lat':lat,'lon':lon,'address':b.address,'feature_id':fid})
        db.commit();return True

def query_plan(p):
    """Try documented feature ID, named search, then geocoder including alternate names."""
    id_=direct_id((p.profile or {}).get('map_links',{}).get('2gis') or '')
    q=[(API,{'q':p.name+' Усть-Каменогорск','page_size':10,
             'fields':'items.point,items.geometry.centroid,items.address,items.rubrics'})]
    if id_:q.insert(0,(BYID,{'id':id_,'fields':'items.point,items.geometry.centroid,items.address,items.rubrics'}))
    if parts(p.address):
        q.append((GEO,{'q':p.address+', Казахстан','page_size':8,
                       'fields':'items.point,items.geometry.centroid,items.address'}))
    return q

async def request_items(client,url,params,key):
    r=await client.get(url,params={**params,'key':key},follow_redirects=False)
    # Do not return the request URL in an error: it contains the credential.
    if r.status_code in (401,402,403):raise PermissionError(f'2ГИС HTTP {r.status_code}: у ключа нет доступа к Search/Geocoder API')
    if r.status_code==429:raise RuntimeError('2ГИС ограничил частоту запросов (429)')
    if r.status_code==404:return []
    if r.status_code>=400:raise RuntimeError(f'2ГИС HTTP {r.status_code} при поиске объекта')
    data=r.json();code=(data.get('meta') or {}).get('code')
    if code==404:return []
    if code in (401,402,403):raise PermissionError(f'2ГИС: ключ не имеет доступа к Search/Geocoder API, код {code}')
    if code not in (None,200):raise RuntimeError(f'2ГИС отклонил запрос (код {code})')
    return (data.get('result') or {}).get('items') or []

async def geocode_one(client,p,key):
    found=[];errors=[]
    if key:
        for url,params in query_plan(p):
            try:found.extend(await request_items(client,url,params,key))
            except PermissionError:raise
            except Exception as e:errors.append('2ГИС: '+type(e).__name__ if isinstance(e,httpx.HTTPError) else '2ГИС: '+str(e)[:90])
        item,kind=choose(p,found)
        if item:return item,kind,errors
    photon_queries=[]
    if parts(p.address):photon_queries.append(('address',p.address+', Усть-Каменогорск, Казахстан'))
    photon_queries.append(('name',p.name+' Усть-Каменогорск'))
    for mode,q in photon_queries:
        try:
            r=await client.get(PHOTON,params={'q':q,'limit':12,
                'bbox':'82.24,49.72,82.98,50.22','lang':'ru'},
                headers={'User-Agent':'SAQ-Qurylys/14 (private building registry)'},follow_redirects=False)
            r.raise_for_status()
            features=(r.json().get('features') or [])
            valid=[x for x in features if (photon_match(x,p.address) if mode=='address' else photon_named(x,p))]
            if len(valid)==1:return valid[0],'osm_exact' if mode=='address' else 'osm_named',errors
            if len(valid)>1:return None,'ambiguous',errors
        except Exception as e:errors.append('Photon: '+str(e)[:90])
    return None,'ambiguous' if len(found)>1 else 'unresolved',errors


def schedule():
    with LOCK:
        if STATE['running'] or STATE['scheduled']:return False
        STATE['scheduled']=True
        return True

async def run():
    with LOCK:
        if STATE['running']:return
        STATE.update(running=True,scheduled=False,total=0,processed=0,resolved_2gis_exact=0,
                     resolved_2gis_named=0,resolved_osm_exact=0,resolved_osm_named=0,unresolved=0,ambiguous=0,errors={})
    try:
        with SessionLocal() as db:
            projects=[record(db,b) for b in db.scalars(select(RegistryBuilding)).all()
                      if b.building_key in all_real_keys() and (b.latitude is None or b.longitude is None)]
        STATE['total']=len(projects)
        key=os.getenv('SAQ_2GIS_KEY','').strip()
        async with httpx.AsyncClient(timeout=httpx.Timeout(16,connect=6),follow_redirects=False) as client:
            for p in projects:
                from types import SimpleNamespace
                try:
                    item,kind,errors=await geocode_one(client,SimpleNamespace(**p),key)
                    if item and save(p['id'],item,kind):
                        STATE['resolved_'+kind]+=1
                    else:STATE['ambiguous' if kind=='ambiguous' else 'unresolved']+=1
                    for err in errors:STATE['errors'][err]=STATE['errors'].get(err,0)+1
                except PermissionError as ex:
                    msg=str(ex)
                    STATE['errors'][msg]=STATE['errors'].get(msg,0)+1
                    # Continue with OSM Photon after Search API permission failure.
                    try:
                        item,kind,errs=await geocode_one(client,SimpleNamespace(**p),'')
                        if item and save(p['id'],item,kind):STATE['resolved_'+kind]+=1
                        else:STATE['unresolved']+=1
                    except Exception:STATE['unresolved']+=1
                    # Avoid 120 repeated forbidden requests.
                    key=''
                except Exception as ex:
                    msg=str(ex)[:130];STATE['errors'][msg]=STATE['errors'].get(msg,0)+1
                    STATE['unresolved']+=1
                finally:STATE['processed']+=1
                await asyncio.sleep(1.1)
    finally:
        STATE['last_finished']=datetime.now(timezone.utc).isoformat()
        with LOCK:STATE['running']=False;STATE['scheduled']=False

async def background_loop():
    if os.getenv('SAQ_AUTO_GEO','1').lower() in ('0','false','no'):return
    await asyncio.sleep(6)
    while True:
        if schedule():await run()
        await asyncio.sleep(24*3600)

@router.get('/status')
def status(db:Session=Depends(get_db)):
    cards=catalog(db)
    return {**STATE,'all':len(cards),'located':sum(p['latitude'] is not None and p['longitude'] is not None for p in cards),
            'missing':sum(p['latitude'] is None or p['longitude'] is None for p in cards)}

@router.post('/start')
def start(tasks:BackgroundTasks):
    if schedule():tasks.add_task(run)
    return dict(STATE)
