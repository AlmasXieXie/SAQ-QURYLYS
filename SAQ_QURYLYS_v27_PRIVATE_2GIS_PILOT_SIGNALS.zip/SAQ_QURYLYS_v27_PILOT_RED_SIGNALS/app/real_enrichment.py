"""Documented, explicit enrichment. Never infer a project's legal entity from branding."""
from urllib.parse import quote
from datetime import date

REVIEW_DATE='2026-10-17'
# Only source-attested links; absent is NULL, not fabricated.
PROFILES={
 'ЖК Золотой квадрат':{
  'source_links':[('КЖК — гарантия','https://www.homeportal.kz/ru/projects/1141'),('Официальная новость КЖК','https://khc.kz/ru/press-center/news/3346/'),('Отбасы банк — срок ввода','https://hcsbk.kz/ru/news/bank_news/uvazhaemye-vkladchiki-zhk-zolotoy-kvadrat/')],
  'related_entities':[{'name':'ТОО «НАУАН КОРП»','role':'застройщик (КЖК)','bin':None,'url':'https://khc.kz/ru/press-center/news/3346/'},{'name':'ТОО «SA-Инжиниринг»','role':'уполномоченная компания (КЖК)','bin':None,'url':'https://khc.kz/ru/press-center/news/3346/'}],
  'notes':['По сообщению Отбасы банка срок сдачи продлён до 01.11.2026. Величину просрочки автоматически не определяем.'],
 },
 'ЖК ЖАНЫМ':{
  'developer_website':'https://biryuza.kz/',
  'source_links':[('Проект ЖАНЫМ на сайте Biryuza','https://biryuza.kz/appartament/14'),('Krisha — ЖК ЖАНЫМ','https://www.krisha.kz/complex/show/ust-kamenogorsk/v-club/')],
  'notes':['Сайт Biryuza подтверждает адрес Ильяса Есенберлина, 92. БИН юридического лица пока не установлен из официального реестра.'],
 },
 'ЖК AINALAIYN':{
  'developer_website':'https://angroups.kz/','developer_instagram':'https://www.instagram.com/an.groups',
  'brand_bin':'970340000010','brand_bin_url':'https://old.goszakup.gov.kz/ru/registry/show_supplier/88690',
  'source_links':[('Проект на сайте девелопера','https://angroups.kz/ainalaiyn')],
  'notes':['БИН указан для ТОО AN Groups по реестру закупок; юридическая роль в конкретном ЖК не подтверждена независимо.'],
 },
 'ЖК ASYLYM':{
  'developer_website':'https://angroups.kz/','developer_instagram':'https://www.instagram.com/an.groups',
  'brand_bin':'970340000010','brand_bin_url':'https://old.goszakup.gov.kz/ru/registry/show_supplier/88690',
  'source_links':[('Девелопер: проект ASYLYM','https://www.angroups.kz/asylym'),('Korter: адрес 18б и EKM Company','https://korter.kz/%D0%B6%D0%BA-asylym-%D1%83%D1%81%D1%82%D1%8C-%D0%BA%D0%B0%D0%BC%D0%B5%D0%BD%D0%BE%D0%B3%D0%BE%D1%80%D1%81%D0%BA')],
  'alternative_addresses':['ул. Кокжал Барака, 18б (Korter)','ул. Кокжал Барака, 18 (Krisha)'],
  'notes':['На Korter фигурирует EKM Company, на официальном сайте AN Groups — бренд девелопера. Роли организаций требуют сверки.','Адрес 18/18б — возможные блоки, геокодирование не объединяет их автоматически.'],
 },
 'ЖК ORDA':{
  'source_links':[('CEO Group — карточка строительной компании 2ГИС','https://2gis.kz/ust-kamenogorsk/firm/70000001094262193/tab/info'),('Карточка объекта в 2ГИС','https://2gis.kz/ust-kamenogorsk/firm/70000001094684176'),('Krisha: объект и разрешение','https://krisha.kz/complex/show/ust-kamenogorsk/orda/')],
  'alternative_addresses':['Кокжал Барака, 17 (2ГИС, заголовок Krisha)','Кокжал Барака, 19а (описание Krisha, другая карточка 2ГИС)'],
  'notes':['Адреса 17 и 19а нельзя считать одной строительной площадкой без проверки очереди/здания.'],
 },
 'ЖК Asyl Tau':{
  'developer_website':'https://tumar-group.kz/','developer_instagram':'https://www.instagram.com/tumar.oskemen/',
  'brand_bin':'040540018865','brand_bin_url':'https://tumar-group.kz/',
  'source_links':[('Страница проекта на сайте девелопера','https://tumar-group.kz/life/asyl-tau/'),('Krisha: участие БВУ','https://www.krisha.kz/complex/show/ust-kamenogorsk/asyltau/')],
  'related_entities':[{'name':'ТОО «Tumar Group»','role':'застройщик (сайт Tumar)','bin':'040540018865','url':'https://tumar-group.kz/'},{'name':'ТОО «Орда Трейдинг»','role':'уполномоченная компания (сайт Tumar)','bin':None,'url':'https://tumar-group.kz/life/asyl-tau/'}],
  'notes':['Сайт Tumar указывает роли застройщика и уполномоченной компании. Номер участия БВУ отражён в Krisha, требует проверки по первичному документу.'],
 },
 'ЖК Altyn Uia':{
  'source_links':[('Девелопер Tumar перечисляет «Алтын Уя» среди реализованных','https://tumar-group.kz/life/')],
  'notes':['Связь с Tumar указана в портфолио девелопера, но БИН юридического лица на конкретном ЖК не установлен.'],
 },
 'ЖК Brick Town':{'source_links':[('Krisha: сданный объект','https://krisha.kz/complex/show/ust-kamenogorsk/bricktown/')], 'notes':['В описании Krisha строительство приписывается UK BUILDING LTD, хотя в карточке девелопер — Kalina Group. Юридическая роль компаний требует сверки.']},
 'ЖК Престиж':{'notes':['По адресу Увалиева, 7 также встречается объект ЖК Diamond (ул. Увалиева, 7 стр.). Без проверки нельзя считать их одинаковой площадкой.']},
 'ЖК Prime Home':{'source_links':[('Госзакупки: БИН Финтэк-Астана','https://old.goszakup.gov.kz/ru/registry/show_supplier/387845')]},
}

def links(address,latitude=None,longitude=None,name=''):
    # Source searches are intentionally by full known city/address, NOT claims of verified footprint.
    q=quote(f'{name} {address}'.strip(),safe='')
    a=quote(address,safe='')
    if latitude is not None and longitude is not None:
        google=f'https://www.google.com/maps/search/?api=1&query={latitude}%2C{longitude}'
        osm=f'https://www.openstreetmap.org/?mlat={latitude}&mlon={longitude}#map=18/{latitude}/{longitude}'
    else:
        google=f'https://www.google.com/maps/search/?api=1&query={a}'
        osm=f'https://www.openstreetmap.org/search?query={a}'
    return {
        '2gis':f'https://2gis.kz/ust-kamenogorsk/search/{q}',
        'yandex':f'https://yandex.kz/maps/?text={a}',
        'google':google,
        'osm':osm
    }

def enrich(payload):
    d=PROFILES.get(payload['name'],{})
    profile={k:v for k,v in d.items()}
    profile.setdefault('source_links',[])
    profile.setdefault('notes',[])
    profile.setdefault('alternative_addresses',[])
    profile['checked_on']=REVIEW_DATE
    profile['map_links']=links(payload['address'],payload.get('latitude'),payload.get('longitude'),payload['name'])
    # Prefer a directly verified 2GIS place card over generic search. 2GIS
    # URL here is evidence/link only, NEVER silently turned into coordinates.
    for e in payload.get('evidence',[]):
        candidate=e.get('url') or ''
        if e.get('source')=='2gis' and ('/firm/' in candidate or '/geo/' in candidate) and candidate.startswith('https://2gis.kz/'):
            profile['map_links']['2gis']=candidate
            profile['direct_2gis_card']=True
            break
    else:
        profile['direct_2gis_card']=False
    source=payload.get('coordinate_source') or ''
    root_source=source.removeprefix('MIGRATED_V10:')
    profile['location_precision']=('confirmed_by_analyst' if root_source.startswith('REVIEWED:')
        else 'named_catalog_location_approximate' if root_source.startswith(('2GIS_NAMED_JK_APPROX:', 'OSM_NAMED_JK_APPROX:'))
        else 'map_provider_pin' if root_source.startswith(('2GIS:', '2GIS_GEOCODE:', '2GIS_EXACT_HOUSE:','2GIS_EXACT_ADDRESS_AUTO:'))
        else 'address_geocoded' if root_source.startswith(('GEOCODE:', 'OSM_')) else 'missing')
    profile['coordinates_note']=('Уникальная именованная карточка ЖК из картографического каталога. Позиция приблизительная; корпус и контур не подтверждены.'
        if profile['location_precision']=='named_catalog_location_approximate'
        else 'Геопривязка подтверждена аналитиком с источником.' if profile['location_precision']=='confirmed_by_analyst'
        else 'Адресная точка из карты, не кадастровая граница.' if profile['location_precision'] in ('address_geocoded','map_provider_pin')
        else 'Координаты ещё не подтверждены.')
    return profile
