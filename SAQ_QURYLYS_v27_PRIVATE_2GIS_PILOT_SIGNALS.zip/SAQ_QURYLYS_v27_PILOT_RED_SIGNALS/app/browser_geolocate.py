"""Validate address/name candidates obtained from the user's browser.

No inventing positions: candidate must match unique ЖК name or the exact
street/house and fall inside city bounding box. Saving creates auditable evidence.
The browser is a fallback because some local Docker networks cannot reach APIs.
"""
from __future__ import annotations
from types import SimpleNamespace
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from app.database import get_db
from app.unified_registry import RegistryBuilding, insert_evidence
from app.extra_problem_sites import all_real_keys
from app.v8_api import record
from app.v14_geofill import choose, photon_match, photon_named, point_of, canonical_title
from app.geocode_2gis import parts, normalize
from app.v13_geolocate import canonical_street
from app.real_geocode import is_local_point

router=APIRouter(prefix='/api/geo/browser',tags=['Геопривязка — проверка'])

class Candidate(BaseModel):
    building_id:int
    source:str=Field(pattern='^(2gis|photon|nominatim)$')
    data:dict


def checked_candidate(building,source,data):
    p=SimpleNamespace(**record(None,building)) if False else SimpleNamespace(
        id=building.id,name=building.name,address=building.address,profile={})
    if source=='2gis':
        if not isinstance(data.get('point') or (data.get('geometry') or {}).get('centroid'),dict):return None
        item,kind=choose(p,[data]);coords=point_of(item) if item else None
        if not coords:return None
        return float(coords['lat']),float(coords['lon']),'2GIS_'+kind, str(data.get('id') or ''),kind
    if source=='photon':
        if photon_match(data,building.address):kind='osm_exact'
        elif photon_named(data,p):kind='osm_named'
        else:return None
        coords=data['geometry']['coordinates'];lon,lat=map(float,coords)
        return lat,lon,'OSM_'+kind,str((data.get('properties') or {}).get('osm_id') or ''),kind
    if source=='nominatim':
        try:lat=float(data['lat']);lon=float(data['lon'])
        except (KeyError,TypeError,ValueError):return None
        if not is_local_point(lat,lon):return None
        expected=parts(building.address)
        if not expected:return None
        road,house=expected
        addr=data.get('address') or {}
        if not isinstance(addr,dict):return None
        number=str(addr.get('house_number') or '')
        street=str(addr.get('road') or addr.get('pedestrian') or addr.get('residential') or '')
        if normalize(house)!=normalize(number) or not street:return None
        if canonical_street(road)!=canonical_street(street) and not (canonical_street(road) in canonical_street(street) or canonical_street(street) in canonical_street(road)):
            return None
        return lat,lon,'OSM_NOMINATIM_EXACT_HOUSE',str(data.get('osm_id') or ''),'osm_exact'
    return None

@router.post('/candidate')
def candidate(payload:Candidate, db:Session=Depends(get_db)):
    item=db.get(RegistryBuilding,payload.building_id)
    if not item or item.building_key not in all_real_keys():raise HTTPException(404,'ЖК не найден')
    if item.latitude is not None and item.longitude is not None:
        return {'saved':False,'reason':'already_geolocated','id':item.id}
    if len(str(payload.data))>14000:raise HTTPException(413,'Слишком большой ответ картографического сервиса')
    try:match=checked_candidate(item,payload.source,payload.data)
    except (ValueError,TypeError,KeyError):match=None
    if not match:raise HTTPException(422,'Не подтверждено точное совпадение адреса или названия ЖК')
    lat,lon,tag,source_id,precision=match
    if not is_local_point(lat,lon):raise HTTPException(422,'Координаты вне района города')
    item.latitude,item.longitude=lat,lon
    item.coordinate_source=('BROWSER_'+tag+':'+source_id)[:480]
    links={'2gis':'https://2gis.kz/ust-kamenogorsk/search/'+__import__('urllib.parse',fromlist=['quote']).quote(item.name),
           'photon':'https://www.openstreetmap.org/', 'nominatim':'https://www.openstreetmap.org/'}
    insert_evidence(db,payload.source,links[payload.source],
      'Геопозиция получена браузером из картографического ответа и сопоставлена с ЖК. Не контур корпуса и не юридическое подтверждение.',
      'client_geocoder_candidate',item.id,
      raw_fields={'latitude':lat,'longitude':lon,'precision':precision,'source_id':source_id,'request_address':item.address})
    db.commit()
    return {'saved':True,'id':item.id,'precision':precision,'latitude':lat,'longitude':lon}
