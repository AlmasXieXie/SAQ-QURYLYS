"""Idempotent public-source search results. No claim of platform-wide completeness."""
import json
from pathlib import Path
from sqlalchemy import select
from app.ad_archive_v24 import PublicAd,save_ad
from app.ad_monitor_v25 import AdYearEvidence
from app.ad_attribution_v24 import canonical_url
FILE=Path(__file__).resolve().parent.parent/'data'/'v26_2026_public_listing_observations.json'

def seed_2026_ads(db):
    doc=json.loads(FILE.read_text(encoding='utf-8'))
    added=0
    for row in doc['items']:
        url=canonical_url(row['url'])
        if not url: continue
        existing=db.scalar(select(PublicAd).where(PublicAd.url==url))
        if existing:
            # If previous crawl discovered exactly the same URL, attach only
            # the missing structured year: never change its author/revisions.
            if db.get(AdYearEvidence, existing.id) is None:
                db.add(AdYearEvidence(ad_id=existing.id,completion_year=int(row['year']),
                  source_note='Год постройки из публичной карточки Krisha, проверено 18.10.2026'))
            continue
        ad,created=save_ad(db,url=url,text=row['text'],feed='Публичная страница Krisha / индекс, 18.10.2026',
            account='',posted_at='',source_kind='public_index_snapshot',completion_year=row['year'])
        if created:added+=1
    db.commit()
    return added
