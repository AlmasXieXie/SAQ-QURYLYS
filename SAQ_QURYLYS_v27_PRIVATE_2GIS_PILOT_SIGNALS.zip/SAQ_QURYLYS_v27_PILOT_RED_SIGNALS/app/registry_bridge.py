"""Evidence-preserving KZhK ↔ real building ↔ legal parties reconciliation.

Only an explicit *project-level* official source can be a candidate for a green
map signal. A company BIN, a similar name, or a sales-site statement is NOT a
verified authorization. No inference from registry absence to illegality.

The bundled KZhK records are a dated, curated public-source snapshot, NOT an
always-on KZhK API integration. Import is idempotent and preserves reviews.
"""
from __future__ import annotations
import json
from pathlib import Path
from datetime import datetime, timezone
from sqlalchemy import Integer, String, Text, ForeignKey, UniqueConstraint, select
from sqlalchemy.orm import Mapped, mapped_column, Session
from fastapi import APIRouter, Depends, HTTPException
from app.database import Base, get_db
from app.unified_registry import (
    RegistryAuthorization, RegistryBuilding, RegistryCompany,
    upsert_company, insert_authorization, insert_evidence, keyify,
)
from app.extra_problem_sites import all_real_keys

DATAFILE = Path(__file__).resolve().parent.parent / 'data' / 'kzhk_verified_links_2026-10-17.json'
router = APIRouter(prefix='/api/registry-linkage', tags=['Связь КЖК, ЖК и юрлиц'])
OFFICIAL_STATES = {
    'official_project_match', 'official_scoped_match',
    'official_historical_match', 'official_guarantee_event', 'official_public_project_list',
}
AUTOMATIC_GREEN_ALLOWED = {'official_project_match', 'official_public_project_list'}
GUARANTEE_EVENT = 'official_guarantee_event'

class ProjectLegalParty(Base):
    __tablename__ = 'registry_project_legal_parties'
    __table_args__ = (UniqueConstraint('building_id', 'company_id', 'role', 'document_number', name='uq_building_party_doc'),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    building_id: Mapped[int] = mapped_column(ForeignKey('unified_buildings.id'), index=True)
    company_id: Mapped[int] = mapped_column(ForeignKey('unified_companies.id'))
    role: Mapped[str] = mapped_column(String(30))
    document_number: Mapped[str] = mapped_column(String(180))
    source_url: Mapped[str] = mapped_column(String(800))
    source_status: Mapped[str] = mapped_column(String(45), default='official_scoped_match')
    scope_note: Mapped[str] = mapped_column(Text, default='')


def source_data():
    doc=json.loads(DATAFILE.read_text(encoding='utf-8'))
    if not doc.get('source_as_of') or len(doc.get('projects',[]))<5:
        raise ValueError('Incorrect curated KZhK source snapshot')
    return doc


def _real(db, name):
    b=db.scalar(select(RegistryBuilding).where(RegistryBuilding.building_key == 'uka:'+keyify(name)))
    if b is None and name in ('ЖК Diamond','ЖК Astoria'):
        b=db.scalar(select(RegistryBuilding).where(RegistryBuilding.building_key == 'uka:problem:'+keyify(name)))
    return b if b and b.building_key in all_real_keys() else None


def reconcile(db: Session):
    """Add sourced guarantees and their *actual* companies; no guess-based match."""
    doc=source_data(); stats={'source_as_of':doc['source_as_of'],'official_rows':0,'parties_added':0,'missing':[], 'linked':[]}
    for entry in doc['projects']:
        b=_real(db,entry['project'])
        if not b:
            stats['missing'].append(entry['project']); continue
        url=entry['source_url']; status=entry['document_status']; number=entry['number']
        source=insert_evidence(db,entry['source_code'],url,
            'Подтверждённая запись КЖК для '+entry['project']+'; '+entry['scope'],
            'official_document_scoped',b.id,raw_fields={
                'guarantee':number,'coverage':entry['coverage'],
                'role_developer_bin':entry['developer_bin'],
                'authorized_bin':entry['authorized_bin'],
                'as_of':doc['source_as_of'],
                'check':'Curated match of exact object, project and developer; phase limitations as noted'})
        if entry.get('supporting_source_url'):
            insert_evidence(db, entry['source_code']+'_registry', entry['supporting_source_url'],
                'Официальный реестр КЖК: номер договора '+number+' и БИН юридических участников '+entry['project'],
                'official_document_scoped', b.id, raw_fields={'guarantee':number, 'as_of':doc['source_as_of'],
                'supports_primary_page':url})
        # If an existing developer label exactly corresponds to the official legal
        # entity name, link it to the BIN. Never override conflicting trade brands
        # such as ATQ Corporate (Crystal) or OKS Group (Prestizh).
        for role,n,binn in (('developer',entry['developer_name'],entry['developer_bin']),
                            ('authorized_company',entry['authorized_name'],entry['authorized_bin'])):
            if not binn:continue
            co=upsert_company(db,n,binn)
            co.entity_type='legal_entity';co.legal_identity_status='official_project_record'
            if role=='developer' and keyify(b.developer_label).removeprefix('too-')==keyify(n).removeprefix('too-'):
                if not b.company_id or not db.get(RegistryCompany,b.company_id).bin:
                    b.company_id=co.id
            row=db.scalar(select(ProjectLegalParty).where(
                ProjectLegalParty.building_id==b.id,ProjectLegalParty.company_id==co.id,
                ProjectLegalParty.role==role,ProjectLegalParty.document_number==number))
            if row is None:
                row=ProjectLegalParty(building_id=b.id,company_id=co.id,role=role,
                    document_number=number,source_url=url,source_status=status,scope_note=entry['scope'])
                db.add(row);stats['parties_added']+=1
        prior=db.scalar(select(RegistryAuthorization).where(
            RegistryAuthorization.building_id==b.id,
            RegistryAuthorization.document_number==number,
            RegistryAuthorization.authorization_type==entry['document_type']))
        if prior:
            # Strengthen existing catalog claim with a *separate* official source;
            # preserve commercial source in unified_evidence history.
            prior.status=status
            prior.source_code=entry['source_code']
            prior.source_url=url
            prior.notes=entry['notes']+' Объём: '+entry['scope']
            prior.evidence_id=source.id
            prior.issued_on=entry['issued_on']
            prior.subject_name=entry['developer_name']
        else:
            insert_authorization(db,authorization_type=entry['document_type'],
                document_number=number,issued_on=entry['issued_on'],
                source_code=entry['source_code'],source_url=url,building_id=b.id,
                evidence_id=source.id,status=status,subject_name=entry['developer_name'],
                location_text=b.address,activity='долевое участие: документ КЖК',
                notes=entry['notes']+' Объём: '+entry['scope'])
        stats['official_rows']+=1;stats['linked'].append(b.name)
    db.commit()
    return stats


def official_sources_for(db:Session, building:RegistryBuilding):
    docs=db.scalars(select(RegistryAuthorization).where(RegistryAuthorization.building_id==building.id)).all()
    parties=[]
    for p in db.scalars(select(ProjectLegalParty).where(ProjectLegalParty.building_id==building.id)).all():
        c=db.get(RegistryCompany,p.company_id)
        if c:
            parties.append({'role':p.role,'name':c.name,'bin':c.bin,'source_url':p.source_url,
                            'document_number':p.document_number,'source_status':p.source_status,'scope':p.scope_note})
    official=[d for d in docs if d.status in OFFICIAL_STATES and d.authorization_type in ('kzhk_guarantee','mio_equity_permit','bank_participation')]
    reported=[d for d in docs if d.status not in OFFICIAL_STATES and d.authorization_type in ('kzhk_guarantee','mio_equity_permit','bank_participation')]
    eligible=any(d.status in AUTOMATIC_GREEN_ALLOWED for d in official)
    public_list=any(d.status=='official_public_project_list' for d in official)
    event=any(d.status==GUARANTEE_EVENT for d in official)
    # Historic/phase-dependent guarantees are documentation, not automatic
    # authorization for an arbitrary block/2026 contract.
    entry=next((x for x in source_data()['projects'] if x['project']==building.name),None)
    return {
        'status':('guarantee_event' if event else 'official_project' if eligible else
                  'official_scoped' if official else 'reported_only' if reported else 'unknown'),
        'eligible_green':eligible and not event,
        'official_public_list':public_list,
        'guarantee_event':event,
        'source_as_of':source_data()['source_as_of'],
        'official_count':len(official), 'reported_count':len(reported),
        'docs':[{'type':d.authorization_type,'number':d.document_number,'status':d.status,
                 'issued_on':d.issued_on,'source':d.source_url,'notes':d.notes} for d in docs],
        'parties':parties,
        'supporting_source_url':entry.get('supporting_source_url','') if entry else '',
        'aliases':entry.get('aliases',[]) if entry else [],
        'scope':entry['scope'] if entry else ('Проект из официального перечня УГАСК ВКО; номер и очередь не указаны' if public_list else ''),
        'warning':('Объект гарантийного случая: наличие договора КЖК не отменяет необходимость проверки проблем со строительством.' if event else
                   'Официальный перечень УГАСК ВКО называет этот ЖК законно привлекающим дольщиков, но не содержит номер и очередь разрешения.' if public_list else
                   'Подтверждена гарантия КЖК по конкретному объекту (проверить очередь в договоре).' if eligible else
                   'В источнике КЖК указаны определённые очереди, либо запись историческая; ручная сверка актуальности необходима.' if official else
                   'Документ указан коммерческим каталогом; проверить у выдавшего органа, статус и корпус.' if reported else
                   'Документы в этой базе не найдены. Это не подтверждение их отсутствия.'),
    }


@router.get('/summary')
def summary(db:Session=Depends(get_db)):
    values=[]
    for b in db.scalars(select(RegistryBuilding)).all():
        if b.building_key in all_real_keys():
            values.append((b.name,official_sources_for(db,b)))
    return {'total':len(values),'official_project':sum(x['status']=='official_project' for _,x in values),
            'official_scoped':sum(x['status']=='official_scoped' for _,x in values),
            'guarantee_event':sum(x['status']=='guarantee_event' for _,x in values),
            'reported_only':sum(x['status']=='reported_only' for _,x in values),
            'unknown':sum(x['status']=='unknown' for _,x in values),
            'source_as_of':source_data()['source_as_of'],'note':'КЖК: сохранённые ссылки и документальные записи. Нет непрерывной синхронизации с закрытым API.'}


@router.get('/buildings/{building_id}')
def linked_building(building_id:int,db:Session=Depends(get_db)):
    b=db.get(RegistryBuilding,building_id)
    if not b or b.building_key not in all_real_keys():raise HTTPException(404,'ЖК не найден в рабочем каталоге')
    return {'building_id':b.id,'building':b.name,**official_sources_for(db,b)}


@router.post('/reconcile')
def resync(db:Session=Depends(get_db)):
    """Repeat deterministic local reconciliation. Not an online KZhK API fetch."""
    return reconcile(db)
