"""Scheduled discovery of publicly indexed housing ads and evidence-first analysis.

Not an OLX/Instagram crawler or an assertion that a government permit is absent.
The default discovery backend uses publicly accessible RSS search-result feeds;
optional operator-owned OLX-parser RSS feed can be connected using an env var.
No copyrighted code from lerdem/olx-parser is copied.
"""
from __future__ import annotations
import asyncio
import html
import os
import re
from datetime import datetime, timezone
from html.parser import HTMLParser
from urllib.parse import urljoin
from urllib.robotparser import RobotFileParser
import time
from threading import Lock
from urllib.parse import quote, urlsplit
from xml.etree import ElementTree as ET

import httpx
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from sqlalchemy import select, Integer, String, Text, DateTime
from sqlalchemy.orm import Mapped, mapped_column, Session

from app.database import Base, SessionLocal, get_db
from app.ad_verification import verify_text
from app.ad_verification_api import PageParser, fetch_public, ocr_image, public_url
from app.v8_api import RegistryAd
from app.ad_archive_v24 import save_ad
from app.ad_attribution_v24 import canonical_url

router=APIRouter(prefix='/api/v13/monitor',tags=['Автоматический мониторинг рекламы'])

class ScanFinding(Base):
    __tablename__='autonomous_scan_findings'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    url:Mapped[str]=mapped_column(String(1500),unique=True,index=True)
    feed:Mapped[str]=mapped_column(String(150))
    title:Mapped[str]=mapped_column(String(500))
    excerpt:Mapped[str]=mapped_column(Text)
    project_id:Mapped[int|None]=mapped_column(Integer,nullable=True)
    project_name:Mapped[str]=mapped_column(String(200),default='')
    assessment:Mapped[str]=mapped_column(String(70),default='')
    confidence:Mapped[str]=mapped_column(String(40),default='')
    keywords:Mapped[str]=mapped_column(Text,default='')
    document_note:Mapped[str]=mapped_column(Text,default='')
    details:Mapped[str]=mapped_column(Text,default='')
    review_status:Mapped[str]=mapped_column(String(40),default='pending')
    ocr_used:Mapped[str]=mapped_column(String(5),default='no')
    last_seen:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))

STATE=dict(running=False,scheduled=False,last_run=None,last_error='',feeds_checked=0,
           feeds_failed=0,discovered=0,inspected=0,matched=0,signals=0,
           saved=0,ocr_images=0,network_available=None,
           enabled=True,interval_minutes=30,source='RSS, public listings, optional authorized Instagram/OLX APIs')
LOCK=Lock()
SEARCH_QUERIES=(
 'site:krisha.kz/a/show/ Усть-Каменогорск ЖК срок сдачи 2026 2027',
 'site:olx.kz/d/obyavlenie/ Усть-Каменогорск ЖК 2026 2027 новостройка',
 'site:instagram.com/p/ Өскемен ЖК сдача 2026 2027',
 'site:instagram.com/reel/ Усть-Каменогорск ЖК 2026 2027',
 'site:olx.kz Усть-Каменогорск ЖК строящийся квартира',
 'site:krisha.kz Усть-Каменогорск ЖК продажа строящийся',
 'site:olx.kz Өскемен тұрғын үй кешені сатылым',
 'site:instagram.com Усть-Каменогорск ЖК бронь квартира',
 'site:olx.kz Усть-Каменогорск новостройка рассрочка',
 'site:krisha.kz Усть-Каменогорск новостройка долевое участие',
 'site:instagram.com Өскемен жаңа тұрғын үй пәтер',
 'site:olx.kz Усть-Каменогорск квартиры от застройщика',
 'site:krisha.kz/a/show/ Усть-Каменогорск ЖК рассрочка',
 'site:krisha.kz/a/show/ Өскемен пәтер новостройка',
 'site:instagram.com/p/ Усть-Каменогорск ЖК отдел продаж',
 'site:instagram.com/reel/ Усть-Каменогорск ЖК квартиры',
 'site:instagram.com/p/ Өскемен құрылыс компаниясы пәтер',
 'site:olx.kz/d/obyavlenie/ Усть-Каменогорск ЖК',
 'site:krisha.kz/a/show/ Усть-Каменогорск бронь ДДУ',
 'site:instagram.com/p/ жк кокжал барака Усть-Каменогорск'
)
AD_HOSTS=('olx.kz','krisha.kz','instagram.com','facebook.com','korter.kz','homsters.kz')
DIRECT_CATALOGS=(
 ('Прямой каталог OLX (ЖК Усть-Каменогорск)',
  'https://www.olx.kz/nedvizhimost/prodazha-kvartiry/ust-kamenogorsk/q-%D0%BA%D0%B2%D0%B0%D1%80%D1%82%D0%B8%D1%80-%D0%B6%D0%BA/'),
 ('Прямой каталог Krisha (ЖК Усть-Каменогорск)',
  'https://krisha.kz/prodazha/kvartiry/ust-kamenogorsk/?das%5Bmap.complex%5D=0'),
)



def host_allowed(host:str) -> bool:
    h=(host or '').casefold().rstrip('.')
    return any(h==base or h.endswith('.'+base) for base in AD_HOSTS)


def source_feeds():
    feeds=[]
    # Public search index RSS: NOT comprehensive OLX coverage. Search queries rotate every run.
    for query in SEARCH_QUERIES:
        feeds.append(('Bing RSS · '+query[:46], 'https://www.bing.com/search?format=rss&q='+quote(query)))
    for i,url in enumerate(os.getenv('SAQ_AD_RSS_FEEDS','').split(';')):
        url=url.strip()
        if url and public_url(url):feeds.append((f'Внешний RSS #{i+1}',url))
    # A separately deployed, locally controlled lerdem/olx-parser is optional.
    own=os.getenv('SAQ_LOCAL_OLX_RSS','').strip()
    if own and urlsplit(own).scheme in ('http','https') and urlsplit(own).hostname in ('127.0.0.1','localhost'):
        feeds.append(('Свой OLX-parser RSS',own))
    # Names from the current real-project registry: no repeated manual input.
    try:
        from app.extra_problem_sites import all_real_keys
        from app.unified_registry import RegistryBuilding
        from app.ad_verification import base_jk_name
        with SessionLocal() as db:
            names=[base_jk_name(b.name) for b in db.scalars(select(RegistryBuilding)).all()
                   if b.building_key in all_real_keys()]
        # 4 names per RSS search; two-part rotation covers every record in 12h.
        for k in range(0,len(names),4):
            group=[f'"ЖК {n}"' for n in names[k:k+4] if n and len(n)>4]
            if not group:continue
            query='('+' OR '.join(group)+') Усть-Каменогорск (site:olx.kz OR site:krisha.kz OR site:instagram.com)'
            feeds.append(('Каталог ЖК '+str(k//4+1), 'https://www.bing.com/search?format=rss&q='+quote(query)))
    except Exception:
        # Registry might not yet exist in first-run migration; generic searches still work.
        pass
    return feeds


class ListingAnchorParser(HTMLParser):
    """Extract source ad links from public HTML listings; no anti-bot bypass."""
    def __init__(self, base):
        super().__init__(convert_charrefs=True)
        self.base=base;self.current=None;self.text=[];self.results={}
    def handle_starttag(self,tag,attrs):
        if tag!='a':return
        href=dict(attrs).get('href') or ''
        full=urljoin(self.base,href)
        host=urlsplit(full).hostname or ''
        path=urlsplit(full).path
        if not host_allowed(host):return
        if not (re.search(r'/d/obyavlenie/[^/?]+',path,re.I) or re.search(r'/a/show/\d+',path,re.I)):
            return
        self.current=full;self.text=[]
    def handle_data(self,data):
        if self.current and data.strip():self.text.append(data.strip())
    def handle_endtag(self,tag):
        if tag=='a' and self.current:
            title=' '.join(self.text)[:500]
            if len(title)>2:self.results[self.current]=title
            self.current=None;self.text=[]
    def parsed(self,max_results=30):
        return [{'link':u,'title':t,'text':t} for u,t in list(self.results.items())[:max_results]]


async def robots_allowed(client,url):
    """Honor a provider's robots policy. Deny when it cannot be verified."""
    parts=urlsplit(url)
    robot=f'{parts.scheme}://{parts.hostname}/robots.txt'
    r=await client.get(robot,follow_redirects=False)
    if r.status_code==404:return True
    if r.status_code!=200 or len(r.content)>250_000:return False
    rp=RobotFileParser();rp.parse(r.text.splitlines())
    return rp.can_fetch('SAQ-Qurylys',url)


async def fetch_catalog(client,url):
    if not public_url(url):raise ValueError('Требуется публичный адрес HTML-каталога')
    if not await robots_allowed(client,url):raise PermissionError('robots.txt запрещает или не удалось проверить правило доступа')
    r=await client.get(url,follow_redirects=False)
    if r.status_code!=200:raise ValueError('HTML-каталог вернул HTTP '+str(r.status_code))
    if len(r.content)>3_000_000:raise ValueError('Каталог слишком большой')
    p=ListingAnchorParser(url);p.feed(r.content.decode('utf-8',errors='replace'))
    return p.parsed()


def parse_rss(raw:bytes,limit=100):
    if len(raw)>2_000_000:raise ValueError('RSS больше 2 MB')
    if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():raise ValueError('RSS c DTD/ENTITY запрещён')
    root=ET.fromstring(raw)
    out=[]
    for item in list(root.findall('.//item'))[:limit]:
        title=(item.findtext('title') or '').strip()
        link=(item.findtext('link') or '').strip()
        description=(item.findtext('description') or '').strip()
        parser=PageParser();parser.feed(html.unescape(description))
        out.append({'title':title[:500],'link':link,'text':(title+' '+parser.get_text()).strip()[:20000], 'posted_at':(item.findtext('pubDate') or '').strip()[:80]})
    if not out:
        for item in list(root.findall('.//{http://www.w3.org/2005/Atom}entry'))[:limit]:
            title=item.findtext('{http://www.w3.org/2005/Atom}title') or ''
            link=next((x.attrib.get('href','') for x in item.findall('{http://www.w3.org/2005/Atom}link') if x.attrib.get('href')), '')
            description=item.findtext('{http://www.w3.org/2005/Atom}summary') or ''
            parser=PageParser();parser.feed(description)
            out.append({'title':title[:500],'link':link,'text':(title+' '+parser.get_text()).strip()[:20000], 'posted_at':(item.findtext('{http://www.w3.org/2005/Atom}updated') or '').strip()[:80]})
    return out


async def fetch_feed(client,url):
    if urlsplit(url).hostname not in ('localhost','127.0.0.1') and not public_url(url):
        raise ValueError('Приватные адреса RSS запрещены')
    # RSS discovery does not bypass anti-bot or access logged-in content.
    response=await client.get(url,follow_redirects=False)
    if response.status_code>=300:raise ValueError('RSS HTTP '+str(response.status_code))
    if len(response.content)>2_000_000:raise ValueError('RSS превышает лимит')
    return parse_rss(response.content)


def extract_page(url,original,ocr_budget):
    """One public HTML ad + one OG image OCR, best-effort; preserve RSS on failure."""
    if not host_allowed(urlsplit(url).hostname):return original,False,'Индексная выдержка — внешняя страница не запрашивалась'
    try:
        raw,ct,_=fetch_public(url)
        if ct.startswith('image/'):
            if not ocr_budget:return original,False,'OCR лимит на обход'
            return original+'\n'+ocr_image(raw),True,'OCR изображения'
        page=PageParser();page.feed(raw.decode('utf-8',errors='replace'))
        content=(original+'\n'+page.get_text())[:20000]
        img=page.meta.get('og:image') or page.meta.get('twitter:image')
        if img and ocr_budget:
            from urllib.parse import urljoin
            try:
                image,imagetype,_=fetch_public(urljoin(url,img))
                if imagetype.startswith('image/'):
                    content+='\n'+ocr_image(image)[:5000]
                    return content,True,'HTML и OCR OG-изображения'
            except Exception:
                pass
        return content,False,'Публичный HTML объявления'
    except Exception as e:
        return original,False,'HTML недоступен: '+type(e).__name__+'; используется поисковая выдержка'


def risk_category(result):
    """Evidence triage. Never returns legal 'illegal' or official authorization verification."""
    if not result['project']:return 'unresolved_project'
    if result['risk_signal']!='requires_review':return 'context_only'
    if result['status']=='no_recorded_basis':return 'potential_equity_collection_no_basis_in_local_db'
    if result['status']=='documents_require_check':return 'document_claim_requires_official_verification'
    return 'review_required'


def ingest(db:Session, rows, feed, *, retrieve_page=False,max_ocr=4,source_kind='search_index'):
    examined=saved=matched=signals=ocr_count=0
    # A discovered link is recorded once and re-seen safely. Revisions are retained
    # when text changes; no manufactured historic publications.
    for row in rows[:250]:
        url=canonical_url(row.get('link') or row.get('source_url') or '')
        if not url:continue
        text=(row.get('text') or row.get('title') or '').strip()[:20000]
        if len(text)<8:continue
        # Capture housing advertisements even before project identification.
        # Do not archive irrelevant generic content in search-engine feeds.
        if not re.search(r'(?iu)(жк\b|жил(?:ой|ого) комплекс|новострой|квартир|пәтер|застрой|долев|сатылым|үй\b)',text):continue
        examined+=1
        original=text
        ocr_used=False; details='Публичный поисковый индекс / подключённый источник'
        if retrieve_page:
            text,ocr_used,details=extract_page(url,text,ocr_budget=ocr_count<max_ocr)
            if ocr_used:ocr_count+=1
        publisher=(row.get('account') or row.get('publisher') or '').strip()
        record,created=save_ad(db,url=url,text=text,feed=feed,account=publisher,
             posted_at=row.get('posted_at',''),source_kind=source_kind,completion_year=row.get('completion_year'))
        if record is None:continue
        if created:saved+=1
        if record.building_id:matched+=1
        # Keep the legacy scan feed in sync with the consolidated archive.
        old=db.scalar(select(ScanFinding).where(ScanFinding.url==url))
        if old is None:
            result=verify_text(text,db,source_url=url,ocr_used=ocr_used)
            category=risk_category(result)
            old=ScanFinding(url=url,feed=feed[:150],title=(row.get('title') or text[:80])[:500],
                excerpt=text[:20000],project_id=record.building_id,
                project_name=record.organization_label if record.building_id else '',
                assessment=category,confidence=record.attribution_level,
                keywords=', '.join(result['keywords']),document_note=result['explanation'],
                details=details,ocr_used='yes' if ocr_used else 'no')
            db.add(old)
            if result['risk_signal']=='requires_review' and record.building_id:signals+=1
        else:
            old.last_seen=datetime.now(timezone.utc)
            old.confidence=record.attribution_level
            if old.review_status=='pending':
                old.excerpt=text[:20000];old.project_id=record.building_id
                old.project_name=record.organization_label if record.building_id else ''
        if created and feed.startswith('Прямой каталог'):time.sleep(.8)
    db.commit()
    return dict(examined=examined,saved=saved,matched=matched,signals=signals,ocr=ocr_count)


def _ingest_batch(rows, label, source_kind="search_index"):
    with SessionLocal() as db:
        return ingest(db, rows, label, retrieve_page=(source_kind not in ("authorized_api",)), max_ocr=3,source_kind=source_kind)


def start_once():
    with LOCK:
        if STATE['running'] or STATE['scheduled']:return False
        STATE['scheduled']=True
    return True


async def scan_once():
    with LOCK:
        if STATE['running']:return
        STATE.update(scheduled=False,running=True,last_error='',feeds_checked=0,feeds_failed=0,
                     discovered=0,inspected=0,matched=0,signals=0,saved=0,ocr_images=0)
    try:
        sources=source_feeds()
        # Rotation spreads requests for 8 searches over two cycles, avoiding bursts.
        cycle=int(datetime.now(timezone.utc).timestamp()//1800)
        # Generic searches plus alternating named-project groups; all 40 are
        # covered in two consecutive runs without flooding the public index.
        sources=[(label,url) for i,(label,url) in enumerate(sources)
                 if (i<len(SEARCH_QUERIES) and i%2==cycle%2) or (i>=len(SEARCH_QUERIES) and (i-len(SEARCH_QUERIES))%2==cycle%2)]
        async with httpx.AsyncClient(timeout=httpx.Timeout(14,connect=5),trust_env=False,
                headers={'User-Agent':'SAQ-Qurylys/13 (+public-evidence-monitor)','Accept':'text/html,application/rss+xml,application/xml,text/xml'}) as client:
            # Public classified listing pages are scanned independently of RSS
            # so the service can discover posts without a separately installed parser.
            if os.getenv('SAQ_DIRECT_CATALOGS','1').lower() not in ('0','false','no'):
                for label,url in DIRECT_CATALOGS:
                    try:
                        rows=await fetch_catalog(client,url)
                        STATE['feeds_checked']+=1;STATE['discovered']+=len(rows)
                        result=await asyncio.to_thread(_ingest_batch,rows,label)
                        STATE['inspected']+=result['examined'];STATE['saved']+=result['saved']
                        STATE['matched']+=result['matched'];STATE['signals']+=result['signals']
                        STATE['ocr_images']+=result['ocr']
                    except Exception as e:
                        STATE['feeds_failed']+=1
                        STATE['last_error']=(label+': '+str(e))[:240]
                    await asyncio.sleep(1)
            for label,url in sources:
                try:
                    rows=await fetch_feed(client,url)
                    STATE['feeds_checked']+=1;STATE['discovered']+=len(rows)
                    # fetch_public is blocking: offload page/OCR work to a worker thread.
                    result=await asyncio.to_thread(_ingest_batch,rows,label)
                    STATE['inspected']+=result['examined'];STATE['saved']+=result['saved']
                    STATE['matched']+=result['matched'];STATE['signals']+=result['signals']
                    STATE['ocr_images']+=result['ocr']
                except Exception as e:
                    STATE['feeds_failed']+=1
                    STATE['last_error']=(label+': '+str(e))[:240]
                await asyncio.sleep(.4)
        # Officially authorized connector access expands coverage, but only
        # when an operator configured provider tokens. Never bypass login walls.
        from app import connectors
        for label, enabled, fn in (
           ('Instagram Meta Graph — доступные хештеги',bool(os.getenv('SAQ_IG_ACCESS_TOKEN') and os.getenv('SAQ_IG_USER_ID')),connectors.instagram_hashtags),
           ('OLX Partner API — собственные объявления',bool(os.getenv('SAQ_OLX_ACCESS_TOKEN')),connectors.olx_account_ads),
        ):
            if not enabled:continue
            try:
                rows=await asyncio.to_thread(fn)
                STATE['feeds_checked']+=1;STATE['discovered']+=len(rows)
                result=await asyncio.to_thread(_ingest_batch,rows,label,'authorized_api')
                STATE['inspected']+=result['examined'];STATE['saved']+=result['saved']
                STATE['matched']+=result['matched'];STATE['signals']+=result['signals']
            except Exception as e:
                STATE['feeds_failed']+=1
                STATE['last_error']=(label+': '+type(e).__name__)[:240]
        STATE['network_available']=STATE['feeds_checked']>0
    finally:
        STATE['last_run']=datetime.now(timezone.utc).isoformat()
        with LOCK:STATE['running']=False;STATE['scheduled']=False


async def background_schedule():
    """Invoked in app lifespan: no manual upload required while server is running."""
    STATE['enabled']=os.getenv('SAQ_MONITOR_ENABLED','1').casefold() not in ('0','false','no')
    # 30-minute best-effort discovery, not instantaneous platform streaming.
    # Respect robots, provider errors and rate limits.
    legacy=os.getenv('SAQ_MONITOR_HOURS')
    interval=int(os.getenv('SAQ_MONITOR_MINUTES',str(int(legacy)*60 if legacy else 30)))
    STATE['interval_minutes']=min(1440,max(15,interval))
    if not STATE['enabled']:return
    await asyncio.sleep(5)
    while True:
        if os.getenv('SAQ_AUTO_MIO','1').casefold() not in ('0','false','no'):
            # Reconcile official CSV daily. Any fetch failure is visible at /sync-status.
            try:
                from app.registry_deep_v24 import sync_public_mio, LAST_SYNC
                from datetime import timedelta
                last=LAST_SYNC['attempted_at']
                if not last or datetime.now(timezone.utc)-datetime.fromisoformat(last)>=timedelta(hours=24):
                    def _sync():
                        with SessionLocal() as s: return sync_public_mio(s)
                    await asyncio.to_thread(_sync)
            except Exception as e:
                STATE['last_error']='МИО: '+type(e).__name__
        if start_once():
            try:await scan_once()
            except Exception as e:STATE['last_error']='Системная ошибка: '+str(e)[:200]
        await asyncio.sleep(STATE['interval_minutes']*60)


@router.get('/status')
def status(db:Session=Depends(get_db)):
    values=dict(STATE)
    entries=db.scalars(select(ScanFinding)).all()
    values['total_saved']=len(entries)
    values['total_pending']=sum(x.review_status=='pending' for x in entries)
    values['basis_unconfirmed']=sum(x.assessment=='potential_equity_collection_no_basis_in_local_db' for x in entries)
    values['note']='Поиск через открытые RSS-индексы не равен сплошному охвату OLX/Instagram. Отсутствие документа в локальной базе не доказывает его отсутствие в реестре МИО.'
    return values

@router.get('/findings')
def findings(limit:int=100,db:Session=Depends(get_db)):
    limit=min(300,max(1,limit))
    return [{'id':f.id,'url':f.url,'title':f.title,'project_id':f.project_id,
             'project_name':f.project_name,'assessment':f.assessment,'keywords':f.keywords,
             'confidence':f.confidence,'document_note':f.document_note,
             'excerpt':f.excerpt[:1200],'source':f.feed,'details':f.details,
             'ocr_used':f.ocr_used,'last_seen':f.last_seen.isoformat() if f.last_seen else ''}
            for f in db.scalars(select(ScanFinding).order_by(ScanFinding.id.desc()).limit(limit)).all()]

@router.post('/start')
def start(background:BackgroundTasks):
    if start_once():background.add_task(scan_once)
    return dict(STATE)
