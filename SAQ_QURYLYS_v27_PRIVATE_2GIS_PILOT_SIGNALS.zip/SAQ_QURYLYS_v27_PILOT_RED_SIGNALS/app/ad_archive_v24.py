"""Durable, deduplicated evidence log for every *discovered* public housing advert.

No promise of platform-wide coverage and no claim that the publisher is the builder.
Scans update sightings, content revisions are immutable, human reviews survive rescans.
"""
from __future__ import annotations
import json
from datetime import datetime, timezone
from sqlalchemy import Integer, String, Text, DateTime, ForeignKey, UniqueConstraint, select, func
from sqlalchemy.orm import Mapped, mapped_column, Session
from fastapi import APIRouter, Depends, Query
from app.database import Base, get_db
from app.ad_attribution_v24 import canonical_url,platform_of,candidates_for,digest_text
from app.v8_api import RegistryAd
from app.unified_registry import RegistryBuilding
from app.auto_decisions import evaluate_building, decide_ad

router=APIRouter(prefix='/api/v24',tags=['Архив рекламы и атрибуция'])

def utcnow():return datetime.now(timezone.utc)

class PublicAd(Base):
    __tablename__='v24_public_ads'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    url:Mapped[str]=mapped_column(String(1500),unique=True,index=True)
    platform:Mapped[str]=mapped_column(String(35))
    source_label:Mapped[str]=mapped_column(String(180),default='')
    publisher:Mapped[str]=mapped_column(String(200),default='')
    posted_at:Mapped[str]=mapped_column(String(80),default='')
    first_seen:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow)
    last_seen:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow)
    seen_count:Mapped[int]=mapped_column(Integer,default=1)
    content_hash:Mapped[str]=mapped_column(String(64))
    latest_text:Mapped[str]=mapped_column(Text,default='')
    building_id:Mapped[int|None]=mapped_column(ForeignKey('unified_buildings.id'),nullable=True,index=True)
    organization_label:Mapped[str]=mapped_column(String(260),default='')
    organization_bin:Mapped[str]=mapped_column(String(15),default='')
    attribution_level:Mapped[str]=mapped_column(String(45),default='unmatched')
    attribution_reason:Mapped[str]=mapped_column(Text,default='')
    candidates_json:Mapped[str]=mapped_column(Text,default='[]')
    source_kind:Mapped[str]=mapped_column(String(35),default='search_index')

class AdRevision(Base):
    __tablename__='v24_ad_revisions'
    __table_args__=(UniqueConstraint('ad_id','content_hash',name='uq_ad_content_v24'),)
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    ad_id:Mapped[int]=mapped_column(ForeignKey('v24_public_ads.id'),index=True)
    recorded_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow)
    content_hash:Mapped[str]=mapped_column(String(64))
    source_label:Mapped[str]=mapped_column(String(180),default='')
    snapshot:Mapped[str]=mapped_column(Text)


def save_ad(db:Session, *,url:str,text:str,feed:str,account:str='',posted_at:str='',source_kind='search_index',completion_year=None):
    canonical=canonical_url(url)
    if not canonical or not (text or '').strip():return None,False
    from app.ad_verification import verify_text
    attrib=candidates_for(db,text,account=account,source_url=canonical)
    # All meaningful advertisements from enabled source channels are saved,
    # even if the project cannot be identified; no synthetic data on failed fetch.
    now=utcnow();fingerprint=digest_text(text)
    ad=db.scalar(select(PublicAd).where(PublicAd.url==canonical))
    created=ad is None
    if created:
        ad=PublicAd(url=canonical,platform=platform_of(canonical),source_label=feed[:180],
             publisher=account[:200],posted_at=posted_at[:80],content_hash=fingerprint,latest_text=text[:20000])
        db.add(ad);db.flush()
    else:
        ad.last_seen=now;ad.seen_count+=1
        if posted_at and not ad.posted_at:ad.posted_at=posted_at[:80]
        if account and not ad.publisher:ad.publisher=account[:200]
    ad.source_kind=source_kind
    if created or ad.content_hash!=fingerprint:
        ad.content_hash=fingerprint;ad.latest_text=text[:20000]
        if not db.scalar(select(AdRevision).where(AdRevision.ad_id==ad.id,AdRevision.content_hash==fingerprint)):
            db.add(AdRevision(ad_id=ad.id,content_hash=fingerprint,source_label=feed[:180],snapshot=text[:20000]))
    # Only high-confidence project name matches are auto-linked to RegistryAd;
    # medium address/BIN clues go into a queue of suggestions, not legal green.
    ad.attribution_level=attrib['confidence'];ad.attribution_reason=attrib['method']
    ad.candidates_json=json.dumps(attrib['candidates'],ensure_ascii=False)
    ad.organization_label=attrib['related_organization']
    ad.organization_bin=attrib['related_bin']
    ad.building_id=attrib['building_id'] if attrib['confidence']=='high' else None
    registered=db.scalar(select(RegistryAd).where(RegistryAd.url==canonical))
    if registered is None:
        db.add(RegistryAd(building_id=ad.building_id,platform=ad.platform,url=canonical,
                    text=text[:20000],status='pending',account=account[:200]))
    elif registered.status=='pending':
        # Human-reviewed data never overwritten by a newer crawl.
        if registered.building_id is None and ad.building_id is not None:registered.building_id=ad.building_id
        registered.text=text[:20000]
    db.flush()
    if completion_year is not None:
        # Store explicit provider field without reinterpreting a posting date.
        from app.ad_monitor_v25 import AdYearEvidence
        try: parsed_year=int(completion_year)
        except (ValueError,TypeError): parsed_year=0
        if 2000<=parsed_year<=2045:
            evidence=db.get(AdYearEvidence,ad.id)
            if evidence:evidence.completion_year=parsed_year
            else:db.add(AdYearEvidence(ad_id=ad.id,completion_year=parsed_year))
    db.flush()
    return ad,created


def ad_json(db,ad):
    legal={'color':'yellow','label':'Нужна проверка привязки','reason':ad.attribution_reason}
    if ad.building_id and ad.attribution_level=='high':
        b=db.get(RegistryBuilding,ad.building_id)
        if b:
            decision,link=evaluate_building(db,b)
            legal=decide_ad({'building_id':b.id,'text':ad.latest_text},decision,link)
    return {'id':ad.id,'url':ad.url,'platform':ad.platform,'source':ad.source_label,
       'posted_at':ad.posted_at,'publisher':ad.publisher,'first_seen':ad.first_seen.isoformat() if ad.first_seen else '',
       'last_seen':ad.last_seen.isoformat() if ad.last_seen else '', 'seen_count':ad.seen_count,
       'building_id':ad.building_id,'project_name':db.get(RegistryBuilding,ad.building_id).name if ad.building_id else '',
       'organization_related':ad.organization_label,'organization_bin':ad.organization_bin,
       'organization_note':'Юридический участник проекта, не обязательно автор объявления',
       'publisher_identity_confirmed':False,'confidence':ad.attribution_level,'method':ad.attribution_reason,
       'candidates':json.loads(ad.candidates_json or '[]'),'legal_assessment':legal,
       'text':ad.latest_text[:2000], 'source_kind':ad.source_kind}

@router.get('/ads')
def publications(platform:str='',building_id:int|None=None,limit:int=Query(default=200,ge=1,le=1000),db:Session=Depends(get_db)):
    q=select(PublicAd)
    if platform:q=q.where(PublicAd.platform==platform)
    if building_id:q=q.where(PublicAd.building_id==building_id)
    return [ad_json(db,a) for a in db.scalars(q.order_by(PublicAd.last_seen.desc()).limit(limit)).all()]

@router.get('/ads/summary')
def ad_summary(db:Session=Depends(get_db)):
    ads=db.scalars(select(PublicAd)).all()
    return {'total':len(ads),'by_platform':{p:sum(x.platform==p for x in ads) for p in ('olx','krisha','instagram')},
       'matched':sum(x.building_id is not None for x in ads),
       'need_attribution':sum(x.building_id is None for x in ads),
       'note':'Архив содержит лишь действительно обнаруженные записи доступных источников, не все объявления платформ.'}

@router.get('/ads/{ad_id}/history')
def history(ad_id:int,db:Session=Depends(get_db)):
    entries=db.scalars(select(AdRevision).where(AdRevision.ad_id==ad_id).order_by(AdRevision.recorded_at.desc())).all()
    return [{'recorded_at':x.recorded_at.isoformat(),'sha256':x.content_hash,'source':x.source_label,'text':x.snapshot} for x in entries]
