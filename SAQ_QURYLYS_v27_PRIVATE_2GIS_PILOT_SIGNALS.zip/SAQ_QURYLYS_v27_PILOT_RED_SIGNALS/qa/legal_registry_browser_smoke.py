"""Actual API-backed browser smoke test for the new official-document UI.

The browser's map library is replaced by a display-only adapter because a
2GIS network connection cannot be tested in CI. Every registry and drawer
response is from the REAL FastAPI endpoints / curated DB, not invented data.
"""
from __future__ import annotations
import os,sys,tempfile,json,re
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
db=Path(tempfile.gettempdir())/'saq_v22_browser_registry_only.sqlite3'
db.unlink(missing_ok=True)
os.environ['SAQ_DATABASE_URL']='sqlite:///'+str(db)
os.environ['PYTEST_CURRENT_TEST']='1'
from app.main import app
from fastapi.testclient import TestClient

with TestClient(app) as client:
    snap=client.get('/api/signal-map/snapshot').json()
    assert snap['total']==40
    records={x['name']:x for x in snap['items']}
    assert records['ЖК Золотой квадрат']['map_color']=='green'
    assert records['ЖК Престиж']['registry_status']=='guarantee_event'
    assert records['ЖК AINALAIYN']['registry_status']=='reported_only'
    urls=['/api/signal-map/snapshot','/api/v8/catalog','/api/v8/developers','/api/v9/links',
          '/api/v14/geofill/status','/api/registry-linkage/summary']
    fixtures={url:client.get(url).json() for url in urls}
    fixtures['/api/v8/settings']={'mapgl_key':'test-local-map-adapter'}
    fixtures['/api/v14/geofill/start']={'running':False,'scheduled':False,'located':0}
    for name in ('ЖК Золотой квадрат','ЖК ЖАНЫМ','ЖК Diamond','ЖК Престиж'):
        id=records[name]['id'];fixtures[f'/api/workbench/cases/{id}']=client.get(f'/api/workbench/cases/{id}').json()

html=re.sub(r'<script defer src="/static/(?:signal_map|geo_recovery)\.js\?v=\d+"></script>|<link rel="stylesheet" href="/static/signal_map\.css\?v=\d+">','',(ROOT/'app/static/signal_map.html').read_text())
css=(ROOT/'app/static/signal_map.css').read_text()
js=(ROOT/'app/static/signal_map.js').read_text()
bootstrap=r'''(function(){
window.fetch=async function(path,opts={}){
 const p=String(path).split('?')[0], value=window.__fixtures[p];
 return new Response(JSON.stringify(value===undefined?{detail:'Fixture unavailable: '+p}:value),{status:value===undefined?404:200,headers:{'Content-Type':'application/json'}});
};
window.mapgl={Map:class{constructor(id){this.node=document.getElementById(id);this.node.style.background='linear-gradient(130deg,#e4eeec,#f8f8f1)'}resize(){}setCenter(){}setZoom(){}},HtmlMarker:class{constructor(map,o){this.el=document.createElement('div');this.el.innerHTML=o.html;map.node.append(this.el)}destroy(){this.el.remove()}},Polygon:class{on(){}destroy(){}}};
})();'''
art=ROOT/'qa_artifacts';art.mkdir(exist_ok=True)
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('SAQ_CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1500,'height':970})
    errors=[];page.on('pageerror',lambda x:errors.append(str(x)))
    page.goto('about:blank');page.set_content(html,wait_until='domcontentloaded')
    page.add_style_tag(content=css)
    page.evaluate('window.__fixtures = '+json.dumps(fixtures,ensure_ascii=False)+';')
    page.evaluate(bootstrap);page.add_script_tag(content=js)
    page.wait_for_timeout(350)
    assert page.locator('.item-row').count()==40
    # Visible registry must distinguish primary KZhK vs commercial sources.
    page.locator('.sidebar [data-view="registry"]').click()
    page.wait_for_timeout(100)
    assert 'ЖК ↔ застройщики ↔ документы КЖК' in page.locator('#data-workspace').inner_text()
    assert 'Официальная карточка КЖК' in page.locator('#data-workspace').inner_text()
    assert 'гарантийный случай' in page.locator('#data-workspace').inner_text().lower()
    page.screenshot(path=str(art/'QA_V22_LINKED_REGISTRY.png'))
    # Drawer uses real KZhK parties from joined DB.
    gold=records['ЖК Золотой квадрат']['id']
    page.locator(f'#data-workspace [data-case="{gold}"]').first.click()
    page.wait_for_timeout(100)
    detail=page.locator('#drawer-content').inner_text()
    for required in ('Золотой квадрат','970640000190','211140032196','ДПГ-25-16-078/194','Уполномоченная компания','Роль застройщика подтверждена документом КЖК'):
        assert required in detail,required
    assert page.locator('#drawer-content a[href="https://www.homeportal.kz/ru/projects/1141"]').count()>0
    page.screenshot(path=str(art/'QA_V22_OFFICIAL_KZHK_CARD.png'))
    page.locator('#drawer-content .section-title').filter(has_text='05 / КЖК').scroll_into_view_if_needed()
    page.screenshot(path=str(art/'QA_V22_OFFICIAL_DOCUMENT_SECTION.png'))
    page.locator('#close-drawer').click()
    diamond=records['ЖК Diamond']['id']
    page.locator(f'#data-workspace [data-case="{diamond}"]').first.click()
    page.wait_for_timeout(100)
    detail=page.locator('#drawer-content').inner_text()
    assert 'ЖК Престиж' in detail and 'гарантийный случай' in detail.lower()
    assert '060240025805' in detail
    assert 'Официальный PDF-реестр КЖК' in detail
    page.locator('#close-drawer').click()
    assert errors==[],errors
    print('PASS v22 GUI: 40 registry rows, KZhK statuses, official BINs, document links, Diamond/Prestizh alias, no JS errors')
    browser.close()
db.unlink(missing_ok=True)
