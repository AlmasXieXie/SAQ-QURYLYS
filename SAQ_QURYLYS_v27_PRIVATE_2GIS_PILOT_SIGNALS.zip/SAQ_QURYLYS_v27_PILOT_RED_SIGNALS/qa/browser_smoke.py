"""Deterministic visual QA of actual shipped HTML/CSS/JS, NO external map/network.

This test injects a controlled MapGL-compatible DOM adapter. Synthetic positions
and colors are used ONLY in its browser fixture, never written to application DB.
"""
import os,sys,json,copy,tempfile
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(ROOT))
TEST_DB=Path(tempfile.gettempdir())/'saq_v17_browser_sandbox.sqlite3'
TEST_DB.unlink(missing_ok=True)
os.environ['SAQ_DATABASE_URL']='sqlite:///'+str(TEST_DB)
os.environ['PYTEST_CURRENT_TEST']='1'
from app.main import app
from fastapi.testclient import TestClient
CLIENT=TestClient(app)
JS=(ROOT/'app/static/signal_map.js').read_text()
CSS=(ROOT/'app/static/signal_map.css').read_text()
HTML=__import__('re').sub(r'<script defer src="/static/(?:signal_map|geo_recovery)\.js\?v=\d+"></script>|<link rel="stylesheet" href="/static/signal_map\.css\?v=\d+">', '', (ROOT/'app/static/signal_map.html').read_text())
ARTIFACTS=ROOT/'qa_artifacts';ARTIFACTS.mkdir(exist_ok=True)
STUB_JS=r'''(function(){
 const f=window.__fixtures;
 window.fetch=async function(path,opts={}){
  const p=String(path).split('?')[0];let data=f[p];
  if(data===undefined && p.startsWith('/api/workbench/cases/'))data=f.__case;
  if(data===undefined && p==='/api/v14/geofill/start')data={running:false,scheduled:false,located:0};
  if(data===undefined){console.warn('fixture not loaded',p);return new Response(JSON.stringify({detail:'No fixture '+p}),{status:404,headers:{'Content-Type':'application/json'}})}
  return new Response(JSON.stringify(data),{status:200,headers:{'Content-Type':'application/json'}});
 };
 window.mapgl={Map:class{constructor(id,opts){this.node=document.getElementById(id);this.node.style.background='linear-gradient(130deg,#e5edf1,#eff7f4)';this.node.dataset.loaded='true';}resize(){}setCenter(){}setZoom(){}},HtmlMarker:class{constructor(map,options){this.el=document.createElement('div');this.el.innerHTML=options.html;this.el.className='test-html-marker';this.el.style.cssText='position:absolute;z-index:5;left:'+Math.max(4,Math.min(90,(options.coordinates[0]-82.2)/.8*100))+'%;top:'+Math.max(4,Math.min(90,(50.2-options.coordinates[1])/.5*100))+'%';map.node.append(this.el)}getContent(){return this.el}destroy(){this.el.remove()}},Polygon:class{on(){}destroy(){}}};
})();'''

def run_page(browser,snapshot,tag):
 page=browser.new_page(viewport={'width':1460,'height':950})
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 pages={'/api/signal-map/snapshot':snapshot,'/api/v8/settings':{'mapgl_key':'test-bundle-key'},'/api/v8/catalog':CLIENT.get('/api/v8/catalog').json(),'/api/v8/developers':CLIENT.get('/api/v8/developers').json(),'/api/v9/links':CLIENT.get('/api/v9/links').json(),'/api/v14/geofill/status':{'running':False,'scheduled':False,'located':snapshot['mapped'],'last_finished':None},'__case':CLIENT.get('/api/workbench/cases/'+str(snapshot['items'][0]['id'])).json()}
 page.goto('about:blank')
 page.set_content(HTML,wait_until='domcontentloaded')
 page.add_style_tag(content=CSS)
 page.evaluate('window.__fixtures = '+json.dumps(pages,ensure_ascii=False)+';')
 page.evaluate(STUB_JS)
 page.add_script_tag(content=JS)
 page.wait_for_timeout(250)
 shown=page.locator('.signal-pin').count()
 placed=page.locator('.test-html-marker').count()
 inpanel=page.locator('.unlocated-pin').count()
 print(tag,'catalog',len(snapshot['items']),'located',snapshot['mapped'],'visible-markers',placed,'pending-cards-on-map',inpanel,'menu',page.locator('[data-view]').count(),'errors',errors[:3])
 assert placed==snapshot['mapped'],f'Expected {snapshot["mapped"]} geographic markers, got {placed}'
 assert page.locator('.signal-pin.gray').count()==0,'Gray geographic buttons are not allowed in three-color map'
 assert sum(page.locator('.test-html-marker .signal-pin.'+color).count() for color in ('red','yellow','green'))==placed, 'Every geographic marker must use exactly one signal color'
 assert page.locator('#map-workspace [data-filter="gray"]').count()==0,'Fourth color filter should not be present'
 assert page.locator('.map-legend .dot').count()==3,'Legend must describe exactly three statuses'
 if placed==40:
  assert all(page.locator('.test-html-marker .signal-pin.'+color).count()>0 for color in ('red','yellow','green')), 'Test fixture must demonstrate three distinct marker styles'

 assert inpanel==snapshot['without_coordinates'],f'Expected {snapshot["without_coordinates"]} missing-coordinate tiles, got {inpanel}'
 assert page.locator('#map-diagnostic').is_visible()
 assert len(errors)==0
 page.screenshot(path=str(ARTIFACTS/f'{tag}.png'),full_page=False)
 if placed:
  page.locator('.test-html-marker [data-pin]').first.click(force=True)
 else:
  page.locator('.unlocated-pin').first.click(force=True)
 page.wait_for_timeout(100)
 assert page.locator('#detail-drawer').is_visible()
 assert page.locator('#drawer-content h2').count()>0
 print(tag,'CLICK opens',page.locator('#drawer-content h2').first.inner_text())
 page.locator('#close-drawer').click()
 for tab in ('review','ads','signals','registry','developers','ocr','sources','training','map'):
  page.locator('.sidebar [data-view="'+tab+'"]').first.click(force=True)
  assert page.locator('.sidebar [data-view="'+tab+'"].active').count()==1,tab
 assert not errors,errors
 print(tag,'menu navigation 9/9 PASS')
 page.close()

snap=CLIENT.get('/api/signal-map/snapshot').json()
assert snap['total']==40
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,**({'executable_path':os.getenv('SAQ_CHROMIUM_PATH')} if os.getenv('SAQ_CHROMIUM_PATH') else {}),args=['--no-sandbox','--disable-dev-shm-usage'])
 run_page(browser,copy.deepcopy(snap),'QA_ZERO_REAL_COORDINATES')
 case=copy.deepcopy(snap)
 for i,row in enumerate(case['items'][:25]):
  row['latitude']=49.84 + (i%5)*.039
  row['longitude']=82.36+(i//5)*.079
  row['has_coordinates']=True
  row['map_color']=('red','yellow','green')[i%3]
 case['mapped']=25;case['without_coordinates']=15
 run_page(browser,case,'QA_25_SYNTHETIC_COORDINATES')
 full=copy.deepcopy(snap)
 for i,row in enumerate(full['items']):
  row['latitude']=49.75+(i%8)*.051
  row['longitude']=82.32+(i//8)*.112
  row['has_coordinates']=True
  row['map_color']=('red','yellow','green')[i%3]
 full['mapped']=40;full['without_coordinates']=0
 run_page(browser,full,'QA_40_SYNTHETIC_COORDINATES')
 browser.close()
print('PASS ALL VISUAL BROWSER CHECKS; SYNTHETIC COORDINATES NEVER EXPORTED')
TEST_DB.unlink(missing_ok=True)
